
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'database.json');

const APP_INFO = {
  shortName: 'OMS',
  appName: 'Organization Management ERP',
  version: 'V5.21',
  vendor: 'CSC Digital Yoddha',
  subtitle: 'Management ERP'
};

const PUBLIC_ORG_DEFAULTS = {
  name: 'CSC Digital Yoddha',
  officeAddress: 'Panskura, Purba Medinipur',
  phone: '8001300092, 8900255364, 9734673867, 9733114561',
  email: '',
  areaOfOperation: 'Panskura'
};

const DONATION_PURPOSES = [
  'General Fund',
  'Social Work',
  'Medical Assistance',
  'Education',
  'Disaster Relief',
  'Event',
  'Infrastructure',
  'Emergency Fund'
];

const INCOME_CATEGORIES = [
  'Joining Fee',
  'Monthly Subscription',
  'Annual Subscription',
  'Donation',
  'Event Collection',
  'Sponsorship',
  'Bank Interest',
  'Permitted Loan Charge / Interest',
  'Special Contribution',
  'Other Legal Income'
];

const EXPENSE_CATEGORIES = [
  'Office Expense',
  'Printing & Stationery',
  'Meeting Expense',
  'Event Expense',
  'Social Work',
  'Travel',
  'Food',
  'Rent',
  'Electricity',
  'Internet',
  'Bank Charges',
  'Member Welfare',
  'Emergency Assistance',
  'Legal/Professional Expense',
  'Other Approved Expense'
];

const SOCIAL_WORK_TYPES = [
  'Blood Donation',
  'Health Camp',
  'Food Distribution',
  'Clothes Distribution',
  'Educational Support',
  'Disaster Relief',
  'Tree Plantation',
  'Awareness Camp',
  'Other Social Work'
];

const ASSET_CATEGORIES = [
  'Computer',
  'Printer',
  'Furniture',
  'Sound System',
  'Projector',
  'Tent',
  'Vehicle',
  'Land / Building',
  'Electrical / Electronic Equipment',
  'Office Equipment',
  'Other Asset'
];

const ASSET_CONDITIONS = ['New','Excellent','Good','Fair','Poor','Damaged'];
const ASSET_STATUSES = ['In Use','Stored','Under Repair','Disposed','Lost'];

const COMMITTEE_DESIGNATIONS = [
  'President',
  'Vice President',
  'Secretary',
  'Joint Secretary',
  'Treasurer',
  'Executive Member',
  'General Member',
  'Other'
];

const RESOLUTION_CATEGORIES = [
  'Loan Approval',
  'Major Expense Approval',
  'Asset Purchase Approval',
  'Fund Allocation Change',
  'General Resolution',
  'Other'
];

const VOTING_RESULTS = ['Passed','Unanimous','Rejected','Tied','Not Voted'];

const APPROVAL_CONTEXTS = {
  Expense:'Expense',
  EventExpense:'Event Expense',
  SocialWorkExpense:'Social Work Expense',
  WelfarePayment:'Welfare Payment',
  AssetPurchase:'Asset Purchase',
  LoanSanction:'Loan Sanction'
};

const DEFAULT_APPROVAL_POLICY = {
  enabled:false,
  policyName:'Financial Approval Policy',
  effectiveDate:'',
  revision:1,
  modules:{
    Expense:true,
    EventExpense:true,
    SocialWorkExpense:true,
    WelfarePayment:true,
    AssetPurchase:true,
    LoanSanction:true
  },
  rules:[
    {id:'APR-RULE-001',upTo:2000,designations:['Treasurer'],requireResolution:false},
    {id:'APR-RULE-002',upTo:10000,designations:['Treasurer','Secretary'],requireResolution:false},
    {id:'APR-RULE-003',upTo:null,designations:[],requireResolution:true}
  ],
  updatedAt:'',
  updatedBy:''
};

const USER_ROLES = ['Super Admin','President','Secretary','Treasurer','Committee Member','General Member'];
const DEFAULT_USER_PASSWORD = 'cscvle';

const ROLE_PAGE_ACCESS = {
  'Super Admin':['dashboard','master','applications','members','committee','meetings','approvals','subscriptions','donations','income','expense','cashbank','accountingledger','collections','accounts','welfare','loans','funds','events','notices','documents','certificates','reminders','grievances','elections','vendors','budgetcontrol','annualaudit','socialwork','assets','reports','security','settings'],
  'President':['dashboard','master','applications','members','committee','meetings','approvals','subscriptions','donations','income','expense','cashbank','accountingledger','collections','accounts','welfare','loans','funds','events','notices','documents','certificates','reminders','grievances','elections','vendors','budgetcontrol','annualaudit','socialwork','assets','reports'],
  'Secretary':['master','applications','members','committee','meetings','events','notices','documents','certificates','reminders','grievances','elections','vendors','annualaudit','socialwork','assets'],
  'Treasurer':['dashboard','master','members','meetings','approvals','subscriptions','donations','income','expense','cashbank','accountingledger','collections','accounts','welfare','loans','funds','events','notices','documents','reminders','grievances','vendors','budgetcontrol','annualaudit','socialwork','reports'],
  'Committee Member':['master','members','committee','meetings','approvals','welfare','loans','events','notices','documents','grievances','elections','annualaudit','socialwork','assets'],
  'General Member':['memberportal']
};

const ROLE_DESCRIPTIONS = {
  'Super Admin':'Full control including users, security, settings, backup and all modules.',
  'President':'View across the organization with approval workflow authority; no routine financial data entry.',
  'Secretary':'Member, joining, committee, event, social-work and meeting administration.',
  'Treasurer':'Subscription, donation, income, expense, cash/bank, accounting and payment execution.',
  'Committee Member':'Limited organizational view with permitted approval workflow actions.',
  'General Member':'Own profile, membership status, subscription/due, donation, receipt, welfare/loan, event and published notice view only.'
};

const DOCUMENT_CATEGORIES = ['Governance','Registration','Member KYC','Finance','Tax / Statutory','Meeting / Resolution','Event','Social Work','Asset','Audit','Agreement / Vendor','Other'];
const DOCUMENT_AUDIENCES = ['Internal','Committee','All Members','Specific Member'];
const CERTIFICATE_TYPES = ['Member ID Card','Membership Certificate','Event Participation Certificate','Appreciation Certificate','General Certificate'];
const REMINDER_TYPES = ['Member Due','Payment','Event','General'];
const REMINDER_CHANNELS = ['SMS','WhatsApp','Both'];
const GRIEVANCE_CATEGORIES = ['Membership','Payment / Receipt','Subscription / Due','Welfare','Loan / Assistance','Event','Conduct / Discipline','Service','Other'];
const GRIEVANCE_STATUSES = ['Open','In Review','Resolved','Rejected'];
const ELECTION_STATUSES = ['Draft','Nomination Open','Voting Open','Closed','Published'];
const VENDOR_CATEGORIES = ['Printing / Stationery','Catering','Venue / Tent','Sound / Light','Transport','IT / Technical','Professional Service','Construction / Repair','General Supplier','Other'];
const VENDOR_STATUSES = ['Active','Inactive','Blacklisted'];
const BUDGET_TYPES = ['Expense','Income'];
const AUDIT_STATUSES = ['Planned','In Progress','Completed'];

const DEFAULT_FUND_ALLOCATION = [
  {name:'General / Operating Fund', percent:25},
  {name:'Emergency Reserve', percent:20},
  {name:'Member Welfare', percent:15},
  {name:'Member Financial Assistance / Loan Fund', percent:15},
  {name:'Social Work', percent:10},
  {name:'Event & Development', percent:10},
  {name:'Contingency Reserve', percent:5}
];

const WELFARE_TYPES = [
  'Medical Emergency',
  'Accident Assistance',
  'Death Assistance',
  'Family Emergency',
  'Education Assistance',
  'Natural Disaster Assistance',
  'Business Emergency Support'
];

for (const dir of [DATA_DIR, UPLOAD_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, {recursive:true});
}

function financialYear(dateStr){
  const d = dateStr ? new Date(String(dateStr).slice(0,10) + 'T00:00:00') : new Date();
  if (Number.isNaN(d.getTime())) return financialYear();
  const y = d.getFullYear(), m = d.getMonth() + 1;
  const start = m >= 4 ? y : y - 1;
  return `${start}-${String(start + 1).slice(-2)}`;
}
function publicTodayIndia(){
  const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
  const get=t=>parts.find(x=>x.type===t)?.value||'';
  return `${get('year')}-${get('month')}-${get('day')}`;
}
function defaultProfile(){
  return {
    registrationNo:'', establishmentDate:'', pan:'', tan:'',
    registeredAddress:'', officeAddress:'', phone:'',
    bankName:'', accountName:'', accountNumber:'', ifsc:'', branch:'',
    upiId:'', objective:'', areaOfOperation:'',
    committeeTermStart:'', committeeTermEnd:'',
    constitutionText:'', logoPath:'', documents:[], loginSlides:[], publicHomeSlides:[],
    whatsappOtp:{
      enabled:false,
      apiVersion:'v26.0',
      phoneNumberId:'',
      accessTokenEnc:'',
      templateName:'authentication_code_copy_code_button',
      templateLanguage:'en_US',
      defaultCountryCode:'91',
      expiryMinutes:10,
      resendSeconds:60,
      maxAttempts:5
    },
    joiningFee:500, monthlyFee:200, annualFee:0, specialContributionDefault:0
  };
}
const seed = {
  setup: null, sessions: {}, users: [], membershipApplications: [], members: [], collections: [], transactions: [],
  loans: [], loanRepayments: [], loanSettings: {}, memberBenefits: [], welfareApplications: [], welfarePayments: [],
  funds: [], events: [], notices: [], documentLibrary: [], issuedDocuments: [], reminders: [], grievances: [], elections: [], vendors: [], budgetPlans: [], annualAudits: [], socialProjects: [], assets: [], committees: [], meetings: [], approvalPolicy: {}, fundTransfers: [], cashBankSettings: {}, audit: []
};

function migrate(db){
  db.sessions ||= {};
  db.users ||= [];
  if(db.setup && db.users.length===0 && db.setup.email && db.setup.passwordHash && db.setup.salt){
    db.users.push({
      id:'USR-000001',name:db.setup.ownerName||'Administrator',email:String(db.setup.email).toLowerCase(),
      passwordHash:db.setup.passwordHash,salt:db.setup.salt,role:'Super Admin',memberId:'',whatsapp:'',
      status:'Active',createdAt:db.setup.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),lastLoginAt:''
    });
  }
  for(const u of db.users){
    u.name ||= u.ownerName || 'User';
    u.email=String(u.email||'').trim().toLowerCase();
    u.role=USER_ROLES.includes(u.role)?u.role:'General Member';
    u.memberId ||= '';
    u.whatsapp=String(u.whatsapp||'').trim();
    if(!u.salt && u.passwordSalt) u.salt=u.passwordSalt;
    u.mustChangePassword=!!u.mustChangePassword;
    u.status ||= 'Active';
    u.createdAt ||= new Date().toISOString();
    u.updatedAt ||= u.createdAt;
    u.lastLoginAt ||= '';
  }
  db.membershipApplications ||= [];
  db.members ||= []; db.collections ||= []; db.transactions ||= [];
  db.loans ||= []; db.loanRepayments ||= []; db.loanSettings ||= {}; db.memberBenefits ||= [];
  db.welfareApplications ||= []; db.welfarePayments ||= []; db.events ||= []; db.notices ||= [];
  db.documentLibrary ||= []; db.issuedDocuments ||= []; db.reminders ||= []; db.grievances ||= []; db.elections ||= []; db.vendors ||= []; db.budgetPlans ||= []; db.annualAudits ||= [];
  db.socialProjects ||= []; db.assets ||= []; db.committees ||= []; db.meetings ||= [];
  db.approvalPolicy ||= {};
  db.approvalPolicy={
    ...DEFAULT_APPROVAL_POLICY,
    ...db.approvalPolicy,
    modules:{...DEFAULT_APPROVAL_POLICY.modules,...(db.approvalPolicy.modules||{})},
    rules:Array.isArray(db.approvalPolicy.rules)&&db.approvalPolicy.rules.length
      ? db.approvalPolicy.rules
      : DEFAULT_APPROVAL_POLICY.rules.map(x=>({...x,designations:[...x.designations]}))
  };
  db.fundTransfers ||= []; db.cashBankSettings ||= {}; db.audit ||= [];
  if(db.setup){
    db.setup.loginSlides ||= [];
    db.setup.publicHomeSlides ||= [];
    db.setup.documents ||= [];
    db.setup.whatsappOtp={
      enabled:false,
      apiVersion:'v26.0',
      phoneNumberId:'',
      accessTokenEnc:'',
      templateName:'authentication_code_copy_code_button',
      templateLanguage:'en_US',
      defaultCountryCode:'91',
      expiryMinutes:10,
      resendSeconds:60,
      maxAttempts:5,
      ...(db.setup.whatsappOtp||{})
    };
    for(const s of db.setup.loginSlides){
      s.id ||= uid('SLD');
      s.title ||= 'Organization Management ERP';
      s.caption ||= 'Secure access for members, accounts, approvals and programs.';
      s.path ||= '';
      s.originalName ||= '';
      s.size=Number(s.size||0);
      s.sortOrder=Number(s.sortOrder||0);
      s.createdAt ||= new Date().toISOString();
      s.updatedAt ||= s.createdAt;
    }
    for(const s of db.setup.publicHomeSlides){
      s.id ||= uid('PUBSLD');
      s.title ||= 'CSC VLE Network';
      s.caption ||= 'Connecting citizens with trusted CSC services and local VLE centres.';
      s.path ||= '';
      s.originalName ||= '';
      s.size=Number(s.size||0);
      s.sortOrder=Number(s.sortOrder||0);
      s.createdAt ||= new Date().toISOString();
      s.updatedAt ||= s.createdAt;
    }
  }
  for(const m of db.members||[]){
    m.nominees ||= [];
    m.cscCentreName ||= '';
    m.cscId ||= '';
    m.cscCentreAddress ||= '';
    m.cscArea ||= '';
    m.cscBlock ||= '';
    m.cscDistrict ||= '';
    m.cscState ||= '';
    m.cscPin ||= '';
    m.cscPhone ||= '';
    m.cscEmail ||= '';
    m.cscLandmark ||= '';
    m.cscServices ||= '';
    m.publicCscVisible=!!m.publicCscVisible;
  }
  for(const e of db.events||[]){
    e.registrationOpen=!!e.registrationOpen;
    e.registrationDeadline ||= '';
    e.capacity=Number(e.capacity||0);
    e.registrations ||= [];
  }
  for(const d of db.documentLibrary||[]){
    d.title ||= d.name || 'Document'; d.category ||= 'Other'; d.documentNo ||= ''; d.date ||= d.createdAt?.slice(0,10)||''; d.expiryDate ||= '';
    d.audience ||= 'Internal'; d.memberId ||= ''; d.version ||= '1.0'; d.description ||= ''; d.path ||= ''; d.originalName ||= ''; d.size=Number(d.size||0);
    d.status ||= 'Active'; d.financialYear ||= financialYear(d.date||d.createdAt); d.createdBy ||= ''; d.createdAt ||= new Date().toISOString(); d.updatedAt ||= d.createdAt;
  }
  for(const c of db.issuedDocuments||[]){
    c.type ||= 'General Certificate'; c.memberId ||= ''; c.eventId ||= ''; c.title ||= c.type; c.issueDate ||= c.createdAt?.slice(0,10)||''; c.certificateNo ||= c.id||'';
    c.notes ||= ''; c.financialYear ||= financialYear(c.issueDate||c.createdAt); c.issuedBy ||= ''; c.createdAt ||= new Date().toISOString();
  }
  for(const r of db.reminders||[]){
    r.type ||= 'General'; r.memberId ||= ''; r.eventId ||= ''; r.channel ||= 'WhatsApp'; r.message ||= ''; r.phone ||= ''; r.dueAmount=moneyNum(r.dueAmount||0);
    r.status ||= 'Pending'; r.scheduledDate ||= r.createdAt?.slice(0,10)||''; r.sentAt ||= ''; r.financialYear ||= financialYear(r.scheduledDate||r.createdAt); r.createdAt ||= new Date().toISOString();
  }
  for(const g of db.grievances||[]){
    g.memberId ||= ''; g.memberName ||= ''; g.category ||= 'Other'; g.subject ||= 'Grievance'; g.description ||= ''; g.priority ||= 'Normal'; g.status ||= 'Open';
    g.assignedTo ||= ''; g.response ||= ''; g.resolution ||= ''; g.attachmentPath ||= ''; g.attachmentOriginalName ||= ''; g.financialYear ||= financialYear(g.createdAt); g.createdAt ||= new Date().toISOString(); g.updatedAt ||= g.createdAt; g.closedAt ||= '';
  }
  for(const e of db.elections||[]){
    e.title ||= 'Election'; e.electionDate ||= ''; e.nominationStart ||= ''; e.nominationEnd ||= ''; e.votingStart ||= ''; e.votingEnd ||= ''; e.status ||= 'Draft'; e.notes ||= '';
    e.financialYear ||= financialYear(e.electionDate||e.createdAt); e.positions ||= []; e.createdAt ||= new Date().toISOString(); e.updatedAt ||= e.createdAt;
    for(const p of e.positions||[]){ p.name ||= 'Position'; p.seats=Number(p.seats||1); p.candidates ||= []; p.voterIds ||= []; for(const c of p.candidates){ c.memberId ||= ''; c.memberName ||= ''; c.manifesto ||= ''; c.status ||= 'Approved'; c.votes=Number(c.votes||0); } }
  }
  for(const v of db.vendors||[]){
    v.name ||= 'Vendor'; v.category ||= 'Other'; v.contactPerson ||= ''; v.phone ||= ''; v.email ||= ''; v.address ||= ''; v.gstin ||= ''; v.pan ||= ''; v.bankName ||= ''; v.accountNumber ||= ''; v.ifsc ||= ''; v.upiId ||= ''; v.status ||= 'Active'; v.rating=Number(v.rating||0); v.notes ||= ''; v.createdAt ||= new Date().toISOString(); v.updatedAt ||= v.createdAt;
  }
  for(const b of db.budgetPlans||[]){ b.type ||= 'Expense'; b.category ||= ''; b.amount=moneyNum(b.amount||0); b.notes ||= ''; b.financialYear ||= financialYear(); b.createdAt ||= new Date().toISOString(); b.updatedAt ||= b.createdAt; }
  for(const a of db.annualAudits||[]){
    a.financialYear ||= financialYear(); a.auditor ||= ''; a.firm ||= ''; a.periodStart ||= ''; a.periodEnd ||= ''; a.status ||= 'Planned'; a.reportDate ||= ''; a.observations ||= ''; a.findings ||= ''; a.recommendations ||= ''; a.reportPath ||= ''; a.reportOriginalName ||= ''; a.financialSnapshot ||= null; a.createdAt ||= new Date().toISOString(); a.updatedAt ||= a.createdAt;
  }
  for(const n of db.notices){
    n.noticeNo ||= n.id || '';
    n.title ||= 'Notice';
    n.date ||= n.publishFrom || n.createdAt?.slice(0,10) || '';
    n.publishFrom ||= n.date || '';
    n.publishUntil ||= '';
    n.priority ||= 'Normal';
    n.audience ||= 'All Members';
    n.memberId ||= '';
    n.status ||= 'Draft';
    n.body ||= '';
    n.attachmentPath ||= '';
    n.attachmentOriginalName ||= '';
    n.financialYear ||= financialYear(n.date||n.createdAt);
    n.createdBy ||= '';
    n.createdAt ||= new Date().toISOString();
    n.updatedAt ||= n.createdAt;
  }
  for(const m of db.meetings){
    m.meetingNo ||= m.id || '';
    m.date ||= '';
    m.title ||= 'Organization Meeting';
    m.agenda ||= '';
    m.discussion ||= '';
    m.decisions ||= '';
    m.approvedBy ||= '';
    m.status ||= 'Draft';
    m.committeeId ||= '';
    m.committeeName ||= '';
    m.attendees ||= [];
    m.resolutions ||= [];
    m.documents ||= [];
    m.notes ||= '';
    m.financialYear ||= financialYear(m.date||m.createdAt);
    m.finalizedAt ||= '';
    m.finalizedBy ||= '';
    m.createdAt ||= new Date().toISOString();
    m.updatedAt ||= m.createdAt;
    for(const a of m.attendees){
      a.memberId ||= '';
      a.memberName ||= a.name || '';
      a.memberMobile ||= '';
      a.role ||= 'Present Member';
      a.notes ||= '';
    }
    for(const r of m.resolutions){
      r.resolutionNo ||= r.id || '';
      r.category ||= 'General Resolution';
      r.title ||= 'Resolution';
      r.decision ||= '';
      r.votesFor=Number(r.votesFor||0);
      r.votesAgainst=Number(r.votesAgainst||0);
      r.abstain=Number(r.abstain||0);
      r.votingResult ||= 'Not Voted';
      r.approvedBy ||= '';
      r.notes ||= '';
      r.createdAt ||= m.createdAt;
    }
  }
  for(const c of db.committees){
    c.name ||= c.termLabel ? `Committee ${c.termLabel}` : 'Organization Committee';
    c.formationDate ||= c.termStart || '';
    c.termLabel ||= '';
    c.termStart ||= '';
    c.termEnd ||= '';
    c.status ||= 'Archived';
    c.members ||= [];
    c.notes ||= '';
    c.history ||= [];
    c.archivedAt ||= '';
    c.archivedBy ||= '';
    c.archiveReason ||= '';
    c.createdAt ||= new Date().toISOString();
    c.updatedAt ||= c.createdAt;
    for(const m of c.members){
      m.memberId ||= '';
      m.memberName ||= m.name || '';
      m.memberMobile ||= '';
      m.designation ||= 'General Member';
      m.startDate ||= c.termStart || '';
      m.endDate ||= '';
      m.roleStatus ||= m.endDate ? 'Ended' : 'Active';
      m.notes ||= '';
      m.endedAt ||= '';
      m.endReason ||= '';
    }
  }
  for(const t of db.transactions||[]) t.approvalSnapshot ||= null;
  for(const w of db.welfarePayments||[]){
    w.approvalSnapshot ||= null;
    w.resolutionId ||= ''; w.resolutionNo ||= ''; w.resolutionTitle ||= '';
  }
  for(const a of db.assets){
    a.assetName ||= a.name || 'Asset';
    a.category ||= 'Other Asset';
    a.purchaseDate ||= '';
    a.purchaseValue=moneyNum(a.purchaseValue||0);
    a.vendor ||= '';
    a.assetDetails ||= '';
    a.billPath ||= '';
    a.billOriginalName ||= '';
    a.currentLocation ||= '';
    a.custodianMemberId ||= '';
    a.custodianName ||= '';
    a.condition ||= 'Good';
    a.status ||= 'In Use';
    a.notes ||= '';
    a.resolutionId ||= '';
    a.resolutionNo ||= '';
    a.resolutionTitle ||= '';
    a.approvalSnapshot ||= null;
    a.createdAt ||= new Date().toISOString();
    a.updatedAt ||= a.createdAt;
  }
  for(const p of db.socialProjects){
    p.projectName ||= p.name || p.socialWorkType || 'Social Work Project';
    p.socialWorkType ||= 'Other Social Work';
    p.date ||= p.startDate || '';
    p.location ||= '';
    p.budget=moneyNum(p.budget||0);
    p.beneficiaryCount=Number(p.beneficiaryCount||0);
    p.status ||= 'Planned';
    p.description ||= '';
    p.responsibleMembers ||= [];
    p.documents ||= [];
    p.financialYear ||= financialYear(p.date||p.createdAt);
    p.createdAt ||= new Date().toISOString();
  }
  for(const e of db.events){
    e.budget=moneyNum(e.budget||0);
    e.status ||= 'Planned';
    e.startDate ||= e.date || '';
    e.endDate ||= e.startDate || '';
    e.venue ||= e.location || '';
    e.description ||= e.notes || '';
    e.participants ||= [];
    e.vendors ||= [];
    e.documents ||= [];
    e.createdAt ||= new Date().toISOString();
  }
  for(const u of db.users||[]){
    if(!u.whatsapp && u.memberId){
      const m=(db.members||[]).find(x=>x.id===u.memberId);
      if(m)u.whatsapp=String(m.whatsapp||m.cscPhone||m.phone||'').trim();
    }
  }
  db.funds ||= [];
  if (db.setup) {
    const p = defaultProfile();
    for (const [k,v] of Object.entries(p)) if (db.setup[k] === undefined) db.setup[k] = v;
    db.setup.documents ||= [];
    if(db.setup.joiningFee===undefined) db.setup.joiningFee=500;
    if(db.setup.monthlyFee===undefined) db.setup.monthlyFee=200;
    if(db.setup.annualFee===undefined) db.setup.annualFee=0;
    if(db.setup.specialContributionDefault===undefined) db.setup.specialContributionDefault=0;
  }
  for (const a of db.membershipApplications) {
    a.status ||= 'Pending';
    a.history ||= [];
    a.photoPath ||= '';
    a.identityProofPath ||= '';
    a.identityProofOriginalName ||= '';
    a.gender ||= '';
    a.whatsapp ||= '';
    a.permanentVillage ||= ''; a.permanentPostOffice ||= ''; a.permanentPoliceStation ||= '';
    a.permanentGpWard ||= ''; a.permanentBlockMunicipality ||= ''; a.permanentDistrict ||= '';
    a.permanentState ||= ''; a.permanentPin ||= ''; a.permanentAddressLine ||= a.address||'';
    a.cscId ||= ''; a.cscCentreName ||= ''; a.sameAsPermanentAddress=!!a.sameAsPermanentAddress;
    a.centreVillage ||= ''; a.centrePostOffice ||= ''; a.centrePoliceStation ||= '';
    a.centreGpWard ||= ''; a.centreBlockMunicipality ||= ''; a.centreDistrict ||= '';
    a.centreState ||= ''; a.centrePin ||= ''; a.centreAddressLine ||= ''; a.centreAddress ||= '';
    a.aadhaarNumber ||= ''; a.aadhaarPath ||= ''; a.aadhaarOriginalName ||= '';
    a.panNumber ||= ''; a.panPath ||= ''; a.panOriginalName ||= '';
    a.voterNumber ||= ''; a.voterPath ||= ''; a.voterOriginalName ||= '';
    a.nomineeWhatsapp ||= ''; a.nomineeAddress ||= '';
    a.reasonForJoining ||= '';
    a.source ||= '';
    a.rejectionReason ||= '';
    a.verificationNotes ||= '';
    a.committeeNotes ||= '';
    a.joiningFee = moneyNum(a.joiningFee || db.setup?.joiningFee || 500);
    a.memberId ||= '';
    a.declaration = !!a.declaration;
  }
  const loanDefaults={
    facilityEnabled:false,
    complianceConfirmed:false,
    complianceNote:'',
    minMembershipMonths:12,
    requireSubscriptionClear:true,
    requireActiveMember:true,
    requireNoOverdueLoan:true,
    requireCommitteeApproval:true,
    guarantorRequired:false,
    permittedChargeEnabled:false,
    permittedChargeComplianceConfirmed:false,
    permittedChargeNote:'',
    defaultChargeRate:0
  };
  db.loanSettings={...loanDefaults,...(db.loanSettings||{})};

  for (const l of db.loans) {
    if(l.status==='Pending') l.status='Applied';
    if(l.status==='Active') l.status='Repayment';
    l.applicationDate ||= l.date || new Date().toISOString().slice(0,10);
    l.date ||= l.applicationDate;
    l.financialYear ||= financialYear(l.applicationDate);
    l.requestedAmount=moneyNum(l.requestedAmount || l.amount || 0);
    l.sanctionedAmount=moneyNum(l.sanctionedAmount || (['Sanctioned','Disbursed','Repayment','Closed'].includes(l.status)?l.amount:0));
    l.disbursedAmount=moneyNum(l.disbursedAmount || (['Disbursed','Repayment','Closed'].includes(l.status)?l.amount:0));
    l.amount=moneyNum(l.disbursedAmount || l.sanctionedAmount || l.requestedAmount);
    l.repaid=moneyNum(l.repaid||0);
    l.repaymentPeriod=Number(l.repaymentPeriod||12);
    l.guarantorName ||= '';
    l.guarantorPhone ||= '';
    l.guarantorMemberId ||= '';
    l.documents ||= [];
    l.history ||= [];
    l.verificationNotes ||= '';
    l.verifiedBy ||= '';
    l.committeeNotes ||= '';
    l.approvedBy ||= '';
    l.sanctionDate ||= '';
    l.disbursementDate ||= '';
    l.disbursementMode ||= '';
    l.disbursementReference ||= '';
    l.maturityDate ||= '';
    l.rejectionReason ||= '';
    l.eligibilitySnapshot ||= null;
    l.resolutionId ||= '';
    l.resolutionNo ||= '';
    l.resolutionTitle ||= '';
    l.approvalSnapshot ||= null;
    l.chargeRate=moneyNum(l.chargeRate||0);
    l.chargeAmount=moneyNum(l.chargeAmount||0);
    const legacyPrincipal=moneyNum(l.disbursedAmount||0);
    l.totalRepayable=moneyNum(l.totalRepayable || legacyPrincipal + l.chargeAmount);
    l.totalPaid=moneyNum(l.totalPaid || (db.loanRepayments||[]).filter(r=>r.loanId===l.id).reduce((s,r)=>s+moneyNum(r.amount),0) || l.repaid || 0);
    l.principalRepaid=moneyNum(l.principalRepaid || Math.min(legacyPrincipal,l.repaid||l.totalPaid||0));
    l.chargeRepaid=moneyNum(l.chargeRepaid || Math.max(0,l.totalPaid-l.principalRepaid));
    l.repaid=l.principalRepaid;
    l.firstInstallmentDate ||= l.disbursementDate ? addMonthsToDate(l.disbursementDate,1) : '';
    l.installmentAmount=moneyNum(l.installmentAmount || (l.repaymentPeriod>0 ? l.totalRepayable/l.repaymentPeriod : 0));
  }
  for (const r of db.loanRepayments) {
    r.financialYear ||= financialYear(r.date);
    r.mode ||= 'Cash';
    r.reference ||= '';
    r.remarks ||= '';
    r.principalComponent=moneyNum(r.principalComponent||r.amount||0);
    r.chargeComponent=moneyNum(r.chargeComponent||0);
  }

  for (const w of db.welfareApplications) {
    w.status ||= 'Pending';
    w.documents ||= [];
    w.history ||= [];
    w.verificationNotes ||= '';
    w.verificationBy ||= '';
    w.committeeNotes ||= '';
    w.approvedBy ||= '';
    w.approvedAmount=moneyNum(w.approvedAmount||0);
    w.rejectionReason ||= '';
    w.paidAmount=moneyNum(w.paidAmount||0);
    w.financialYear ||= financialYear(w.applicationDate||w.createdAt);
  }
  for (const p of db.welfarePayments) {
    p.financialYear ||= financialYear(p.date);
  }
  for (const m of db.members) {
    m.fatherSpouse ||= '';
    m.dob ||= '';
    m.membershipType ||= 'General';
    m.designation ||= 'Member';
    m.emergencyName ||= '';
    m.emergencyPhone ||= '';
    m.emergencyRelation ||= '';
    m.photoPath ||= '';
    m.status ||= 'Active';
    m.monthlyFee = moneyNum(m.monthlyFee || db.setup?.monthlyFee || 0);
  }
  for (const x of db.collections) {
    x.financialYear ||= financialYear(x.date);
    if(String(x.type||'').toLowerCase().includes('donation')){
      x.type='Donation';
      x.donationType ||= x.memberId ? 'Member Donation' : 'External Donation';
      x.donationPurpose ||= 'General Fund';
      if(x.donorMobile===undefined){
        const member=db.members.find(m=>m.id===x.memberId);
        x.donorMobile=member?.phone||'';
      }
    }
  }
  for (const x of db.transactions) {
    x.financialYear ||= financialYear(x.date);
    x.fundingPurpose ||= '';
    x.source ||= '';
    x.remarks ||= x.description || '';
    if(x.type==='Income'){
      if(!INCOME_CATEGORIES.includes(x.category)) x.category='Other Legal Income';
    }
    if(x.type==='Expense'){
      if(!EXPENSE_CATEGORIES.includes(x.category)) x.category='Other Approved Expense';
      x.paidTo ||= '';
      x.purpose ||= x.description || '';
      x.approvedBy ||= '';
      x.billPath ||= '';
      x.billOriginalName ||= '';
    }
  }
  for (const x of db.loans) x.financialYear ||= financialYear(x.date);
  for (const x of db.events) x.financialYear ||= financialYear(x.date);
  if (db.funds.length === 0) {
    const fy = financialYear();
    db.funds = DEFAULT_FUND_ALLOCATION.map((f,i)=>({
      id:`FUND-${String(i+1).padStart(3,'0')}`,
      name:f.name,percent:f.percent,financialYear:fy,notes:''
    }));
  }
  for (const x of db.funds) {
    x.financialYear ||= financialYear();
    x.notes ||= '';
  }
  return db;
}
function loadDB(){
  try {
    const db = migrate(JSON.parse(fs.readFileSync(DB_FILE,'utf8')));
    saveDB(db);
    return db;
  } catch {
    const db = migrate(structuredClone(seed));
    saveDB(db);
    return db;
  }
}
function saveDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
function json(res, code, data){
  res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(data));
}
function body(req){
  return new Promise((resolve,reject)=>{
    let d='';
    req.on('data',c=>{ d+=c; if(d.length>16e6){ reject(new Error('Request too large')); req.destroy(); } });
    req.on('end',()=>{ try{resolve(d?JSON.parse(d):{})}catch(e){reject(e)} });
    req.on('error',reject);
  });
}
function hashPassword(password, salt=crypto.randomBytes(16).toString('hex')){
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return {salt, hash};
}
function verifyPassword(password, salt, hash){
  const a=Buffer.from(crypto.scryptSync(password,salt,64).toString('hex'),'hex');
  const b=Buffer.from(hash,'hex');
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function cookies(req){
  const out={}; const raw=req.headers.cookie||'';
  raw.split(';').forEach(p=>{const i=p.indexOf('='); if(i>0) out[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim())});
  return out;
}
function normalizeWhatsAppNumber(value, defaultCountryCode='91'){
  let s=String(value||'').replace(/[^\d]/g,'');
  const cc=String(defaultCountryCode||'91').replace(/[^\d]/g,'')||'91';
  if(s.length===10) s=cc+s;
  if(s.startsWith('00')) s=s.slice(2);
  return s;
}
function maskedPhone(value){
  const s=String(value||'');
  if(s.length<=4)return s;
  return `${s.slice(0,2)}••••••${s.slice(-4)}`;
}
function secretKeyFile(){return path.join(DATA_DIR,'.local_secret_key');}
let LOCAL_SECRET_KEY_CACHE=null;
function getLocalSecretKey(){
  if(LOCAL_SECRET_KEY_CACHE)return LOCAL_SECRET_KEY_CACHE;
  const f=secretKeyFile();
  try{
    if(fs.existsSync(f)){
      const raw=fs.readFileSync(f,'utf8').trim();
      const b=Buffer.from(raw,'hex');
      if(b.length===32){LOCAL_SECRET_KEY_CACHE=b;return b;}
    }
  }catch{}
  const key=crypto.randomBytes(32);
  try{
    fs.writeFileSync(f,key.toString('hex'),{encoding:'utf8',mode:0o600});
  }catch{
    fs.writeFileSync(f,key.toString('hex'),'utf8');
  }
  LOCAL_SECRET_KEY_CACHE=key;
  return key;
}
function encryptSecret(text){
  if(!text)return '';
  const key=getLocalSecretKey(),iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
  const enc=Buffer.concat([cipher.update(String(text),'utf8'),cipher.final()]);
  const tag=cipher.getAuthTag();
  return `enc:v1:${iv.toString('hex')}:${tag.toString('hex')}:${enc.toString('hex')}`;
}
function decryptSecret(value){
  if(!value)return '';
  const parts=String(value).split(':');
  if(parts.length!==5||parts[0]!=='enc'||parts[1]!=='v1')return '';
  try{
    const key=getLocalSecretKey(),iv=Buffer.from(parts[2],'hex'),tag=Buffer.from(parts[3],'hex'),data=Buffer.from(parts[4],'hex');
    const dec=crypto.createDecipheriv('aes-256-gcm',key,iv);dec.setAuthTag(tag);
    return Buffer.concat([dec.update(data),dec.final()]).toString('utf8');
  }catch{return ''}
}
function safeUser(u){
  if(!u) return null;
  return {id:u.id,name:u.name,email:u.email,whatsapp:u.whatsapp||'',role:u.role,memberId:u.memberId||'',status:u.status,lastLoginAt:u.lastLoginAt||'',createdAt:u.createdAt||'',updatedAt:u.updatedAt||'',mustChangePassword:!!u.mustChangePassword};
}
const OTP_RUNTIME={challenges:new Map(),requests:new Map()};
function otpCleanup(){
  const now=Date.now();
  for(const [id,c] of OTP_RUNTIME.challenges)if(!c||c.expiresAt<now-60000)OTP_RUNTIME.challenges.delete(id);
  for(const [k,v] of OTP_RUNTIME.requests){
    const recent=(v||[]).filter(t=>now-t<15*60*1000);
    if(recent.length)OTP_RUNTIME.requests.set(k,recent);else OTP_RUNTIME.requests.delete(k);
  }
}
function otpHash(challengeId,otp,salt){
  return crypto.createHash('sha256').update(`${challengeId}|${otp}|${salt}`).digest('hex');
}
function otpRateCheck(key,resendSeconds=60){
  otpCleanup();
  const now=Date.now(),arr=OTP_RUNTIME.requests.get(key)||[];
  const recent=arr.filter(t=>now-t<15*60*1000);
  if(recent.length>=5)return {ok:false,error:'Too many OTP requests. Please try again after 15 minutes.'};
  const last=recent[recent.length-1]||0;
  if(last && now-last<Math.max(30,Number(resendSeconds||60))*1000)
    return {ok:false,error:`Please wait ${Math.ceil((Math.max(30,Number(resendSeconds||60))*1000-(now-last))/1000)} seconds before requesting another OTP.`};
  recent.push(now);OTP_RUNTIME.requests.set(key,recent);return {ok:true};
}
function whatsappOtpConfig(db){
  return {
    enabled:!!db.setup?.whatsappOtp?.enabled,
    apiVersion:String(db.setup?.whatsappOtp?.apiVersion||'v26.0').trim()||'v26.0',
    phoneNumberId:String(db.setup?.whatsappOtp?.phoneNumberId||'').trim(),
    accessToken:decryptSecret(db.setup?.whatsappOtp?.accessTokenEnc||''),
    templateName:String(db.setup?.whatsappOtp?.templateName||'authentication_code_copy_code_button').trim(),
    templateLanguage:String(db.setup?.whatsappOtp?.templateLanguage||'en_US').trim()||'en_US',
    defaultCountryCode:String(db.setup?.whatsappOtp?.defaultCountryCode||'91').replace(/[^\d]/g,'')||'91',
    expiryMinutes:Math.min(15,Math.max(3,Number(db.setup?.whatsappOtp?.expiryMinutes||10))),
    resendSeconds:Math.min(300,Math.max(30,Number(db.setup?.whatsappOtp?.resendSeconds||60))),
    maxAttempts:Math.min(10,Math.max(3,Number(db.setup?.whatsappOtp?.maxAttempts||5)))
  };
}
function validateWhatsAppConfigShape(c){
  const errors=[];
  if(!c.phoneNumberId)errors.push('Phone Number ID is required.');
  else if(!/^\d{8,30}$/.test(String(c.phoneNumberId)))errors.push('Phone Number ID must be the numeric Meta Phone Number ID. Do not enter an email address, mobile number, WABA ID or Business ID.');
  if(!c.accessToken)errors.push('Meta Access Token is required.');
  else if(String(c.accessToken).length<40 || /\s/.test(String(c.accessToken)) || /@/.test(String(c.accessToken)) || /^\*+$/.test(String(c.accessToken)))errors.push('Meta Access Token format is invalid. Paste the complete OAuth/System User access token from Meta, not an email, password or masked value.');
  if(!c.templateName)errors.push('Authentication Template Name is required.');
  else if(!/^[a-z0-9_]+$/.test(String(c.templateName)))errors.push('Authentication Template Name should use lowercase letters, numbers and underscores only, exactly as approved in WhatsApp Manager.');
  if(!/^v\d+(?:\.\d+)?$/i.test(String(c.apiVersion||'')))errors.push('Graph API Version must look like v26.0.');
  if(!/^[a-z]{2}(?:_[A-Z]{2})?$/.test(String(c.templateLanguage||'')))errors.push('Template Language must look like en_US.');
  return {ok:errors.length===0,errors};
}
function whatsappOtpReady(db){
  const c=whatsappOtpConfig(db),shape=validateWhatsAppConfigShape(c);
  return !!(c.enabled&&shape.ok);
}
function httpsJsonGet(urlString,headers={}){
  return new Promise((resolve,reject)=>{
    const u=new URL(urlString),client=u.protocol==='http:'?http:https;
    const req=client.request({
      protocol:u.protocol,hostname:u.hostname,port:u.port||undefined,path:u.pathname+u.search,method:'GET',
      headers:{...headers},timeout:12000
    },resp=>{
      const chunks=[];resp.on('data',d=>chunks.push(d));resp.on('end',()=>{
        const raw=Buffer.concat(chunks).toString('utf8');
        let parsed={};try{parsed=raw?JSON.parse(raw):{}}catch{parsed={raw}}
        if(resp.statusCode>=200&&resp.statusCode<300)return resolve({status:resp.statusCode,data:parsed});
        const msg=parsed?.error?.message||parsed?.message||`Meta API returned HTTP ${resp.statusCode}`;
        const err=new Error(msg);err.meta=parsed;err.status=resp.statusCode;reject(err);
      });
    });
    req.on('timeout',()=>req.destroy(new Error('Meta API request timed out')));
    req.on('error',reject);req.end();
  });
}
function metaErrorMessage(err){
  const msg=String(err?.message||'Meta API validation failed.');
  if(/cannot parse access token|invalid oauth access token/i.test(msg))return 'Meta Access Token is invalid or incomplete. Copy the full access token from Meta WhatsApp API Setup / System User and save it again.';
  if(/unsupported get request|object with id .* does not exist|cannot be loaded/i.test(msg))return 'Phone Number ID is not valid for this Meta account/token. Enter the numeric Phone Number ID from WhatsApp API Setup.';
  if(/permissions|permission/i.test(msg))return 'The Meta Access Token does not have the required WhatsApp permissions. Use a System User token with whatsapp_business_messaging (and management access where required).';
  return msg;
}
async function validateWhatsAppMetaConfig(db,override={}){
  const base=whatsappOtpConfig(db),c={...base,...override};
  const shape=validateWhatsAppConfigShape(c);
  if(!shape.ok)throw new Error(shape.errors.join(' '));
  if(process.env.WA_OTP_TEST_MODE==='1')return {ok:true,verifiedName:'Mock Business',displayPhoneNumber:'+91 98765 43210',qualityRating:'GREEN'};
  const graphBase=String(process.env.WHATSAPP_API_BASE||'https://graph.facebook.com').replace(/\/+$/,'');
  const endpoint=`${graphBase}/${encodeURIComponent(c.apiVersion)}/${encodeURIComponent(c.phoneNumberId)}?fields=verified_name,display_phone_number,quality_rating`;
  try{
    const r=await httpsJsonGet(endpoint,{Authorization:`Bearer ${c.accessToken}`});
    return {ok:true,verifiedName:r.data?.verified_name||'',displayPhoneNumber:r.data?.display_phone_number||'',qualityRating:r.data?.quality_rating||''};
  }catch(err){
    throw new Error(metaErrorMessage(err));
  }
}
function httpsJsonPost(urlString,headers,payload){
  return new Promise((resolve,reject)=>{
    const u=new URL(urlString),client=u.protocol==='http:'?http:https;
    const data=Buffer.from(JSON.stringify(payload));
    const req=client.request({
      protocol:u.protocol,hostname:u.hostname,port:u.port||undefined,path:u.pathname+u.search,method:'POST',
      headers:{'Content-Type':'application/json','Content-Length':data.length,...headers},
      timeout:12000
    },resp=>{
      const chunks=[];resp.on('data',d=>chunks.push(d));resp.on('end',()=>{
        const raw=Buffer.concat(chunks).toString('utf8');
        let parsed={};try{parsed=raw?JSON.parse(raw):{}}catch{parsed={raw}}
        if(resp.statusCode>=200&&resp.statusCode<300)return resolve({status:resp.statusCode,data:parsed});
        const msg=parsed?.error?.message||parsed?.message||`WhatsApp API returned HTTP ${resp.statusCode}`;
        reject(new Error(msg));
      });
    });
    req.on('timeout',()=>req.destroy(new Error('WhatsApp API request timed out')));
    req.on('error',reject);req.write(data);req.end();
  });
}
async function sendWhatsAppOtp(db,to,otp){
  const c=whatsappOtpConfig(db);
  const shape=validateWhatsAppConfigShape(c);
  if(!shape.ok)throw new Error(shape.errors.join(' '));
  if(process.env.WA_OTP_TEST_MODE==='1')return {mock:true};
  const base=String(process.env.WHATSAPP_API_BASE||'https://graph.facebook.com').replace(/\/+$/,'');
  const endpoint=`${base}/${encodeURIComponent(c.apiVersion)}/${encodeURIComponent(c.phoneNumberId)}/messages`;
  const payload={
    messaging_product:'whatsapp',
    to,
    type:'template',
    template:{
      name:c.templateName,
      language:{code:c.templateLanguage},
      components:[
        {type:'body',parameters:[{type:'text',text:otp}]},
        {type:'button',sub_type:'url',index:'0',parameters:[{type:'text',text:otp}]}
      ]
    }
  };
  return httpsJsonPost(endpoint,{Authorization:`Bearer ${c.accessToken}`},payload);
}
function nextUserCode(db){
  let max=0;
  for(const u of db.users||[]){const m=String(u.id||'').match(/^USR-(\d{6})$/);if(m)max=Math.max(max,Number(m[1]));}
  return `USR-${String(max+1).padStart(6,'0')}`;
}
function rolePages(role){ return ROLE_PAGE_ACCESS[role]||[]; }
function sessionUser(req, db){
  const sid=cookies(req).sid;if(!sid)return null;
  const s=db.sessions[sid];if(!s)return null;
  const u=(db.users||[]).find(x=>x.id===s.userId || (!s.userId&&x.email===s.email));
  if(!u || u.status!=='Active') return null;
  return u;
}
function requireAuth(req,res,db){
  const u=sessionUser(req,db); if(!u){json(res,401,{error:'Unauthorized'}); return null;} return u;
}
function attachAuditContext(db,user,req,pathname){
  try{Object.defineProperty(db,'_auditActor',{value:user||null,enumerable:false,configurable:true});}catch{}
  try{Object.defineProperty(db,'_auditRequest',{value:{method:req?.method||'',path:pathname||''},enumerable:false,configurable:true});}catch{}
}
function audit(db, action, detail='', meta={}){
  const a=db._auditActor||meta.actor||null, r=db._auditRequest||{};
  db.audit.unshift({
    id:'A'+Date.now()+crypto.randomBytes(2).toString('hex'),action,detail,at:new Date().toISOString(),
    actorId:a?.id||'',actorName:a?.name||a?.ownerName||'System',actorEmail:a?.email||'',actorRole:a?.role||'System',
    method:r.method||'',path:r.path||'',recordType:meta.recordType||'',recordId:meta.recordId||''
  });
  db.audit=db.audit.slice(0,2000);
}
function apiPageForPath(pathname){
  if(pathname==='/api/dashboard')return 'dashboard';
  if(pathname.startsWith('/api/master-profile')||pathname.startsWith('/api/upload-logo')||pathname.startsWith('/api/upload-document')||pathname.startsWith('/api/documents/'))return 'master';
  if(pathname.startsWith('/api/applications'))return 'applications';
  if(pathname.startsWith('/api/members'))return 'members';
  if(pathname.startsWith('/api/committees'))return 'committee';
  if(pathname.startsWith('/api/meetings'))return 'meetings';
  if(pathname.startsWith('/api/approval-policy')||pathname.startsWith('/api/approval-requirement'))return 'approvals';
  if(pathname.startsWith('/api/subscriptions'))return 'subscriptions';
  if(pathname.startsWith('/api/donations'))return 'donations';
  if(pathname.startsWith('/api/incomes'))return 'income';
  if(pathname.startsWith('/api/expenses'))return 'expense';
  if(pathname.startsWith('/api/cash-bank'))return 'cashbank';
  if(pathname.startsWith('/api/accounting-ledgers'))return 'accountingledger';
  if(pathname.startsWith('/api/collections'))return 'collections';
  if(pathname.startsWith('/api/transactions'))return 'accounts';
  if(pathname.startsWith('/api/welfare'))return 'welfare';
  if(pathname.startsWith('/api/loans'))return 'loans';
  if(pathname.startsWith('/api/funds'))return 'funds';
  if(pathname.startsWith('/api/events'))return 'events';
  if(pathname.startsWith('/api/notices'))return 'notices';
  if(pathname.startsWith('/api/document-library'))return 'documents';
  if(pathname.startsWith('/api/issued-documents'))return 'certificates';
  if(pathname.startsWith('/api/reminders'))return 'reminders';
  if(pathname.startsWith('/api/grievances'))return 'grievances';
  if(pathname.startsWith('/api/elections'))return 'elections';
  if(pathname.startsWith('/api/vendors'))return 'vendors';
  if(pathname.startsWith('/api/budget-control'))return 'budgetcontrol';
  if(pathname.startsWith('/api/annual-audits'))return 'annualaudit';
  if(pathname.startsWith('/api/social-projects'))return 'socialwork';
  if(pathname.startsWith('/api/assets'))return 'assets';
  if(pathname.startsWith('/api/reports'))return 'reports';
  if(pathname.startsWith('/api/users')||pathname.startsWith('/api/audit-log'))return 'security';
  if(pathname.startsWith('/api/settings')||pathname.startsWith('/api/backup')||pathname.startsWith('/api/public-home-slides')||pathname.startsWith('/api/whatsapp-otp-settings'))return 'settings';
  if(pathname.startsWith('/api/my-portal'))return 'memberportal';
  return '';
}
function roleCanRead(user,pathname,url){
  if(user.role==='Super Admin')return true;
  if(['/api/me','/api/financial-years'].includes(pathname))return true;
  if(user.role==='General Member')return pathname.startsWith('/api/my-portal');
  const page=apiPageForPath(pathname);
  if(!page)return false;
  if(!rolePages(user.role).includes(page))return false;
  if(page==='reports'){
    const type=String(url?.searchParams?.get('type')||'');
    if(user.role==='Treasurer') return !type || ['subscriptions','due','donations','income','expense','cash','bank','welfare','loans','outstanding','funds','annual'].includes(type);
    if(user.role==='President') return true;
    return false;
  }
  return true;
}
function roleCanWrite(user,method,pathname){
  if(user.role==='Super Admin')return true;
  const post=method==='POST', put=method==='PUT', del=method==='DELETE';
  if(user.role==='General Member'){
    if(post && pathname==='/api/my-portal/grievances')return true;
    if(post && pathname==='/api/my-portal/nominees')return true;
    if((put||del) && /^\/api\/my-portal\/nominees\/[^/]+$/.test(pathname))return true;
    if((post||del) && /^\/api\/my-portal\/events\/[^/]+\/register$/.test(pathname))return true;
    if(post && /^\/api\/my-portal\/elections\/[^/]+\/vote$/.test(pathname))return true;
    return false;
  }
  if(!(post||put||del))return roleCanRead(user,pathname,null);

  if(user.role==='President'){
    if(post && /^\/api\/applications\/[^/]+\/status$/.test(pathname))return true;
    if(post && /^\/api\/welfare\/applications\/[^/]+\/status$/.test(pathname))return true;
    if(post && /^\/api\/loans\/[^/]+\/status$/.test(pathname))return true;
    if(post && /^\/api\/meetings\/[^/]+\/resolutions$/.test(pathname))return true;
    if(post && /^\/api\/meetings\/[^/]+\/finalize$/.test(pathname))return true;
    if(put && /^\/api\/grievances\/[^/]+$/.test(pathname))return true;
    if(put && /^\/api\/elections\/[^/]+$/.test(pathname))return true;
    if(put && /^\/api\/annual-audits\/[^/]+$/.test(pathname))return true;
    return false;
  }
  if(user.role==='Committee Member'){
    if(post && /^\/api\/applications\/[^/]+\/status$/.test(pathname))return true;
    if(post && /^\/api\/welfare\/applications\/[^/]+\/status$/.test(pathname))return true;
    if(post && /^\/api\/loans\/[^/]+\/status$/.test(pathname))return true;
    return false;
  }
  if(user.role==='Secretary'){
    if(pathname.startsWith('/api/applications')) return !pathname.endsWith('/activate');
    if(pathname.startsWith('/api/members')) return true;
    if(pathname.startsWith('/api/committees')) return true;
    if(pathname.startsWith('/api/meetings')) return true;
    if(pathname.startsWith('/api/events')) return !/\/(income|expense)$/.test(pathname);
    if(pathname.startsWith('/api/notices')) return true;
    if(pathname.startsWith('/api/document-library')) return true;
    if(pathname.startsWith('/api/issued-documents')) return true;
    if(pathname.startsWith('/api/reminders')) return true;
    if(pathname.startsWith('/api/grievances')) return true;
    if(pathname.startsWith('/api/elections')) return true;
    if(pathname.startsWith('/api/vendors')) return true;
    if(pathname.startsWith('/api/social-projects')) return !/\/expense$/.test(pathname);
    return false;
  }
  if(user.role==='Treasurer'){
    if(post && /^\/api\/applications\/[^/]+\/activate$/.test(pathname))return true;
    if(pathname.startsWith('/api/subscriptions'))return true;
    if(pathname.startsWith('/api/donations'))return true;
    if(pathname.startsWith('/api/incomes'))return true;
    if(pathname.startsWith('/api/expenses'))return true;
    if(pathname.startsWith('/api/cash-bank'))return true;
    if(pathname.startsWith('/api/collections'))return true;
    if(pathname.startsWith('/api/transactions'))return true;
    if(post && /^\/api\/welfare\/applications\/[^/]+\/payment$/.test(pathname))return true;
    if(post && /^\/api\/loans\/[^/]+\/(disburse|repayment)$/.test(pathname))return true;
    if(post && /^\/api\/events\/[^/]+\/(income|expense)$/.test(pathname))return true;
    if(post && /^\/api\/social-projects\/[^/]+\/expense$/.test(pathname))return true;
    if(pathname.startsWith('/api/reminders'))return true;
    if(pathname.startsWith('/api/vendors'))return true;
    if(pathname.startsWith('/api/budget-control'))return true;
    if(pathname.startsWith('/api/annual-audits'))return true;
    if(put && /^\/api\/grievances\/[^/]+$/.test(pathname))return true;
    return false;
  }
  return false;
}
function authorizeApi(user,req,res,pathname,url){
  const ok=req.method==='GET'?roleCanRead(user,pathname,url):roleCanWrite(user,req.method,pathname);
  if(!ok){json(res,403,{error:`Permission denied for ${user.role}`});return false;}
  return true;
}
function uid(prefix){ return prefix+'-'+Date.now().toString().slice(-8); }
function nextApplicationCode(db){
  let max=0;
  for(const a of db.membershipApplications){
    const n=Number(String(a.id||'').replace(/\D/g,''));
    if(Number.isFinite(n)) max=Math.max(max,n);
  }
  return 'APP-' + String(max+1).padStart(6,'0');
}
function nextMemberCode(db){
  let max=0;
  for(const m of db.members){
    const n=Number(String(m.id||'').replace(/\D/g,''));
    if(Number.isFinite(n)) max=Math.max(max,n);
  }
  return 'MEM-' + String(max+1).padStart(6,'0');
}
function nextReceiptNo(db, fy){
  let max=0;
  for(const c of db.collections){
    const cfy=c.financialYear||financialYear(c.date);
    if(cfy!==fy) continue;
    const m=String(c.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `RCPT-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextIncomeVoucherNo(db, fy){
  let max=0;
  for(const t of db.transactions){
    if((t.financialYear||financialYear(t.date))!==fy || t.type!=='Income') continue;
    const m=String(t.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `INC-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextExpenseVoucherNo(db, fy){
  let max=0;
  for(const t of db.transactions){
    if((t.financialYear||financialYear(t.date))!==fy || t.type!=='Expense') continue;
    const m=String(t.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `EXP-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextLoanApplicationNo(db, fy){
  let max=0;
  for(const l of db.loans||[]){
    if((l.financialYear||financialYear(l.applicationDate||l.date))!==fy) continue;
    const m=String(l.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `LNA-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextLoanRepaymentNo(db, fy){
  let max=0;
  for(const r of db.loanRepayments||[]){
    if((r.financialYear||financialYear(r.date))!==fy) continue;
    const m=String(r.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `LRP-${fy}-${String(max+1).padStart(6,'0')}`;
}
function addMonthsToDate(dateStr, months){
  const d=new Date(String(dateStr).slice(0,10)+'T00:00:00');
  if(Number.isNaN(d.getTime())) return '';
  const day=d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth()+Number(months||0));
  const last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();
  d.setDate(Math.min(day,last));
  return d.toISOString().slice(0,10);
}
function fullMembershipMonths(joinDate, onDate){
  const j=new Date(String(joinDate||'').slice(0,10)+'T00:00:00');
  const d=new Date(String(onDate||'').slice(0,10)+'T00:00:00');
  if(Number.isNaN(j.getTime())||Number.isNaN(d.getTime())||d<j) return 0;
  let months=(d.getFullYear()-j.getFullYear())*12+(d.getMonth()-j.getMonth());
  if(d.getDate()<j.getDate()) months--;
  return Math.max(0,months);
}
function subscriptionDueToDate(db, member, onDate){
  const fy=financialYear(onDate);
  const monthKey=String(onDate).slice(0,7);
  const ledger=memberSubscriptionLedger(db,member,fy);
  let due=0;
  for(const row of ledger){
    if(row.month>monthKey) continue;
    due+=moneyNum(row.due);
  }
  return due;
}
function round2(v){ return Math.round((moneyNum(v)+Number.EPSILON)*100)/100; }
function loanOutstandingAmount(l){
  const principal=moneyNum(l.disbursedAmount || (['Disbursed','Repayment','Closed'].includes(l.status)?l.amount:0));
  return Math.max(0,principal-moneyNum(l.principalRepaid||l.repaid));
}
function loanTotalOutstanding(l){
  return Math.max(0,moneyNum(l.totalRepayable||l.disbursedAmount)-moneyNum(l.totalPaid));
}
function loanInstallmentSchedule(loan, asOfDate){
  const principal=moneyNum(loan.disbursedAmount||0);
  const charge=moneyNum(loan.chargeAmount||0);
  const total=moneyNum(loan.totalRepayable || principal+charge);
  const period=Math.max(1,Number(loan.repaymentPeriod||1));
  const paidTotal=moneyNum(loan.totalPaid||0);
  const first=loan.firstInstallmentDate || (loan.disbursementDate?addMonthsToDate(loan.disbursementDate,1):'');
  if(!first || principal<=0) return [];
  const today=String(asOfDate||new Date().toISOString().slice(0,10)).slice(0,10);
  let scheduledBefore=0;
  const rows=[];
  for(let i=0;i<period;i++){
    const dueDate=addMonthsToDate(first,i);
    const scheduledAmount=i===period-1
      ? round2(total-scheduledBefore)
      : round2(total/period);
    const principalPayable=i===period-1
      ? round2(principal-rows.reduce((s,x)=>s+x.principalPayable,0))
      : round2(principal/period);
    const chargePayable=round2(scheduledAmount-principalPayable);
    const paid=Math.max(0,Math.min(scheduledAmount,round2(paidTotal-scheduledBefore)));
    const due=Math.max(0,round2(scheduledAmount-paid));
    let status='Upcoming';
    if(due<=0.001) status='Paid';
    else if(today>dueDate) status='Overdue';
    else if(today===dueDate) status='Due';
    scheduledBefore=round2(scheduledBefore+scheduledAmount);
    rows.push({
      installmentNo:i+1,dueDate,
      principalPayable,chargePayable,
      installmentAmount:scheduledAmount,
      paid,due,status
    });
  }
  return rows;
}
function loanRepaymentStatus(loan, asOfDate){
  if(loanTotalOutstanding(loan)<=0.001 || loan.status==='Closed') return 'Closed';
  if(!['Disbursed','Repayment'].includes(loan.status)) return 'Current';
  const schedule=loanInstallmentSchedule(loan,asOfDate);
  if(schedule.some(x=>x.status==='Overdue')) return 'Overdue';
  if(schedule.some(x=>x.status==='Due')) return 'Due';
  return 'Current';
}
function allocateRepaymentComponents(loan, amount){
  const principal=moneyNum(loan.disbursedAmount||0);
  const charge=moneyNum(loan.chargeAmount||0);
  const total=moneyNum(loan.totalRepayable||principal+charge);
  const principalRemaining=Math.max(0,principal-moneyNum(loan.principalRepaid||loan.repaid));
  const chargeRemaining=Math.max(0,charge-moneyNum(loan.chargeRepaid));
  if(total<=0 || charge<=0){
    return {principalComponent:round2(Math.min(amount,principalRemaining)),chargeComponent:0};
  }
  let principalComponent=round2(amount*(principal/total));
  let chargeComponent=round2(amount-principalComponent);
  if(principalComponent>principalRemaining){
    const excess=principalComponent-principalRemaining;
    principalComponent=round2(principalRemaining);
    chargeComponent=round2(chargeComponent+excess);
  }
  if(chargeComponent>chargeRemaining){
    const excess=chargeComponent-chargeRemaining;
    chargeComponent=round2(chargeRemaining);
    principalComponent=round2(principalComponent+excess);
  }
  if(principalComponent>principalRemaining) principalComponent=round2(principalRemaining);
  const diff=round2(amount-principalComponent-chargeComponent);
  if(Math.abs(diff)>0.001){
    if(principalRemaining-principalComponent>=diff) principalComponent=round2(principalComponent+diff);
    else chargeComponent=round2(chargeComponent+diff);
  }
  return {principalComponent,chargeComponent};
}
function loanEligibility(db, member, onDate){
  const settings=db.loanSettings||{};
  const membershipMonths=fullMembershipMonths(member?.joinDate,onDate);
  const subscriptionDue=member?subscriptionDueToDate(db,member,onDate):0;
  const overdueLoans=(db.loans||[]).filter(l=>{
    if(l.memberId!==member?.id) return false;
    const outstanding=loanOutstandingAmount(l);
    if(outstanding<=0) return false;
    if(!l.maturityDate) return false;
    return String(l.maturityDate)<String(onDate).slice(0,10);
  });
  const checks=[
    {
      key:'activeMember',label:'Active Member',
      required:!!settings.requireActiveMember,
      passed:!settings.requireActiveMember || member?.status==='Active',
      detail:`Status: ${member?.status||'Unknown'}`
    },
    {
      key:'membershipDuration',label:`Minimum ${Number(settings.minMembershipMonths||12)} months membership`,
      required:true,
      passed:membershipMonths>=Number(settings.minMembershipMonths||12),
      detail:`Completed membership: ${membershipMonths} month(s)`
    },
    {
      key:'subscriptionClear',label:'No subscription due',
      required:!!settings.requireSubscriptionClear,
      passed:!settings.requireSubscriptionClear || subscriptionDue<=0.001,
      detail:`Subscription due up to ${String(onDate).slice(0,7)}: ₹${subscriptionDue.toFixed(2)}`
    },
    {
      key:'noOverdueLoan',label:'No previous overdue loan',
      required:!!settings.requireNoOverdueLoan,
      passed:!settings.requireNoOverdueLoan || overdueLoans.length===0,
      detail:overdueLoans.length?`${overdueLoans.length} overdue loan(s)`:'No overdue loan'
    }
  ];
  const eligible=!!member && checks.every(c=>c.passed);
  return {eligible,membershipMonths,subscriptionDue,overdueLoans:overdueLoans.map(x=>x.id),checks};
}
function approvalPolicy(db){
  const p=db.approvalPolicy||{};
  return {
    ...DEFAULT_APPROVAL_POLICY,...p,
    modules:{...DEFAULT_APPROVAL_POLICY.modules,...(p.modules||{})},
    rules:Array.isArray(p.rules)&&p.rules.length?p.rules:DEFAULT_APPROVAL_POLICY.rules.map(x=>({...x,designations:[...x.designations]}))
  };
}
function approvalRuleForAmount(policy,amount){
  const v=moneyNum(amount);
  for(let i=0;i<(policy.rules||[]).length;i++){
    const r=policy.rules[i];
    if(r.upTo===null||r.upTo===''||v<=moneyNum(r.upTo)+0.0001){
      const prev=i?moneyNum(policy.rules[i-1].upTo):0;
      const rangeText=r.upTo===null||r.upTo===''?`Above ₹${prev.toFixed(2)}`:`₹${(i?prev+0.01:0).toFixed(2)} – ₹${moneyNum(r.upTo).toFixed(2)}`;
      return {...r,index:i,rangeText};
    }
  }
  return null;
}
function committeeForApprovalDate(db,date){
  const day=String(date||new Date().toISOString().slice(0,10)).slice(0,10);
  const rows=(db.committees||[]).filter(c=>{
    if(c.termStart&&c.termEnd) return c.termStart<=day&&c.termEnd>=day;
    return c.status==='Current';
  }).sort((a,b)=>{
    if(a.status!==b.status){
      if(a.status==='Current') return -1;
      if(b.status==='Current') return 1;
    }
    return String(b.termStart||'').localeCompare(String(a.termStart||''));
  });
  return rows[0]||currentCommittee(db)||null;
}
function approvalRoleHolders(db,designation,date){
  const c=committeeForApprovalDate(db,date);
  if(!c) return [];
  const day=String(date||new Date().toISOString().slice(0,10)).slice(0,10);
  return (c.members||[]).filter(r=>{
    if(r.designation!==designation) return false;
    if(r.startDate&&r.startDate>day) return false;
    if(r.endDate&&r.endDate<day) return false;
    return r.roleStatus==='Active'||(!r.endDate);
  });
}
function approvalResolutionCategory(context){
  if(context==='LoanSanction') return 'Loan Approval';
  if(context==='AssetPurchase') return 'Asset Purchase Approval';
  if(['Expense','EventExpense','SocialWorkExpense','WelfarePayment'].includes(context)) return 'Major Expense Approval';
  return '';
}
function approvalRequirement(db,amount,context,date){
  const p=approvalPolicy(db);
  if(!p.enabled||p.modules?.[context]===false){
    return {required:false,enabled:!!p.enabled,context,amount:moneyNum(amount),policyName:p.policyName,policyRevision:Number(p.revision||1)};
  }
  const rule=approvalRuleForAmount(p,amount);
  if(!rule) return {required:true,error:'No Financial Approval rule covers this amount'};
  const c=committeeForApprovalDate(db,date);
  return {
    required:true,enabled:true,context,amount:moneyNum(amount),
    policyName:p.policyName,policyRevision:Number(p.revision||1),
    ruleId:rule.id,rangeText:rule.rangeText,
    designations:[...(rule.designations||[])],requireResolution:!!rule.requireResolution,
    resolutionCategory:approvalResolutionCategory(context),
    committeeId:c?.id||'',committeeName:c?.name||''
  };
}
function validateFinancialApproval(db,{amount,context,date,approvals,resolutionId}){
  const req=approvalRequirement(db,amount,context,date);
  if(req.error) return {ok:false,error:req.error};
  const map=approvals&&typeof approvals==='object'?approvals:{};
  const approvers=[];

  if(req.required){
    if((req.designations||[]).length&&!req.committeeId)
      return {ok:false,error:'No committee exists for the transaction date. Required designation approvals cannot be verified.'};
    for(const designation of req.designations||[]){
      const memberId=String(map[designation]||'').trim();
      if(!memberId) return {ok:false,error:`${designation} approval is required for ${req.rangeText}`};
      const holder=approvalRoleHolders(db,designation,date).find(x=>x.memberId===memberId);
      if(!holder) return {ok:false,error:`Selected member ${memberId} is not the active ${designation} for this transaction date`};
      approvers.push({designation,memberId:holder.memberId,memberName:holder.memberName});
    }
  }

  let resolution=null;
  const rid=String(resolutionId||'').trim();
  if(rid){
    const found=usableResolution(db,rid);
    if(!found) return {ok:false,error:'Resolution must be from a Finalized meeting and Passed/Unanimous'};
    const expected=req.resolutionCategory||approvalResolutionCategory(context);
    if(expected&&found.resolution.category!==expected)
      return {ok:false,error:`This approval requires a "${expected}" Resolution`};
    resolution={
      resolutionId:found.resolution.id,resolutionNo:found.resolution.resolutionNo,
      resolutionTitle:found.resolution.title,resolutionCategory:found.resolution.category,
      resolutionApprovedBy:found.resolution.approvedBy||''
    };
  }
  if(req.required&&req.requireResolution&&!resolution)
    return {ok:false,error:`Committee Resolution is required for ${req.rangeText}`};

  const snapshot={
    policyName:req.policyName,policyRevision:req.policyRevision,context,amount:moneyNum(amount),
    rangeText:req.rangeText||'Policy not enforced',ruleId:req.ruleId||'',
    requiredDesignations:req.designations||[],requireResolution:!!req.requireResolution,
    committeeId:req.committeeId||'',committeeName:req.committeeName||'',
    approvers,
    ...(resolution||{resolutionId:'',resolutionNo:'',resolutionTitle:'',resolutionCategory:'',resolutionApprovedBy:''}),
    validatedAt:new Date().toISOString()
  };
  return {ok:true,required:req.required,snapshot,resolution};
}
function approvalDisplayName(result,manual){
  const parts=(result?.snapshot?.approvers||[]).map(x=>`${x.designation}: ${x.memberName}`);
  if(result?.snapshot?.resolutionApprovedBy) parts.push(`Resolution: ${result.snapshot.resolutionApprovedBy}`);
  return parts.join(' + ')||String(manual||'').trim();
}
function recentFinancialApprovals(db){
  const rows=[];
  for(const t of db.transactions||[]){
    if(t.type==='Expense'&&t.approvalSnapshot) rows.push({date:t.date,type:'Expense',id:t.id,amount:moneyNum(t.amount),subject:`${t.category||''} / ${t.paidTo||''}`,approval:t.approvalSnapshot});
  }
  for(const a of db.assets||[]){
    if(a.approvalSnapshot) rows.push({date:a.purchaseDate||'',type:'Asset Purchase',id:a.id,amount:moneyNum(a.purchaseValue),subject:a.assetName||'',approval:a.approvalSnapshot});
  }
  for(const l of db.loans||[]){
    if(l.approvalSnapshot) rows.push({date:l.sanctionDate||l.applicationDate||'',type:'Loan Sanction',id:l.id,amount:moneyNum(l.sanctionedAmount),subject:l.memberName||'',approval:l.approvalSnapshot});
  }
  for(const w of db.welfarePayments||[]){
    if(w.approvalSnapshot) rows.push({date:w.date||'',type:'Welfare Payment',id:w.id,amount:moneyNum(w.amount),subject:w.memberName||'',approval:w.approvalSnapshot});
  }
  return rows.sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,50);
}
function nextMeetingNo(db, fy){
  let max=0;
  for(const m of db.meetings||[]){
    if((m.financialYear||financialYear(m.date))!==fy) continue;
    const x=String(m.meetingNo||m.id||'').match(/-(\d{6})$/);
    if(x) max=Math.max(max,Number(x[1]));
  }
  return `MTG-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextResolutionNo(db, fy){
  let max=0;
  for(const m of db.meetings||[]){
    for(const r of m.resolutions||[]){
      const rfy=m.financialYear||financialYear(m.date);
      if(rfy!==fy) continue;
      const x=String(r.resolutionNo||r.id||'').match(/-(\d{6})$/);
      if(x) max=Math.max(max,Number(x[1]));
    }
  }
  return `RES-${fy}-${String(max+1).padStart(6,'0')}`;
}
function findResolution(db,resolutionId){
  if(!resolutionId) return null;
  for(const m of db.meetings||[]){
    const r=(m.resolutions||[]).find(x=>x.id===resolutionId || x.resolutionNo===resolutionId);
    if(r) return {meeting:m,resolution:r};
  }
  return null;
}
function usableResolution(db,resolutionId){
  const found=findResolution(db,resolutionId);
  if(!found) return null;
  if(found.meeting.status!=='Finalized') return null;
  if(!['Passed','Unanimous'].includes(found.resolution.votingResult)) return null;
  return found;
}
function resolutionSnapshot(db,resolutionId){
  if(!resolutionId) return {resolutionId:'',resolutionNo:'',resolutionTitle:''};
  const found=usableResolution(db,resolutionId);
  if(!found) return null;
  return {
    resolutionId:found.resolution.id,
    resolutionNo:found.resolution.resolutionNo,
    resolutionTitle:found.resolution.title
  };
}
function availableResolutions(db,fy){
  const rows=[];
  for(const m of db.meetings||[]){
    if((m.financialYear||financialYear(m.date))!==fy || m.status!=='Finalized') continue;
    for(const r of m.resolutions||[]){
      if(!['Passed','Unanimous'].includes(r.votingResult)) continue;
      rows.push({
        id:r.id,resolutionNo:r.resolutionNo,category:r.category,title:r.title,
        decision:r.decision,votingResult:r.votingResult,approvedBy:r.approvedBy,
        meetingId:m.id,meetingNo:m.meetingNo,meetingTitle:m.title,date:m.date
      });
    }
  }
  return rows.sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.resolutionNo).localeCompare(String(a.resolutionNo)));
}
function resolutionLinks(db,resolutionId){
  const links=[];
  for(const l of db.loans||[]){
    if(l.resolutionId===resolutionId) links.push({type:'Loan',id:l.id,label:`${l.id} - ${l.memberName||l.memberId||''}`});
  }
  for(const t of db.transactions||[]){
    if(t.resolutionId===resolutionId) links.push({type:t.type||'Transaction',id:t.id,label:`${t.id} - ${t.category||''}`});
  }
  for(const a of db.assets||[]){
    if(a.resolutionId===resolutionId) links.push({type:'Asset',id:a.id,label:`${a.id} - ${a.assetName||''}`});
  }
  const fundFY=new Set();
  for(const f of db.funds||[]){
    if(f.resolutionId===resolutionId) fundFY.add(f.financialYear||'');
  }
  for(const fy of fundFY) links.push({type:'Fund Allocation',id:fy,label:`Fund Allocation Policy - FY ${fy}`});
  return links;
}
function nextCommitteeCode(db){
  let max=0;
  for(const c of db.committees||[]){
    const m=String(c.id||'').match(/^COM-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `COM-${String(max+1).padStart(6,'0')}`;
}
function nextCommitteeMemberCode(committee){
  let max=0;
  for(const m of committee.members||[]){
    const x=String(m.id||'').match(/^CMB-(\d{6})$/);
    if(x) max=Math.max(max,Number(x[1]));
  }
  return `CMB-${String(max+1).padStart(6,'0')}`;
}
function currentCommittee(db){
  return (db.committees||[]).find(c=>c.status==='Current')||null;
}
function committeeSummary(c){
  const members=c?.members||[];
  return {
    totalRoles:members.length,
    activeRoles:members.filter(x=>x.roleStatus==='Active').length,
    endedRoles:members.filter(x=>x.roleStatus==='Ended').length,
    officeBearers:members.filter(x=>['President','Vice President','Secretary','Joint Secretary','Treasurer'].includes(x.designation)).length,
    executiveMembers:members.filter(x=>x.designation==='Executive Member').length,
    generalMembers:members.filter(x=>x.designation==='General Member').length
  };
}
function syncCurrentCommitteeTerm(db){
  if(!db.setup) return;
  const current=currentCommittee(db);
  db.setup.committeeTermStart=current?.termStart||'';
  db.setup.committeeTermEnd=current?.termEnd||'';
}
function nextAssetCode(db){
  let max=0;
  for(const a of db.assets||[]){
    const m=String(a.id||'').match(/^AST-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `AST-${String(max+1).padStart(6,'0')}`;
}
function nextSocialProjectCode(db, fy){
  let max=0;
  for(const p of db.socialProjects||[]){
    if((p.financialYear||financialYear(p.date))!==fy) continue;
    const m=String(p.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `SWP-${fy}-${String(max+1).padStart(6,'0')}`;
}
function socialFundingPurpose(type){
  if(type==='Disaster Relief') return 'Disaster Relief';
  if(type==='Educational Support') return 'Education';
  return 'Social Work';
}
function socialProjectExpenses(db,projectId,fy){
  return inFY(db.transactions,fy)
    .filter(t=>t.type==='Expense' && t.socialProjectId===projectId)
    .map(t=>({
      id:t.id,date:t.date,category:t.category,
      paidTo:t.paidTo||'',purpose:t.purpose||t.description||'',
      mode:t.mode||'',amount:moneyNum(t.amount),
      approvedBy:t.approvedBy||'',
      billPath:t.billPath||'',billOriginalName:t.billOriginalName||'',
      fundingPurpose:t.fundingPurpose||'',remarks:t.remarks||''
    }))
    .sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.id).localeCompare(String(a.id)));
}
function socialProjectSummary(db,project,fy){
  const expenses=socialProjectExpenses(db,project.id,fy);
  const totalExpense=expenses.reduce((s,x)=>s+moneyNum(x.amount),0);
  const budget=moneyNum(project.budget);
  return {
    budget,totalExpense,
    budgetBalance:budget-totalExpense,
    beneficiaryCount:Number(project.beneficiaryCount||0),
    responsibleMembers:(project.responsibleMembers||[]).length,
    documents:(project.documents||[]).length
  };
}
function nextGlobalCode(list,prefix){
  let max=0; for(const x of list||[]){const m=String(x.id||'').match(new RegExp('^'+prefix+'-(\\d{6})$'));if(m)max=Math.max(max,Number(m[1]));}
  return `${prefix}-${String(max+1).padStart(6,'0')}`;
}
function nextFYCode(list,prefix,fy,dateKey='date'){
  let max=0;for(const x of list||[]){if((x.financialYear||financialYear(x[dateKey]||x.createdAt))!==fy)continue;const m=String(x.id||'').match(/-(\d{6})$/);if(m)max=Math.max(max,Number(m[1]));}
  return `${prefix}-${fy}-${String(max+1).padStart(6,'0')}`;
}
function memberDueAsOf(db,member,fy,asOfDate){
  const ym=String(asOfDate||new Date().toISOString().slice(0,10)).slice(0,7);let due=0;
  for(const r of memberSubscriptionLedger(db,member,fy)){if(r.month<=ym)due+=moneyNum(r.due);}
  return round2(due);
}
function eventRegistrationSummary(event){
  const regs=event.registrations||[];return {registered:regs.filter(x=>x.status==='Registered').length,attended:regs.filter(x=>x.status==='Attended').length,cancelled:regs.filter(x=>x.status==='Cancelled').length,capacity:Number(event.capacity||0),registrationOpen:!!event.registrationOpen,registrationDeadline:event.registrationDeadline||''};
}
function budgetActual(db,head,fy){
  if(head.type==='Expense'){
    const rows=accountingExpenseRows(db,fy);return round2(rows.filter(x=>!head.category||head.category==='All Expense'||x.category===head.category).reduce((s,x)=>s+moneyNum(x.amount),0));
  }
  const rows=accountingIncomeRows(db,fy);return round2(rows.filter(x=>!head.category||head.category==='All Income'||x.category===head.category).reduce((s,x)=>s+moneyNum(x.amount),0));
}
function electionPublicView(e,memberId='',includeAdmin=false){
  return {...e,positions:(e.positions||[]).map(p=>({id:p.id,name:p.name,seats:p.seats,candidates:(p.candidates||[]).map(c=>({id:c.id,memberId:c.memberId,memberName:c.memberName,manifesto:c.manifesto,status:c.status,votes:(includeAdmin||e.status==='Published')?Number(c.votes||0):null})),voterCount:(p.voterIds||[]).length,hasVoted:memberId?(p.voterIds||[]).includes(memberId):false,voterIds:includeAdmin?(p.voterIds||[]):undefined}))};
}
function nextNoticeNo(db,fy){
  let max=0;
  for(const n of db.notices||[]){
    if((n.financialYear||financialYear(n.date))!==fy) continue;
    const m=String(n.noticeNo||n.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `NOT-${fy}-${String(max+1).padStart(6,'0')}`;
}
function memberIsCurrentCommitteeMember(db,memberId){
  const c=currentCommittee(db);
  return !!(c&&(c.members||[]).some(x=>x.memberId===memberId&&x.roleStatus==='Active'));
}
function noticeVisibleToMember(db,notice,member,today){
  if(notice.status!=='Published') return false;
  const day=String(today||new Date().toISOString().slice(0,10)).slice(0,10);
  if(notice.publishFrom&&notice.publishFrom>day) return false;
  if(notice.publishUntil&&notice.publishUntil<day) return false;
  if(notice.audience==='Active Members') return member.status==='Active';
  if(notice.audience==='Committee Members') return memberIsCurrentCommitteeMember(db,member.id);
  if(notice.audience==='Specific Member') return notice.memberId===member.id;
  return notice.audience==='All Members'||!notice.audience;
}
function nextEventCode(db, fy){
  let max=0;
  for(const e of db.events||[]){
    if((e.financialYear||financialYear(e.startDate||e.date))!==fy) continue;
    const m=String(e.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `EVT-${fy}-${String(max+1).padStart(6,'0')}`;
}
function eventIncomeRows(db,eventId,fy){
  const rows=[];
  for(const c of inFY(db.collections,fy)){
    if(c.eventId!==eventId) continue;
    let eventIncomeType=c.eventIncomeType||'Collection';
    if(c.type==='Donation') eventIncomeType='Donation';
    else if(c.type==='Event Collection') eventIncomeType='Collection';
    else if(c.type==='Event Member Contribution') eventIncomeType='Member Contribution';
    rows.push({
      id:c.id,date:c.date,type:eventIncomeType,source:c.personName||'',
      mode:c.mode||'',amount:moneyNum(c.amount),remarks:c.notes||'',
      recordType:'Receipt'
    });
  }
  for(const t of inFY(db.transactions,fy)){
    if(t.type!=='Income' || t.eventId!==eventId) continue;
    rows.push({
      id:t.id,date:t.date,type:t.eventIncomeType||t.category||'Income',
      source:t.source||'',mode:t.mode||'',amount:moneyNum(t.amount),
      remarks:t.remarks||t.description||'',recordType:'Voucher'
    });
  }
  return rows.sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.id).localeCompare(String(a.id)));
}
function eventExpenseRows(db,eventId,fy){
  return inFY(db.transactions,fy)
    .filter(t=>t.type==='Expense' && t.eventId===eventId)
    .map(t=>({
      id:t.id,date:t.date,category:t.category,paidTo:t.paidTo||'',
      purpose:t.purpose||t.description||'',mode:t.mode||'',
      amount:moneyNum(t.amount),approvedBy:t.approvedBy||'',
      billPath:t.billPath||'',billOriginalName:t.billOriginalName||'',
      remarks:t.remarks||''
    }))
    .sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.id).localeCompare(String(a.id)));
}
function eventSummary(db,event,fy){
  const incomes=eventIncomeRows(db,event.id,fy);
  const expenses=eventExpenseRows(db,event.id,fy);
  const totalIncome=incomes.reduce((s,x)=>s+moneyNum(x.amount),0);
  const totalExpense=expenses.reduce((s,x)=>s+moneyNum(x.amount),0);
  const byType={};
  for(const x of incomes) byType[x.type]=(byType[x.type]||0)+moneyNum(x.amount);
  return {
    totalIncome,totalExpense,finalBalance:totalIncome-totalExpense,
    budget:moneyNum(event.budget),budgetVariance:moneyNum(event.budget)-totalExpense,
    participants:(event.participants||[]).length,
    registrations:(event.registrations||[]).filter(x=>x.status!=='Cancelled').length,
    vendors:(event.vendors||[]).length,
    documents:(event.documents||[]).length,
    collection:moneyNum(byType['Collection']),
    donation:moneyNum(byType['Donation']),
    sponsorship:moneyNum(byType['Sponsorship']),
    memberContribution:moneyNum(byType['Member Contribution'])
  };
}
function nextWelfareApplicationNo(db, fy){
  let max=0;
  for(const w of db.welfareApplications||[]){
    if((w.financialYear||financialYear(w.applicationDate))!==fy) continue;
    const m=String(w.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `WFA-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextWelfarePaymentNo(db, fy){
  let max=0;
  for(const p of db.welfarePayments||[]){
    if((p.financialYear||financialYear(p.date))!==fy) continue;
    const m=String(p.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `WFP-${fy}-${String(max+1).padStart(6,'0')}`;
}
function nextTransferNo(db, fy){
  let max=0;
  for(const t of db.fundTransfers||[]){
    if((t.financialYear||financialYear(t.date))!==fy) continue;
    const m=String(t.id||'').match(/-(\d{6})$/);
    if(m) max=Math.max(max,Number(m[1]));
  }
  return `TRF-${fy}-${String(max+1).padStart(6,'0')}`;
}
function accountKeyForMode(mode){
  const m=String(mode||'').toLowerCase();
  if(m.includes('cash')) return 'cash';
  if(m.includes('bank') || m.includes('cheque') || m.includes('check')) return 'bank';
  if(m.includes('upi')) return 'upi';
  return 'upi';
}
function defaultCashBankSettings(db, fy){
  const master=db.setup||{};
  return {
    cash:{name:'Cash in Hand',openingBalance:0},
    bank:{name:master.bankName?`${master.bankName} - Bank Account`:'Bank Account',openingBalance:0},
    upi:{name:master.upiId?`UPI / Other - ${master.upiId}`:'UPI / Other Account',openingBalance:0}
  };
}
function getCashBankSettings(db, fy){
  const defs=defaultCashBankSettings(db,fy);
  const cur=db.cashBankSettings?.[fy]||{};
  return {
    cash:{...defs.cash,...(cur.cash||{})},
    bank:{...defs.bank,...(cur.bank||{})},
    upi:{...defs.upi,...(cur.upi||{})}
  };
}
function buildAccountLedger(db, fy, accountKey){
  const settings=getCashBankSettings(db,fy);
  const entries=[];
  const opening=moneyNum(settings[accountKey]?.openingBalance);

  for(const c of inFY(db.collections,fy)){
    if(accountKeyForMode(c.mode)!==accountKey) continue;
    entries.push({
      date:c.date,ref:c.id,type:'Receipt',
      particular:`${c.type||'Collection'} - ${c.personName||''}`.trim(),
      inflow:moneyNum(c.amount),outflow:0,source:'Collection'
    });
  }
  for(const t of inFY(db.transactions,fy)){
    if(t.skipCashBank) continue;
    if(accountKeyForMode(t.mode)!==accountKey) continue;
    if(t.type==='Income'){
      entries.push({
        date:t.date,ref:t.id,type:'Income',
        particular:`${t.category||'Income'} - ${t.source||t.description||''}`.trim(),
        inflow:moneyNum(t.amount),outflow:0,source:'Income'
      });
    }else if(t.type==='Expense'){
      entries.push({
        date:t.date,ref:t.id,type:'Expense',
        particular:`${t.category||'Expense'} - ${t.paidTo||t.purpose||''}`.trim(),
        inflow:0,outflow:moneyNum(t.amount),source:'Expense'
      });
    }
  }
  for(const l of db.loans||[]){
    if(!l.disbursementDate || financialYear(l.disbursementDate)!==fy || moneyNum(l.disbursedAmount)<=0) continue;
    if(accountKeyForMode(l.disbursementMode)!==accountKey) continue;
    entries.push({
      date:l.disbursementDate,ref:l.id,type:'Loan Disbursement',
      particular:`Member Loan / Financial Assistance - ${l.memberName||l.memberId||''}`,
      inflow:0,outflow:moneyNum(l.disbursedAmount),source:'Loan'
    });
  }
  for(const r of inFY(db.loanRepayments||[],fy)){
    if(accountKeyForMode(r.mode)!==accountKey) continue;
    const loan=(db.loans||[]).find(x=>x.id===r.loanId);
    entries.push({
      date:r.date,ref:r.id,type:'Loan Repayment',
      particular:`Loan repayment - ${loan?.memberName||r.loanId}`,
      inflow:moneyNum(r.amount),outflow:0,source:'Loan'
    });
  }

  for(const tr of inFY(db.fundTransfers||[],fy)){
    if(tr.fromAccount===accountKey){
      entries.push({
        date:tr.date,ref:tr.id,type:'Fund Transfer',
        particular:`Transfer to ${settings[tr.toAccount]?.name||tr.toAccount}${tr.reference?` / ${tr.reference}`:''}`,
        inflow:0,outflow:moneyNum(tr.amount),source:'Transfer'
      });
    }
    if(tr.toAccount===accountKey){
      entries.push({
        date:tr.date,ref:tr.id,type:'Fund Transfer',
        particular:`Transfer from ${settings[tr.fromAccount]?.name||tr.fromAccount}${tr.reference?` / ${tr.reference}`:''}`,
        inflow:moneyNum(tr.amount),outflow:0,source:'Transfer'
      });
    }
  }

  entries.sort((a,b)=>String(a.date).localeCompare(String(b.date)) || String(a.ref).localeCompare(String(b.ref)));
  let balance=opening;
  const rows=entries.map(e=>{
    balance+=moneyNum(e.inflow)-moneyNum(e.outflow);
    return {...e,balance};
  });
  return {
    accountKey,accountName:settings[accountKey]?.name||accountKey,
    openingBalance:opening,closingBalance:balance,rows
  };
}
function ensureFundPolicyForFY(db, fy){
  let rows=db.funds.filter(x=>(x.financialYear||financialYear())===fy);
  if(rows.length===0){
    const stamp=Date.now().toString().slice(-6);
    rows=DEFAULT_FUND_ALLOCATION.map((f,i)=>({
      id:`FUND-${stamp}-${i+1}`,
      name:f.name,percent:f.percent,financialYear:fy,notes:''
    }));
    db.funds.push(...rows);
    audit(db,'Fund Policy Initialized',`Default allocation created for FY ${fy}`);
    saveDB(db);
  }
  return rows;
}
function collectionIncomeCategory(c){
  const t=String(c.type||'');
  if(t==='Joining Fee') return 'Joining Fee';
  if(t==='Monthly Membership Fee' || t==='Monthly Subscription') return 'Monthly Subscription';
  if(t==='Annual Fee') return 'Annual Subscription';
  if(t==='Donation') return 'Donation';
  if(t==='Special Contribution') return 'Special Contribution';
  if(t==='Event Collection' || t==='Event Member Contribution') return 'Event Collection';
  return 'Other Legal Income';
}
function accountingDateString(d){
  if(d instanceof Date) return d.toISOString().slice(0,10);
  return String(d||'').slice(0,10);
}
function dayBeforeDate(dateStr){
  const d=new Date(String(dateStr).slice(0,10)+'T00:00:00');
  if(Number.isNaN(d.getTime())) return '';
  d.setDate(d.getDate()-1);
  return d.toISOString().slice(0,10);
}
function accountingIncomeRows(db,fy){
  const rows=[];
  for(const c of inFY(db.collections||[],fy)){
    rows.push({
      date:c.date||'',ref:c.id,type:'Receipt',category:collectionIncomeCategory(c),
      particular:`${c.type||'Collection'} - ${c.personName||''}`.trim(),
      source:c.personName||'',mode:c.mode||'',amount:moneyNum(c.amount),
      memberId:c.memberId||'',eventId:c.eventId||'',donationPurpose:c.donationPurpose||'',
      donationType:c.donationType||'',recordSource:'Collection'
    });
  }
  for(const t of inFY(db.transactions||[],fy)){
    if(t.type!=='Income') continue;
    rows.push({
      date:t.date||'',ref:t.id,type:'Income Voucher',category:t.category||'Other Legal Income',
      particular:`${t.category||'Income'} - ${t.source||t.description||''}`.trim(),
      source:t.source||'',mode:t.mode||'',amount:moneyNum(t.amount),
      memberId:t.memberId||'',eventId:t.eventId||'',loanId:t.loanId||'',
      fundingPurpose:t.fundingPurpose||'',skipCashBank:!!t.skipCashBank,recordSource:'Transaction'
    });
  }
  rows.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  let total=0;
  return rows.map(x=>{ total=round2(total+moneyNum(x.amount)); return {...x,runningTotal:total}; });
}
function accountingExpenseRows(db,fy){
  const rows=inFY(db.transactions||[],fy).filter(t=>t.type==='Expense').map(t=>({
    date:t.date||'',ref:t.id,category:t.category||'Other Approved Expense',
    paidTo:t.paidTo||'',particular:`${t.category||'Expense'} - ${t.paidTo||t.purpose||''}`.trim(),
    purpose:t.purpose||t.description||'',mode:t.mode||'',amount:moneyNum(t.amount),
    fundingPurpose:t.fundingPurpose||'',memberId:t.memberId||'',eventId:t.eventId||'',
    socialProjectId:t.socialProjectId||'',welfareApplicationId:t.welfareApplicationId||'',
    welfarePaymentId:t.welfarePaymentId||'',billPath:t.billPath||'',billOriginalName:t.billOriginalName||'',
    resolutionNo:t.resolutionNo||'',approvedBy:t.approvedBy||''
  })).sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  let total=0;
  return rows.map(x=>{ total=round2(total+moneyNum(x.amount)); return {...x,runningTotal:total}; });
}
function loanPrincipalReceivableAt(db,asOfDate,memberId=''){
  const day=String(asOfDate||'').slice(0,10);
  if(!day) return 0;
  let total=0;
  for(const l of db.loans||[]){
    if(memberId && l.memberId!==memberId) continue;
    if(!l.disbursementDate || String(l.disbursementDate)>day || moneyNum(l.disbursedAmount)<=0) continue;
    const paid=(db.loanRepayments||[]).filter(r=>r.loanId===l.id && String(r.date||'')<=day)
      .reduce((s,r)=>s+moneyNum(r.principalComponent||r.amount),0);
    total+=Math.max(0,moneyNum(l.disbursedAmount)-paid);
  }
  return round2(total);
}
function accountingOverview(db,fy){
  const bounds=fyBounds(fy);
  const start=accountingDateString(bounds.start),end=accountingDateString(bounds.end);
  const beforeStart=dayBeforeDate(start);
  const cash=buildAccountLedger(db,fy,'cash'),bank=buildAccountLedger(db,fy,'bank'),upi=buildAccountLedger(db,fy,'upi');
  const openingLiquid=round2(moneyNum(cash.openingBalance)+moneyNum(bank.openingBalance)+moneyNum(upi.openingBalance));
  const openingLoanReceivable=loanPrincipalReceivableAt(db,beforeStart);
  const openingBalance=round2(openingLiquid+openingLoanReceivable);
  const incomeRows=accountingIncomeRows(db,fy),expenseRows=accountingExpenseRows(db,fy);
  const income=round2(incomeRows.reduce((s,x)=>s+moneyNum(x.amount),0));
  const expense=round2(expenseRows.reduce((s,x)=>s+moneyNum(x.amount),0));
  const closingBalance=round2(openingBalance+income-expense);
  const liquidClosing=round2(moneyNum(cash.closingBalance)+moneyNum(bank.closingBalance)+moneyNum(upi.closingBalance));
  const closingLoanReceivable=loanPrincipalReceivableAt(db,end);
  const reconciledClosing=round2(liquidClosing+closingLoanReceivable);
  const reconciliationDifference=round2(closingBalance-reconciledClosing);
  return {
    financialYear:fy,startDate:start,endDate:end,
    openingLiquid,openingLoanReceivable,openingBalance,
    income,expense,closingBalance,
    liquidClosing,closingLoanReceivable,reconciledClosing,reconciliationDifference,
    reconciled:Math.abs(reconciliationDifference)<=0.01
  };
}
function memberFinancialLedger(db,member,fy){
  const bounds=fyBounds(fy),start=accountingDateString(bounds.start),end=accountingDateString(bounds.end);
  const rows=[];
  for(const c of inFY(db.collections||[],fy)){
    if(c.memberId!==member.id) continue;
    rows.push({date:c.date||'',ref:c.id,type:'Payment / Receipt',particular:c.type||'Collection',inflow:moneyNum(c.amount),outflow:0,memoAmount:0,mode:c.mode||''});
  }
  for(const l of db.loans||[]){
    if(l.memberId!==member.id) continue;
    if(l.disbursementDate && financialYear(l.disbursementDate)===fy && moneyNum(l.disbursedAmount)>0){
      rows.push({date:l.disbursementDate,ref:l.id,type:'Loan / Assistance Disbursement',particular:l.purpose||'Member financial assistance',inflow:0,outflow:moneyNum(l.disbursedAmount),memoAmount:0,mode:l.disbursementMode||''});
    }
  }
  for(const r of inFY(db.loanRepayments||[],fy)){
    const loan=(db.loans||[]).find(x=>x.id===r.loanId);
    if(loan?.memberId!==member.id) continue;
    rows.push({date:r.date||'',ref:r.id,type:'Loan Repayment',particular:`Principal ₹${moneyNum(r.principalComponent).toFixed(2)}${moneyNum(r.chargeComponent)>0?` + Charge ₹${moneyNum(r.chargeComponent).toFixed(2)}`:''}`,inflow:moneyNum(r.amount),outflow:0,memoAmount:0,mode:r.mode||''});
  }
  for(const w of inFY(db.welfarePayments||[],fy)){
    if(w.memberId!==member.id) continue;
    const app=(db.welfareApplications||[]).find(x=>x.id===w.applicationId);
    rows.push({date:w.date||'',ref:w.id,type:'Welfare Payment',particular:app?.welfareType||'Member Welfare Assistance',inflow:0,outflow:moneyNum(w.amount),memoAmount:0,mode:w.mode||''});
  }
  for(const b of inFY(db.memberBenefits||[],fy)){
    if(b.memberId!==member.id) continue;
    rows.push({date:b.date||'',ref:b.id,type:'Benefit Record',particular:`${b.type||'Benefit'} - ${b.description||''}`.trim(),inflow:0,outflow:0,memoAmount:moneyNum(b.amount),mode:'Memo'});
  }
  rows.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  let net=0;
  const ledgerRows=rows.map(x=>{net=round2(net+moneyNum(x.inflow)-moneyNum(x.outflow));return {...x,netCashMovement:net};});
  const profileCollections=inFY(db.collections||[],fy).filter(x=>x.memberId===member.id);
  const donationTotal=profileCollections.filter(x=>x.type==='Donation').reduce((s,x)=>s+moneyNum(x.amount),0);
  const today=new Date().toISOString().slice(0,10);
  const dueAsOf=today<end?today:end;
  const subscriptionDue=subscriptionDueToDate(db,member,dueAsOf);
  return {
    memberId:member.id,memberName:member.name,status:member.status,phone:member.phone||'',
    summary:{
      paidToOrganization:round2(rows.reduce((s,x)=>s+moneyNum(x.inflow),0)),
      paidToMember:round2(rows.reduce((s,x)=>s+moneyNum(x.outflow),0)),
      benefitMemoValue:round2(rows.reduce((s,x)=>s+moneyNum(x.memoAmount),0)),
      donationTotal:round2(donationTotal),subscriptionDue:round2(subscriptionDue),
      openingLoanOutstanding:loanPrincipalReceivableAt(db,dayBeforeDate(start),member.id),
      closingLoanOutstanding:loanPrincipalReceivableAt(db,end,member.id),
      netCashMovement:round2(net)
    },
    rows:ledgerRows
  };
}
function donationLedgerData(db,fy){
  const bounds=fyBounds(fy),start=accountingDateString(bounds.start),beforeStart=dayBeforeDate(start);
  const allDonationReceipts=(db.collections||[]).filter(c=>c.type==='Donation');
  const allTaggedExpenses=(db.transactions||[]).filter(t=>t.type==='Expense'&&DONATION_PURPOSES.includes(t.fundingPurpose));
  const purposeSummary=DONATION_PURPOSES.map(purpose=>{
    const openingReceived=allDonationReceipts.filter(c=>(c.donationPurpose||'General Fund')===purpose && String(c.date||'')<=beforeStart).reduce((s,x)=>s+moneyNum(x.amount),0);
    const openingSpent=allTaggedExpenses.filter(t=>t.fundingPurpose===purpose && String(t.date||'')<=beforeStart).reduce((s,x)=>s+moneyNum(x.amount),0);
    const currentReceipts=inFY(allDonationReceipts,fy).filter(c=>(c.donationPurpose||'General Fund')===purpose);
    const currentExpenses=inFY(allTaggedExpenses,fy).filter(t=>t.fundingPurpose===purpose);
    const received=currentReceipts.reduce((s,x)=>s+moneyNum(x.amount),0),spent=currentExpenses.reduce((s,x)=>s+moneyNum(x.amount),0);
    const opening=round2(openingReceived-openingSpent);
    return {purpose,opening,received:round2(received),spent:round2(spent),closing:round2(opening+received-spent)};
  });
  const openingBalance=round2(purposeSummary.reduce((s,x)=>s+moneyNum(x.opening),0));
  const rows=[];
  for(const c of inFY(allDonationReceipts,fy)){
    rows.push({date:c.date||'',ref:c.id,purpose:c.donationPurpose||'General Fund',particular:`Donation - ${c.personName||''}`,received:moneyNum(c.amount),spent:0,mode:c.mode||'',donor:c.personName||'',donationType:c.donationType||''});
  }
  for(const t of inFY(allTaggedExpenses,fy)){
    rows.push({date:t.date||'',ref:t.id,purpose:t.fundingPurpose,particular:`Expense - ${t.paidTo||t.purpose||''}`,received:0,spent:moneyNum(t.amount),mode:t.mode||'',donor:'',donationType:''});
  }
  rows.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  let bal=openingBalance;
  const ledgerRows=rows.map(x=>{bal=round2(bal+moneyNum(x.received)-moneyNum(x.spent));return {...x,balance:bal};});
  return {
    openingBalance,
    received:round2(rows.reduce((s,x)=>s+moneyNum(x.received),0)),
    spent:round2(rows.reduce((s,x)=>s+moneyNum(x.spent),0)),
    closingBalance:round2(bal),purposeSummary,rows:ledgerRows
  };
}
function eventLedgersData(db,fy){
  return inFY(db.events||[],fy).map(event=>{
    const income=eventIncomeRows(db,event.id,fy).map(x=>({date:x.date,ref:x.id,type:x.type,particular:x.source||x.type,inflow:moneyNum(x.amount),outflow:0,mode:x.mode||''}));
    const expense=eventExpenseRows(db,event.id,fy).map(x=>({date:x.date,ref:x.id,type:'Expense',particular:`${x.category||'Expense'} - ${x.paidTo||''}`,inflow:0,outflow:moneyNum(x.amount),mode:x.mode||''}));
    const rows=[...income,...expense].sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
    let bal=0;
    const ledgerRows=rows.map(x=>{bal=round2(bal+moneyNum(x.inflow)-moneyNum(x.outflow));return {...x,balance:bal};});
    return {eventId:event.id,eventName:event.name||event.eventName||'Event',date:event.date||event.startDate||'',budget:moneyNum(event.budget),income:round2(income.reduce((s,x)=>s+x.inflow,0)),expense:round2(expense.reduce((s,x)=>s+x.outflow,0)),surplusDeficit:round2(bal),rows:ledgerRows};
  }).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
}
function welfareLedgerData(db,fy){
  const apps=inFY(db.welfareApplications||[],fy);
  const payments=inFY(db.welfarePayments||[],fy).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.id).localeCompare(String(b.id)));
  let spent=0;
  const rows=payments.map(p=>{
    const app=(db.welfareApplications||[]).find(x=>x.id===p.applicationId);
    spent=round2(spent+moneyNum(p.amount));
    const exp=(db.transactions||[]).find(t=>t.welfarePaymentId===p.id);
    return {date:p.date||'',ref:p.id,applicationId:p.applicationId,memberId:p.memberId,memberName:p.memberName||app?.memberName||'',type:app?.welfareType||'',amount:moneyNum(p.amount),mode:p.mode||'',expenseVoucher:exp?.id||'',runningPaid:spent};
  });
  const totalApproved=apps.reduce((s,x)=>s+moneyNum(x.approvedAmount),0),totalPaid=payments.reduce((s,x)=>s+moneyNum(x.amount),0);
  return {summary:{applications:apps.length,approved:round2(totalApproved),paid:round2(totalPaid),approvedOutstanding:round2(Math.max(0,totalApproved-totalPaid))},rows};
}
function loanLedgerData(db,fy){
  const bounds=fyBounds(fy),start=accountingDateString(bounds.start),end=accountingDateString(bounds.end),beforeStart=dayBeforeDate(start);
  const today=new Date().toISOString().slice(0,10),asOf=today<end?today:end;
  const openingOutstanding=loanPrincipalReceivableAt(db,beforeStart);
  const rows=[];
  for(const l of db.loans||[]){
    if(l.disbursementDate&&financialYear(l.disbursementDate)===fy&&moneyNum(l.disbursedAmount)>0){
      rows.push({date:l.disbursementDate,ref:l.id,memberId:l.memberId,memberName:l.memberName||'',type:'Disbursement',principalOut:moneyNum(l.disbursedAmount),principalRecovered:0,chargeIncome:0,cashIn:0,mode:l.disbursementMode||''});
    }
  }
  for(const r of inFY(db.loanRepayments||[],fy)){
    const l=(db.loans||[]).find(x=>x.id===r.loanId);
    rows.push({date:r.date||'',ref:r.id,memberId:l?.memberId||'',memberName:l?.memberName||'',type:'Repayment',principalOut:0,principalRecovered:moneyNum(r.principalComponent),chargeIncome:moneyNum(r.chargeComponent),cashIn:moneyNum(r.amount),mode:r.mode||''});
  }
  rows.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  let outstanding=openingOutstanding;
  const ledgerRows=rows.map(x=>{outstanding=round2(outstanding+moneyNum(x.principalOut)-moneyNum(x.principalRecovered));return {...x,principalOutstanding:Math.max(0,outstanding)};});
  const portfolio=(db.loans||[]).filter(l=>loanPrincipalReceivableAt(db,end,l.memberId)>=0 && l.disbursementDate && String(l.disbursementDate)<=end);
  return {
    summary:{
      openingOutstanding,
      disbursed:round2(rows.reduce((s,x)=>s+moneyNum(x.principalOut),0)),
      principalRecovered:round2(rows.reduce((s,x)=>s+moneyNum(x.principalRecovered),0)),
      chargeIncome:round2(rows.reduce((s,x)=>s+moneyNum(x.chargeIncome),0)),
      cashRecovered:round2(rows.reduce((s,x)=>s+moneyNum(x.cashIn),0)),
      closingOutstanding:loanPrincipalReceivableAt(db,end),
      activeLoans:(db.loans||[]).filter(l=>loanOutstandingAmount(l)>0.001&&String(l.disbursementDate||'')<=end).length,
      overdueLoans:(db.loans||[]).filter(l=>loanOutstandingAmount(l)>0.001&&loanRepaymentStatus(l,asOf)==='Overdue').length
    },rows:ledgerRows
  };
}
function findPolicyFundName(policy,keywords,fallback){
  const rows=policy||[];
  for(const keyword of keywords){
    const found=rows.find(x=>String(x.name||'').toLowerCase().includes(keyword));
    if(found) return found.name;
  }
  return rows.find(x=>x.name===fallback)?.name || rows[0]?.name || fallback;
}
function fundHeadForMovement(policy,record,kind){
  const purpose=String(record.fundingPurpose||record.donationPurpose||'').toLowerCase();
  if(kind==='Loan') return findPolicyFundName(policy,['loan','financial assistance'],'Member Financial Assistance / Loan Fund');
  if(kind==='Welfare'||record.welfareApplicationId||record.welfarePaymentId) return findPolicyFundName(policy,['member welfare','welfare'],'Member Welfare');
  if(kind==='Event'||record.eventId||purpose==='event') return findPolicyFundName(policy,['event','development'],'Event & Development');
  if(kind==='Social'||record.socialProjectId||['social work','education','disaster relief'].includes(purpose)) return findPolicyFundName(policy,['social work','social'],'Social Work');
  if(['medical assistance'].includes(purpose)) return findPolicyFundName(policy,['member welfare','welfare'],'Member Welfare');
  if(['emergency fund'].includes(purpose)) return findPolicyFundName(policy,['emergency'],'Emergency Reserve');
  if(['infrastructure'].includes(purpose)) return findPolicyFundName(policy,['event','development','general','operating'],'General / Operating Fund');
  return findPolicyFundName(policy,['general','operating'],'General / Operating Fund');
}
function fundWiseLedgerData(db,fy){
  const policy=ensureFundPolicyForFY(db,fy);
  const cash=buildAccountLedger(db,fy,'cash'),bank=buildAccountLedger(db,fy,'bank'),upi=buildAccountLedger(db,fy,'upi');
  const openingLiquid=round2(moneyNum(cash.openingBalance)+moneyNum(bank.openingBalance)+moneyNum(upi.openingBalance));
  const closingLiquid=round2(moneyNum(cash.closingBalance)+moneyNum(bank.closingBalance)+moneyNum(upi.closingBalance));
  const entries=[];
  for(const c of inFY(db.collections||[],fy)){
    entries.push({date:c.date||'',ref:c.id,type:'Receipt',particular:`${c.type||'Collection'} - ${c.personName||''}`.trim(),inflow:moneyNum(c.amount),outflow:0,fundName:fundHeadForMovement(policy,c,c.eventId?'Event':'Receipt')});
  }
  for(const t of inFY(db.transactions||[],fy)){
    if(t.skipCashBank) continue;
    if(t.type==='Income') entries.push({date:t.date||'',ref:t.id,type:'Income',particular:`${t.category||'Income'} - ${t.source||''}`.trim(),inflow:moneyNum(t.amount),outflow:0,fundName:fundHeadForMovement(policy,t,t.eventId?'Event':'Income')});
    if(t.type==='Expense') entries.push({date:t.date||'',ref:t.id,type:'Expense',particular:`${t.category||'Expense'} - ${t.paidTo||''}`.trim(),inflow:0,outflow:moneyNum(t.amount),fundName:fundHeadForMovement(policy,t,t.eventId?'Event':t.socialProjectId?'Social':t.welfareApplicationId?'Welfare':'Expense')});
  }
  for(const l of db.loans||[]){
    if(!l.disbursementDate||financialYear(l.disbursementDate)!==fy||moneyNum(l.disbursedAmount)<=0) continue;
    entries.push({date:l.disbursementDate,ref:l.id,type:'Loan Disbursement',particular:`${l.memberName||l.memberId||''} - ${l.purpose||''}`,inflow:0,outflow:moneyNum(l.disbursedAmount),fundName:fundHeadForMovement(policy,l,'Loan')});
  }
  for(const r of inFY(db.loanRepayments||[],fy)){
    const l=(db.loans||[]).find(x=>x.id===r.loanId);
    entries.push({date:r.date||'',ref:r.id,type:'Loan Repayment',particular:`${l?.memberName||r.loanId}`,inflow:moneyNum(r.amount),outflow:0,fundName:fundHeadForMovement(policy,r,'Loan')});
  }
  entries.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.ref).localeCompare(String(b.ref)));
  const funds=policy.map(f=>{
    const opening=round2(openingLiquid*moneyNum(f.percent)/100);
    let bal=opening;
    const rows=entries.filter(x=>x.fundName===f.name).map(x=>{bal=round2(bal+moneyNum(x.inflow)-moneyNum(x.outflow));return {...x,balance:bal};});
    const inflow=round2(rows.reduce((s,x)=>s+moneyNum(x.inflow),0)),outflow=round2(rows.reduce((s,x)=>s+moneyNum(x.outflow),0));
    const policyTarget=round2(closingLiquid*moneyNum(f.percent)/100);
    return {name:f.name,percent:moneyNum(f.percent),opening,inflow,outflow,closing:round2(bal),policyTarget,varianceToPolicy:round2(bal-policyTarget),rows};
  });
  return {openingLiquid,closingLiquid,totalPercent:round2(policy.reduce((s,x)=>s+moneyNum(x.percent),0)),funds,reconciled:Math.abs(round2(funds.reduce((s,x)=>s+moneyNum(x.closing),0)-closingLiquid))<=0.01};
}
function accountingLedgerPackage(db,fy){
  const overview=accountingOverview(db,fy);
  const incomeRows=accountingIncomeRows(db,fy),expenseRows=accountingExpenseRows(db,fy);
  const incomeCategories=[...new Set(incomeRows.map(x=>x.category))].map(category=>({category,amount:round2(incomeRows.filter(x=>x.category===category).reduce((s,x)=>s+moneyNum(x.amount),0)),count:incomeRows.filter(x=>x.category===category).length}));
  const expenseCategories=[...new Set(expenseRows.map(x=>x.category))].map(category=>({category,amount:round2(expenseRows.filter(x=>x.category===category).reduce((s,x)=>s+moneyNum(x.amount),0)),count:expenseRows.filter(x=>x.category===category).length}));
  const memberLedgers=(db.members||[]).map(m=>memberFinancialLedger(db,m,fy));
  return {
    financialYear:fy,overview,
    incomeLedger:{total:overview.income,categorySummary:incomeCategories,rows:incomeRows},
    expenseLedger:{total:overview.expense,categorySummary:expenseCategories,rows:expenseRows},
    cashBook:buildAccountLedger(db,fy,'cash'),
    bankBook:buildAccountLedger(db,fy,'bank'),
    upiBook:buildAccountLedger(db,fy,'upi'),
    memberLedgers,
    donationLedger:donationLedgerData(db,fy),
    eventLedgers:eventLedgersData(db,fy),
    welfareLedger:welfareLedgerData(db,fy),
    loanLedger:loanLedgerData(db,fy),
    fundLedger:fundWiseLedgerData(db,fy)
  };
}
function moneyNum(v){ const n=Number(v); return Number.isFinite(n)?n:0; }
function fyMonthKeys(fy){
  const y=Number(String(fy).slice(0,4));
  const months=[];
  for(let i=0;i<12;i++){
    const d=new Date(y,3+i,1);
    months.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`);
  }
  return months;
}
function monthLabel(key){
  const [y,m]=String(key).split('-').map(Number);
  return new Date(y,m-1,1).toLocaleString('en-IN',{month:'long',year:'numeric'});
}
function memberEligibleForMonth(member, monthKey){
  if(!member || !['Active','Inactive','Suspended','Resigned'].includes(member.status||'Active')) return false;
  const [y,m]=monthKey.split('-').map(Number);
  const monthEnd=new Date(y,m,0,23,59,59);
  const join=new Date(String(member.joinDate||'').slice(0,10)+'T00:00:00');
  if(!Number.isNaN(join.getTime()) && join>monthEnd) return false;
  return true;
}
function subscriptionPaidForMonth(db, memberId, monthKey){
  let total=0, lastDate='', lastMode='';
  for(const c of db.collections){
    if(c.memberId!==memberId) continue;
    const t=String(c.type||'').toLowerCase();
    if(!t.includes('monthly membership') && !t.includes('monthly subscription')) continue;
    if(Array.isArray(c.subscriptionAllocations) && c.subscriptionAllocations.length){
      for(const a of c.subscriptionAllocations){
        if(a.month===monthKey){
          total+=moneyNum(a.amount);
          if(!lastDate || String(c.date)>lastDate){lastDate=String(c.date);lastMode=String(c.mode||'');}
        }
      }
    }else{
      // Backward compatibility for older monthly receipts: allocate to receipt month.
      if(String(c.date||'').slice(0,7)===monthKey){
        total+=moneyNum(c.amount);
        if(!lastDate || String(c.date)>lastDate){lastDate=String(c.date);lastMode=String(c.mode||'');}
      }
    }
  }
  return {paid:total,paymentDate:lastDate,paymentMode:lastMode};
}
function memberSubscriptionLedger(db, member, fy){
  const rows=[];
  for(const month of fyMonthKeys(fy)){
    const eligible=memberEligibleForMonth(member,month);
    const payable=eligible?moneyNum(member.monthlyFee):0;
    const pay=subscriptionPaidForMonth(db,member.id,month);
    const paid=Math.min(payable, moneyNum(pay.paid));
    const due=Math.max(0,payable-paid);
    const status=payable<=0?'Not Due':paid<=0?'Unpaid':paid+0.0001>=payable?'Paid':'Partial Paid';
    rows.push({
      month,monthLabel:monthLabel(month),payable,paid,due,status,
      paymentDate:pay.paymentDate,paymentMode:pay.paymentMode
    });
  }
  return rows;
}
function fyBounds(fy){
  const startYear=Number(String(fy).slice(0,4));
  return {
    start:new Date(`${startYear}-04-01T00:00:00`),
    end:new Date(`${startYear+1}-03-31T23:59:59`)
  };
}
function monthsDueForFY(joinDate, fy){
  const {start,end}=fyBounds(fy);
  const today=new Date();
  let from=new Date(String(joinDate||'').slice(0,10)+'T00:00:00');
  if(Number.isNaN(from.getTime())) from=start;
  if(from<start) from=start;
  let to=today<end?today:end;
  if(to<from) return 0;
  return (to.getFullYear()-from.getFullYear())*12 + (to.getMonth()-from.getMonth()) + 1;
}
const REPORT_CATALOG = [
  {key:'members',label:'Member List'},
  {key:'joining',label:'Joining Report'},
  {key:'subscriptions',label:'Monthly Subscription Report'},
  {key:'due',label:'Due Report'},
  {key:'donations',label:'Donation Report'},
  {key:'income',label:'Income Report'},
  {key:'expense',label:'Expense Report'},
  {key:'cash',label:'Cash Book'},
  {key:'bank',label:'Bank Book'},
  {key:'events',label:'Event Report'},
  {key:'social',label:'Social Work Report'},
  {key:'welfare',label:'Welfare Report'},
  {key:'loans',label:'Loan / Assistance Report'},
  {key:'outstanding',label:'Outstanding Report'},
  {key:'assets',label:'Asset Register'},
  {key:'funds',label:'Fund Allocation Report'},
  {key:'annual',label:'Annual Financial Summary'}
];
function reportToday(){ return new Date().toISOString().slice(0,10); }
function reportCutoff(fy){
  const b=fyBounds(fy),start=accountingDateString(b.start),end=accountingDateString(b.end),today=reportToday();
  if(today<start) return {asOfDate:dayBeforeDate(start),dueMonth:'',fyStart:start,fyEnd:end};
  const asOfDate=today>end?end:today;
  return {asOfDate,dueMonth:asOfDate.slice(0,7),fyStart:start,fyEnd:end};
}
function reportMoneySummary(label,value){ return {label,value:round2(value),kind:'money'}; }
function reportTextSummary(label,value){ return {label,value:String(value??''),kind:'text'}; }
function reportNumberSummary(label,value){ return {label,value:Number(value||0),kind:'number'}; }
function reportLoanPrincipalAt(db,loan,asOfDate){
  if(!loan?.disbursementDate || String(loan.disbursementDate)>String(asOfDate) || moneyNum(loan.disbursedAmount)<=0) return 0;
  const paid=(db.loanRepayments||[]).filter(r=>r.loanId===loan.id && String(r.date||'')<=String(asOfDate))
    .reduce((s,r)=>s+moneyNum(r.principalComponent||r.amount),0);
  return round2(Math.max(0,moneyNum(loan.disbursedAmount)-paid));
}
function reportSubscriptionDueNow(db,member,fy,dueMonth){
  if(!dueMonth) return {due:0,dueMonths:0,firstDue:'',lastDue:''};
  const rows=memberSubscriptionLedger(db,member,fy).filter(x=>x.month<=dueMonth && moneyNum(x.due)>0.001);
  return {
    due:round2(rows.reduce((s,x)=>s+moneyNum(x.due),0)),dueMonths:rows.length,
    firstDue:rows[0]?.monthLabel||'',lastDue:rows[rows.length-1]?.monthLabel||''
  };
}
function buildReport(db,type,fy){
  const cat=REPORT_CATALOG.find(x=>x.key===type);
  if(!cat) return null;
  const cut=reportCutoff(fy),generatedAt=new Date().toISOString();
  let columns=[],rows=[],summary=[],notes=[];
  const pkg=(extra={})=>({
    type,title:cat.label,financialYear:fy,asOfDate:cut.asOfDate,generatedAt,
    columns,rows,summary,notes,...extra
  });

  if(type==='members'){
    const list=(db.members||[]).filter(m=>!m.joinDate || String(m.joinDate)<=cut.fyEnd)
      .slice().sort((a,b)=>String(a.id).localeCompare(String(b.id)));
    columns=[
      {key:'id',label:'Member ID'},{key:'name',label:'Member Name'},{key:'phone',label:'Mobile'},
      {key:'membershipType',label:'Membership Type'},{key:'designation',label:'Designation'},
      {key:'joinDate',label:'Join Date',kind:'date'},{key:'status',label:'Status'},
      {key:'monthlyFee',label:'Monthly Fee',kind:'money'},{key:'address',label:'Address'}
    ];
    rows=list.map(m=>({id:m.id,name:m.name,phone:m.phone||'',membershipType:m.membershipType||'General',designation:m.designation||'Member',joinDate:m.joinDate||'',status:m.status||'',monthlyFee:moneyNum(m.monthlyFee),address:m.address||''}));
    summary=[reportNumberSummary('Members in Register',rows.length),reportNumberSummary('Currently Active',rows.filter(x=>x.status==='Active').length),reportNumberSummary('Inactive / Other',rows.filter(x=>x.status!=='Active').length)];
    notes.push('Member status shown is the current status; historical status changes are not reconstructed.');
    return pkg();
  }

  if(type==='joining'){
    const list=(db.membershipApplications||[]).filter(a=>financialYear(a.applicationDate||a.createdAt)===fy)
      .slice().sort((a,b)=>String(a.applicationDate||'').localeCompare(String(b.applicationDate||''))||String(a.id).localeCompare(String(b.id)));
    columns=[
      {key:'id',label:'Application ID'},{key:'applicationDate',label:'Application Date',kind:'date'},
      {key:'name',label:'Applicant'},{key:'phone',label:'Mobile'},{key:'membershipType',label:'Membership Type'},
      {key:'status',label:'Workflow Status'},{key:'joiningFee',label:'Joining Fee',kind:'money'},
      {key:'memberId',label:'Generated Member ID'},{key:'remarks',label:'Verification / Rejection Notes'}
    ];
    rows=list.map(a=>({id:a.id,applicationDate:a.applicationDate||'',name:a.name||'',phone:a.phone||'',membershipType:a.membershipType||'',status:a.status||'',joiningFee:moneyNum(a.joiningFee),memberId:a.memberId||'',remarks:a.rejectionReason||a.committeeNotes||a.verificationNotes||''}));
    summary=[reportNumberSummary('Applications',rows.length),reportNumberSummary('Activated / Joined',rows.filter(x=>x.status==='Active'||x.memberId).length),reportNumberSummary('Rejected',rows.filter(x=>x.status==='Rejected').length),reportMoneySummary('Joining Fee Expected',rows.reduce((s,x)=>s+moneyNum(x.joiningFee),0))];
    return pkg();
  }

  if(type==='subscriptions'){
    const list=(db.members||[]).filter(m=>memberSubscriptionLedger(db,m,fy).some(x=>moneyNum(x.payable)>0));
    columns=[
      {key:'memberId',label:'Member ID'},{key:'name',label:'Member Name'},{key:'mobile',label:'Mobile'},
      {key:'monthlyFee',label:'Monthly Fee',kind:'money'},{key:'fyPayable',label:'FY Payable',kind:'money'},
      {key:'fyPaid',label:'FY Paid',kind:'money'},{key:'fyBalance',label:'FY Balance',kind:'money'},
      {key:'currentDue',label:`Due As Of ${cut.asOfDate}`,kind:'money'},{key:'paidMonths',label:'Paid Months',kind:'number'},
      {key:'partialMonths',label:'Partial Months',kind:'number'},{key:'unpaidDueMonths',label:'Due Months',kind:'number'}
    ];
    rows=list.map(m=>{
      const ledger=memberSubscriptionLedger(db,m,fy),now=reportSubscriptionDueNow(db,m,fy,cut.dueMonth);
      return {memberId:m.id,name:m.name,mobile:m.phone||'',monthlyFee:moneyNum(m.monthlyFee),fyPayable:round2(ledger.reduce((s,x)=>s+moneyNum(x.payable),0)),fyPaid:round2(ledger.reduce((s,x)=>s+moneyNum(x.paid),0)),fyBalance:round2(ledger.reduce((s,x)=>s+moneyNum(x.due),0)),currentDue:now.due,paidMonths:ledger.filter(x=>x.status==='Paid').length,partialMonths:ledger.filter(x=>x.status==='Partial Paid').length,unpaidDueMonths:now.dueMonths};
    }).sort((a,b)=>String(a.memberId).localeCompare(String(b.memberId)));
    summary=[reportNumberSummary('Members',rows.length),reportMoneySummary('FY Payable',rows.reduce((s,x)=>s+x.fyPayable,0)),reportMoneySummary('FY Paid',rows.reduce((s,x)=>s+x.fyPaid,0)),reportMoneySummary('Current Due',rows.reduce((s,x)=>s+x.currentDue,0))];
    notes.push('FY Balance includes the full selected Financial Year; Current Due excludes future months.');
    return pkg();
  }

  if(type==='due'){
    const list=(db.members||[]).filter(m=>m.status==='Active').map(m=>({m,d:reportSubscriptionDueNow(db,m,fy,cut.dueMonth)})).filter(x=>x.d.due>0.001);
    columns=[{key:'memberId',label:'Member ID'},{key:'name',label:'Member Name'},{key:'mobile',label:'Mobile'},{key:'monthlyFee',label:'Monthly Fee',kind:'money'},{key:'dueMonths',label:'Due Months',kind:'number'},{key:'firstDue',label:'First Due Month'},{key:'lastDue',label:'Latest Due Month'},{key:'dueAmount',label:'Total Due',kind:'money'}];
    rows=list.map(x=>({memberId:x.m.id,name:x.m.name,mobile:x.m.phone||'',monthlyFee:moneyNum(x.m.monthlyFee),dueMonths:x.d.dueMonths,firstDue:x.d.firstDue,lastDue:x.d.lastDue,dueAmount:x.d.due})).sort((a,b)=>b.dueAmount-a.dueAmount);
    summary=[reportNumberSummary('Members With Due',rows.length),reportNumberSummary('Total Due Months',rows.reduce((s,x)=>s+x.dueMonths,0)),reportMoneySummary('Outstanding Subscription',rows.reduce((s,x)=>s+x.dueAmount,0)),reportTextSummary('Due Calculated As Of',cut.asOfDate)];
    return pkg();
  }

  if(type==='donations'){
    const list=inFY(db.collections||[],fy).filter(c=>c.type==='Donation').slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.id).localeCompare(String(b.id)));
    columns=[{key:'receiptNo',label:'Receipt No.'},{key:'date',label:'Date',kind:'date'},{key:'donationType',label:'Donation Type'},{key:'donor',label:'Donor Name'},{key:'mobile',label:'Mobile'},{key:'purpose',label:'Purpose'},{key:'mode',label:'Payment Mode'},{key:'amount',label:'Amount',kind:'money'}];
    rows=list.map(c=>({receiptNo:c.id,date:c.date||'',donationType:c.donationType||'',donor:c.personName||'',mobile:c.donorMobile||'',purpose:c.donationPurpose||'General Fund',mode:c.mode||'',amount:moneyNum(c.amount)}));
    summary=[reportNumberSummary('Donation Receipts',rows.length),reportMoneySummary('Total Donation',rows.reduce((s,x)=>s+x.amount,0)),reportMoneySummary('Member Donation',list.filter(x=>x.donationType==='Member').reduce((s,x)=>s+moneyNum(x.amount),0)),reportMoneySummary('External Donation',list.filter(x=>x.donationType==='External').reduce((s,x)=>s+moneyNum(x.amount),0))];
    return pkg();
  }

  if(type==='income'){
    const list=accountingIncomeRows(db,fy);
    columns=[{key:'date',label:'Date',kind:'date'},{key:'ref',label:'Receipt / Voucher'},{key:'category',label:'Category'},{key:'source',label:'Source'},{key:'mode',label:'Payment Mode'},{key:'amount',label:'Amount',kind:'money'},{key:'runningTotal',label:'Running Income',kind:'money'}];
    rows=list.map(x=>({date:x.date,ref:x.ref,category:x.category,source:x.source||x.particular,mode:x.mode||'',amount:moneyNum(x.amount),runningTotal:moneyNum(x.runningTotal)}));
    summary=[reportNumberSummary('Income Entries',rows.length),reportMoneySummary('Total Income',rows.reduce((s,x)=>s+x.amount,0))];
    return pkg();
  }

  if(type==='expense'){
    const list=accountingExpenseRows(db,fy);
    columns=[{key:'date',label:'Date',kind:'date'},{key:'ref',label:'Voucher No.'},{key:'category',label:'Category'},{key:'paidTo',label:'Paid To'},{key:'purpose',label:'Purpose'},{key:'mode',label:'Payment Mode'},{key:'amount',label:'Amount',kind:'money'},{key:'approvedBy',label:'Approved By'},{key:'resolutionNo',label:'Resolution No.'},{key:'bill',label:'Bill'},{key:'runningTotal',label:'Running Expense',kind:'money'}];
    rows=list.map(x=>({date:x.date,ref:x.ref,category:x.category,paidTo:x.paidTo,purpose:x.purpose,mode:x.mode||'',amount:moneyNum(x.amount),approvedBy:x.approvedBy||'',resolutionNo:x.resolutionNo||'',bill:x.billPath?'Attached':'No',runningTotal:moneyNum(x.runningTotal)}));
    summary=[reportNumberSummary('Expense Vouchers',rows.length),reportMoneySummary('Total Expense',rows.reduce((s,x)=>s+x.amount,0)),reportNumberSummary('Bills Attached',rows.filter(x=>x.bill==='Attached').length)];
    return pkg();
  }

  if(type==='cash'||type==='bank'){
    const key=type==='cash'?'cash':'bank',book=buildAccountLedger(db,fy,key);
    columns=[{key:'date',label:'Date',kind:'date'},{key:'ref',label:'Ref No.'},{key:'particular',label:'Particulars'},{key:'entryType',label:'Type'},{key:'inflow',label:'In',kind:'money'},{key:'outflow',label:'Out',kind:'money'},{key:'balance',label:'Running Balance',kind:'money'}];
    rows=[{date:cut.fyStart,ref:'OPENING',particular:'Opening Balance',entryType:'Opening',inflow:0,outflow:0,balance:moneyNum(book.openingBalance)},...book.rows.map(x=>({date:x.date||'',ref:x.ref||'',particular:x.particular||'',entryType:x.type||'',inflow:moneyNum(x.inflow),outflow:moneyNum(x.outflow),balance:moneyNum(x.balance)}))];
    summary=[reportTextSummary('Account',book.accountName),reportMoneySummary('Opening Balance',book.openingBalance),reportMoneySummary('Total In',book.rows.reduce((s,x)=>s+moneyNum(x.inflow),0)),reportMoneySummary('Total Out',book.rows.reduce((s,x)=>s+moneyNum(x.outflow),0)),reportMoneySummary('Closing Balance',book.closingBalance)];
    return pkg({title:type==='cash'?'Cash Book':'Bank Book'});
  }

  if(type==='events'){
    const list=inFY(db.events||[],fy).slice().sort((a,b)=>String(a.startDate||'').localeCompare(String(b.startDate||'')));
    columns=[{key:'id',label:'Event ID'},{key:'name',label:'Event Name'},{key:'startDate',label:'Start Date',kind:'date'},{key:'venue',label:'Venue'},{key:'budget',label:'Budget',kind:'money'},{key:'income',label:'Total Income',kind:'money'},{key:'expense',label:'Total Expense',kind:'money'},{key:'balance',label:'Surplus / Deficit',kind:'money'},{key:'participants',label:'Participants',kind:'number'},{key:'vendors',label:'Vendors',kind:'number'},{key:'status',label:'Status'}];
    rows=list.map(e=>{const s=eventSummary(db,e,fy);return {id:e.id,name:e.name||'',startDate:e.startDate||'',venue:e.venue||'',budget:moneyNum(e.budget),income:round2(s.totalIncome),expense:round2(s.totalExpense),balance:round2(s.finalBalance),participants:s.participants,vendors:s.vendors,status:e.status||''}});
    summary=[reportNumberSummary('Events',rows.length),reportMoneySummary('Total Budget',rows.reduce((s,x)=>s+x.budget,0)),reportMoneySummary('Total Income',rows.reduce((s,x)=>s+x.income,0)),reportMoneySummary('Total Expense',rows.reduce((s,x)=>s+x.expense,0)),reportMoneySummary('Net Balance',rows.reduce((s,x)=>s+x.balance,0))];
    return pkg();
  }

  if(type==='social'){
    const list=inFY(db.socialProjects||[],fy).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
    columns=[{key:'id',label:'Project ID'},{key:'name',label:'Project Name'},{key:'workType',label:'Social Work Type'},{key:'date',label:'Date',kind:'date'},{key:'location',label:'Location'},{key:'budget',label:'Budget',kind:'money'},{key:'expense',label:'Expense',kind:'money'},{key:'balance',label:'Budget Balance',kind:'money'},{key:'beneficiaries',label:'Beneficiaries',kind:'number'},{key:'responsible',label:'Responsible Members',kind:'number'},{key:'status',label:'Status'}];
    rows=list.map(p=>{const s=socialProjectSummary(db,p,fy);return {id:p.id,name:p.projectName||'',workType:p.socialWorkType||'',date:p.date||'',location:p.location||'',budget:moneyNum(p.budget),expense:round2(s.totalExpense),balance:round2(s.budgetBalance),beneficiaries:Number(p.beneficiaryCount||0),responsible:(p.responsibleMembers||[]).length,status:p.status||''}});
    summary=[reportNumberSummary('Social Projects',rows.length),reportMoneySummary('Total Budget',rows.reduce((s,x)=>s+x.budget,0)),reportMoneySummary('Total Expense',rows.reduce((s,x)=>s+x.expense,0)),reportNumberSummary('Total Beneficiaries',rows.reduce((s,x)=>s+x.beneficiaries,0))];
    return pkg();
  }

  if(type==='welfare'){
    const apps=inFY(db.welfareApplications||[],fy).slice().sort((a,b)=>String(a.applicationDate||'').localeCompare(String(b.applicationDate||'')));
    columns=[{key:'id',label:'Application No.'},{key:'date',label:'Application Date',kind:'date'},{key:'memberId',label:'Member ID'},{key:'memberName',label:'Member Name'},{key:'welfareType',label:'Assistance Type'},{key:'requested',label:'Requested',kind:'money'},{key:'approved',label:'Approved',kind:'money'},{key:'paid',label:'Paid',kind:'money'},{key:'outstanding',label:'Approved Outstanding',kind:'money'},{key:'status',label:'Status'},{key:'approvedBy',label:'Approved By'}];
    rows=apps.map(a=>{const paid=(db.welfarePayments||[]).filter(p=>p.applicationId===a.id && String(p.date||'')<=cut.asOfDate).reduce((s,p)=>s+moneyNum(p.amount),0);return {id:a.id,date:a.applicationDate||'',memberId:a.memberId||'',memberName:a.memberName||'',welfareType:a.welfareType||'',requested:moneyNum(a.requestedAmount),approved:moneyNum(a.approvedAmount),paid:round2(paid),outstanding:round2(Math.max(0,moneyNum(a.approvedAmount)-paid)),status:a.status||'',approvedBy:a.approvedBy||''}});
    summary=[reportNumberSummary('Applications',rows.length),reportMoneySummary('Requested',rows.reduce((s,x)=>s+x.requested,0)),reportMoneySummary('Approved',rows.reduce((s,x)=>s+x.approved,0)),reportMoneySummary('Paid',rows.reduce((s,x)=>s+x.paid,0)),reportMoneySummary('Approved Outstanding',rows.reduce((s,x)=>s+x.outstanding,0))];
    return pkg();
  }

  if(type==='loans'){
    const list=inFY(db.loans||[],fy).slice().sort((a,b)=>String(a.applicationDate||'').localeCompare(String(b.applicationDate||'')));
    columns=[{key:'id',label:'Loan / Assistance ID'},{key:'date',label:'Application Date',kind:'date'},{key:'memberId',label:'Member ID'},{key:'memberName',label:'Member Name'},{key:'requested',label:'Requested',kind:'money'},{key:'sanctioned',label:'Sanctioned',kind:'money'},{key:'disbursed',label:'Disbursed',kind:'money'},{key:'totalRepayable',label:'Total Repayable',kind:'money'},{key:'paid',label:'Paid',kind:'money'},{key:'totalOutstanding',label:'Total Outstanding',kind:'money'},{key:'principalOutstanding',label:'Principal Outstanding',kind:'money'},{key:'repaymentStatus',label:'Repayment Status'},{key:'status',label:'Workflow Status'},{key:'resolutionNo',label:'Resolution No.'}];
    rows=list.map(l=>({id:l.id,date:l.applicationDate||'',memberId:l.memberId||'',memberName:l.memberName||'',requested:moneyNum(l.requestedAmount||l.amount),sanctioned:moneyNum(l.sanctionedAmount),disbursed:moneyNum(l.disbursedAmount),totalRepayable:moneyNum(l.totalRepayable||moneyNum(l.disbursedAmount)+moneyNum(l.chargeAmount)),paid:moneyNum(l.totalPaid),totalOutstanding:loanTotalOutstanding(l),principalOutstanding:reportLoanPrincipalAt(db,l,cut.asOfDate),repaymentStatus:loanRepaymentStatus(l,cut.asOfDate),status:l.status||'',resolutionNo:l.resolutionNo||''}));
    summary=[reportNumberSummary('Applications',rows.length),reportMoneySummary('Disbursed',rows.reduce((s,x)=>s+x.disbursed,0)),reportMoneySummary('Paid',rows.reduce((s,x)=>s+x.paid,0)),reportMoneySummary('Principal Outstanding',rows.reduce((s,x)=>s+x.principalOutstanding,0)),reportNumberSummary('Overdue',rows.filter(x=>x.repaymentStatus==='Overdue').length)];
    return pkg();
  }

  if(type==='outstanding'){
    columns=[{key:'category',label:'Outstanding Type'},{key:'reference',label:'Reference'},{key:'party',label:'Member / Party'},{key:'details',label:'Details'},{key:'amount',label:'Outstanding Amount',kind:'money'},{key:'nature',label:'Nature / Position'}];
    for(const m of (db.members||[]).filter(x=>x.status==='Active')){
      const d=reportSubscriptionDueNow(db,m,fy,cut.dueMonth);
      if(d.due>0.001) rows.push({category:'Subscription Due',reference:m.id,party:m.name,details:`${d.dueMonths} due month(s)${d.firstDue?` · ${d.firstDue} to ${d.lastDue}`:''}`,amount:d.due,nature:'Receivable'});
    }
    for(const l of db.loans||[]){
      const out=reportLoanPrincipalAt(db,l,cut.asOfDate);
      if(out>0.001) rows.push({category:'Loan Principal Outstanding',reference:l.id,party:l.memberName||l.memberId||'',details:l.purpose||'',amount:out,nature:'Receivable'});
    }
    for(const a of db.welfareApplications||[]){
      if(!a.applicationDate || String(a.applicationDate)>cut.asOfDate) continue;
      const paid=(db.welfarePayments||[]).filter(p=>p.applicationId===a.id && String(p.date||'')<=cut.asOfDate).reduce((s,p)=>s+moneyNum(p.amount),0);
      const out=Math.max(0,moneyNum(a.approvedAmount)-paid);
      if(out>0.001) rows.push({category:'Approved Welfare Unpaid',reference:a.id,party:a.memberName||a.memberId||'',details:a.welfareType||'',amount:round2(out),nature:'Organization Commitment'});
    }
    rows.sort((a,b)=>a.category.localeCompare(b.category)||b.amount-a.amount);
    const receivable=rows.filter(x=>x.nature==='Receivable').reduce((s,x)=>s+x.amount,0),commitment=rows.filter(x=>x.nature!=='Receivable').reduce((s,x)=>s+x.amount,0);
    summary=[reportNumberSummary('Outstanding Records',rows.length),reportMoneySummary('Total Receivable',receivable),reportMoneySummary('Approved Welfare Commitment',commitment),reportTextSummary('As Of',cut.asOfDate)];
    notes.push('Outstanding Report separates amounts receivable by the organization from approved welfare commitments payable by the organization.');
    return pkg();
  }

  if(type==='assets'){
    const list=(db.assets||[]).filter(a=>!a.purchaseDate || String(a.purchaseDate)<=cut.fyEnd).slice().sort((a,b)=>String(a.id).localeCompare(String(b.id)));
    columns=[{key:'id',label:'Asset ID'},{key:'assetName',label:'Asset Name'},{key:'category',label:'Category'},{key:'purchaseDate',label:'Purchase Date',kind:'date'},{key:'purchaseValue',label:'Purchase Value',kind:'money'},{key:'vendor',label:'Vendor'},{key:'location',label:'Current Location'},{key:'custodian',label:'Custodian'},{key:'condition',label:'Condition'},{key:'status',label:'Status'},{key:'bill',label:'Bill'},{key:'resolutionNo',label:'Resolution No.'}];
    rows=list.map(a=>({id:a.id,assetName:a.assetName||'',category:a.category||'',purchaseDate:a.purchaseDate||'',purchaseValue:moneyNum(a.purchaseValue),vendor:a.vendor||'',location:a.currentLocation||'',custodian:a.custodianName||'',condition:a.condition||'',status:a.status||'',bill:a.billPath?'Attached':'No',resolutionNo:a.resolutionNo||''}));
    summary=[reportNumberSummary('Assets As Of FY End',rows.length),reportMoneySummary('Original Purchase Value',rows.reduce((s,x)=>s+x.purchaseValue,0)),reportNumberSummary('In Use',rows.filter(x=>x.status==='In Use').length),reportNumberSummary('Under Repair',rows.filter(x=>x.status==='Under Repair').length)];
    notes.push('Asset condition/status/location are current values; historical changes are not reconstructed.');
    return pkg();
  }

  if(type==='funds'){
    const cash=buildAccountLedger(db,fy,'cash'),bank=buildAccountLedger(db,fy,'bank'),upi=buildAccountLedger(db,fy,'upi'),available=round2(cash.closingBalance+bank.closingBalance+upi.closingBalance);
    const policy=ensureFundPolicyForFY(db,fy);
    columns=[{key:'fund',label:'Fund / Reserve'},{key:'percent',label:'Allocation %',kind:'number'},{key:'amount',label:'Allocated Amount',kind:'money'},{key:'notes',label:'Policy Notes'},{key:'resolutionNo',label:'Resolution No.'}];
    rows=policy.map(f=>({fund:f.name,percent:moneyNum(f.percent),amount:round2(available*moneyNum(f.percent)/100),notes:f.notes||'',resolutionNo:f.resolutionNo||''}));
    summary=[reportMoneySummary('Current Liquid Fund',available),reportNumberSummary('Fund Heads',rows.length),reportTextSummary('Total Allocation',`${round2(rows.reduce((s,x)=>s+x.percent,0))}%`),reportMoneySummary('Allocated Total',rows.reduce((s,x)=>s+x.amount,0))];
    notes.push('Fund allocation is an internal policy earmarking and does not itself create income, expense or transfer entries.');
    return pkg();
  }

  if(type==='annual'){
    const o=accountingOverview(db,fy),cash=buildAccountLedger(db,fy,'cash'),bank=buildAccountLedger(db,fy,'bank'),upi=buildAccountLedger(db,fy,'upi');
    const donation=donationLedgerData(db,fy),welfare=welfareLedgerData(db,fy),loan=loanLedgerData(db,fy);
    let subDue=0;for(const m of (db.members||[]).filter(x=>x.status==='Active')) subDue+=reportSubscriptionDueNow(db,m,fy,cut.dueMonth).due;
    columns=[{key:'section',label:'Section'},{key:'metric',label:'Financial Metric'},{key:'amount',label:'Amount',kind:'money'},{key:'notes',label:'Notes'}];
    rows=[
      {section:'Opening Position',metric:'Opening Liquid Balance',amount:o.openingLiquid,notes:'Cash + Bank + UPI opening'},
      {section:'Opening Position',metric:'Opening Loan Principal Receivable',amount:o.openingLoanReceivable,notes:'Principal outstanding before FY start'},
      {section:'Opening Position',metric:'Opening Fund Position',amount:o.openingBalance,notes:'Opening liquid + loan receivable'},
      {section:'Income & Expense',metric:'Total Income',amount:o.income,notes:'Accounting income for FY'},
      {section:'Income & Expense',metric:'Total Expense',amount:o.expense,notes:'Accounting expense for FY'},
      {section:'Closing Position',metric:'Closing Fund Position',amount:o.closingBalance,notes:'Opening + Income - Expense'},
      {section:'Closing Position',metric:'Cash Closing Balance',amount:cash.closingBalance,notes:cash.accountName},
      {section:'Closing Position',metric:'Bank Closing Balance',amount:bank.closingBalance,notes:bank.accountName},
      {section:'Closing Position',metric:'UPI / Other Closing Balance',amount:upi.closingBalance,notes:upi.accountName},
      {section:'Closing Position',metric:'Liquid Closing Balance',amount:o.liquidClosing,notes:'Cash + Bank + UPI'},
      {section:'Closing Position',metric:'Loan Principal Receivable',amount:o.closingLoanReceivable,notes:'Outstanding principal at FY end'},
      {section:'Reconciliation',metric:'Reconciled Closing Position',amount:o.reconciledClosing,notes:o.reconciled?'Reconciled':'Requires review'},
      {section:'Reconciliation',metric:'Reconciliation Difference',amount:o.reconciliationDifference,notes:o.reconciled?'OK':'Check accounting entries'},
      {section:'Supporting Metrics',metric:'Donation Received',amount:donation.received,notes:'Selected FY donations'},
      {section:'Supporting Metrics',metric:'Welfare Assistance Paid',amount:welfare.summary.paid,notes:'Selected FY payments'},
      {section:'Supporting Metrics',metric:'Loan Principal Disbursed',amount:loan.summary.disbursed,notes:'Selected FY'},
      {section:'Supporting Metrics',metric:'Loan Principal Recovered',amount:loan.summary.principalRecovered,notes:'Selected FY'},
      {section:'Supporting Metrics',metric:'Outstanding Subscription Due',amount:round2(subDue),notes:`As of ${cut.asOfDate}`}
    ];
    summary=[reportMoneySummary('Opening Fund Position',o.openingBalance),reportMoneySummary('Total Income',o.income),reportMoneySummary('Total Expense',o.expense),reportMoneySummary('Closing Fund Position',o.closingBalance),reportTextSummary('Reconciliation',o.reconciled?'Reconciled':'Check Difference')];
    notes.push('Annual Financial Summary follows the V2.8 accounting basis: Opening Fund Position + Income - Expense = Closing Fund Position.');
    return pkg();
  }

  return pkg();
}

function safeSetup(setup){
  const x={...(setup||{})}; delete x.passwordHash; delete x.salt;
  if(x.whatsappOtp){x.whatsappOtp={...x.whatsappOtp};delete x.whatsappOtp.accessTokenEnc;x.whatsappOtp.accessTokenConfigured=!!setup?.whatsappOtp?.accessTokenEnc;}
  return x;
}
function requestedFY(url){ return url.searchParams.get('fy') || financialYear(); }
function inFY(list, fy){ return list.filter(x => (x.financialYear || financialYear(x.date)) === fy); }
function safeName(name){
  return String(name||'file').normalize('NFKD').replace(/[^\w.\-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,100) || 'file';
}
function saveDataUrl(dataUrl, filename, maxBytes){
  const m=String(dataUrl||'').match(/^data:([^;]+);base64,(.+)$/);
  if(!m) throw new Error('Invalid file data');
  const buf=Buffer.from(m[2],'base64');
  if(buf.length>maxBytes) throw new Error(`File too large. Maximum ${Math.round(maxBytes/1024/1024)} MB.`);
  const ext=path.extname(filename||'').toLowerCase().replace(/[^.\w]/g,'');
  const stored=`${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext || ''}`;
  fs.writeFileSync(path.join(UPLOAD_DIR,stored),buf);
  return {stored, path:`/uploads/${stored}`, size:buf.length, mime:m[1]};
}
function deleteUploaded(publicPath){
  if(!publicPath || !String(publicPath).startsWith('/uploads/')) return;
  const name=path.basename(publicPath);
  const fp=path.join(UPLOAD_DIR,name);
  if(fp.startsWith(UPLOAD_DIR) && fs.existsSync(fp)) {
    try{fs.unlinkSync(fp)}catch{}
  }
}

function api(req,res,url){
  let db=loadDB();
  const pathname=url.pathname;

  if(pathname==='/api/status' && req.method==='GET'){
    return json(res,200,{
      configured:!!db.setup,
      organization:db.setup?.organizationName||'',
      owner:db.setup?.ownerName||'',
      authMode:whatsappOtpReady(db)?'whatsapp_otp':'password',
      whatsappOtpEnabled:!!db.setup?.whatsappOtp?.enabled,
      appInfo: APP_INFO
    });
  }

  if(pathname==='/api/public-site' && req.method==='GET'){
    const today=publicTodayIndia();
    const setup=db.setup||{};
    const publishedNotices=(db.notices||[])
      .filter(n=>n.status==='Published' && n.audience==='All Members')
      .filter(n=>(!n.publishFrom||n.publishFrom<=today) && (!n.publishUntil||n.publishUntil>=today))
      .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))
      .slice(0,6)
      .map(n=>({
        id:n.id||n.noticeNo||'',
        noticeNo:n.noticeNo||n.id||'',
        title:n.title||'',
        date:n.date||'',
        priority:n.priority||'Normal',
        body:n.body||'',
        attachmentOriginalName:n.attachmentOriginalName||'',
        attachmentUrl:n.attachmentPath?`/api/public-notice-attachment/${encodeURIComponent(n.id||n.noticeNo||'')}`:''
      }));

    const upcomingEvents=(db.events||[])
      .filter(e=>e.status!=='Cancelled')
      .filter(e=>String(e.endDate||e.startDate||'')>=today)
      .sort((a,b)=>String(a.startDate||'').localeCompare(String(b.startDate||'')))
      .slice(0,6)
      .map(e=>({
        id:e.id||'',
        name:e.name||'',
        startDate:e.startDate||'',
        endDate:e.endDate||e.startDate||'',
        venue:e.venue||'',
        status:e.status||'Planned',
        description:e.description||'',
        registrationOpen:!!e.registrationOpen,
        registrationDeadline:e.registrationDeadline||''
      }));

    const recentPrograms=(db.socialProjects||[])
      .filter(p=>p.status!=='Cancelled')
      .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))
      .slice(0,6)
      .map(p=>({
        id:p.id||'',
        name:p.projectName||'Social Work Program',
        type:p.socialWorkType||'Social Work',
        date:p.date||'',
        location:p.location||'',
        beneficiaryCount:Number(p.beneficiaryCount||0),
        status:p.status||'Planned',
        description:p.description||''
      }));

    return json(res,200,{
      configured:!!db.setup,
      appInfo:APP_INFO,
      organization:{
        name:setup.organizationName||PUBLIC_ORG_DEFAULTS.name,
        establishmentDate:setup.establishmentDate||'',
        registrationNo:setup.registrationNo||'',
        officeAddress:setup.officeAddress||setup.registeredAddress||PUBLIC_ORG_DEFAULTS.officeAddress,
        phone:setup.phone||PUBLIC_ORG_DEFAULTS.phone,
        email:setup.email||PUBLIC_ORG_DEFAULTS.email,
        objective:setup.objective||'',
        areaOfOperation:setup.areaOfOperation||PUBLIC_ORG_DEFAULTS.areaOfOperation,
        logoAvailable:!!setup.logoPath
      },
      stats:{
        activeMembers:(db.members||[]).filter(x=>x.status==='Active').length,
        totalMembers:(db.members||[]).length,
        upcomingEvents:upcomingEvents.length,
        publishedNotices:publishedNotices.length,
        completedSocialPrograms:(db.socialProjects||[]).filter(x=>x.status==='Completed').length
      },
      notices:publishedNotices,
      events:upcomingEvents,
      programs:recentPrograms
    });
  }

  if(pathname==='/api/public-logo' && req.method==='GET'){
    if(!db.setup?.logoPath){
      res.writeHead(404,{'Content-Type':'text/plain'});
      return res.end('No public logo');
    }
    const name=path.basename(db.setup.logoPath);
    return sendFile(res,path.join(UPLOAD_DIR,name),'public, max-age=300');
  }

  if(pathname==='/api/login-slider' && req.method==='GET'){
    const slides=(db.setup?.loginSlides||[])
      .slice()
      .sort((a,b)=>(Number(a.sortOrder||0)-Number(b.sortOrder||0)) || String(a.createdAt||'').localeCompare(String(b.createdAt||'')))
      .map(s=>({
        id:s.id,
        title:s.title||'Organization Management ERP',
        caption:s.caption||'Secure access for members, accounts, approvals and programs.',
        imageUrl:`/api/login-slider-image/${encodeURIComponent(s.id)}?v=${encodeURIComponent(s.updatedAt||s.createdAt||'')}`
      }));
    return json(res,200,{slides});
  }

  if(/^\/api\/login-slider-image\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const slide=(db.setup?.loginSlides||[]).find(x=>x.id===id);
    if(!slide?.path){
      res.writeHead(404,{'Content-Type':'text/plain'});
      return res.end('Slide image not found');
    }
    const name=path.basename(slide.path);
    return sendFile(res,path.join(UPLOAD_DIR,name),'public, max-age=300');
  }

  if(pathname==='/api/public-home-slider' && req.method==='GET'){
    const slides=(db.setup?.publicHomeSlides||[])
      .slice()
      .sort((a,b)=>(Number(a.sortOrder||0)-Number(b.sortOrder||0)) || String(a.createdAt||'').localeCompare(String(b.createdAt||'')))
      .map(s=>({
        id:s.id,
        title:s.title||'CSC VLE Network',
        caption:s.caption||'Connecting citizens with trusted CSC services and local VLE centres.',
        imageUrl:`/api/public-home-slide-image/${encodeURIComponent(s.id)}?v=${encodeURIComponent(s.updatedAt||s.createdAt||'')}`
      }));
    return json(res,200,{slides});
  }

  if(/^\/api\/public-home-slide-image\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const slide=(db.setup?.publicHomeSlides||[]).find(x=>x.id===id);
    if(!slide?.path){
      res.writeHead(404,{'Content-Type':'text/plain'});
      return res.end('Public slide image not found');
    }
    const name=path.basename(slide.path);
    return sendFile(res,path.join(UPLOAD_DIR,name),'public, max-age=300');
  }

  if(pathname==='/api/public-csc-centres' && req.method==='GET'){
    const rows=(db.members||[])
      .filter(m=>m.status==='Active' && m.publicCscVisible)
      .map(m=>({
        memberId:m.id,
        vleName:m.name||'',
        designation:m.designation||'CSC VLE',
        cscCentreName:m.cscCentreName||'CSC Centre',
        cscId:m.cscId||'',
        centreAddress:m.cscCentreAddress||'',
        area:m.cscArea||'',
        block:m.cscBlock||'',
        district:m.cscDistrict||'',
        state:m.cscState||'',
        pin:m.cscPin||'',
        phone:m.cscPhone||'',
        email:m.cscEmail||'',
        landmark:m.cscLandmark||'',
        services:m.cscServices||''
      }))
      .sort((a,b)=>String(a.cscCentreName||a.vleName).localeCompare(String(b.cscCentreName||b.vleName)));
    const blocks=[...new Set(rows.map(x=>String(x.block||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    const districts=[...new Set(rows.map(x=>String(x.district||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    return json(res,200,{rows,blocks,districts,total:rows.length});
  }


  if(/^\/api\/public-notice-attachment\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const today=publicTodayIndia();
    const n=(db.notices||[]).find(x=>x.id===id||x.noticeNo===id);
    const publicNow=!!(n && n.status==='Published' && n.audience==='All Members' &&
      (!n.publishFrom||n.publishFrom<=today) && (!n.publishUntil||n.publishUntil>=today));
    if(!publicNow||!n.attachmentPath){
      res.writeHead(404,{'Content-Type':'text/plain'});
      return res.end('Public notice attachment not found');
    }
    const name=path.basename(n.attachmentPath);
    return sendFile(res,path.join(UPLOAD_DIR,name),'public, max-age=120');
  }

  if(pathname==='/api/public-membership-application' && req.method==='POST'){
    if(!db.setup)return json(res,503,{error:'The organization management system is not configured yet. Please contact the organization.'});
    return body(req).then(d=>{
      const required=[
        ['Full Name',d.name],['Father / Guardian Name',d.fatherSpouse],['Date of Birth',d.dob],['Gender',d.gender],
        ['Mobile Number',d.phone],['WhatsApp Number',d.whatsapp],
        ['Permanent Village',d.permanentVillage],['Permanent Post Office',d.permanentPostOffice],['Permanent Police Station',d.permanentPoliceStation],
        ['Permanent GP / Ward No.',d.permanentGpWard],['Permanent Block / Municipality',d.permanentBlockMunicipality],['Permanent District',d.permanentDistrict],['Permanent State',d.permanentState],
        ['CSC ID',d.cscId],['CSC Centre Name',d.cscCentreName],
        ['Centre Village',d.centreVillage],['Centre Post Office',d.centrePostOffice],['Centre Police Station',d.centrePoliceStation],
        ['Centre GP / Ward No.',d.centreGpWard],['Centre Block / Municipality',d.centreBlockMunicipality],['Centre District',d.centreDistrict],['Centre State',d.centreState],
        ['Aadhaar Card No.',d.aadhaarNumber],['PAN Card No.',d.panNumber],['Voter Card No.',d.voterNumber],
        ['Nominee Name',d.nomineeName],['Nominee Relation',d.nomineeRelation],['Nominee Mobile',d.nomineePhone]
      ];
      const missing=required.find(x=>!String(x[1]||'').trim());
      if(missing)return json(res,400,{error:`${missing[0]} is required.`});
      if(!d.declaration)return json(res,400,{error:'You must accept the applicant declaration before submitting.'});
      const aadhaar=String(d.aadhaarNumber||'').replace(/\D/g,'');
      const pan=String(d.panNumber||'').trim().toUpperCase();
      const voter=String(d.voterNumber||'').trim().toUpperCase();
      if(!/^\d{12}$/.test(aadhaar))return json(res,400,{error:'Aadhaar Card Number must contain exactly 12 digits.'});
      if(!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan))return json(res,400,{error:'Enter a valid PAN Card Number.'});
      if(voter.length<6)return json(res,400,{error:'Enter a valid Voter Card / EPIC Number.'});
      const files=[
        ['photo','Applicant Photo',d.photoDataUrl,d.photoFilename,3*1024*1024,/\.(png|jpg|jpeg|webp)$/i],
        ['aadhaar','Aadhaar Card',d.aadhaarDataUrl,d.aadhaarFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i],
        ['pan','PAN Card',d.panDataUrl,d.panFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i],
        ['voter','Voter Card',d.voterDataUrl,d.voterFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i]
      ];
      for(const [_,label,dataUrl,filename,,pattern] of files){
        if(!dataUrl||!filename)return json(res,400,{error:`${label} upload is required.`});
        if(!pattern.test(String(filename)))return json(res,400,{error:`${label} file type is not supported.`});
      }
      const saved={};
      try{for(const [key,,dataUrl,filename,max] of files)saved[key]=saveDataUrl(dataUrl,safeName(filename),max)}
      catch(err){for(const x of Object.values(saved))if(x?.path)deleteUploaded(x.path);throw err}
      const permanentAddress=[d.permanentAddressLine,d.permanentVillage,d.permanentPostOffice,d.permanentPoliceStation,d.permanentGpWard,d.permanentBlockMunicipality,d.permanentDistrict,d.permanentState,d.permanentPin].filter(Boolean).join(', ');
      const centreAddress=[d.centreAddressLine,d.centreVillage,d.centrePostOffice,d.centrePoliceStation,d.centreGpWard,d.centreBlockMunicipality,d.centreDistrict,d.centreState,d.centrePin].filter(Boolean).join(', ');
      const declarationText="I hereby apply for membership in the organization. I declare that the information and documents provided are true and correct to the best of my knowledge. I agree to follow the organization's Constitution, Rules & Regulations, maintain discipline and transparency, and cooperate in organizational and social-welfare activities. I understand that submission does not automatically confirm membership and is subject to document verification, committee review, approval and completion of the applicable joining process.";
      const now=new Date().toISOString();
      const obj={
        id:nextApplicationCode(db),applicationDate:now.slice(0,10),
        name:String(d.name).trim(),fatherSpouse:String(d.fatherSpouse).trim(),dob:String(d.dob),gender:String(d.gender).trim(),
        phone:String(d.phone).trim(),whatsapp:String(d.whatsapp).trim(),email:String(d.email||'').trim(),address:permanentAddress,
        permanentVillage:String(d.permanentVillage).trim(),permanentPostOffice:String(d.permanentPostOffice).trim(),permanentPoliceStation:String(d.permanentPoliceStation).trim(),
        permanentGpWard:String(d.permanentGpWard).trim(),permanentBlockMunicipality:String(d.permanentBlockMunicipality).trim(),permanentDistrict:String(d.permanentDistrict).trim(),
        permanentState:String(d.permanentState).trim(),permanentPin:String(d.permanentPin||'').trim(),permanentAddressLine:String(d.permanentAddressLine||'').trim(),
        cscId:String(d.cscId).trim(),cscCentreName:String(d.cscCentreName).trim(),sameAsPermanentAddress:!!d.sameAsPermanentAddress,
        centreVillage:String(d.centreVillage).trim(),centrePostOffice:String(d.centrePostOffice).trim(),centrePoliceStation:String(d.centrePoliceStation).trim(),
        centreGpWard:String(d.centreGpWard).trim(),centreBlockMunicipality:String(d.centreBlockMunicipality).trim(),centreDistrict:String(d.centreDistrict).trim(),
        centreState:String(d.centreState).trim(),centrePin:String(d.centrePin||'').trim(),centreAddressLine:String(d.centreAddressLine||'').trim(),centreAddress,
        aadhaarNumber:aadhaar,aadhaarPath:saved.aadhaar.path,aadhaarOriginalName:safeName(d.aadhaarFilename),
        panNumber:pan,panPath:saved.pan.path,panOriginalName:safeName(d.panFilename),
        voterNumber:voter,voterPath:saved.voter.path,voterOriginalName:safeName(d.voterFilename),
        identityType:'Aadhaar / PAN / Voter',identityNumber:aadhaar,identityProofPath:saved.aadhaar.path,identityProofOriginalName:safeName(d.aadhaarFilename),
        membershipType:'General',designation:'Member',
        nomineeName:String(d.nomineeName).trim(),nomineeRelation:String(d.nomineeRelation).trim(),nomineePhone:String(d.nomineePhone).trim(),
        nomineeWhatsapp:String(d.nomineeWhatsapp||'').trim(),nomineeAddress:String(d.nomineeAddress||'').trim(),
        monthlyFee:moneyNum(db.setup.monthlyFee||0),joiningFee:moneyNum(db.setup.joiningFee||0),declaration:true,declarationText,
        photoPath:saved.photo.path,status:'Pending',verificationNotes:'',committeeNotes:'',rejectionReason:'',memberId:'',source:'Public Website',
        history:[{status:'Pending',note:'Public CSC VLE membership application submitted with KYC documents',at:now}],createdAt:now
      };
      db.membershipApplications.unshift(obj);
      attachAuditContext(db,null,req,pathname);
      audit(db,'Public Membership Application Submitted',`${obj.id} - ${obj.name}`,{recordType:'MembershipApplication',recordId:obj.id});
      saveDB(db);
      return json(res,200,{ok:true,applicationId:obj.id,status:obj.status,applicationDate:obj.applicationDate,message:'Application submitted successfully and sent for document verification.'});
    }).catch(e=>json(res,400,{error:e.message||'Unable to submit membership application'}));
  }

  if(pathname==='/api/setup' && req.method==='POST'){
    if(db.setup) return json(res,409,{error:'System already configured'});
    return body(req).then(d=>{
      if(!d.organizationName||!d.ownerName||!d.email||!d.password||String(d.password).length<6)
        return json(res,400,{error:'Please complete all fields. Password minimum 6 characters.'});
      const hp=hashPassword(String(d.password));
      db.setup={
        ...defaultProfile(),
        organizationName:String(d.organizationName).trim(),
        ownerName:String(d.ownerName).trim(),
        email:String(d.email).trim().toLowerCase(),
        adminWhatsapp:normalizeWhatsAppNumber(d.whatsapp||'','91'),
        passwordHash:hp.hash, salt:hp.salt,
        createdAt:new Date().toISOString()
      };
      const admin={
        id:nextUserCode(db),name:db.setup.ownerName,email:db.setup.email,whatsapp:db.setup.adminWhatsapp||'',passwordHash:hp.hash,salt:hp.salt,
        role:'Super Admin',memberId:'',status:'Active',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),lastLoginAt:''
      };
      db.users.push(admin);
      attachAuditContext(db,admin,req,pathname);
      audit(db,'Initial Setup','Organization account and Super Admin user created',{recordType:'User',recordId:admin.id});
      saveDB(db);
      json(res,200,{ok:true});
    }).catch(e=>json(res,400,{error:e.message||'Invalid request'}));
  }


  if(pathname==='/api/whatsapp-otp/request' && req.method==='POST'){
    return body(req).then(async d=>{
      if(!db.setup)return json(res,400,{error:'Setup required'});
      const c=whatsappOtpConfig(db);
      if(!whatsappOtpReady(db))return json(res,503,{error:'WhatsApp OTP Login is not configured or enabled by Super Admin.'});
      const normalized=normalizeWhatsAppNumber(d.whatsapp,c.defaultCountryCode);
      if(normalized.length<10||normalized.length>15)return json(res,400,{error:'Enter a valid WhatsApp number.'});
      const ip=String(req.socket?.remoteAddress||'local');
      const rate=otpRateCheck(`${normalized}|${ip}`,c.resendSeconds);
      if(!rate.ok)return json(res,429,{error:rate.error});

      const account=(db.users||[]).find(u=>u.status==='Active'&&normalizeWhatsAppNumber(u.whatsapp,c.defaultCountryCode)===normalized);
      const challengeId=crypto.randomBytes(18).toString('hex');
      const otp=String(crypto.randomInt(100000,1000000));
      const salt=crypto.randomBytes(12).toString('hex');
      const expiresAt=Date.now()+c.expiryMinutes*60*1000;

      if(account){
        try{await sendWhatsAppOtp(db,normalized,otp);}
        catch(err){
          attachAuditContext(db,null,req,pathname);
          audit(db,'WhatsApp OTP Delivery Failed',`${account.id} · ${maskedPhone(normalized)} · ${err.message}`,{recordType:'User',recordId:account.id});
          saveDB(db);
          return json(res,502,{error:`WhatsApp OTP could not be sent. ${err.message}`});
        }
      }

      OTP_RUNTIME.challenges.set(challengeId,{
        userId:account?.id||'',
        phone:normalized,
        salt,
        hash:otpHash(challengeId,otp,salt),
        attempts:0,
        expiresAt,
        used:false
      });

      attachAuditContext(db,account||null,req,pathname);
      audit(db,'WhatsApp OTP Requested',`${account?.id||'Unknown account'} · ${maskedPhone(normalized)}`,{recordType:'User',recordId:account?.id||''});
      saveDB(db);
      const out={
        ok:true,
        challengeId,
        maskedPhone:maskedPhone(normalized),
        expiresInSeconds:c.expiryMinutes*60,
        resendAfterSeconds:c.resendSeconds,
        message:'If this WhatsApp number is registered, a login OTP has been sent.'
      };
      if(process.env.WA_OTP_TEST_MODE==='1')out.debugOtp=otp;
      return json(res,200,out);
    }).catch(e=>json(res,400,{error:e.message||'Unable to request OTP'}));
  }

  if(pathname==='/api/whatsapp-otp/verify' && req.method==='POST'){
    return body(req).then(d=>{
      if(!db.setup)return json(res,400,{error:'Setup required'});
      if(!whatsappOtpReady(db))return json(res,503,{error:'WhatsApp OTP Login is not enabled.'});
      otpCleanup();
      const id=String(d.challengeId||''),code=String(d.otp||'').replace(/[^\d]/g,'');
      const c=OTP_RUNTIME.challenges.get(id);
      if(!c)return json(res,400,{error:'OTP session expired. Please request a new OTP.'});
      const settings=whatsappOtpConfig(db);
      if(c.used||Date.now()>c.expiresAt){OTP_RUNTIME.challenges.delete(id);return json(res,400,{error:'OTP expired. Please request a new OTP.'});}
      if(c.attempts>=settings.maxAttempts){OTP_RUNTIME.challenges.delete(id);return json(res,429,{error:'Too many incorrect attempts. Please request a new OTP.'});}
      c.attempts++;
      const candidate=otpHash(id,code,c.salt);
      const a=Buffer.from(candidate,'hex'),b=Buffer.from(c.hash,'hex');
      const valid=a.length===b.length&&crypto.timingSafeEqual(a,b);
      if(!valid){
        if(c.attempts>=settings.maxAttempts)OTP_RUNTIME.challenges.delete(id);
        return json(res,401,{error:`Invalid OTP. ${Math.max(0,settings.maxAttempts-c.attempts)} attempt(s) remaining.`});
      }
      const account=(db.users||[]).find(x=>x.id===c.userId&&x.status==='Active');
      if(!account){OTP_RUNTIME.challenges.delete(id);return json(res,401,{error:'Invalid or inactive user account.'});}
      c.used=true;OTP_RUNTIME.challenges.delete(id);
      const sid=crypto.randomBytes(24).toString('hex');
      account.lastLoginAt=new Date().toISOString();account.updatedAt=account.updatedAt||account.lastLoginAt;
      db.sessions[sid]={userId:account.id,email:account.email,role:account.role,createdAt:Date.now(),authMethod:'WhatsApp OTP'};
      attachAuditContext(db,account,req,pathname);audit(db,'User Login via WhatsApp OTP',`${account.name} logged in with verified WhatsApp OTP`,{recordType:'User',recordId:account.id});
      saveDB(db);
      res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':`sid=${sid}; Path=/; HttpOnly; SameSite=Lax`});
      return res.end(JSON.stringify({ok:true,role:account.role}));
    }).catch(e=>json(res,400,{error:e.message||'Unable to verify OTP'}));
  }

  if(pathname==='/api/login' && req.method==='POST'){
    return body(req).then(d=>{
      if(!db.setup) return json(res,400,{error:'Setup required'});
      if(whatsappOtpReady(db))return json(res,403,{error:'WhatsApp OTP verification is required for every login.'});
      const email=String(d.email||'').trim().toLowerCase();
      const account=(db.users||[]).find(x=>x.email===email);
      if(!account || account.status!=='Active' || !account.passwordHash || !account.salt ||
         !verifyPassword(String(d.password||''),account.salt,account.passwordHash))
        return json(res,401,{error:'Invalid email or password'});
      const sid=crypto.randomBytes(24).toString('hex');
      account.lastLoginAt=new Date().toISOString();account.updatedAt=account.updatedAt||account.lastLoginAt;
      db.sessions[sid]={userId:account.id,email:account.email,role:account.role,createdAt:Date.now()};
      attachAuditContext(db,account,req,pathname);audit(db,'User Login',`${account.name} logged in`,{recordType:'User',recordId:account.id});
      saveDB(db);
      res.writeHead(200, {'Content-Type':'application/json','Set-Cookie':`sid=${sid}; Path=/; HttpOnly; SameSite=Lax`});
      res.end(JSON.stringify({ok:true,role:account.role}));
    }).catch(e=>json(res,400,{error:e.message||'Invalid request'}));
  }

  if(pathname==='/api/logout' && req.method==='POST'){
    const sid=cookies(req).sid;const logoutUser=sessionUser(req,db);
    if(logoutUser){attachAuditContext(db,logoutUser,req,pathname);audit(db,'User Logout',`${logoutUser.name} logged out`,{recordType:'User',recordId:logoutUser.id});}
    if(sid && db.sessions[sid]) delete db.sessions[sid];
    saveDB(db);
    res.writeHead(200, {'Content-Type':'application/json','Set-Cookie':'sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax'});
    return res.end(JSON.stringify({ok:true}));
  }

  if(pathname==='/api/me' && req.method==='GET'){
    const u=requireAuth(req,res,db); if(!u) return;
    const linkedMember=u.memberId?(db.members||[]).find(x=>x.id===u.memberId):null;
    return json(res,200,{
      ownerName:u.name,email:u.email,organizationName:db.setup.organizationName,logoPath:db.setup.logoPath||'',
      profilePhotoPath:linkedMember?.photoPath||'',
      memberProfile:linkedMember?{
        id:linkedMember.id,
        name:linkedMember.name,
        designation:linkedMember.designation||'',
        membershipType:linkedMember.membershipType||'',
        status:linkedMember.status||''
      }:null,
      user:{...safeUser(u),pages:rolePages(u.role),roleDescription:ROLE_DESCRIPTIONS[u.role]||''},
      appInfo: APP_INFO
    });
  }

  const user=requireAuth(req,res,db); if(!user) return;
  attachAuditContext(db,user,req,pathname);

  if(pathname==='/api/my-password' && req.method==='POST'){
    return body(req).then(d=>{
      const currentPassword=String(d.currentPassword||'');
      const newPassword=String(d.newPassword||'');
      if(!user.passwordHash||!user.salt||!verifyPassword(currentPassword,user.salt,user.passwordHash))
        return json(res,400,{error:'Current password is incorrect.'});
      if(newPassword.length<6)return json(res,400,{error:'New password minimum 6 characters.'});
      if(currentPassword===newPassword)return json(res,400,{error:'New password must be different from the current password.'});
      const hp=hashPassword(newPassword);
      user.passwordHash=hp.hash;user.salt=hp.salt;user.mustChangePassword=false;user.updatedAt=new Date().toISOString();
      const sid=cookies(req).sid;
      for(const id of Object.keys(db.sessions||{}))if(db.sessions[id].userId===user.id && id!==sid)delete db.sessions[id];
      audit(db,'Password Changed',`${user.id} changed own password`,{recordType:'User',recordId:user.id});
      saveDB(db);
      return json(res,200,{ok:true});
    }).catch(e=>json(res,400,{error:e.message||'Unable to change password'}));
  }

  if(!authorizeApi(user,req,res,pathname,url)) return;
  const fy=requestedFY(url);

  if(pathname==='/api/financial-years' && req.method==='GET'){
    const years=new Set();
    const nowStart=Number(financialYear().slice(0,4));
    for(let y=nowStart-5;y<=nowStart+2;y++) years.add(`${y}-${String(y+1).slice(-2)}`);
    for(const list of [db.collections,db.transactions,db.loans,db.events,db.notices,db.documentLibrary,db.issuedDocuments,db.reminders,db.grievances,db.elections,db.budgetPlans,db.annualAudits,db.funds])
      for(const x of list) years.add(x.financialYear||financialYear(x.date));
    return json(res,200,{current:financialYear(),years:[...years].sort().reverse()});
  }


  if(pathname==='/api/users' && req.method==='GET'){
    return json(res,200,{roles:USER_ROLES,roleDescriptions:ROLE_DESCRIPTIONS,users:(db.users||[]).map(safeUser)});
  }

  if(pathname==='/api/users' && req.method==='POST'){
    return body(req).then(d=>{
      const name=String(d.name||'').trim();
      const email=String(d.email||'').trim().toLowerCase();
      const whatsapp=String(d.whatsapp||'').trim();
      const role=String(d.role||'General Member').trim();
      const memberId=String(d.memberId||'').trim();

      if(!memberId)return json(res,400,{error:'Select a Member before creating the user.'});
      const member=(db.members||[]).find(m=>m.id===memberId);
      if(!member)return json(res,400,{error:'Selected Member ID was not found.'});
      if(member.status!=='Active')return json(res,400,{error:'Only an Active Member can be linked to a new user account.'});

      if(!name)return json(res,400,{error:'Name is required.'});
      if(!email)return json(res,400,{error:'Login Email is required.'});
      if(!USER_ROLES.includes(role))return json(res,400,{error:'Select a valid User Role.'});

      if((db.users||[]).some(u=>String(u.email||'').toLowerCase()===email))
        return json(res,400,{error:'Login Email already exists.'});

      if(whatsapp && (db.users||[]).some(u=>String(u.whatsapp||'').trim()===whatsapp))
        return json(res,400,{error:'WhatsApp Login Number already exists.'});

      if((db.users||[]).some(u=>u.memberId===memberId && u.status==='Active'))
        return json(res,400,{error:'This Member already has an Active linked user account.'});

      if(role==='Super Admin' && (db.users||[]).some(u=>u.role==='Super Admin'&&u.status==='Active'))
        return json(res,400,{error:'Only one Active Super Admin is allowed.'});

      const ph=hashPassword(DEFAULT_USER_PASSWORD);
      const now=new Date().toISOString();
      const obj={
        id:nextUserCode(db),
        name,
        email,
        whatsapp,
        role,
        memberId,
        status:'Active',
        passwordHash:ph.hash,
        salt:ph.salt,
        mustChangePassword:true,
        createdAt:now,
        updatedAt:now,
        lastLogin:''
      };

      db.users.unshift(obj);
      audit(db,'User Created',`${obj.id} - ${obj.name} - ${obj.role} - Linked ${memberId} - Default password assigned`,{recordType:'User',recordId:obj.id});
      saveDB(db);
      return json(res,200,safeUser(obj));
    }).catch(e=>json(res,400,{error:e.message||'Unable to create user'}));
  }

  if(/^\/api\/users\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);const target=db.users.find(x=>x.id===id);
    if(!target)return json(res,404,{error:'User not found'});
    return body(req).then(d=>{
      const before=safeUser(target),changes=[];
      if(d.name!==undefined){const v=String(d.name||'').trim();if(!v)return json(res,400,{error:'Name is required'});if(v!==target.name){target.name=v;changes.push('Name');}}
      if(d.email!==undefined){const v=String(d.email||'').trim().toLowerCase();if(!v)return json(res,400,{error:'Email is required'});if(db.users.some(x=>x.id!==id&&x.email===v))return json(res,409,{error:'Email already used'});if(v!==target.email){target.email=v;changes.push('Email');}}
      if(d.whatsapp!==undefined){
        const v=normalizeWhatsAppNumber(d.whatsapp||'',db.setup?.whatsappOtp?.defaultCountryCode||'91');
        if(v&&db.users.some(x=>x.id!==id&&normalizeWhatsAppNumber(x.whatsapp,db.setup?.whatsappOtp?.defaultCountryCode||'91')===v))return json(res,409,{error:'WhatsApp login number already used'});
        if(db.setup?.whatsappOtp?.enabled&&!v)return json(res,400,{error:'WhatsApp Login Number is required while WhatsApp OTP Login is enabled'});
        if(v!==target.whatsapp){target.whatsapp=v;changes.push('WhatsApp Login Number');}
      }
      if(d.role!==undefined){const v=String(d.role);if(!USER_ROLES.includes(v))return json(res,400,{error:'Invalid Role'});if(v!==target.role){target.role=v;changes.push(`Role ${before.role} → ${v}`);}}
      if(d.memberId!==undefined){const v=String(d.memberId||'').trim();if(v&&!db.members.some(x=>x.id===v))return json(res,400,{error:'Linked Member ID not found'});if(v&&db.users.some(x=>x.id!==id&&x.memberId===v&&x.status==='Active'))return json(res,409,{error:'Member ID already linked to active user'});if(v!==target.memberId){target.memberId=v;changes.push('Member Link');}}
      if(target.role==='General Member'&&!target.memberId)return json(res,400,{error:'General Member user must be linked to a Member ID'});
      if(d.status!==undefined){const v=String(d.status);if(!['Active','Disabled'].includes(v))return json(res,400,{error:'Invalid user status'});if(v!==target.status){target.status=v;changes.push(`Status ${before.status} → ${v}`);}}
      if(d.newPassword){if(String(d.newPassword).length<6)return json(res,400,{error:'Password minimum 6 characters'});const hp=hashPassword(String(d.newPassword));target.passwordHash=hp.hash;target.salt=hp.salt;target.mustChangePassword=true;changes.push('Password Reset');}
      const activeSupers=db.users.filter(x=>x.status==='Active'&&x.role==='Super Admin'&&x.id!==target.id);
      if(before.role==='Super Admin'&&before.status==='Active'&&(target.role!=='Super Admin'||target.status!=='Active')&&activeSupers.length===0)
        return json(res,400,{error:'At least one active Super Admin account is required'});
      target.updatedAt=new Date().toISOString();
      if(d.newPassword||target.status==='Disabled'||target.role!==before.role){for(const sid of Object.keys(db.sessions))if(db.sessions[sid].userId===target.id)delete db.sessions[sid];}
      audit(db,'User Account Updated',`${target.id} ${target.name}: ${changes.join(', ')||'No material field change'}`,{recordType:'User',recordId:target.id});
      saveDB(db);json(res,200,safeUser(target));
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/audit-log' && req.method==='GET'){
    const limit=Math.min(1000,Math.max(20,Number(url.searchParams.get('limit')||300)));
    const role=String(url.searchParams.get('role')||'').trim(),q=String(url.searchParams.get('q')||'').trim().toLowerCase();
    let rows=(db.audit||[]).slice();
    if(role)rows=rows.filter(x=>x.actorRole===role);
    if(q)rows=rows.filter(x=>`${x.actorName} ${x.actorEmail} ${x.actorRole} ${x.action} ${x.detail} ${x.path}`.toLowerCase().includes(q));
    return json(res,200,{total:rows.length,rows:rows.slice(0,limit),roles:USER_ROLES});
  }

  if(pathname==='/api/my-portal' && req.method==='GET'){
    const memberId=String(user.memberId||'');
    const member=db.members.find(x=>x.id===memberId);
    if(!member)return json(res,404,{error:'This user is not linked to a valid Member record'});
    const today=new Date().toISOString().slice(0,10);
    const ledger=memberSubscriptionLedger(db,member,fy);
    const receipts=inFY(db.collections||[],fy).filter(x=>x.memberId===memberId).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
    const donations=receipts.filter(x=>String(x.type||'').toLowerCase()==='donation').map(x=>({
      id:x.id,date:x.date||'',purpose:x.donationPurpose||x.purpose||'General Fund',mode:x.mode||'',amount:moneyNum(x.amount),notes:x.notes||''
    }));
    const loans=(db.loans||[]).filter(x=>x.memberId===memberId).map(x=>{
      const schedule=loanInstallmentSchedule(x,today);
      const nextInstallment=schedule.find(r=>r.due>0.001)||null;
      return {
        id:x.id,applicationDate:x.applicationDate||'',purpose:x.purpose||'',requestedAmount:moneyNum(x.requestedAmount||x.amount),
        sanctionedAmount:moneyNum(x.sanctionedAmount),disbursedAmount:moneyNum(x.disbursedAmount),chargeAmount:moneyNum(x.chargeAmount),
        totalRepayable:moneyNum(x.totalRepayable),totalPaid:moneyNum(x.totalPaid),principalOutstanding:loanOutstandingAmount(x),outstanding:loanTotalOutstanding(x),
        status:x.status||'',repaymentStatus:loanRepaymentStatus(x,today),repaymentPeriod:Number(x.repaymentPeriod||0),
        nextInstallment:nextInstallment?{installmentNo:nextInstallment.installmentNo,dueDate:nextInstallment.dueDate,due:nextInstallment.due,status:nextInstallment.status}:null
      };
    }).sort((a,b)=>String(b.applicationDate).localeCompare(String(a.applicationDate)));
    const welfare=(db.welfareApplications||[]).filter(x=>x.memberId===memberId).map(x=>({
      id:x.id,applicationDate:x.applicationDate||'',welfareType:x.welfareType||'',purpose:x.purpose||'',requestedAmount:moneyNum(x.requestedAmount),
      approvedAmount:moneyNum(x.approvedAmount),paidAmount:moneyNum(x.paidAmount),outstandingApproved:Math.max(0,round2(moneyNum(x.approvedAmount)-moneyNum(x.paidAmount))),status:x.status||'',rejectionReason:x.rejectionReason||''
    })).sort((a,b)=>String(b.applicationDate).localeCompare(String(a.applicationDate)));
    const joining=(db.membershipApplications||[]).filter(x=>x.memberId===memberId||x.id===member.sourceApplication).map(x=>({
      id:x.id,date:x.applicationDate||x.createdAt||'',status:x.status||'',membershipType:x.membershipType||'',memberId:x.memberId||'',joiningFee:moneyNum(x.joiningFee),rejectionReason:x.rejectionReason||''
    }));
    const events=inFY(db.events||[],fy).filter(x=>x.status!=='Cancelled').map(e=>{
      const participant=(e.participants||[]).find(p=>p.memberId===memberId),registration=(e.registrations||[]).find(r=>r.memberId===memberId&&r.status!=='Cancelled');
      return {id:e.id,name:e.name||'',startDate:e.startDate||'',endDate:e.endDate||e.startDate||'',venue:e.venue||'',description:e.description||'',status:e.status||'Planned',participating:!!participant,participantRole:participant?.role||'',registrationOpen:!!e.registrationOpen,registrationDeadline:e.registrationDeadline||'',capacity:Number(e.capacity||0),registered:!!registration,registrationStatus:registration?.status||'',registrationId:registration?.id||'',registrationCount:(e.registrations||[]).filter(r=>r.status!=='Cancelled').length};
    }).sort((a,b)=>String(a.startDate).localeCompare(String(b.startDate)));
    const notices=inFY(db.notices||[],fy).filter(n=>noticeVisibleToMember(db,n,member,today)).map(n=>({
      id:n.id,noticeNo:n.noticeNo,title:n.title,date:n.date,publishFrom:n.publishFrom,publishUntil:n.publishUntil,priority:n.priority,audience:n.audience,
      body:n.body,attachmentPath:n.attachmentPath||'',attachmentOriginalName:n.attachmentOriginalName||''
    })).sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.noticeNo).localeCompare(String(a.noticeNo)));
    const grievances=inFY(db.grievances||[],fy).filter(x=>x.memberId===memberId).map(x=>({id:x.id,category:x.category,subject:x.subject,description:x.description,priority:x.priority,status:x.status,assignedTo:x.assignedTo,response:x.response,resolution:x.resolution,attachmentPath:x.attachmentPath||'',createdAt:x.createdAt,updatedAt:x.updatedAt})).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
    const issuedDocuments=inFY(db.issuedDocuments||[],fy).filter(x=>x.memberId===memberId).map(x=>({...x,eventName:db.events.find(e=>e.id===x.eventId)?.name||''})).sort((a,b)=>String(b.issueDate).localeCompare(String(a.issueDate)));
    const reminders=inFY(db.reminders||[],fy).filter(x=>x.memberId===memberId&&x.status!=='Cancelled').map(x=>({id:x.id,type:x.type,channel:x.channel,message:x.message,dueAmount:x.dueAmount,scheduledDate:x.scheduledDate,status:x.status,sentAt:x.sentAt})).sort((a,b)=>String(b.scheduledDate).localeCompare(String(a.scheduledDate)));
    const elections=inFY(db.elections||[],fy).filter(x=>['Voting Open','Closed','Published'].includes(x.status)).map(x=>electionPublicView(x,memberId,false));
    const nominees=(member.nominees||[]).map(x=>({...x}));
    const paid=round2(ledger.reduce((sum,x)=>sum+moneyNum(x.paid),0)),due=round2(ledger.reduce((sum,x)=>sum+moneyNum(x.due),0)),payable=round2(ledger.reduce((sum,x)=>sum+moneyNum(x.payable),0));
    const totalDonation=round2(donations.reduce((sum,x)=>sum+moneyNum(x.amount),0));
    return json(res,200,{
      financialYear:fy,
      organization:{name:db.setup.organizationName,logoPath:db.setup.logoPath||'',phone:db.setup.phone||'',email:db.setup.email||'',address:db.setup.officeAddress||db.setup.registeredAddress||''},
      profile:{
        id:member.id,name:member.name,photoPath:member.photoPath||'',fatherSpouse:member.fatherSpouse||'',dob:member.dob||'',phone:member.phone||'',email:member.email||'',address:member.address||'',
        joinDate:member.joinDate||'',membershipType:member.membershipType||'',designation:member.designation||'',status:member.status||'',monthlyFee:moneyNum(member.monthlyFee||db.setup.monthlyFee),
        emergencyName:member.emergencyName||'',emergencyPhone:member.emergencyPhone||'',emergencyRelation:member.emergencyRelation||'',sourceApplication:member.sourceApplication||''
      },
      membership:{status:member.status||'',membershipType:member.membershipType||'',designation:member.designation||'',joinDate:member.joinDate||'',membershipMonths:fullMembershipMonths(member.joinDate,today),monthlyFee:moneyNum(member.monthlyFee||db.setup.monthlyFee)},
      subscription:{payable,paid,due,ledger},
      donation:{total:totalDonation,count:donations.length,rows:donations},
      receipts,loans,welfare,joining,events,notices,nominees,grievances,issuedDocuments,reminders,elections,
      summary:{receiptCount:receipts.length,donationTotal:totalDonation,welfareCount:welfare.length,loanCount:loans.length,eventCount:events.length,noticeCount:notices.length,nomineeCount:nominees.length,grievanceCount:grievances.length,certificateCount:issuedDocuments.length,reminderCount:reminders.length,electionCount:elections.length}
    });
  }

  // ---- V3.3 Member self-service endpoints ----
  if(pathname==='/api/my-portal/nominees' && req.method==='POST'){
    const member=db.members.find(x=>x.id===user.memberId);if(!member)return json(res,404,{error:'Linked Member not found'});
    return body(req).then(d=>{const share=Math.max(0,Math.min(100,moneyNum(d.sharePercent)));const current=(member.nominees||[]).reduce((s,x)=>s+moneyNum(x.sharePercent),0);if(current+share>100.001)return json(res,400,{error:'Total nominee share cannot exceed 100%'});const obj={id:uid('NOM'),name:String(d.name||'').trim(),relation:String(d.relation||'').trim(),dob:String(d.dob||''),phone:String(d.phone||'').trim(),address:String(d.address||'').trim(),sharePercent:share,isPrimary:!!d.isPrimary,notes:String(d.notes||'').trim()};if(!obj.name||!obj.relation)return json(res,400,{error:'Nominee Name and Relation are required'});if(obj.isPrimary)for(const n of member.nominees||[])n.isPrimary=false;member.nominees.push(obj);audit(db,'Member Nominee Added',`${member.id} ${obj.name}`,{recordType:'Nominee',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/my-portal\/nominees\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[4]),member=db.members.find(x=>x.id===user.memberId);if(!member)return json(res,404,{error:'Member not found'});const nom=(member.nominees||[]).find(x=>x.id===id);if(!nom)return json(res,404,{error:'Nominee not found'});
    return body(req).then(d=>{const other=(member.nominees||[]).filter(x=>x.id!==id).reduce((s,x)=>s+moneyNum(x.sharePercent),0);const share=d.sharePercent!==undefined?moneyNum(d.sharePercent):moneyNum(nom.sharePercent);if(other+share>100.001)return json(res,400,{error:'Total nominee share cannot exceed 100%'});for(const k of ['name','relation','dob','phone','address','notes'])if(d[k]!==undefined)nom[k]=String(d[k]||'').trim();if(d.sharePercent!==undefined)nom.sharePercent=share;if(d.isPrimary!==undefined){nom.isPrimary=!!d.isPrimary;if(nom.isPrimary)for(const n of member.nominees||[])if(n.id!==id)n.isPrimary=false;}audit(db,'Member Nominee Updated',`${member.id} ${nom.name}`,{recordType:'Nominee',recordId:id});saveDB(db);json(res,200,nom);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/my-portal\/nominees\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const id=decodeURIComponent(pathname.split('/')[4]),member=db.members.find(x=>x.id===user.memberId);if(!member)return json(res,404,{error:'Member not found'});member.nominees=(member.nominees||[]).filter(x=>x.id!==id);audit(db,'Member Nominee Removed',`${member.id} ${id}`,{recordType:'Nominee',recordId:id});saveDB(db);return json(res,200,{ok:true});
  }
  if(pathname==='/api/my-portal/grievances' && req.method==='POST'){
    const member=db.members.find(x=>x.id===user.memberId);if(!member)return json(res,404,{error:'Member not found'});
    return body(req).then(d=>{const date=new Date().toISOString(),fyValue=d.financialYear||fy;let attachmentPath='',attachmentOriginalName='';if(d.attachmentDataUrl){const filename=safeName(d.attachmentFilename||'attachment');if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))return json(res,400,{error:'Invalid attachment type'});const saved=saveDataUrl(d.attachmentDataUrl,filename,10*1024*1024);attachmentPath=saved.path;attachmentOriginalName=filename;}const obj={id:nextFYCode(db.grievances,'GRV',fyValue,'createdAt'),memberId:member.id,memberName:member.name,category:GRIEVANCE_CATEGORIES.includes(String(d.category))?String(d.category):'Other',subject:String(d.subject||'').trim(),description:String(d.description||'').trim(),priority:['Normal','Important','Urgent'].includes(String(d.priority))?String(d.priority):'Normal',status:'Open',assignedTo:'',response:'',resolution:'',attachmentPath,attachmentOriginalName,financialYear:fyValue,createdAt:date,updatedAt:date,closedAt:''};if(!obj.subject||!obj.description)return json(res,400,{error:'Subject and Description are required'});db.grievances.unshift(obj);audit(db,'Grievance Submitted',`${obj.id} ${member.id} ${obj.subject}`,{recordType:'Grievance',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/my-portal\/events\/[^/]+\/register$/.test(pathname)){
    const eventId=decodeURIComponent(pathname.split('/')[4]),event=(db.events||[]).find(x=>x.id===eventId),member=db.members.find(x=>x.id===user.memberId);if(!event||!member)return json(res,404,{error:'Event or Member not found'});
    if(req.method==='POST')return body(req).then(d=>{const today=new Date().toISOString().slice(0,10);if(!event.registrationOpen)return json(res,400,{error:'Event registration is not open'});if(event.registrationDeadline&&event.registrationDeadline<today)return json(res,400,{error:'Registration deadline has passed'});const active=(event.registrations||[]).filter(x=>x.status!=='Cancelled');if(event.capacity>0&&active.length>=event.capacity)return json(res,400,{error:'Event registration capacity is full'});const existing=(event.registrations||[]).find(x=>x.memberId===member.id&&x.status!=='Cancelled');if(existing)return json(res,409,{error:'You are already registered'});const obj={id:nextFYCode((db.events||[]).flatMap(e=>e.registrations||[]),'EVR',event.financialYear||fy,'date'),memberId:member.id,memberName:member.name,phone:member.phone||'',date:today,status:'Registered',notes:String(d.notes||'').trim(),source:'Member Portal'};event.registrations.push(obj);audit(db,'Event Self Registration',`${event.id} ${member.id} ${obj.id}`,{recordType:'EventRegistration',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
    if(req.method==='DELETE'){const reg=(event.registrations||[]).find(x=>x.memberId===member.id&&x.status==='Registered');if(!reg)return json(res,404,{error:'Active registration not found'});reg.status='Cancelled';reg.cancelledAt=new Date().toISOString();audit(db,'Event Registration Cancelled',`${event.id} ${member.id} ${reg.id}`,{recordType:'EventRegistration',recordId:reg.id});saveDB(db);return json(res,200,{ok:true});}
  }
  if(/^\/api\/my-portal\/elections\/[^/]+\/vote$/.test(pathname) && req.method==='POST'){
    const electionId=decodeURIComponent(pathname.split('/')[4]),election=(db.elections||[]).find(x=>x.id===electionId),member=db.members.find(x=>x.id===user.memberId);if(!election||!member)return json(res,404,{error:'Election or Member not found'});if(election.status!=='Voting Open')return json(res,400,{error:'Voting is not open'});
    return body(req).then(d=>{const position=(election.positions||[]).find(x=>x.id===d.positionId);if(!position)return json(res,400,{error:'Position not found'});if((position.voterIds||[]).includes(member.id))return json(res,409,{error:'You have already voted for this position'});const candidate=(position.candidates||[]).find(x=>x.id===d.candidateId&&x.status==='Approved');if(!candidate)return json(res,400,{error:'Candidate not found'});candidate.votes=Number(candidate.votes||0)+1;position.voterIds ||= [];position.voterIds.push(member.id);election.updatedAt=new Date().toISOString();audit(db,'Election Vote Cast',`${election.id} ${position.name} voter ${member.id}`,{recordType:'Election',recordId:election.id});saveDB(db);json(res,200,{ok:true,positionId:position.id});}).catch(e=>json(res,400,{error:e.message}));
  }

  // ---- Document Management ----
  if(pathname==='/api/document-library' && req.method==='GET'){
    const rows=(db.documentLibrary||[]).filter(x=>(x.financialYear||fy)===fy).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));return json(res,200,{financialYear:fy,categories:DOCUMENT_CATEGORIES,audiences:DOCUMENT_AUDIENCES,summary:{total:rows.length,expiring:rows.filter(x=>x.expiryDate&&x.expiryDate>=new Date().toISOString().slice(0,10)).length,memberLinked:rows.filter(x=>x.memberId).length},rows});
  }
  if(pathname==='/api/document-library' && req.method==='POST'){
    return body(req).then(d=>{const filename=safeName(d.filename||'document');if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx|xls|xlsx)$/i.test(filename))return json(res,400,{error:'Allowed: PDF, Image, DOC/DOCX, XLS/XLSX'});const saved=saveDataUrl(d.dataUrl,filename,15*1024*1024);const date=d.date||new Date().toISOString().slice(0,10),fyValue=d.financialYear||financialYear(date);const obj={id:nextFYCode(db.documentLibrary,'DOC',fyValue),title:String(d.title||filename).trim(),category:DOCUMENT_CATEGORIES.includes(String(d.category))?String(d.category):'Other',documentNo:String(d.documentNo||'').trim(),date,expiryDate:String(d.expiryDate||''),audience:DOCUMENT_AUDIENCES.includes(String(d.audience))?String(d.audience):'Internal',memberId:String(d.memberId||'').trim(),version:String(d.version||'1.0').trim(),description:String(d.description||'').trim(),path:saved.path,originalName:filename,size:saved.size,status:'Active',financialYear:fyValue,createdBy:user.name,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};if(obj.memberId&&!db.members.some(x=>x.id===obj.memberId))return json(res,400,{error:'Linked Member ID not found'});db.documentLibrary.unshift(obj);audit(db,'Document Library Upload',`${obj.id} ${obj.title}`,{recordType:'Document',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/document-library\/[^/]+$/.test(pathname) && req.method==='DELETE'){const id=decodeURIComponent(pathname.split('/')[3]),doc=db.documentLibrary.find(x=>x.id===id);if(!doc)return json(res,404,{error:'Document not found'});deleteUploaded(doc.path);db.documentLibrary=db.documentLibrary.filter(x=>x.id!==id);audit(db,'Document Library Delete',`${id} ${doc.title}`,{recordType:'Document',recordId:id});saveDB(db);return json(res,200,{ok:true});}

  // ---- Certificate / ID Generation ----
  if(pathname==='/api/issued-documents' && req.method==='GET'){
    const rows=inFY(db.issuedDocuments||[],fy).map(x=>({...x,member:db.members.find(m=>m.id===x.memberId)||null,event:db.events.find(e=>e.id===x.eventId)||null})).sort((a,b)=>String(b.issueDate).localeCompare(String(a.issueDate)));return json(res,200,{types:CERTIFICATE_TYPES,rows,summary:{total:rows.length,idCards:rows.filter(x=>x.type==='Member ID Card').length,certificates:rows.filter(x=>x.type!=='Member ID Card').length}});
  }
  if(pathname==='/api/issued-documents' && req.method==='POST'){
    return body(req).then(d=>{const member=db.members.find(x=>x.id===d.memberId);if(!member)return json(res,400,{error:'Select a valid Member'});const type=CERTIFICATE_TYPES.includes(String(d.type))?String(d.type):'General Certificate';const issueDate=d.issueDate||new Date().toISOString().slice(0,10),fyValue=d.financialYear||financialYear(issueDate);const event=d.eventId?db.events.find(x=>x.id===d.eventId):null;if(type==='Event Participation Certificate'&&!event)return json(res,400,{error:'Select a valid Event'});const id=nextFYCode(db.issuedDocuments,type==='Member ID Card'?'IDC':'CERT',fyValue,'issueDate');const obj={id,type,memberId:member.id,eventId:event?.id||'',title:String(d.title||type).trim(),issueDate,certificateNo:id,notes:String(d.notes||'').trim(),financialYear:fyValue,issuedBy:user.name,createdAt:new Date().toISOString()};db.issuedDocuments.unshift(obj);audit(db,'Certificate / ID Issued',`${obj.certificateNo} ${obj.type} ${member.id}`,{recordType:'IssuedDocument',recordId:obj.id});saveDB(db);json(res,200,{...obj,member,event});}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/issued-documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){const id=decodeURIComponent(pathname.split('/')[3]);db.issuedDocuments=db.issuedDocuments.filter(x=>x.id!==id);audit(db,'Issued Document Cancelled',id,{recordType:'IssuedDocument',recordId:id});saveDB(db);return json(res,200,{ok:true});}

  // ---- Reminder Center ----
  if(pathname==='/api/reminders' && req.method==='GET'){
    const rows=inFY(db.reminders||[],fy).slice().sort((a,b)=>String(b.scheduledDate).localeCompare(String(a.scheduledDate)));return json(res,200,{types:REMINDER_TYPES,channels:REMINDER_CHANNELS,summary:{total:rows.length,pending:rows.filter(x=>x.status==='Pending').length,sent:rows.filter(x=>x.status==='Sent').length,dueAmount:round2(rows.filter(x=>x.type==='Member Due'&&x.status==='Pending').reduce((s,x)=>s+moneyNum(x.dueAmount),0))},rows});
  }
  if(pathname==='/api/reminders' && req.method==='POST'){
    return body(req).then(d=>{const member=d.memberId?db.members.find(x=>x.id===d.memberId):null;if(d.memberId&&!member)return json(res,400,{error:'Member not found'});const scheduledDate=d.scheduledDate||new Date().toISOString().slice(0,10),fyValue=d.financialYear||financialYear(scheduledDate);const obj={id:nextFYCode(db.reminders,'REM',fyValue,'scheduledDate'),type:REMINDER_TYPES.includes(String(d.type))?String(d.type):'General',memberId:member?.id||'',memberName:member?.name||String(d.memberName||'').trim(),eventId:String(d.eventId||''),channel:REMINDER_CHANNELS.includes(String(d.channel))?String(d.channel):'WhatsApp',phone:member?.phone||String(d.phone||'').trim(),message:String(d.message||'').trim(),dueAmount:moneyNum(d.dueAmount),scheduledDate,status:'Pending',sentAt:'',financialYear:fyValue,createdAt:new Date().toISOString(),createdBy:user.name};if(!obj.message)return json(res,400,{error:'Reminder message is required'});db.reminders.unshift(obj);audit(db,'Reminder Created',`${obj.id} ${obj.type} ${obj.memberId||obj.phone}`,{recordType:'Reminder',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(pathname==='/api/reminders/generate-dues' && req.method==='POST'){
    return body(req).then(d=>{const asOf=d.asOfDate||new Date().toISOString().slice(0,10),channel=REMINDER_CHANNELS.includes(String(d.channel))?String(d.channel):'WhatsApp';let created=0,skipped=0;for(const m of (db.members||[]).filter(x=>x.status==='Active')){const due=memberDueAsOf(db,m,fy,asOf);if(due<=0.001){skipped++;continue;}const duplicate=(db.reminders||[]).find(x=>x.financialYear===fy&&x.type==='Member Due'&&x.memberId===m.id&&x.status==='Pending');if(duplicate){skipped++;continue;}const obj={id:nextFYCode(db.reminders,'REM',fy,'scheduledDate'),type:'Member Due',memberId:m.id,memberName:m.name,eventId:'',channel,phone:m.phone||'',message:`Dear ${m.name}, your membership subscription due for FY ${fy} is ₹${due.toFixed(2)}. Please pay at the organization office / approved payment channel.`,dueAmount:due,scheduledDate:asOf,status:'Pending',sentAt:'',financialYear:fy,createdAt:new Date().toISOString(),createdBy:user.name};db.reminders.unshift(obj);created++;}audit(db,'Member Due Reminders Generated',`FY ${fy}: ${created} created, ${skipped} skipped`,{recordType:'Reminder'});saveDB(db);json(res,200,{created,skipped});}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/reminders\/[^/]+$/.test(pathname) && req.method==='PUT'){const id=decodeURIComponent(pathname.split('/')[3]),r=db.reminders.find(x=>x.id===id);if(!r)return json(res,404,{error:'Reminder not found'});return body(req).then(d=>{if(d.status!==undefined&&['Pending','Sent','Cancelled'].includes(String(d.status)))r.status=String(d.status);if(d.message!==undefined)r.message=String(d.message||'').trim();if(d.channel!==undefined&&REMINDER_CHANNELS.includes(String(d.channel)))r.channel=String(d.channel);if(r.status==='Sent'&&!r.sentAt)r.sentAt=new Date().toISOString();audit(db,'Reminder Updated',`${r.id} ${r.status}`,{recordType:'Reminder',recordId:r.id});saveDB(db);json(res,200,r);}).catch(e=>json(res,400,{error:e.message}));}

  // ---- Grievance Management ----
  if(pathname==='/api/grievances' && req.method==='GET'){const rows=inFY(db.grievances||[],fy).slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));return json(res,200,{categories:GRIEVANCE_CATEGORIES,statuses:GRIEVANCE_STATUSES,summary:{total:rows.length,open:rows.filter(x=>x.status==='Open').length,inReview:rows.filter(x=>x.status==='In Review').length,resolved:rows.filter(x=>x.status==='Resolved').length,urgent:rows.filter(x=>x.priority==='Urgent'&&x.status!=='Resolved').length},rows});}
  if(/^\/api\/grievances\/[^/]+$/.test(pathname) && req.method==='PUT'){const id=decodeURIComponent(pathname.split('/')[3]),g=db.grievances.find(x=>x.id===id);if(!g)return json(res,404,{error:'Grievance not found'});return body(req).then(d=>{if(d.status!==undefined&&GRIEVANCE_STATUSES.includes(String(d.status)))g.status=String(d.status);if(d.assignedTo!==undefined)g.assignedTo=String(d.assignedTo||'').trim();if(d.response!==undefined)g.response=String(d.response||'').trim();if(d.resolution!==undefined)g.resolution=String(d.resolution||'').trim();g.updatedAt=new Date().toISOString();if(['Resolved','Rejected'].includes(g.status))g.closedAt=g.updatedAt;audit(db,'Grievance Updated',`${g.id} ${g.status}`,{recordType:'Grievance',recordId:g.id});saveDB(db);json(res,200,g);}).catch(e=>json(res,400,{error:e.message}));}

  // ---- Election Management ----
  if(pathname==='/api/elections' && req.method==='GET'){const rows=inFY(db.elections||[],fy).map(e=>electionPublicView(e,'',true)).sort((a,b)=>String(b.electionDate).localeCompare(String(a.electionDate)));return json(res,200,{statuses:ELECTION_STATUSES,summary:{total:rows.length,draft:rows.filter(x=>x.status==='Draft').length,votingOpen:rows.filter(x=>x.status==='Voting Open').length,published:rows.filter(x=>x.status==='Published').length},rows});}
  if(pathname==='/api/elections' && req.method==='POST'){return body(req).then(d=>{const electionDate=d.electionDate||new Date().toISOString().slice(0,10),fyValue=d.financialYear||financialYear(electionDate);const obj={id:nextFYCode(db.elections,'ELE',fyValue,'electionDate'),title:String(d.title||'').trim(),electionDate,nominationStart:String(d.nominationStart||''),nominationEnd:String(d.nominationEnd||''),votingStart:String(d.votingStart||''),votingEnd:String(d.votingEnd||''),status:'Draft',notes:String(d.notes||'').trim(),financialYear:fyValue,positions:[],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};if(!obj.title)return json(res,400,{error:'Election title required'});db.elections.unshift(obj);audit(db,'Election Created',`${obj.id} ${obj.title}`,{recordType:'Election',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/elections\/[^/]+$/.test(pathname) && req.method==='PUT'){const id=decodeURIComponent(pathname.split('/')[3]),e=db.elections.find(x=>x.id===id);if(!e)return json(res,404,{error:'Election not found'});return body(req).then(d=>{for(const k of ['title','electionDate','nominationStart','nominationEnd','votingStart','votingEnd','notes'])if(d[k]!==undefined)e[k]=String(d[k]||'').trim();if(d.status!==undefined&&ELECTION_STATUSES.includes(String(d.status)))e.status=String(d.status);e.updatedAt=new Date().toISOString();audit(db,'Election Updated',`${e.id} ${e.status}`,{recordType:'Election',recordId:e.id});saveDB(db);json(res,200,e);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/elections\/[^/]+\/positions$/.test(pathname) && req.method==='POST'){const id=decodeURIComponent(pathname.split('/')[3]),e=db.elections.find(x=>x.id===id);if(!e)return json(res,404,{error:'Election not found'});return body(req).then(d=>{if(!['Draft','Nomination Open'].includes(e.status))return json(res,400,{error:'Positions can only be added before voting opens'});const p={id:uid('POS'),name:String(d.name||'').trim(),seats:Math.max(1,Number(d.seats||1)),candidates:[],voterIds:[]};if(!p.name)return json(res,400,{error:'Position name required'});e.positions.push(p);audit(db,'Election Position Added',`${e.id} ${p.name}`,{recordType:'Election',recordId:e.id});saveDB(db);json(res,200,p);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/elections\/[^/]+\/positions\/[^/]+\/candidates$/.test(pathname) && req.method==='POST'){const parts=pathname.split('/'),e=db.elections.find(x=>x.id===decodeURIComponent(parts[3]));if(!e)return json(res,404,{error:'Election not found'});const p=(e.positions||[]).find(x=>x.id===decodeURIComponent(parts[5]));if(!p)return json(res,404,{error:'Position not found'});return body(req).then(d=>{if(!['Draft','Nomination Open'].includes(e.status))return json(res,400,{error:'Candidate nomination is closed'});const m=db.members.find(x=>x.id===d.memberId);if(!m)return json(res,400,{error:'Valid Member required'});if((p.candidates||[]).some(x=>x.memberId===m.id))return json(res,409,{error:'Member already nominated for this position'});const c={id:uid('CAN'),memberId:m.id,memberName:m.name,manifesto:String(d.manifesto||'').trim(),status:'Approved',votes:0};p.candidates.push(c);audit(db,'Election Candidate Added',`${e.id} ${p.name} ${m.id}`,{recordType:'Election',recordId:e.id});saveDB(db);json(res,200,c);}).catch(e=>json(res,400,{error:e.message}));}

  // ---- Vendor Management ----
  if(pathname==='/api/vendors' && req.method==='GET'){const rows=(db.vendors||[]).slice().sort((a,b)=>String(a.name).localeCompare(String(b.name)));return json(res,200,{categories:VENDOR_CATEGORIES,statuses:VENDOR_STATUSES,summary:{total:rows.length,active:rows.filter(x=>x.status==='Active').length,inactive:rows.filter(x=>x.status==='Inactive').length,blacklisted:rows.filter(x=>x.status==='Blacklisted').length},rows});}
  if(pathname==='/api/vendors' && req.method==='POST'){return body(req).then(d=>{const obj={id:nextGlobalCode(db.vendors,'VEN'),name:String(d.name||'').trim(),category:VENDOR_CATEGORIES.includes(String(d.category))?String(d.category):'Other',contactPerson:String(d.contactPerson||'').trim(),phone:String(d.phone||'').trim(),email:String(d.email||'').trim(),address:String(d.address||'').trim(),gstin:String(d.gstin||'').trim(),pan:String(d.pan||'').trim(),bankName:String(d.bankName||'').trim(),accountNumber:String(d.accountNumber||'').trim(),ifsc:String(d.ifsc||'').trim(),upiId:String(d.upiId||'').trim(),status:VENDOR_STATUSES.includes(String(d.status))?String(d.status):'Active',rating:Math.max(0,Math.min(5,Number(d.rating||0))),notes:String(d.notes||'').trim(),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};if(!obj.name)return json(res,400,{error:'Vendor Name required'});db.vendors.push(obj);audit(db,'Vendor Added',`${obj.id} ${obj.name}`,{recordType:'Vendor',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/vendors\/[^/]+$/.test(pathname) && req.method==='PUT'){const id=decodeURIComponent(pathname.split('/')[3]),v=db.vendors.find(x=>x.id===id);if(!v)return json(res,404,{error:'Vendor not found'});return body(req).then(d=>{for(const k of ['name','contactPerson','phone','email','address','gstin','pan','bankName','accountNumber','ifsc','upiId','notes'])if(d[k]!==undefined)v[k]=String(d[k]||'').trim();if(d.category!==undefined&&VENDOR_CATEGORIES.includes(String(d.category)))v.category=String(d.category);if(d.status!==undefined&&VENDOR_STATUSES.includes(String(d.status)))v.status=String(d.status);if(d.rating!==undefined)v.rating=Math.max(0,Math.min(5,Number(d.rating||0)));v.updatedAt=new Date().toISOString();audit(db,'Vendor Updated',`${v.id} ${v.name}`,{recordType:'Vendor',recordId:v.id});saveDB(db);json(res,200,v);}).catch(e=>json(res,400,{error:e.message}));}

  // ---- Budget vs Actual ----
  if(pathname==='/api/budget-control' && req.method==='GET'){const rows=inFY(db.budgetPlans||[],fy).map(x=>{const actual=budgetActual(db,x,fy),variance=x.type==='Expense'?round2(moneyNum(x.amount)-actual):round2(actual-moneyNum(x.amount));return {...x,actual,variance,utilization:x.amount>0?round2(actual/moneyNum(x.amount)*100):0};});const exp=rows.filter(x=>x.type==='Expense'),inc=rows.filter(x=>x.type==='Income');return json(res,200,{expenseCategories:['All Expense',...EXPENSE_CATEGORIES],incomeCategories:['All Income',...INCOME_CATEGORIES],summary:{expenseBudget:round2(exp.reduce((s,x)=>s+moneyNum(x.amount),0)),expenseActual:round2(exp.reduce((s,x)=>s+moneyNum(x.actual),0)),incomeTarget:round2(inc.reduce((s,x)=>s+moneyNum(x.amount),0)),incomeActual:round2(inc.reduce((s,x)=>s+moneyNum(x.actual),0))},rows});}
  if(pathname==='/api/budget-control' && req.method==='POST'){return body(req).then(d=>{const type=BUDGET_TYPES.includes(String(d.type))?String(d.type):'Expense',category=String(d.category||'').trim(),amount=moneyNum(d.amount);if(!category||amount<0)return json(res,400,{error:'Category and valid budget amount required'});const obj={id:nextFYCode(db.budgetPlans,'BUD',fy),type,category,amount,notes:String(d.notes||'').trim(),financialYear:fy,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};db.budgetPlans.push(obj);audit(db,'Budget Head Added',`${obj.id} ${type} ${category} ₹${amount}`,{recordType:'Budget',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/budget-control\/[^/]+$/.test(pathname) && req.method==='DELETE'){const id=decodeURIComponent(pathname.split('/')[3]);db.budgetPlans=db.budgetPlans.filter(x=>x.id!==id);audit(db,'Budget Head Deleted',id,{recordType:'Budget',recordId:id});saveDB(db);return json(res,200,{ok:true});}

  // ---- Annual Audit ----
  if(pathname==='/api/annual-audits' && req.method==='GET'){const rows=(db.annualAudits||[]).filter(x=>x.financialYear===fy).slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));return json(res,200,{statuses:AUDIT_STATUSES,summary:{total:rows.length,completed:rows.filter(x=>x.status==='Completed').length,inProgress:rows.filter(x=>x.status==='In Progress').length},rows,financialSnapshot:accountingOverview(db,fy),auditTrailCount:(db.audit||[]).filter(x=>financialYear(x.at)===fy).length});}
  if(pathname==='/api/annual-audits' && req.method==='POST'){return body(req).then(d=>{const bounds=fyBounds(fy),obj={id:nextFYCode(db.annualAudits,'AUD',fy),financialYear:fy,auditor:String(d.auditor||'').trim(),firm:String(d.firm||'').trim(),periodStart:String(d.periodStart||accountingDateString(bounds.start)),periodEnd:String(d.periodEnd||accountingDateString(bounds.end)),status:'Planned',reportDate:'',observations:String(d.observations||'').trim(),findings:'',recommendations:'',reportPath:'',reportOriginalName:'',financialSnapshot:null,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};if(!obj.auditor)return json(res,400,{error:'Auditor Name required'});db.annualAudits.unshift(obj);audit(db,'Annual Audit Created',`${obj.id} FY ${fy} ${obj.auditor}`,{recordType:'AnnualAudit',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));}
  if(/^\/api\/annual-audits\/[^/]+$/.test(pathname) && req.method==='PUT'){const id=decodeURIComponent(pathname.split('/')[3]),a=db.annualAudits.find(x=>x.id===id);if(!a)return json(res,404,{error:'Audit not found'});return body(req).then(d=>{for(const k of ['auditor','firm','periodStart','periodEnd','reportDate','observations','findings','recommendations'])if(d[k]!==undefined)a[k]=String(d[k]||'').trim();if(d.status!==undefined&&AUDIT_STATUSES.includes(String(d.status)))a.status=String(d.status);if(d.reportDataUrl){const filename=safeName(d.reportFilename||'audit-report');if(!/\.(pdf|doc|docx|png|jpg|jpeg)$/i.test(filename))return json(res,400,{error:'Audit report must be PDF/DOC/DOCX/Image'});const saved=saveDataUrl(d.reportDataUrl,filename,15*1024*1024);if(a.reportPath)deleteUploaded(a.reportPath);a.reportPath=saved.path;a.reportOriginalName=filename;}if(a.status==='Completed')a.financialSnapshot=accountingOverview(db,a.financialYear);a.updatedAt=new Date().toISOString();audit(db,'Annual Audit Updated',`${a.id} ${a.status}`,{recordType:'AnnualAudit',recordId:a.id});saveDB(db);json(res,200,a);}).catch(e=>json(res,400,{error:e.message}));}

  if(pathname==='/api/reports' && req.method==='GET'){
    const type=String(url.searchParams.get('type')||'').trim();
    if(!type) return json(res,200,{financialYear:fy,catalog:REPORT_CATALOG});
    const report=buildReport(db,type,fy);
    if(!report) return json(res,400,{error:'Invalid Report Type'});
    return json(res,200,report);
  }

  if(pathname==='/api/dashboard' && req.method==='GET'){
    const collections=inFY(db.collections||[],fy);
    const tx=inFY(db.transactions||[],fy);
    const months=fyMonthKeys(fy);
    const bounds=fyBounds(fy);
    const fyStart=accountingDateString(bounds.start), fyEnd=accountingDateString(bounds.end);
    const now=new Date();
    const today=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
    const currentYM=today.slice(0,7);

    let dueLimit='';
    let loanAsOf=dayBeforeDate(fyStart);
    if(today<fyStart){
      dueLimit='';
      loanAsOf=dayBeforeDate(fyStart);
    }else if(today>fyEnd){
      dueLimit=fyEnd.slice(0,7);
      loanAsOf=fyEnd;
    }else{
      dueLimit=currentYM;
      loanAsOf=today;
    }

    const activeMembers=(db.members||[]).filter(x=>x.status==='Active');
    const subscriptionMonths=months.map(month=>({
      month,monthLabel:monthLabel(month),payable:0,paid:0,due:0,
      unpaidMembers:0,partialMembers:0,paidMembers:0,future:!dueLimit||month>dueLimit
    }));

    let totalDue=0;
    for(const member of activeMembers){
      const ledger=memberSubscriptionLedger(db,member,fy);
      for(const row of ledger){
        const target=subscriptionMonths.find(x=>x.month===row.month);
        if(!target || !dueLimit || row.month>dueLimit) continue;
        target.payable=round2(target.payable+moneyNum(row.payable));
        target.paid=round2(target.paid+moneyNum(row.paid));
        target.due=round2(target.due+moneyNum(row.due));
        if(row.status==='Unpaid') target.unpaidMembers++;
        else if(row.status==='Partial Paid') target.partialMembers++;
        else if(row.status==='Paid') target.paidMembers++;
        totalDue=round2(totalDue+moneyNum(row.due));
      }
    }

    const incomeRows=accountingIncomeRows(db,fy);
    const expenseRows=accountingExpenseRows(db,fy);
    const incomeExpense=months.map(month=>({
      month,monthLabel:monthLabel(month),
      income:round2(incomeRows.filter(x=>String(x.date||'').slice(0,7)===month).reduce((s,x)=>s+moneyNum(x.amount),0)),
      expense:round2(expenseRows.filter(x=>String(x.date||'').slice(0,7)===month).reduce((s,x)=>s+moneyNum(x.amount),0))
    }));

    const monthlyCollection=months.map(month=>({
      month,monthLabel:monthLabel(month),
      amount:round2(collections.filter(x=>String(x.date||'').slice(0,7)===month).reduce((s,x)=>s+moneyNum(x.amount),0))
    }));

    const cashBook=buildAccountLedger(db,fy,'cash');
    const bankBook=buildAccountLedger(db,fy,'bank');
    const upiBook=buildAccountLedger(db,fy,'upi');
    const cashBalance=round2(cashBook.closingBalance);
    const bankBalance=round2(bankBook.closingBalance);
    const upiBalance=round2(upiBook.closingBalance);
    const currentFund=round2(cashBalance+bankBalance+upiBalance);

    const policy=ensureFundPolicyForFY(db,fy);
    const fundDistribution=(policy||[]).map(f=>({
      name:f.name,percent:moneyNum(f.percent),
      amount:round2(currentFund*moneyNum(f.percent)/100)
    }));

    const monthCollection=months.includes(currentYM)
      ? round2(collections.filter(x=>String(x.date||'').slice(0,7)===currentYM).reduce((s,x)=>s+moneyNum(x.amount),0))
      : 0;
    const monthExpense=months.includes(currentYM)
      ? round2(expenseRows.filter(x=>String(x.date||'').slice(0,7)===currentYM).reduce((s,x)=>s+moneyNum(x.amount),0))
      : 0;

    const donations=round2(collections.filter(x=>String(x.type||'').toLowerCase()==='donation').reduce((s,x)=>s+moneyNum(x.amount),0));
    const welfare=welfareLedgerData(db,fy);
    const welfareAssistance=round2(welfare.summary?.paid||0);
    const loanOutstanding=round2(loanPrincipalReceivableAt(db,loanAsOf));

    const events=inFY(db.events||[],fy);
    const upcomingRows=events.filter(e=>{
      const end=String(e.endDate||e.startDate||'');
      return !['Completed','Cancelled'].includes(e.status) && end>=today;
    }).sort((a,b)=>String(a.startDate||'').localeCompare(String(b.startDate||'')));
    const upcomingEvents=upcomingRows.length;

    const accounting=accountingOverview(db,fy);
    const totalCollection=round2(collections.reduce((s,x)=>s+moneyNum(x.amount),0));
    const otherIncome=round2(tx.filter(x=>x.type==='Income').reduce((s,x)=>s+moneyNum(x.amount),0));
    const expenses=round2(expenseRows.reduce((s,x)=>s+moneyNum(x.amount),0));

    return json(res,200,{
      financialYear:fy,
      asOfDate:today,
      stats:{
        totalMembers:(db.members||[]).length,
        activeMembers:activeMembers.length,
        members:activeMembers.length,
        pendingApplications:(db.membershipApplications||[]).filter(x=>!['Active','Rejected'].includes(x.status)).length,
        monthCollection,totalDue,donations,currentFund,cashBalance,bankBalance,upiBalance,
        monthExpense,welfareAssistance,loanOutstanding,upcomingEvents,
        totalCollection,otherIncome,expenses,
        availableFund:currentFund
      },
      accounting:{
        openingBalance:accounting.openingBalance,
        income:accounting.income,
        expense:accounting.expense,
        closingBalance:accounting.closingBalance,
        liquidClosing:accounting.liquidClosing,
        loanReceivable:accounting.closingLoanReceivable,
        reconciled:accounting.reconciled,
        reconciliationDifference:accounting.reconciliationDifference
      },
      charts:{
        incomeExpense,
        monthlyCollection,
        fundDistribution,
        outstandingSubscription:subscriptionMonths
      },
      upcoming:upcomingRows.slice(0,6).map(e=>({
        id:e.id,name:e.name||'Event',startDate:e.startDate||'',endDate:e.endDate||e.startDate||'',
        venue:e.venue||'',status:e.status||'Planned'
      })),
      audit:(db.audit||[]).slice(0,8)
    });
  }













  if(pathname==='/api/approval-policy' && req.method==='GET'){
    const p=approvalPolicy(db),c=currentCommittee(db);
    return json(res,200,{
      policy:p,contexts:APPROVAL_CONTEXTS,
      committee:c?{
        id:c.id,name:c.name,termStart:c.termStart,termEnd:c.termEnd,
        activeRoles:(c.members||[]).filter(x=>x.roleStatus==='Active').map(x=>({
          memberId:x.memberId,memberName:x.memberName,designation:x.designation,startDate:x.startDate,endDate:x.endDate
        }))
      }:null,
      recentApprovals:recentFinancialApprovals(db)
    });
  }

  if(pathname==='/api/approval-policy' && req.method==='POST'){
    return body(req).then(d=>{
      const policyName=String(d.policyName||'Financial Approval Policy').trim();
      if(!policyName) return json(res,400,{error:'Policy Name is required'});
      const input=Array.isArray(d.rules)?d.rules:[];
      if(!input.length) return json(res,400,{error:'At least one approval slab is required'});
      const rules=[];
      let last=-0.01;
      for(let i=0;i<input.length;i++){
        const x=input[i]||{};
        let upTo=x.upTo;
        if(upTo===''||upTo===undefined) upTo=null;
        if(upTo!==null){
          upTo=moneyNum(upTo);
          if(upTo<0) return json(res,400,{error:`Rule ${i+1}: amount cannot be negative`});
          if(upTo<=last+0.0001) return json(res,400,{error:'Approval slab limits must be strictly increasing'});
          last=upTo;
        }else if(i!==input.length-1){
          return json(res,400,{error:'Only the last approval slab may be No Limit'});
        }
        const designations=[...new Set((Array.isArray(x.designations)?x.designations:[]).filter(v=>COMMITTEE_DESIGNATIONS.includes(String(v))).map(String))];
        const requireResolution=!!x.requireResolution;
        if(!designations.length&&!requireResolution)
          return json(res,400,{error:`Rule ${i+1} must require a designation approval or Committee Resolution`});
        rules.push({id:String(x.id||`APR-RULE-${String(i+1).padStart(3,'0')}`),upTo,designations,requireResolution});
      }
      if(rules[rules.length-1].upTo!==null)
        return json(res,400,{error:'Last approval slab must be No Limit so all amounts are covered'});
      const old=approvalPolicy(db);
      db.approvalPolicy={
        enabled:!!d.enabled,policyName,effectiveDate:String(d.effectiveDate||''),
        revision:Number(old.revision||1)+1,
        modules:{...DEFAULT_APPROVAL_POLICY.modules,...(d.modules||{})},
        rules,updatedAt:new Date().toISOString(),
        updatedBy:String(d.updatedBy||db.setup?.ownerName||'Administrator').trim()
      };
      audit(db,'Financial Approval Policy Updated',`${policyName} revision ${db.approvalPolicy.revision} / ${db.approvalPolicy.enabled?'Enabled':'Disabled'}`);
      saveDB(db);json(res,200,db.approvalPolicy);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/approval-requirement' && req.method==='GET'){
    const amount=moneyNum(u.searchParams.get('amount'));
    const context=String(u.searchParams.get('context')||'Expense');
    const date=String(u.searchParams.get('date')||new Date().toISOString().slice(0,10));
    if(!Object.keys(APPROVAL_CONTEXTS).includes(context)) return json(res,400,{error:'Invalid approval context'});
    const req=approvalRequirement(db,amount,context,date);
    const approvers={};
    for(const d of req.designations||[]) approvers[d]=approvalRoleHolders(db,d,date).map(x=>({memberId:x.memberId,memberName:x.memberName}));
    return json(res,200,{...req,approvers});
  }

  if(pathname==='/api/meetings' && req.method==='GET'){
    const rows=inFY(db.meetings||[],fy).slice()
      .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.meetingNo||'').localeCompare(String(a.meetingNo||'')));

    const resolutionRows=[];
    for(const m of rows){
      for(const r of m.resolutions||[]){
        resolutionRows.push({
          ...r,meetingId:m.id,meetingNo:m.meetingNo,meetingTitle:m.title,meetingDate:m.date,
          meetingStatus:m.status,links:resolutionLinks(db,r.id)
        });
      }
    }

    const usable=availableResolutions(db,fy);
    return json(res,200,{
      financialYear:fy,
      categories:RESOLUTION_CATEGORIES,
      votingResults:VOTING_RESULTS,
      summary:{
        totalMeetings:rows.length,
        draft:rows.filter(x=>x.status==='Draft').length,
        finalized:rows.filter(x=>x.status==='Finalized').length,
        totalResolutions:resolutionRows.length,
        passed:resolutionRows.filter(x=>['Passed','Unanimous'].includes(x.votingResult)).length,
        rejected:resolutionRows.filter(x=>x.votingResult==='Rejected').length,
        totalAttendance:rows.reduce((s,x)=>s+(x.attendees||[]).length,0)
      },
      meetings:rows.map(m=>({
        ...m,
        resolutionCount:(m.resolutions||[]).length,
        passedResolutions:(m.resolutions||[]).filter(r=>['Passed','Unanimous'].includes(r.votingResult)).length,
        attendeeCount:(m.attendees||[]).length,
        documentCount:(m.documents||[]).length
      })),
      resolutions:usable,
      allResolutions:resolutionRows
    });
  }

  if(pathname==='/api/meetings' && req.method==='POST'){
    return body(req).then(d=>{
      const date=String(d.date||new Date().toISOString().slice(0,10));
      const fyValue=d.financialYear||financialYear(date);
      const title=String(d.title||'').trim();
      const agenda=String(d.agenda||'').trim();
      if(!title) return json(res,400,{error:'Meeting title is required'});
      if(!agenda) return json(res,400,{error:'Meeting agenda is required'});

      const committee=currentCommittee(db);
      const meetingNo=nextMeetingNo(db,fyValue);
      const now=new Date().toISOString();
      const obj={
        id:meetingNo,meetingNo,
        date,title,agenda,
        discussion:String(d.discussion||'').trim(),
        decisions:String(d.decisions||'').trim(),
        approvedBy:String(d.approvedBy||'').trim(),
        status:'Draft',
        committeeId:committee?.id||'',
        committeeName:committee?.name||'',
        attendees:[],resolutions:[],documents:[],
        notes:String(d.notes||'').trim(),
        financialYear:fyValue,
        finalizedAt:'',finalizedBy:'',
        createdAt:now,updatedAt:now
      };
      db.meetings.unshift(obj);
      audit(db,'Meeting Created',`${obj.meetingNo} ${obj.title}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/meetings\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id || x.meetingNo===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    return json(res,200,{
      ...meeting,
      resolutions:(meeting.resolutions||[]).map(r=>({...r,links:resolutionLinks(db,r.id)}))
    });
  }

  if(/^\/api\/meetings\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id || x.meetingNo===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized')
      return json(res,400,{error:'Finalized meeting is read-only. Create an addendum/new meeting instead of altering approved minutes.'});

    return body(req).then(d=>{
      if(d.date!==undefined) meeting.date=String(d.date||'');
      if(d.title!==undefined){
        const title=String(d.title||'').trim();
        if(!title) return json(res,400,{error:'Meeting title is required'});
        meeting.title=title;
      }
      if(d.agenda!==undefined){
        const agenda=String(d.agenda||'').trim();
        if(!agenda) return json(res,400,{error:'Meeting agenda is required'});
        meeting.agenda=agenda;
      }
      if(d.discussion!==undefined) meeting.discussion=String(d.discussion||'').trim();
      if(d.decisions!==undefined) meeting.decisions=String(d.decisions||'').trim();
      if(d.approvedBy!==undefined) meeting.approvedBy=String(d.approvedBy||'').trim();
      if(d.notes!==undefined) meeting.notes=String(d.notes||'').trim();
      meeting.updatedAt=new Date().toISOString();
      audit(db,'Meeting Updated',`${meeting.meetingNo} ${meeting.title}`);
      saveDB(db); json(res,200,meeting);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/meetings\/[^/]+\/attendees$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting attendance is read-only'});
    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid organization member'});
      if((meeting.attendees||[]).some(x=>x.memberId===member.id))
        return json(res,400,{error:'This member is already in the attendance list'});
      const obj={
        id:uid('ATT'),memberId:member.id,memberName:member.name,memberMobile:member.phone||'',
        role:String(d.role||'Present Member').trim(),
        notes:String(d.notes||'').trim()
      };
      meeting.attendees.push(obj);
      meeting.updatedAt=new Date().toISOString();
      audit(db,'Meeting Attendee Added',`${meeting.meetingNo} ${member.id} ${member.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/meetings\/[^/]+\/attendees\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const meetingId=decodeURIComponent(parts[3]), attendeeId=decodeURIComponent(parts[5]);
    const meeting=(db.meetings||[]).find(x=>x.id===meetingId);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting attendance is read-only'});
    meeting.attendees=(meeting.attendees||[]).filter(x=>x.id!==attendeeId);
    meeting.updatedAt=new Date().toISOString();
    audit(db,'Meeting Attendee Removed',`${meeting.meetingNo} ${attendeeId}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/meetings\/[^/]+\/resolutions$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting resolutions are read-only'});
    return body(req).then(d=>{
      const category=String(d.category||'General Resolution');
      if(!RESOLUTION_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid Resolution Category'});
      const title=String(d.title||'').trim();
      const decision=String(d.decision||'').trim();
      const approvedBy=String(d.approvedBy||'').trim();
      if(!title) return json(res,400,{error:'Resolution title is required'});
      if(!decision) return json(res,400,{error:'Resolution decision text is required'});
      if(!approvedBy) return json(res,400,{error:'Resolution Approved By is required'});
      const votingResult=String(d.votingResult||'Not Voted');
      if(!VOTING_RESULTS.includes(votingResult))
        return json(res,400,{error:'Select a valid Voting Result'});

      const resolutionNo=nextResolutionNo(db,meeting.financialYear||financialYear(meeting.date));
      const obj={
        id:resolutionNo,resolutionNo,category,title,decision,
        votesFor:Math.max(0,Number(d.votesFor||0)),
        votesAgainst:Math.max(0,Number(d.votesAgainst||0)),
        abstain:Math.max(0,Number(d.abstain||0)),
        votingResult,approvedBy,
        notes:String(d.notes||'').trim(),
        createdAt:new Date().toISOString()
      };
      meeting.resolutions.push(obj);
      meeting.updatedAt=new Date().toISOString();
      audit(db,'Resolution Added',`${resolutionNo} ${title} / ${votingResult}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/meetings\/[^/]+\/resolutions\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const meetingId=decodeURIComponent(parts[3]), resolutionId=decodeURIComponent(parts[5]);
    const meeting=(db.meetings||[]).find(x=>x.id===meetingId);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting resolutions are read-only'});
    if(resolutionLinks(db,resolutionId).length)
      return json(res,400,{error:'Resolution is already linked to another module and cannot be deleted'});
    meeting.resolutions=(meeting.resolutions||[]).filter(x=>x.id!==resolutionId);
    meeting.updatedAt=new Date().toISOString();
    audit(db,'Resolution Deleted',`${meeting.meetingNo} ${resolutionId}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/meetings\/[^/]+\/document$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting documents are read-only'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'meeting-document');
      if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))
        return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,filename,10*1024*1024);
      const obj={
        id:uid('MTDOC'),
        name:String(d.displayName||filename).trim(),
        type:String(d.documentType||'Minutes / Meeting Document').trim(),
        originalName:filename,path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      meeting.documents.unshift(obj);
      meeting.updatedAt=new Date().toISOString();
      audit(db,'Meeting Document Uploaded',`${meeting.meetingNo} ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/meetings\/[^/]+\/documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const meetingId=decodeURIComponent(parts[3]), docId=decodeURIComponent(parts[5]);
    const meeting=(db.meetings||[]).find(x=>x.id===meetingId);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Finalized meeting documents are read-only'});
    const doc=(meeting.documents||[]).find(x=>x.id===docId);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    meeting.documents=meeting.documents.filter(x=>x.id!==docId);
    meeting.updatedAt=new Date().toISOString();
    audit(db,'Meeting Document Deleted',`${meeting.meetingNo} ${doc.name}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/meetings\/[^/]+\/finalize$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const meeting=(db.meetings||[]).find(x=>x.id===id);
    if(!meeting) return json(res,404,{error:'Meeting not found'});
    if(meeting.status==='Finalized') return json(res,400,{error:'Meeting is already Finalized'});
    return body(req).then(d=>{
      if(!(meeting.attendees||[]).length)
        return json(res,400,{error:'Add at least one present member before finalizing the meeting'});
      if(!String(meeting.discussion||'').trim())
        return json(res,400,{error:'Discussion must be recorded before finalizing'});
      if(!String(meeting.decisions||'').trim())
        return json(res,400,{error:'Decisions must be recorded before finalizing'});
      const approvedBy=String(d.approvedBy||meeting.approvedBy||'').trim();
      if(!approvedBy) return json(res,400,{error:'Meeting Approved By is required before finalizing'});
      meeting.approvedBy=approvedBy;
      meeting.status='Finalized';
      meeting.finalizedAt=new Date().toISOString();
      meeting.finalizedBy=String(d.finalizedBy||approvedBy).trim();
      meeting.updatedAt=meeting.finalizedAt;
      audit(db,'Meeting Finalized',`${meeting.meetingNo} ${meeting.title} / ${meeting.finalizedBy}`);
      saveDB(db); json(res,200,meeting);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/committees' && req.method==='GET'){
    const rows=(db.committees||[]).slice()
      .sort((a,b)=>{
        if(a.status!==b.status){
          if(a.status==='Current') return -1;
          if(b.status==='Current') return 1;
        }
        return String(b.formationDate||'').localeCompare(String(a.formationDate||'')) || String(b.id).localeCompare(String(a.id));
      });
    const current=rows.find(x=>x.status==='Current')||null;
    const archived=rows.filter(x=>x.status==='Archived');
    const today=new Date().toISOString().slice(0,10);
    return json(res,200,{
      designations:COMMITTEE_DESIGNATIONS,
      summary:{
        totalCommittees:rows.length,
        archivedCommittees:archived.length,
        currentCommitteeId:current?.id||'',
        currentCommitteeName:current?.name||'',
        currentRoles:current?committeeSummary(current).activeRoles:0,
        currentTermStart:current?.termStart||'',
        currentTermEnd:current?.termEnd||'',
        currentTermExpired:!!(current?.termEnd && current.termEnd<today)
      },
      current:current?{...current,summary:committeeSummary(current)}:null,
      archived:archived.map(x=>({...x,summary:committeeSummary(x)})),
      committees:rows.map(x=>({...x,summary:committeeSummary(x)}))
    });
  }

  if(pathname==='/api/committees' && req.method==='POST'){
    return body(req).then(d=>{
      if(currentCommittee(db))
        return json(res,400,{error:'A Current Committee already exists. Archive the existing committee before creating a new Current Committee.'});

      const name=String(d.name||'').trim();
      const formationDate=String(d.formationDate||'');
      const termStart=String(d.termStart||'');
      const termEnd=String(d.termEnd||'');
      if(!name) return json(res,400,{error:'Committee name is required'});
      if(!formationDate) return json(res,400,{error:'Committee Formation Date is required'});
      if(!termStart || !termEnd) return json(res,400,{error:'Committee Term Start and End Date are required'});
      if(termEnd<termStart) return json(res,400,{error:'Committee Term End Date cannot be before Start Date'});

      const now=new Date().toISOString();
      const obj={
        id:nextCommitteeCode(db),
        name,
        formationDate,
        termLabel:String(d.termLabel||'').trim(),
        termStart,termEnd,
        status:'Current',
        members:[],
        notes:String(d.notes||'').trim(),
        archivedAt:'',archivedBy:'',archiveReason:'',
        history:[{
          action:'Committee Formed',
          detail:`Current committee created for term ${termStart} to ${termEnd}`,
          at:now
        }],
        createdAt:now,updatedAt:now
      };
      db.committees.unshift(obj);
      syncCurrentCommitteeTerm(db);
      audit(db,'Committee Formed',`${obj.id} ${obj.name} / ${obj.termStart} to ${obj.termEnd}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/committees\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const committee=(db.committees||[]).find(x=>x.id===id);
    if(!committee) return json(res,404,{error:'Committee not found'});
    return json(res,200,{...committee,summary:committeeSummary(committee)});
  }

  if(/^\/api\/committees\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const committee=(db.committees||[]).find(x=>x.id===id);
    if(!committee) return json(res,404,{error:'Committee not found'});
    if(committee.status==='Archived')
      return json(res,400,{error:'Archived committee history is read-only and cannot be edited'});

    return body(req).then(d=>{
      if(d.name!==undefined){
        const name=String(d.name||'').trim();
        if(!name) return json(res,400,{error:'Committee name is required'});
        committee.name=name;
      }
      if(d.formationDate!==undefined) committee.formationDate=String(d.formationDate||'');
      if(d.termLabel!==undefined) committee.termLabel=String(d.termLabel||'').trim();
      if(d.termStart!==undefined) committee.termStart=String(d.termStart||'');
      if(d.termEnd!==undefined) committee.termEnd=String(d.termEnd||'');
      if(committee.termStart && committee.termEnd && committee.termEnd<committee.termStart)
        return json(res,400,{error:'Committee Term End Date cannot be before Start Date'});
      if(d.notes!==undefined) committee.notes=String(d.notes||'').trim();

      committee.updatedAt=new Date().toISOString();
      committee.history.unshift({
        action:'Committee Updated',
        detail:String(d.updateNote||'Committee master details updated').trim(),
        at:committee.updatedAt
      });
      syncCurrentCommitteeTerm(db);
      audit(db,'Committee Updated',`${committee.id} ${committee.name}`);
      saveDB(db); json(res,200,committee);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/committees\/[^/]+\/members$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const committee=(db.committees||[]).find(x=>x.id===id);
    if(!committee) return json(res,404,{error:'Committee not found'});
    if(committee.status==='Archived')
      return json(res,400,{error:'Cannot add members to an Archived Committee'});

    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid organization member'});
      const designation=String(d.designation||'');
      if(!COMMITTEE_DESIGNATIONS.includes(designation))
        return json(res,400,{error:'Select a valid committee designation'});

      const startDate=String(d.startDate||committee.termStart||new Date().toISOString().slice(0,10));
      const endDate=String(d.endDate||'');
      if(endDate && endDate<startDate)
        return json(res,400,{error:'Role End Date cannot be before Start Date'});

      const duplicate=(committee.members||[]).find(x=>
        x.memberId===member.id && x.designation===designation && x.roleStatus==='Active'
      );
      if(duplicate)
        return json(res,400,{error:'This member already has the same active designation in the current committee'});

      const obj={
        id:nextCommitteeMemberCode(committee),
        memberId:member.id,
        memberName:member.name,
        memberMobile:member.phone||'',
        designation,
        startDate,endDate,
        roleStatus:endDate && endDate<=new Date().toISOString().slice(0,10)?'Ended':'Active',
        notes:String(d.notes||'').trim(),
        endedAt:'',
        endReason:''
      };
      committee.members.push(obj);
      committee.updatedAt=new Date().toISOString();
      committee.history.unshift({
        action:'Committee Member Assigned',
        detail:`${member.id} ${member.name} → ${designation}`,
        at:committee.updatedAt
      });
      audit(db,'Committee Member Assigned',`${committee.id} ${member.id} ${member.name} - ${designation}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/committees\/[^/]+\/members\/[^/]+\/end$/.test(pathname) && req.method==='POST'){
    const parts=pathname.split('/');
    const committeeId=decodeURIComponent(parts[3]), roleId=decodeURIComponent(parts[5]);
    const committee=(db.committees||[]).find(x=>x.id===committeeId);
    if(!committee) return json(res,404,{error:'Committee not found'});
    if(committee.status==='Archived')
      return json(res,400,{error:'Archived committee history is read-only'});
    const role=(committee.members||[]).find(x=>x.id===roleId);
    if(!role) return json(res,404,{error:'Committee member role not found'});
    if(role.roleStatus==='Ended')
      return json(res,400,{error:'This committee role has already ended'});

    return body(req).then(d=>{
      const endDate=String(d.endDate||new Date().toISOString().slice(0,10));
      if(role.startDate && endDate<role.startDate)
        return json(res,400,{error:'Role End Date cannot be before Start Date'});
      role.endDate=endDate;
      role.roleStatus='Ended';
      role.endedAt=new Date().toISOString();
      role.endReason=String(d.reason||'Role tenure ended').trim();
      committee.updatedAt=role.endedAt;
      committee.history.unshift({
        action:'Committee Role Ended',
        detail:`${role.memberName} / ${role.designation} ended on ${endDate}. ${role.endReason}`,
        at:role.endedAt
      });
      audit(db,'Committee Role Ended',`${committee.id} ${role.memberId} ${role.designation}`);
      saveDB(db); json(res,200,role);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/committees\/[^/]+\/archive$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const committee=(db.committees||[]).find(x=>x.id===id);
    if(!committee) return json(res,404,{error:'Committee not found'});
    if(committee.status==='Archived')
      return json(res,400,{error:'Committee is already archived'});

    return body(req).then(d=>{
      const archiveDate=String(d.archiveDate||new Date().toISOString().slice(0,10));
      const archivedBy=String(d.archivedBy||db.setup?.ownerName||'Administrator').trim();
      const reason=String(d.reason||'Committee term completed').trim();
      if(!reason) return json(res,400,{error:'Archive reason is required'});

      for(const role of committee.members||[]){
        if(role.roleStatus==='Active'){
          role.roleStatus='Ended';
          role.endDate=role.endDate||archiveDate;
          role.endedAt=new Date().toISOString();
          role.endReason=role.endReason||`Committee archived: ${reason}`;
        }
      }

      committee.status='Archived';
      committee.archivedAt=new Date().toISOString();
      committee.archivedBy=archivedBy;
      committee.archiveReason=reason;
      committee.updatedAt=committee.archivedAt;
      committee.history.unshift({
        action:'Committee Archived',
        detail:`Archived on ${archiveDate} by ${archivedBy}. Reason: ${reason}`,
        at:committee.archivedAt
      });
      syncCurrentCommitteeTerm(db);
      audit(db,'Committee Archived',`${committee.id} ${committee.name} - ${reason}`);
      saveDB(db); json(res,200,committee);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/assets' && req.method==='GET'){
    const rows=(db.assets||[]).slice()
      .sort((a,b)=>String(b.purchaseDate||'').localeCompare(String(a.purchaseDate||'')) || String(a.id).localeCompare(String(b.id)));

    const categorySummary=ASSET_CATEGORIES.map(category=>{
      const items=rows.filter(x=>x.category===category);
      return {
        category,
        count:items.length,
        purchaseValue:items.reduce((s,x)=>s+moneyNum(x.purchaseValue),0),
        inUse:items.filter(x=>x.status==='In Use').length
      };
    });

    return json(res,200,{
      categories:ASSET_CATEGORIES,
      conditions:ASSET_CONDITIONS,
      statuses:ASSET_STATUSES,
      summary:{
        totalAssets:rows.length,
        totalPurchaseValue:rows.reduce((s,x)=>s+moneyNum(x.purchaseValue),0),
        inUse:rows.filter(x=>x.status==='In Use').length,
        stored:rows.filter(x=>x.status==='Stored').length,
        underRepair:rows.filter(x=>x.status==='Under Repair').length,
        disposed:rows.filter(x=>x.status==='Disposed').length,
        lost:rows.filter(x=>x.status==='Lost').length,
        withBill:rows.filter(x=>x.billPath).length
      },
      categorySummary,
      assets:rows
    });
  }

  if(pathname==='/api/assets' && req.method==='POST'){
    return body(req).then(d=>{
      const assetName=String(d.assetName||'').trim();
      if(!assetName) return json(res,400,{error:'Asset name is required'});
      const category=String(d.category||'');
      if(!ASSET_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid asset category'});

      const condition=String(d.condition||'Good');
      const status=String(d.status||'In Use');
      if(!ASSET_CONDITIONS.includes(condition))
        return json(res,400,{error:'Select a valid asset condition'});
      if(!ASSET_STATUSES.includes(status))
        return json(res,400,{error:'Select a valid asset status'});

      const purchaseDate=String(d.purchaseDate||new Date().toISOString().slice(0,10));
      const approval=validateFinancialApproval(db,{amount:moneyNum(d.purchaseValue),context:'AssetPurchase',date:purchaseDate,approvals:d.approvals||{},resolutionId:d.resolutionId||''});
      if(!approval.ok) return json(res,400,{error:approval.error});
      const resolution=approval.snapshot?.resolutionId?{
        resolutionId:approval.snapshot.resolutionId,resolutionNo:approval.snapshot.resolutionNo,resolutionTitle:approval.snapshot.resolutionTitle
      }:resolutionSnapshot(db,String(d.resolutionId||'').trim());
      if(d.resolutionId&&!resolution) return json(res,400,{error:'Asset purchase Resolution is not valid for this approval'});

      let custodianName=String(d.custodianName||'').trim();
      let custodianMemberId=String(d.custodianMemberId||'').trim();
      if(custodianMemberId){
        const member=db.members.find(x=>x.id===custodianMemberId);
        if(!member) return json(res,400,{error:'Selected custodian member was not found'});
        custodianName=member.name;
      }

      let billPath='',billOriginalName='';
      if(d.billDataUrl){
        const filename=safeName(d.billFilename||'asset-bill');
        if(!/\.(pdf|png|jpg|jpeg|webp)$/i.test(filename))
          return json(res,400,{error:'Bill must be PDF, PNG, JPG, JPEG or WEBP'});
        const saved=saveDataUrl(d.billDataUrl,filename,10*1024*1024);
        billPath=saved.path;billOriginalName=filename;
      }

      const now=new Date().toISOString();
      const obj={
        id:nextAssetCode(db),
        assetName,category,
        purchaseDate,
        purchaseValue:moneyNum(d.purchaseValue),
        vendor:String(d.vendor||'').trim(),
        assetDetails:String(d.assetDetails||'').trim(),
        billPath,billOriginalName,
        currentLocation:String(d.currentLocation||'').trim(),
        custodianMemberId,custodianName,
        condition,status,
        notes:String(d.notes||'').trim(),
        approvalSnapshot:approval.required?approval.snapshot:null,
        ...(resolution||{resolutionId:'',resolutionNo:'',resolutionTitle:''}),
        createdAt:now,updatedAt:now
      };
      db.assets.unshift(obj);
      audit(db,'Asset Added',`${obj.id} ${obj.assetName} ₹${obj.purchaseValue}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/assets\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const asset=(db.assets||[]).find(x=>x.id===id);
    if(!asset) return json(res,404,{error:'Asset not found'});
    return json(res,200,asset);
  }

  if(/^\/api\/assets\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const asset=(db.assets||[]).find(x=>x.id===id);
    if(!asset) return json(res,404,{error:'Asset not found'});
    return body(req).then(d=>{
      if(d.assetName!==undefined){
        const name=String(d.assetName||'').trim();
        if(!name) return json(res,400,{error:'Asset name is required'});
        asset.assetName=name;
      }
      if(d.category!==undefined){
        const category=String(d.category||'');
        if(!ASSET_CATEGORIES.includes(category)) return json(res,400,{error:'Select a valid asset category'});
        asset.category=category;
      }
      if(d.condition!==undefined){
        const condition=String(d.condition||'');
        if(!ASSET_CONDITIONS.includes(condition)) return json(res,400,{error:'Select a valid asset condition'});
        asset.condition=condition;
      }
      if(d.status!==undefined){
        const status=String(d.status||'');
        if(!ASSET_STATUSES.includes(status)) return json(res,400,{error:'Select a valid asset status'});
        asset.status=status;
      }
      if(d.purchaseDate!==undefined) asset.purchaseDate=String(d.purchaseDate||'');
      if(d.purchaseValue!==undefined) asset.purchaseValue=moneyNum(d.purchaseValue);
      if(d.vendor!==undefined) asset.vendor=String(d.vendor||'').trim();
      if(d.assetDetails!==undefined) asset.assetDetails=String(d.assetDetails||'').trim();
      if(d.currentLocation!==undefined) asset.currentLocation=String(d.currentLocation||'').trim();
      if(d.notes!==undefined) asset.notes=String(d.notes||'').trim();
      if(d.resolutionId!==undefined){
        const resolution=resolutionSnapshot(db,String(d.resolutionId||'').trim());
        if(d.resolutionId && !resolution)
          return json(res,400,{error:'Asset purchase Resolution must be from a Finalized meeting and Passed/Unanimous'});
        Object.assign(asset,resolution||{resolutionId:'',resolutionNo:'',resolutionTitle:''});
      }

      if(d.custodianMemberId!==undefined || d.custodianName!==undefined){
        let memberId=String(d.custodianMemberId||'').trim();
        let name=String(d.custodianName||'').trim();
        if(memberId){
          const member=db.members.find(x=>x.id===memberId);
          if(!member) return json(res,400,{error:'Selected custodian member was not found'});
          name=member.name;
        }
        asset.custodianMemberId=memberId;
        asset.custodianName=name;
      }

      if(d.billDataUrl){
        const filename=safeName(d.billFilename||'asset-bill');
        if(!/\.(pdf|png|jpg|jpeg|webp)$/i.test(filename))
          return json(res,400,{error:'Bill must be PDF, PNG, JPG, JPEG or WEBP'});
        const saved=saveDataUrl(d.billDataUrl,filename,10*1024*1024);
        if(asset.billPath) deleteUploaded(asset.billPath);
        asset.billPath=saved.path;
        asset.billOriginalName=filename;
      }

      asset.updatedAt=new Date().toISOString();
      audit(db,'Asset Updated',`${asset.id} ${asset.assetName}`);
      saveDB(db); json(res,200,asset);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/assets\/[^/]+\/bill$/.test(pathname) && req.method==='DELETE'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const asset=(db.assets||[]).find(x=>x.id===id);
    if(!asset) return json(res,404,{error:'Asset not found'});
    if(asset.billPath) deleteUploaded(asset.billPath);
    asset.billPath='';asset.billOriginalName='';asset.updatedAt=new Date().toISOString();
    audit(db,'Asset Bill Removed',`${asset.id} ${asset.assetName}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/assets\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const asset=(db.assets||[]).find(x=>x.id===id);
    if(!asset) return json(res,404,{error:'Asset not found'});
    if(asset.billPath) deleteUploaded(asset.billPath);
    db.assets=db.assets.filter(x=>x.id!==id);
    audit(db,'Asset Deleted',`${asset.id} ${asset.assetName}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(pathname==='/api/social-projects' && req.method==='GET'){
    const rows=inFY(db.socialProjects||[],fy)
      .map(p=>({...p,summary:socialProjectSummary(db,p,fy)}))
      .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.id).localeCompare(String(a.id)));

    const totalBudget=rows.reduce((s,x)=>s+moneyNum(x.budget),0);
    const totalExpense=rows.reduce((s,x)=>s+moneyNum(x.summary.totalExpense),0);
    const totalBeneficiaries=rows.reduce((s,x)=>s+Number(x.beneficiaryCount||0),0);
    const typeSummary=SOCIAL_WORK_TYPES.map(type=>{
      const projects=rows.filter(x=>x.socialWorkType===type);
      return {
        type,
        projects:projects.length,
        beneficiaries:projects.reduce((s,x)=>s+Number(x.beneficiaryCount||0),0),
        expense:projects.reduce((s,x)=>s+moneyNum(x.summary.totalExpense),0)
      };
    });

    return json(res,200,{
      financialYear:fy,
      types:SOCIAL_WORK_TYPES,
      summary:{
        totalProjects:rows.length,
        planned:rows.filter(x=>x.status==='Planned').length,
        ongoing:rows.filter(x=>x.status==='Ongoing').length,
        completed:rows.filter(x=>x.status==='Completed').length,
        totalBudget,totalExpense,
        budgetBalance:totalBudget-totalExpense,
        totalBeneficiaries
      },
      typeSummary,
      projects:rows
    });
  }

  if(pathname==='/api/social-projects' && req.method==='POST'){
    return body(req).then(d=>{
      const socialWorkType=String(d.socialWorkType||'');
      if(!SOCIAL_WORK_TYPES.includes(socialWorkType))
        return json(res,400,{error:'Select a valid Social Work Type'});
      const projectName=String(d.projectName||'').trim();
      if(!projectName) return json(res,400,{error:'Project name is required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const obj={
        id:nextSocialProjectCode(db,fyValue),
        projectName,socialWorkType,date,
        location:String(d.location||'').trim(),
        budget:moneyNum(d.budget),
        beneficiaryCount:Math.max(0,Number(d.beneficiaryCount||0)),
        status:['Planned','Ongoing','Completed','Cancelled'].includes(String(d.status))?String(d.status):'Planned',
        description:String(d.description||'').trim(),
        financialYear:fyValue,
        responsibleMembers:[],
        documents:[],
        createdAt:new Date().toISOString()
      };
      db.socialProjects.unshift(obj);
      audit(db,'Social Work Project Created',`${obj.id} ${obj.projectName} / ${obj.socialWorkType}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/social-projects\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const project=db.socialProjects.find(x=>x.id===id);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    const projectFY=project.financialYear||fy;
    return json(res,200,{
      ...project,
      summary:socialProjectSummary(db,project,projectFY),
      expenses:socialProjectExpenses(db,id,projectFY)
    });
  }

  if(/^\/api\/social-projects\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const project=db.socialProjects.find(x=>x.id===id);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    return body(req).then(d=>{
      if(d.projectName!==undefined) project.projectName=String(d.projectName||'').trim();
      if(d.socialWorkType!==undefined && SOCIAL_WORK_TYPES.includes(String(d.socialWorkType))) project.socialWorkType=String(d.socialWorkType);
      if(d.date!==undefined) project.date=String(d.date||'');
      if(d.location!==undefined) project.location=String(d.location||'').trim();
      if(d.budget!==undefined) project.budget=moneyNum(d.budget);
      if(d.beneficiaryCount!==undefined) project.beneficiaryCount=Math.max(0,Number(d.beneficiaryCount||0));
      if(d.status!==undefined && ['Planned','Ongoing','Completed','Cancelled'].includes(String(d.status))) project.status=String(d.status);
      if(d.description!==undefined) project.description=String(d.description||'').trim();
      audit(db,'Social Work Project Updated',`${project.id} ${project.projectName}`);
      saveDB(db); json(res,200,project);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/social-projects\/[^/]+\/responsible-members$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const project=db.socialProjects.find(x=>x.id===id);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid member'});
      if((project.responsibleMembers||[]).some(x=>x.memberId===member.id))
        return json(res,400,{error:'This member is already assigned'});
      const obj={
        id:uid('RESP'),memberId:member.id,name:member.name,mobile:member.phone||'',
        role:String(d.role||'Responsible Member').trim(),
        notes:String(d.notes||'').trim()
      };
      project.responsibleMembers.push(obj);
      audit(db,'Social Work Responsible Member Added',`${project.id} - ${member.id} ${member.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/social-projects\/[^/]+\/responsible-members\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const projectId=decodeURIComponent(parts[3]), responsibleId=decodeURIComponent(parts[5]);
    const project=db.socialProjects.find(x=>x.id===projectId);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    project.responsibleMembers=(project.responsibleMembers||[]).filter(x=>x.id!==responsibleId);
    audit(db,'Social Work Responsible Member Removed',`${project.id} - ${responsibleId}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/social-projects\/[^/]+\/document$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const project=db.socialProjects.find(x=>x.id===id);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'social-work-document');
      if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))
        return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,filename,10*1024*1024);
      const obj={
        id:uid('SWDOC'),
        name:String(d.displayName||filename).trim(),
        type:String(d.documentType||'Project Document').trim(),
        originalName:filename,path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      project.documents.unshift(obj);
      audit(db,'Social Work Document Uploaded',`${project.id} - ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/social-projects\/[^/]+\/documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const projectId=decodeURIComponent(parts[3]), docId=decodeURIComponent(parts[5]);
    const project=db.socialProjects.find(x=>x.id===projectId);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    const doc=(project.documents||[]).find(x=>x.id===docId);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    project.documents=project.documents.filter(x=>x.id!==docId);
    audit(db,'Social Work Document Deleted',`${project.id} - ${doc.name}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/social-projects\/[^/]+\/expense$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const project=db.socialProjects.find(x=>x.id===id);
    if(!project) return json(res,404,{error:'Social Work Project not found'});
    return body(req).then(d=>{
      const category=String(d.category||'Social Work');
      if(!EXPENSE_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid expense category'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid expense amount required'});
      const paidTo=String(d.paidTo||'').trim();
      const purpose=String(d.purpose||'').trim();
      let approvedBy=String(d.approvedBy||'').trim();
      if(!paidTo || !purpose) return json(res,400,{error:'Paid To and Purpose are required'});

      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=project.financialYear||financialYear(date);
      const approval=validateFinancialApproval(db,{amount,context:'SocialWorkExpense',date,approvals:d.approvals||{},resolutionId:d.resolutionId||''});
      if(!approval.ok) return json(res,400,{error:approval.error});
      approvedBy=approvalDisplayName(approval,approvedBy);
      if(!approvedBy) return json(res,400,{error:'Approved By is required'});
      let billPath='',billOriginalName='';

      if(d.billDataUrl){
        const filename=safeName(d.billFilename||'bill');
        if(!/\.(pdf|png|jpg|jpeg|webp)$/i.test(filename))
          return json(res,400,{error:'Bill must be PDF, PNG, JPG, JPEG or WEBP'});
        const saved=saveDataUrl(d.billDataUrl,filename,10*1024*1024);
        billPath=saved.path;billOriginalName=filename;
      }

      const obj={
        id:nextExpenseVoucherNo(db,fyValue),
        type:'Expense',category,amount,date,financialYear:fyValue,
        paidTo,mode:d.mode||'Cash',
        purpose,description:purpose,
        remarks:String(d.remarks||'').trim(),
        approvedBy,
        fundingPurpose:socialFundingPurpose(project.socialWorkType),
        billPath,billOriginalName,
        eventId:'',socialProjectId:project.id,
        approvalSnapshot:approval.required?approval.snapshot:null,
        resolutionId:approval.snapshot?.resolutionId||'',resolutionNo:approval.snapshot?.resolutionNo||'',resolutionTitle:approval.snapshot?.resolutionTitle||''
      };
      db.transactions.unshift(obj);
      audit(db,'Social Work Expense Added',`${project.id} ${obj.id} ₹${amount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/notices' && req.method==='GET'){
    const rows=inFY(db.notices||[],fy).slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.noticeNo||'').localeCompare(String(a.noticeNo||'')));
    return json(res,200,{
      financialYear:fy,
      summary:{
        total:rows.length,
        published:rows.filter(x=>x.status==='Published').length,
        draft:rows.filter(x=>x.status==='Draft').length,
        archived:rows.filter(x=>x.status==='Archived').length,
        urgent:rows.filter(x=>x.priority==='Urgent'&&x.status==='Published').length
      },
      notices:rows
    });
  }

  if(pathname==='/api/notices' && req.method==='POST'){
    return body(req).then(d=>{
      const title=String(d.title||'').trim(),bodyText=String(d.body||'').trim();
      if(!title) return json(res,400,{error:'Notice title is required'});
      if(!bodyText) return json(res,400,{error:'Notice content is required'});
      const date=String(d.date||new Date().toISOString().slice(0,10));
      const fyValue=d.financialYear||financialYear(date);
      const audience=['All Members','Active Members','Committee Members','Specific Member'].includes(String(d.audience))?String(d.audience):'All Members';
      const memberId=String(d.memberId||'').trim();
      if(audience==='Specific Member'&&!db.members.some(x=>x.id===memberId)) return json(res,400,{error:'Specific Member audience requires a valid Member ID'});
      const priority=['Normal','Important','Urgent'].includes(String(d.priority))?String(d.priority):'Normal';
      const status=['Draft','Published','Archived'].includes(String(d.status))?String(d.status):'Draft';
      const publishFrom=String(d.publishFrom||date),publishUntil=String(d.publishUntil||'');
      if(publishUntil&&publishUntil<publishFrom) return json(res,400,{error:'Publish Until cannot be before Publish From'});
      let attachmentPath='',attachmentOriginalName='';
      if(d.attachmentDataUrl){
        const filename=safeName(d.attachmentFilename||'notice-document');
        if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename)) return json(res,400,{error:'Notice attachment must be PDF, PNG, JPG, WEBP, DOC or DOCX'});
        const saved=saveDataUrl(d.attachmentDataUrl,filename,10*1024*1024);
        attachmentPath=saved.path;attachmentOriginalName=filename;
      }
      const now=new Date().toISOString(),noticeNo=nextNoticeNo(db,fyValue);
      const obj={
        id:noticeNo,noticeNo,title,date,publishFrom,publishUntil,priority,audience,memberId,status,
        body:bodyText,attachmentPath,attachmentOriginalName,financialYear:fyValue,
        createdBy:user.id,createdByName:user.name,createdAt:now,updatedAt:now
      };
      db.notices.unshift(obj);
      audit(db,'Notice Created',`${obj.noticeNo} ${obj.title} · ${obj.status} · ${obj.audience}`,{recordType:'Notice',recordId:obj.id});
      saveDB(db);json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/notices\/[^/]+$/.test(pathname)&&req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);const n=(db.notices||[]).find(x=>x.id===id);
    if(!n) return json(res,404,{error:'Notice not found'});
    return body(req).then(d=>{
      if(d.title!==undefined){const v=String(d.title||'').trim();if(!v)return json(res,400,{error:'Notice title is required'});n.title=v;}
      if(d.body!==undefined){const v=String(d.body||'').trim();if(!v)return json(res,400,{error:'Notice content is required'});n.body=v;}
      if(d.date!==undefined)n.date=String(d.date||'');
      if(d.publishFrom!==undefined)n.publishFrom=String(d.publishFrom||'');
      if(d.publishUntil!==undefined)n.publishUntil=String(d.publishUntil||'');
      if(n.publishUntil&&n.publishUntil<n.publishFrom)return json(res,400,{error:'Publish Until cannot be before Publish From'});
      if(d.priority!==undefined&&['Normal','Important','Urgent'].includes(String(d.priority)))n.priority=String(d.priority);
      if(d.status!==undefined&&['Draft','Published','Archived'].includes(String(d.status)))n.status=String(d.status);
      if(d.audience!==undefined){
        const a=String(d.audience);if(!['All Members','Active Members','Committee Members','Specific Member'].includes(a))return json(res,400,{error:'Invalid notice audience'});n.audience=a;
      }
      if(d.memberId!==undefined)n.memberId=String(d.memberId||'').trim();
      if(n.audience==='Specific Member'&&!db.members.some(x=>x.id===n.memberId))return json(res,400,{error:'Specific Member audience requires a valid Member ID'});
      if(d.attachmentDataUrl){
        const filename=safeName(d.attachmentFilename||'notice-document');
        if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename)) return json(res,400,{error:'Notice attachment must be PDF, PNG, JPG, WEBP, DOC or DOCX'});
        const saved=saveDataUrl(d.attachmentDataUrl,filename,10*1024*1024);
        if(n.attachmentPath) deleteUploaded(n.attachmentPath);
        n.attachmentPath=saved.path;n.attachmentOriginalName=filename;
      }
      if(d.removeAttachment&&n.attachmentPath){deleteUploaded(n.attachmentPath);n.attachmentPath='';n.attachmentOriginalName='';}
      n.updatedAt=new Date().toISOString();
      audit(db,'Notice Updated',`${n.noticeNo} ${n.title} · ${n.status} · ${n.audience}`,{recordType:'Notice',recordId:n.id});
      saveDB(db);json(res,200,n);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/events' && req.method==='GET'){
    const rows=inFY(db.events||[],fy)
      .map(e=>({...e,summary:eventSummary(db,e,fy)}))
      .sort((a,b)=>String(b.startDate||'').localeCompare(String(a.startDate||''))||String(b.id).localeCompare(String(a.id)));
    const totalBudget=rows.reduce((s,x)=>s+moneyNum(x.budget),0);
    const totalIncome=rows.reduce((s,x)=>s+moneyNum(x.summary.totalIncome),0);
    const totalExpense=rows.reduce((s,x)=>s+moneyNum(x.summary.totalExpense),0);
    return json(res,200,{
      financialYear:fy,
      summary:{
        totalEvents:rows.length,
        planned:rows.filter(x=>x.status==='Planned').length,
        ongoing:rows.filter(x=>x.status==='Ongoing').length,
        completed:rows.filter(x=>x.status==='Completed').length,
        totalBudget,totalIncome,totalExpense,netBalance:totalIncome-totalExpense
      },
      events:rows
    });
  }

  if(pathname==='/api/events' && req.method==='POST'){
    return body(req).then(d=>{
      const name=String(d.name||'').trim();
      if(!name) return json(res,400,{error:'Event name is required'});
      const startDate=d.startDate||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(startDate);
      const obj={
        id:nextEventCode(db,fyValue),
        name,startDate,endDate:d.endDate||startDate,
        venue:String(d.venue||'').trim(),
        budget:moneyNum(d.budget),
        description:String(d.description||'').trim(),
        status:['Planned','Ongoing','Completed','Cancelled'].includes(String(d.status))?String(d.status):'Planned',
        registrationOpen:!!d.registrationOpen,registrationDeadline:String(d.registrationDeadline||''),capacity:Math.max(0,Number(d.capacity||0)),
        financialYear:fyValue,
        participants:[],registrations:[],vendors:[],documents:[],
        createdAt:new Date().toISOString()
      };
      db.events.unshift(obj);
      audit(db,'Event Project Created',`${obj.id} ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    const eventFY=event.financialYear||fy;
    return json(res,200,{
      ...event,
      summary:{...eventSummary(db,event,eventFY),...eventRegistrationSummary(event)},
      incomes:eventIncomeRows(db,id,eventFY),
      expenses:eventExpenseRows(db,id,eventFY)
    });
  }

  if(/^\/api\/events\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      if(d.name!==undefined) event.name=String(d.name||'').trim();
      if(d.startDate!==undefined) event.startDate=String(d.startDate||'');
      if(d.endDate!==undefined) event.endDate=String(d.endDate||'');
      if(d.venue!==undefined) event.venue=String(d.venue||'').trim();
      if(d.budget!==undefined) event.budget=moneyNum(d.budget);
      if(d.registrationOpen!==undefined) event.registrationOpen=!!d.registrationOpen;
      if(d.registrationDeadline!==undefined) event.registrationDeadline=String(d.registrationDeadline||'');
      if(d.capacity!==undefined) event.capacity=Math.max(0,Number(d.capacity||0));
      if(d.description!==undefined) event.description=String(d.description||'').trim();
      if(d.status!==undefined && ['Planned','Ongoing','Completed','Cancelled'].includes(String(d.status))) event.status=String(d.status);
      audit(db,'Event Project Updated',`${event.id} ${event.name}`);
      saveDB(db); json(res,200,event);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/registrations$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]),event=db.events.find(x=>x.id===id);if(!event)return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{const member=db.members.find(x=>x.id===d.memberId);if(!member)return json(res,400,{error:'Valid Member required'});const existing=(event.registrations||[]).find(x=>x.memberId===member.id&&x.status!=='Cancelled');if(existing)return json(res,409,{error:'Member already registered'});const active=(event.registrations||[]).filter(x=>x.status!=='Cancelled');if(event.capacity>0&&active.length>=event.capacity)return json(res,400,{error:'Event capacity is full'});const obj={id:nextFYCode((db.events||[]).flatMap(e=>e.registrations||[]),'EVR',event.financialYear||fy,'date'),memberId:member.id,memberName:member.name,phone:member.phone||'',date:new Date().toISOString().slice(0,10),status:'Registered',notes:String(d.notes||'').trim(),source:'Admin'};event.registrations.push(obj);audit(db,'Event Registration Added',`${event.id} ${member.id} ${obj.id}`,{recordType:'EventRegistration',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/events\/[^/]+\/registrations\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const parts=pathname.split('/'),event=db.events.find(x=>x.id===decodeURIComponent(parts[3]));if(!event)return json(res,404,{error:'Event not found'});const reg=(event.registrations||[]).find(x=>x.id===decodeURIComponent(parts[5]));if(!reg)return json(res,404,{error:'Registration not found'});return body(req).then(d=>{if(d.status!==undefined&&['Registered','Attended','Cancelled'].includes(String(d.status)))reg.status=String(d.status);if(d.notes!==undefined)reg.notes=String(d.notes||'').trim();if(reg.status==='Attended'&&!(event.participants||[]).some(x=>x.memberId===reg.memberId)){event.participants.push({id:uid('EVP'),memberId:reg.memberId,name:reg.memberName,mobile:reg.phone||'',role:'Participant',notes:'Added from Event Registration'});}audit(db,'Event Registration Updated',`${event.id} ${reg.id} ${reg.status}`,{recordType:'EventRegistration',recordId:reg.id});saveDB(db);json(res,200,reg);}).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/participants$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      let member=null;
      if(d.memberId) member=db.members.find(x=>x.id===d.memberId);
      const name=member?.name||String(d.name||'').trim();
      if(!name) return json(res,400,{error:'Participant name is required'});
      const obj={
        id:uid('PART'),memberId:member?.id||'',
        name,mobile:member?.phone||String(d.mobile||'').trim(),
        role:String(d.role||'Participant').trim(),
        notes:String(d.notes||'').trim()
      };
      event.participants.push(obj);
      audit(db,'Event Participant Added',`${event.id} - ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/participants\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const eventId=decodeURIComponent(parts[3]), participantId=decodeURIComponent(parts[5]);
    const event=db.events.find(x=>x.id===eventId);
    if(!event) return json(res,404,{error:'Event not found'});
    event.participants=(event.participants||[]).filter(x=>x.id!==participantId);
    audit(db,'Event Participant Deleted',`${event.id} - ${participantId}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/events\/[^/]+\/vendors$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      const masterVendor=d.vendorId?(db.vendors||[]).find(x=>x.id===d.vendorId):null;
      const name=masterVendor?.name||String(d.name||'').trim();
      if(!name) return json(res,400,{error:'Vendor name is required'});
      const obj={
        id:uid('VEND'),vendorId:masterVendor?.id||'',name,
        mobile:masterVendor?.phone||String(d.mobile||'').trim(),
        service:String(d.service||masterVendor?.category||'').trim(),
        contractAmount:moneyNum(d.contractAmount),
        notes:String(d.notes||'').trim()
      };
      event.vendors.push(obj);
      audit(db,'Event Vendor Added',`${event.id} - ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/vendors\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const eventId=decodeURIComponent(parts[3]), vendorId=decodeURIComponent(parts[5]);
    const event=db.events.find(x=>x.id===eventId);
    if(!event) return json(res,404,{error:'Event not found'});
    event.vendors=(event.vendors||[]).filter(x=>x.id!==vendorId);
    audit(db,'Event Vendor Deleted',`${event.id} - ${vendorId}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/events\/[^/]+\/document$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'event-document');
      if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))
        return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,filename,10*1024*1024);
      const obj={
        id:uid('EVDOC'),
        name:String(d.displayName||filename).trim(),
        type:String(d.documentType||'Event Document').trim(),
        originalName:filename,path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      event.documents.unshift(obj);
      audit(db,'Event Document Uploaded',`${event.id} - ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const eventId=decodeURIComponent(parts[3]), docId=decodeURIComponent(parts[5]);
    const event=db.events.find(x=>x.id===eventId);
    if(!event) return json(res,404,{error:'Event not found'});
    const doc=(event.documents||[]).find(x=>x.id===docId);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    event.documents=event.documents.filter(x=>x.id!==docId);
    audit(db,'Event Document Deleted',`${event.id} - ${doc.name}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/events\/[^/]+\/income$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      const incomeType=String(d.incomeType||'');
      if(!['Collection','Donation','Sponsorship','Member Contribution'].includes(incomeType))
        return json(res,400,{error:'Invalid event income type'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid amount required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=event.financialYear||financialYear(date);

      if(incomeType==='Donation'){
        const member=d.memberId?db.members.find(x=>x.id===d.memberId):null;
        const donorName=member?.name||String(d.source||'').trim();
        if(!donorName) return json(res,400,{error:'Donor name/member required'});
        const receipt={
          id:nextReceiptNo(db,fyValue),memberId:member?.id||'',
          personName:donorName,donorMobile:member?.phone||String(d.mobile||'').trim(),
          donationType:member?'Member Donation':'External Donation',
          donationPurpose:'Event',type:'Donation',eventId:event.id,eventIncomeType:'Donation',
          mode:d.mode||'Cash',amount,date,financialYear:fyValue,notes:String(d.remarks||'')
        };
        db.collections.unshift(receipt);
        audit(db,'Event Donation Received',`${event.id} ${receipt.id} ₹${amount}`);
        saveDB(db); return json(res,200,receipt);
      }

      if(incomeType==='Sponsorship'){
        const source=String(d.source||'').trim();
        if(!source) return json(res,400,{error:'Sponsor / Source is required'});
        const obj={
          id:nextIncomeVoucherNo(db,fyValue),type:'Income',category:'Sponsorship',
          source,description:String(d.remarks||''),remarks:String(d.remarks||''),
          mode:d.mode||'Cash',amount,date,financialYear:fyValue,fundingPurpose:'Event',
          eventId:event.id,eventIncomeType:'Sponsorship'
        };
        db.transactions.unshift(obj);
        audit(db,'Event Sponsorship Received',`${event.id} ${obj.id} ₹${amount}`);
        saveDB(db); return json(res,200,obj);
      }

      const member=d.memberId?db.members.find(x=>x.id===d.memberId):null;
      const source=member?.name||String(d.source||'').trim();
      if(!source) return json(res,400,{error:'Source / member is required'});
      const receipt={
        id:nextReceiptNo(db,fyValue),memberId:member?.id||'',
        personName:source,type:incomeType==='Member Contribution'?'Event Member Contribution':'Event Collection',
        eventId:event.id,eventIncomeType:incomeType,
        mode:d.mode||'Cash',amount,date,financialYear:fyValue,notes:String(d.remarks||'')
      };
      db.collections.unshift(receipt);
      audit(db,'Event Income Received',`${event.id} ${incomeType} ${receipt.id} ₹${amount}`);
      saveDB(db); return json(res,200,receipt);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/events\/[^/]+\/expense$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const event=db.events.find(x=>x.id===id);
    if(!event) return json(res,404,{error:'Event not found'});
    return body(req).then(d=>{
      const category=String(d.category||'Event Expense');
      if(!EXPENSE_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid expense category'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid expense amount required'});
      const paidTo=String(d.paidTo||'').trim();
      const purpose=String(d.purpose||'').trim();
      let approvedBy=String(d.approvedBy||'').trim();
      if(!paidTo || !purpose) return json(res,400,{error:'Paid To and Purpose are required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=event.financialYear||financialYear(date);
      const approval=validateFinancialApproval(db,{amount,context:'EventExpense',date,approvals:d.approvals||{},resolutionId:d.resolutionId||''});
      if(!approval.ok) return json(res,400,{error:approval.error});
      approvedBy=approvalDisplayName(approval,approvedBy);
      if(!approvedBy) return json(res,400,{error:'Approved By is required'});
      let billPath='',billOriginalName='';
      if(d.billDataUrl){
        const filename=safeName(d.billFilename||'bill');
        if(!/\.(pdf|png|jpg|jpeg|webp)$/i.test(filename))
          return json(res,400,{error:'Bill must be PDF, PNG, JPG, JPEG or WEBP'});
        const saved=saveDataUrl(d.billDataUrl,filename,10*1024*1024);
        billPath=saved.path;billOriginalName=filename;
      }
      const obj={
        id:nextExpenseVoucherNo(db,fyValue),type:'Expense',category,
        amount,date,financialYear:fyValue,
        paidTo,mode:d.mode||'Cash',purpose,description:purpose,
        remarks:String(d.remarks||''),approvedBy,
        fundingPurpose:'Event',billPath,billOriginalName,eventId:event.id,
        approvalSnapshot:approval.required?approval.snapshot:null,
        resolutionId:approval.snapshot?.resolutionId||'',resolutionNo:approval.snapshot?.resolutionNo||'',resolutionTitle:approval.snapshot?.resolutionTitle||''
      };
      db.transactions.unshift(obj);
      audit(db,'Event Expense Added',`${event.id} ${obj.id} ₹${amount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/welfare' && req.method==='GET'){
    const applications=inFY(db.welfareApplications||[],fy)
      .slice().sort((a,b)=>String(b.applicationDate||'').localeCompare(String(a.applicationDate||'')) || String(b.id).localeCompare(String(a.id)));
    const payments=inFY(db.welfarePayments||[],fy)
      .slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')) || String(b.id).localeCompare(String(a.id)));

    const fundPolicy=ensureFundPolicyForFY(db,fy);
    const welfareHead=fundPolicy.find(x=>String(x.name||'').toLowerCase().includes('member welfare'));
    const cashBankTotal=buildAccountLedger(db,fy,'cash').closingBalance
      + buildAccountLedger(db,fy,'bank').closingBalance
      + buildAccountLedger(db,fy,'upi').closingBalance;
    const welfarePercent=moneyNum(welfareHead?.percent||0);
    const currentEarmarkedAmount=cashBankTotal*welfarePercent/100;

    const totalRequested=applications.reduce((s,x)=>s+moneyNum(x.requestedAmount),0);
    const totalApproved=applications.reduce((s,x)=>s+moneyNum(x.approvedAmount),0);
    const totalPaid=payments.reduce((s,x)=>s+moneyNum(x.amount),0);
    const outstandingApproved=Math.max(0,totalApproved-totalPaid);

    return json(res,200,{
      financialYear:fy,
      types:WELFARE_TYPES,
      policy:{
        welfarePercent,
        currentEarmarkedAmount,
        currentAvailableFund:cashBankTotal,
        fundHeadName:welfareHead?.name||'Member Welfare'
      },
      summary:{
        totalApplications:applications.length,
        pending:applications.filter(x=>x.status==='Pending').length,
        verification:applications.filter(x=>x.status==='Document Verification').length,
        committeeReview:applications.filter(x=>x.status==='Committee Review').length,
        approved:applications.filter(x=>x.status==='Approved').length,
        paid:applications.filter(x=>x.status==='Paid').length,
        rejected:applications.filter(x=>x.status==='Rejected').length,
        totalRequested,totalApproved,totalPaid,outstandingApproved
      },
      applications,payments
    });
  }

  if(pathname==='/api/welfare/applications' && req.method==='POST'){
    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid member'});
      if(!WELFARE_TYPES.includes(String(d.welfareType||'')))
        return json(res,400,{error:'Select a valid welfare assistance type'});
      const requestedAmount=moneyNum(d.requestedAmount);
      if(requestedAmount<=0) return json(res,400,{error:'Requested amount must be greater than zero'});
      const reason=String(d.reason||'').trim();
      if(!reason) return json(res,400,{error:'Application reason / purpose is required'});
      const applicationDate=d.applicationDate||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(applicationDate);
      const obj={
        id:nextWelfareApplicationNo(db,fyValue),
        memberId:member.id,memberName:member.name,memberMobile:member.phone||'',
        welfareType:String(d.welfareType),
        requestedAmount,
        incidentDate:String(d.incidentDate||''),
        applicationDate,
        financialYear:fyValue,
        reason,
        details:String(d.details||'').trim(),
        status:'Pending',
        documents:[],
        verificationNotes:'',
        verificationBy:'',
        committeeNotes:'',
        approvedBy:'',
        approvedAmount:0,
        rejectionReason:'',
        paidAmount:0,
        history:[{status:'Pending',note:'Welfare application submitted',at:new Date().toISOString()}],
        createdAt:new Date().toISOString()
      };
      db.welfareApplications.unshift(obj);
      audit(db,'Welfare Application Submitted',`${obj.id} ${member.id} ${member.name} / ${obj.welfareType} ₹${requestedAmount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/welfare\/applications\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[4]);
    const app=db.welfareApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Welfare application not found'});
    const payments=(db.welfarePayments||[]).filter(x=>x.applicationId===id);
    return json(res,200,{...app,payments});
  }

  if(/^\/api\/welfare\/applications\/[^/]+\/document$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[4]);
    const app=db.welfareApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Welfare application not found'});
    if(['Paid','Rejected'].includes(app.status))
      return json(res,400,{error:'Documents cannot be changed after application is closed'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'document');
      if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))
        return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,filename,10*1024*1024);
      const doc={
        id:uid('WFDOC'),
        name:String(d.displayName||filename).trim(),
        type:String(d.documentType||'Supporting Document').trim(),
        originalName:filename,path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      app.documents.unshift(doc);
      app.history.unshift({status:app.status,note:`Document uploaded: ${doc.name}`,at:new Date().toISOString()});
      audit(db,'Welfare Document Uploaded',`${app.id} - ${doc.name}`);
      saveDB(db); json(res,200,doc);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/welfare\/applications\/[^/]+\/documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const appId=decodeURIComponent(parts[4]), docId=decodeURIComponent(parts[6]);
    const app=db.welfareApplications.find(x=>x.id===appId);
    if(!app) return json(res,404,{error:'Welfare application not found'});
    if(['Paid','Rejected'].includes(app.status))
      return json(res,400,{error:'Documents cannot be changed after application is closed'});
    const doc=(app.documents||[]).find(x=>x.id===docId);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    app.documents=app.documents.filter(x=>x.id!==docId);
    app.history.unshift({status:app.status,note:`Document deleted: ${doc.name}`,at:new Date().toISOString()});
    audit(db,'Welfare Document Deleted',`${app.id} - ${doc.name}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/welfare\/applications\/[^/]+\/status$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[4]);
    const app=db.welfareApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Welfare application not found'});
    return body(req).then(d=>{
      const next=String(d.status||'');
      const allowed={
        'Pending':['Document Verification','Rejected'],
        'Document Verification':['Committee Review','Rejected'],
        'Committee Review':['Approved','Rejected']
      };
      if(!(allowed[app.status]||[]).includes(next))
        return json(res,400,{error:`Invalid welfare workflow change: ${app.status} → ${next}`});

      if(next==='Document Verification'){
        app.verificationBy=String(d.actionBy||'').trim();
        app.verificationNotes=String(d.notes||'').trim();
      }
      if(next==='Committee Review'){
        if((app.documents||[]).length===0 && !String(d.notes||'').trim())
          return json(res,400,{error:'Add supporting document or verification note before Committee Review'});
        app.verificationBy=app.verificationBy||String(d.actionBy||'').trim();
        app.verificationNotes=String(d.notes||app.verificationNotes||'').trim();
      }
      if(next==='Approved'){
        const approvedAmount=moneyNum(d.approvedAmount);
        if(approvedAmount<=0) return json(res,400,{error:'Approved amount is required'});
        if(approvedAmount-moneyNum(app.requestedAmount)>0.001)
          return json(res,400,{error:'Approved amount cannot exceed requested amount'});
        app.approvedAmount=approvedAmount;
        app.approvedBy=String(d.approvedBy||'').trim();
        app.committeeNotes=String(d.notes||'').trim();
        if(!app.approvedBy) return json(res,400,{error:'Approved By is required'});
      }
      if(next==='Rejected'){
        const reason=String(d.reason||'').trim();
        if(!reason) return json(res,400,{error:'Rejection reason is mandatory'});
        app.rejectionReason=reason;
      }

      app.status=next;
      app.history.unshift({
        status:next,
        note:next==='Rejected'?app.rejectionReason:String(d.notes||'').trim(),
        at:new Date().toISOString()
      });
      audit(db,'Welfare Workflow',`${app.id}: ${next}`);
      saveDB(db); json(res,200,app);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/welfare\/applications\/[^/]+\/payment$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[4]);
    const app=db.welfareApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Welfare application not found'});
    if(app.status!=='Approved') return json(res,400,{error:'Application must be Approved before payment'});
    return body(req).then(d=>{
      const remaining=Math.max(0,moneyNum(app.approvedAmount)-moneyNum(app.paidAmount));
      const amount=moneyNum(d.amount||remaining);
      if(amount<=0) return json(res,400,{error:'Valid welfare payment amount required'});
      if(amount-remaining>0.001) return json(res,400,{error:`Payment exceeds approved outstanding amount (${remaining})`});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const approval=validateFinancialApproval(db,{amount,context:'WelfarePayment',date,approvals:d.approvals||{},resolutionId:d.resolutionId||''});
      if(!approval.ok) return json(res,400,{error:approval.error});
      if(fyValue!==app.financialYear)
        return json(res,400,{error:'Payment Financial Year must match the welfare application Financial Year'});
      const mode=String(d.mode||'Cash');
      const accountKey=accountKeyForMode(mode);
      const ledger=buildAccountLedger(db,fyValue,accountKey);
      if(amount-ledger.closingBalance>0.001)
        return json(res,400,{error:`Insufficient balance in ${ledger.accountName}. Available: ${ledger.closingBalance}`});

      const expenseId=nextExpenseVoucherNo(db,fyValue);
      const payment={
        id:nextWelfarePaymentNo(db,fyValue),
        applicationId:app.id,memberId:app.memberId,memberName:app.memberName,
        welfareType:app.welfareType,amount,date,mode,
        financialYear:fyValue,expenseVoucherNo:expenseId,
        reference:String(d.reference||'').trim(),
        remarks:String(d.remarks||'').trim(),
        approvedBy:approvalDisplayName(approval,app.approvedBy)||app.approvedBy,
        approvalSnapshot:approval.required?approval.snapshot:null,
        resolutionId:approval.snapshot?.resolutionId||'',resolutionNo:approval.snapshot?.resolutionNo||'',resolutionTitle:approval.snapshot?.resolutionTitle||''
      };
      const expense={
        id:expenseId,type:'Expense',category:'Member Welfare',
        amount,date,financialYear:fyValue,
        paidTo:app.memberName,mode,
        purpose:`${app.welfareType}: ${app.reason}`,
        description:`Welfare assistance against ${app.id}`,
        remarks:`Welfare Payment ${payment.id}${payment.reference?` / ${payment.reference}`:''}`,
        approvedBy:payment.approvedBy,
        fundingPurpose:'',
        billPath:'',billOriginalName:'',
        welfareApplicationId:app.id,welfarePaymentId:payment.id,
        approvalSnapshot:payment.approvalSnapshot,
        resolutionId:payment.resolutionId||'',resolutionNo:payment.resolutionNo||'',resolutionTitle:payment.resolutionTitle||''
      };

      db.welfarePayments.unshift(payment);
      db.transactions.unshift(expense);
      app.paidAmount=moneyNum(app.paidAmount)+amount;
      if(app.paidAmount+0.001>=app.approvedAmount) app.status='Paid';
      app.history.unshift({
        status:app.status,
        note:`Payment ${payment.id} ₹${amount}; Expense Voucher ${expenseId}`,
        at:new Date().toISOString()
      });
      audit(db,'Welfare Payment',`${payment.id} ${app.memberId} ${app.memberName} ₹${amount}`);
      saveDB(db); json(res,200,{payment,expense,application:app});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/accounting-ledgers' && req.method==='GET'){
    return json(res,200,accountingLedgerPackage(db,fy));
  }

  if(pathname==='/api/cash-bank' && req.method==='GET'){
    const settings=getCashBankSettings(db,fy);
    const cash=buildAccountLedger(db,fy,'cash');
    const bank=buildAccountLedger(db,fy,'bank');
    const upi=buildAccountLedger(db,fy,'upi');
    const transfers=inFY(db.fundTransfers||[],fy).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id)));
    return json(res,200,{
      financialYear:fy,settings,
      summary:{
        cashBalance:cash.closingBalance,
        bankBalance:bank.closingBalance,
        upiBalance:upi.closingBalance,
        totalBalance:cash.closingBalance+bank.closingBalance+upi.closingBalance
      },
      accounts:{cash,bank,upi},
      transfers
    });
  }

  if(pathname==='/api/cash-bank/settings' && req.method==='POST'){
    return body(req).then(d=>{
      db.cashBankSettings ||= {};
      db.cashBankSettings[fy]={
        cash:{name:String(d.cashName||'Cash in Hand').trim()||'Cash in Hand',openingBalance:moneyNum(d.cashOpening)},
        bank:{name:String(d.bankName||'Bank Account').trim()||'Bank Account',openingBalance:moneyNum(d.bankOpening)},
        upi:{name:String(d.upiName||'UPI / Other Account').trim()||'UPI / Other Account',openingBalance:moneyNum(d.upiOpening)}
      };
      audit(db,'Cash & Bank Settings Updated',`Financial Year ${fy}`);
      saveDB(db); json(res,200,db.cashBankSettings[fy]);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/fund-transfers' && req.method==='POST'){
    return body(req).then(d=>{
      const allowed=['cash','bank','upi'];
      const from=String(d.fromAccount||''), to=String(d.toAccount||'');
      if(!allowed.includes(from)||!allowed.includes(to)||from===to)
        return json(res,400,{error:'Select two different valid accounts'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid transfer amount required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      if(fyValue!==fy) return json(res,400,{error:'Transfer date must belong to selected Financial Year'});
      const sourceLedger=buildAccountLedger(db,fy,from);
      if(amount-sourceLedger.closingBalance>0.001)
        return json(res,400,{error:`Insufficient balance in ${sourceLedger.accountName}. Available: ${sourceLedger.closingBalance}`});
      const obj={
        id:nextTransferNo(db,fy),fromAccount:from,toAccount:to,amount,date,
        financialYear:fy,reference:String(d.reference||'').trim(),
        remarks:String(d.remarks||'').trim()
      };
      db.fundTransfers.unshift(obj);
      audit(db,'Fund Transfer',`${obj.id} ${from} → ${to} ₹${amount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/fund-transfers\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const before=db.fundTransfers.length;
    db.fundTransfers=db.fundTransfers.filter(x=>x.id!==id);
    if(db.fundTransfers.length===before) return json(res,404,{error:'Transfer not found'});
    audit(db,'Fund Transfer Deleted',id); saveDB(db);
    return json(res,200,{ok:true});
  }

  if(pathname==='/api/expenses' && req.method==='GET'){
    const rows=inFY(db.transactions,fy).filter(x=>x.type==='Expense').map(x=>({
      id:x.id,date:x.date,category:EXPENSE_CATEGORIES.includes(x.category)?x.category:'Other Approved Expense',
      amount:moneyNum(x.amount),paidTo:x.paidTo||'',paymentMode:x.mode||'',
      purpose:x.purpose||x.description||'',approvedBy:x.approvedBy||'',
      billPath:x.billPath||'',billOriginalName:x.billOriginalName||'',
      fundingPurpose:x.fundingPurpose||'',remarks:x.remarks||x.description||'',
      resolutionId:x.resolutionId||'',resolutionNo:x.resolutionNo||'',resolutionTitle:x.resolutionTitle||'',approvalSnapshot:x.approvalSnapshot||null
    })).sort((a,b)=>String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id)));

    const categorySummary=EXPENSE_CATEGORIES.map(category=>{
      const subset=rows.filter(x=>x.category===category);
      return {category,amount:subset.reduce((s,x)=>s+moneyNum(x.amount),0),count:subset.length};
    });
    const totalExpense=rows.reduce((s,x)=>s+moneyNum(x.amount),0);
    const withBill=rows.filter(x=>x.billPath).length;
    const withoutBill=rows.length-withBill;
    return json(res,200,{
      financialYear:fy,categories:EXPENSE_CATEGORIES,
      summary:{totalExpense,totalEntries:rows.length,withBill,withoutBill},
      categorySummary,rows
    });
  }

  if(pathname==='/api/expenses' && req.method==='POST'){
    return body(req).then(d=>{
      const category=String(d.category||'').trim();
      if(!EXPENSE_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid expense category'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid expense amount required'});
      const paidTo=String(d.paidTo||'').trim();
      const purpose=String(d.purpose||'').trim();
      let approvedBy=String(d.approvedBy||'').trim();
      if(!paidTo) return json(res,400,{error:'Paid To is required'});
      if(!purpose) return json(res,400,{error:'Expense purpose is required'});

      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const fundingPurpose=String(d.fundingPurpose||'').trim();
      if(fundingPurpose && !DONATION_PURPOSES.includes(fundingPurpose))
        return json(res,400,{error:'Invalid Fund / Donation Purpose'});
      const approval=validateFinancialApproval(db,{amount,context:'Expense',date,approvals:d.approvals||{},resolutionId:d.resolutionId||''});
      if(!approval.ok) return json(res,400,{error:approval.error});
      approvedBy=approvalDisplayName(approval,approvedBy);
      if(!approvedBy) return json(res,400,{error:'Approved By is required'});
      const resolution=approval.snapshot?.resolutionId?{
        resolutionId:approval.snapshot.resolutionId,resolutionNo:approval.snapshot.resolutionNo,resolutionTitle:approval.snapshot.resolutionTitle
      }:resolutionSnapshot(db,String(d.resolutionId||'').trim());
      if(d.resolutionId&&!resolution) return json(res,400,{error:'Selected Resolution is not valid for this approval'});

      let billPath='', billOriginalName='';
      if(d.billDataUrl){
        const filename=safeName(d.billFilename||'bill');
        if(!/\.(pdf|png|jpg|jpeg|webp)$/i.test(filename))
          return json(res,400,{error:'Bill must be PDF, PNG, JPG, JPEG or WEBP'});
        const saved=saveDataUrl(d.billDataUrl,filename,10*1024*1024);
        billPath=saved.path;
        billOriginalName=filename;
      }

      const obj={
        id:nextExpenseVoucherNo(db,fyValue),
        type:'Expense',category,amount,date,financialYear:fyValue,
        paidTo,mode:d.paymentMode||'Cash',purpose,
        description:purpose,remarks:String(d.remarks||'').trim(),
        approvedBy,fundingPurpose,billPath,billOriginalName,
        eventId:String(d.eventId||''),
        socialProjectId:String(d.socialProjectId||''),
        approvalSnapshot:approval.required?approval.snapshot:null,
        ...(resolution||{resolutionId:'',resolutionNo:'',resolutionTitle:''})
      };
      db.transactions.unshift(obj);
      audit(db,'Expense Added',`${obj.id} ${category} ₹${amount} / ${paidTo}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/incomes' && req.method==='GET'){
    const collections=inFY(db.collections,fy);
    const manualIncome=inFY(db.transactions,fy).filter(x=>x.type==='Income');
    const rows=[];

    for(const c of collections){
      rows.push({
        id:c.id,date:c.date,category:collectionIncomeCategory(c),
        source:c.personName||'',paymentMode:c.mode||'',
        amount:moneyNum(c.amount),remarks:c.notes||'',
        recordType:'Receipt',linkedType:c.type||'',memberId:c.memberId||''
      });
    }
    for(const t of manualIncome){
      rows.push({
        id:t.id,date:t.date,category:INCOME_CATEGORIES.includes(t.category)?t.category:'Other Legal Income',
        source:t.source||t.description||'',paymentMode:t.mode||'',
        amount:moneyNum(t.amount),remarks:t.remarks||t.description||'',
        recordType:'Voucher',linkedType:'Manual Income',memberId:''
      });
    }

    rows.sort((a,b)=>String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id)));
    const categorySummary=INCOME_CATEGORIES.map(category=>{
      const amount=rows.filter(x=>x.category===category).reduce((s,x)=>s+moneyNum(x.amount),0);
      const count=rows.filter(x=>x.category===category).length;
      return {category,amount,count};
    });
    const totalIncome=rows.reduce((s,x)=>s+moneyNum(x.amount),0);
    const receiptIncome=rows.filter(x=>x.recordType==='Receipt').reduce((s,x)=>s+moneyNum(x.amount),0);
    const voucherIncome=rows.filter(x=>x.recordType==='Voucher').reduce((s,x)=>s+moneyNum(x.amount),0);
    return json(res,200,{
      financialYear:fy,categories:INCOME_CATEGORIES,
      summary:{totalIncome,receiptIncome,voucherIncome,totalEntries:rows.length},
      categorySummary,rows
    });
  }

  if(pathname==='/api/incomes' && req.method==='POST'){
    return body(req).then(d=>{
      const category=String(d.category||'').trim();
      if(!INCOME_CATEGORIES.includes(category))
        return json(res,400,{error:'Select a valid income category'});
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid income amount required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const fundingPurpose=String(d.fundingPurpose||'').trim();
      if(fundingPurpose && !DONATION_PURPOSES.includes(fundingPurpose))
        return json(res,400,{error:'Invalid Fund / Donation Purpose'});
      const obj={
        id:nextIncomeVoucherNo(db,fyValue),
        type:'Income',category,
        source:String(d.source||'').trim(),
        description:String(d.remarks||'').trim(),
        remarks:String(d.remarks||'').trim(),
        mode:d.paymentMode||'Cash',
        amount,date,financialYear:fyValue,fundingPurpose,
        eventId:String(d.eventId||''),
        eventIncomeType:String(d.eventIncomeType||'')
      };
      if(!obj.source) return json(res,400,{error:'Income source is required'});
      db.transactions.unshift(obj);
      audit(db,'Income Added',`${obj.id} ${category} ₹${amount} / ${obj.source}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/donations' && req.method==='GET'){
    const donations=inFY(db.collections,fy).filter(x=>String(x.type||'').toLowerCase()==='donation');
    const expenses=inFY(db.transactions,fy).filter(x=>x.type==='Expense');
    const memberDonation=donations.filter(x=>x.donationType==='Member Donation').reduce((s,x)=>s+moneyNum(x.amount),0);
    const externalDonation=donations.filter(x=>x.donationType==='External Donation').reduce((s,x)=>s+moneyNum(x.amount),0);
    const totalDonation=memberDonation+externalDonation;
    const donorKeys=new Set(donations.map(x=>x.memberId?`M:${x.memberId}`:`E:${String(x.personName||'').toLowerCase()}:${String(x.donorMobile||'')}`));
    const purposeSummary=DONATION_PURPOSES.map(purpose=>{
      const received=donations.filter(x=>(x.donationPurpose||'General Fund')===purpose).reduce((s,x)=>s+moneyNum(x.amount),0);
      const spent=expenses.filter(x=>String(x.fundingPurpose||'')===purpose).reduce((s,x)=>s+moneyNum(x.amount),0);
      return {purpose,received,spent,balance:received-spent};
    });
    const totalPurposeSpent=purposeSummary.reduce((s,x)=>s+moneyNum(x.spent),0);
    return json(res,200,{
      financialYear:fy,
      purposes:DONATION_PURPOSES,
      summary:{totalDonation,memberDonation,externalDonation,totalDonors:donorKeys.size,totalPurposeSpent,purposeBalance:totalDonation-totalPurposeSpent},
      purposeSummary,donations
    });
  }

  if(pathname==='/api/donations' && req.method==='POST'){
    return body(req).then(d=>{
      const donationType=String(d.donationType||'');
      if(!['Member Donation','External Donation'].includes(donationType))
        return json(res,400,{error:'Select Member Donation or External Donation'});
      const purpose=String(d.donationPurpose||'');
      if(!DONATION_PURPOSES.includes(purpose))
        return json(res,400,{error:'Select a valid donation purpose'});
      let member=null, donorName='', donorMobile='';
      if(donationType==='Member Donation'){
        member=db.members.find(x=>x.id===d.memberId);
        if(!member) return json(res,400,{error:'Select a valid member'});
        donorName=member.name;
        donorMobile=member.phone||'';
      }else{
        donorName=String(d.donorName||'').trim();
        donorMobile=String(d.donorMobile||'').trim();
        if(!donorName) return json(res,400,{error:'External donor name is required'});
      }
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid donation amount required'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const receipt={
        id:nextReceiptNo(db,fyValue),
        memberId:member?.id||'',
        personName:donorName,
        donorMobile,
        donationType,
        donationPurpose:purpose,
        type:'Donation',
        eventId:String(d.eventId||''),
        eventIncomeType:d.eventId?'Donation':'',
        mode:d.mode||'Cash',
        amount,date,financialYear:fyValue,
        notes:String(d.notes||'')
      };
      db.collections.unshift(receipt);
      audit(db,'Donation Received',`${receipt.id} ${donationType} - ${donorName} ₹${amount} / ${purpose}`);
      saveDB(db);
      json(res,200,receipt);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/subscriptions' && req.method==='GET'){
    const month=url.searchParams.get('month') || fyMonthKeys(fy)[0];
    const monthKeys=fyMonthKeys(fy);
    if(!monthKeys.includes(month)) return json(res,400,{error:'Month does not belong to selected Financial Year'});
    const memberRows=[];
    for(const member of db.members){
      if(!memberEligibleForMonth(member,month)) continue;
      const ledger=memberSubscriptionLedger(db,member,fy);
      const row=ledger.find(x=>x.month===month);
      memberRows.push({
        memberId:member.id,name:member.name,phone:member.phone||'',
        membershipType:member.membershipType||'General',
        designation:member.designation||'Member',
        status:member.status||'Active',monthlyFee:moneyNum(member.monthlyFee),
        ...row
      });
    }
    const dueRows=memberRows.filter(x=>x.payable>0);
    const totalMembers=dueRows.length;
    const paid=dueRows.filter(x=>x.status==='Paid').length;
    const unpaid=dueRows.filter(x=>x.status==='Unpaid').length;
    const partialPaid=dueRows.filter(x=>x.status==='Partial Paid').length;
    const totalCollection=dueRows.reduce((s,x)=>s+moneyNum(x.paid),0);
    const totalDue=dueRows.reduce((s,x)=>s+moneyNum(x.due),0);
    return json(res,200,{
      financialYear:fy,selectedMonth:month,
      months:monthKeys.map(k=>({key:k,label:monthLabel(k)})),
      summary:{totalMembers,paid,unpaid,partialPaid,totalCollection,totalDue},
      members:memberRows
    });
  }

  if(/^\/api\/subscriptions\/member\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[4]);
    const member=db.members.find(x=>x.id===id);
    if(!member) return json(res,404,{error:'Member not found'});
    const ledger=memberSubscriptionLedger(db,member,fy);
    const totalPayable=ledger.reduce((s,x)=>s+moneyNum(x.payable),0);
    const totalPaid=ledger.reduce((s,x)=>s+moneyNum(x.paid),0);
    const totalDue=ledger.reduce((s,x)=>s+moneyNum(x.due),0);
    return json(res,200,{
      financialYear:fy,member,
      summary:{totalPayable,totalPaid,totalDue},
      ledger
    });
  }

  if(pathname==='/api/subscriptions/payment' && req.method==='POST'){
    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid member'});
      const count=Number(d.monthsCount||1);
      if(![1,3,6,12].includes(count)) return json(res,400,{error:'Months count must be 1, 3, 6 or 12'});
      const months=fyMonthKeys(fy);
      const startIndex=months.indexOf(String(d.startMonth||''));
      if(startIndex<0) return json(res,400,{error:'Select a valid start month'});
      const selected=months.slice(startIndex,startIndex+count);
      if(!selected.length) return json(res,400,{error:'No valid months selected'});
      const ledger=memberSubscriptionLedger(db,member,fy);
      const dueMap=new Map(ledger.map(x=>[x.month,x.due]));
      const totalSelectedDue=selected.reduce((s,m)=>s+moneyNum(dueMap.get(m)),0);
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid payment amount required'});
      if(totalSelectedDue<=0) return json(res,400,{error:'Selected month(s) have no outstanding subscription due'});
      if(amount-totalSelectedDue>0.001) return json(res,400,{error:`Payment exceeds selected due amount (${totalSelectedDue})`});

      let remaining=amount;
      const allocations=[];
      for(const month of selected){
        if(remaining<=0) break;
        const due=moneyNum(dueMap.get(month));
        if(due<=0) continue;
        const allocated=Math.min(due,remaining);
        allocations.push({month,amount:allocated});
        remaining=Number((remaining-allocated).toFixed(2));
      }
      if(!allocations.length) return json(res,400,{error:'Nothing could be allocated to selected months'});

      const date=d.date||new Date().toISOString().slice(0,10);
      const receipt={
        id:nextReceiptNo(db,fy),memberId:member.id,personName:member.name,
        type:'Monthly Membership Fee',mode:d.mode||'Cash',
        amount,date,financialYear:fy,notes:String(d.notes||''),
        subscriptionAllocations:allocations,
        subscriptionMonths:allocations.map(x=>x.month)
      };
      db.collections.unshift(receipt);
      audit(db,'Monthly Subscription Received',`${member.id} ${member.name} ₹${amount} / ${allocations.map(x=>x.month).join(', ')}`);
      saveDB(db);
      json(res,200,{receipt,allocations,totalSelectedDue});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/applications' && req.method==='GET'){
    return json(res,200,db.membershipApplications);
  }

  if(pathname==='/api/applications' && req.method==='POST'){
    return body(req).then(d=>{
      const required=[['Full Name',d.name],['Gender',d.gender],['Mobile Number',d.phone],['Email ID',d.email]];
      const missing=required.find(x=>!String(x[1]||'').trim());
      if(missing)return json(res,400,{error:`${missing[0]} is required.`});

      const aadhaar=String(d.aadhaarNumber||'').replace(/\D/g,'');
      const pan=String(d.panNumber||'').trim().toUpperCase();
      const voter=String(d.voterNumber||'').trim().toUpperCase();
      if(aadhaar && !/^\d{12}$/.test(aadhaar))return json(res,400,{error:'Aadhaar Card Number must contain exactly 12 digits when entered.'});
      if(pan && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan))return json(res,400,{error:'Enter a valid PAN Card Number.'});
      if(voter && voter.length<6)return json(res,400,{error:'Enter a valid Voter Card / EPIC Number.'});

      const files=[
        ['photo','Applicant Photo',d.photoDataUrl,d.photoFilename,3*1024*1024,/\.(png|jpg|jpeg|webp)$/i],
        ['aadhaar','Aadhaar Card',d.aadhaarDataUrl,d.aadhaarFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i],
        ['pan','PAN Card',d.panDataUrl,d.panFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i],
        ['voter','Voter Card',d.voterDataUrl,d.voterFilename,6*1024*1024,/\.(pdf|png|jpg|jpeg|webp)$/i]
      ];
      for(const [_,label,dataUrl,filename,,pattern] of files){
        if((dataUrl&&!filename)||(!dataUrl&&filename))return json(res,400,{error:`${label} upload data is incomplete.`});
        if(filename&&!pattern.test(String(filename)))return json(res,400,{error:`${label} file type is not supported.`});
      }
      const saved={};
      try{
        for(const [key,,dataUrl,filename,max] of files)if(dataUrl&&filename)saved[key]=saveDataUrl(dataUrl,safeName(filename),max);
      }catch(err){
        for(const x of Object.values(saved))if(x?.path)deleteUploaded(x.path);
        throw err;
      }

      const permanentAddress=[d.permanentAddressLine,d.permanentVillage,d.permanentPostOffice,d.permanentPoliceStation,d.permanentGpWard,d.permanentBlockMunicipality,d.permanentDistrict,d.permanentState,d.permanentPin].filter(Boolean).join(', ');
      const centreAddress=[d.centreAddressLine,d.centreVillage,d.centrePostOffice,d.centrePoliceStation,d.centreGpWard,d.centreBlockMunicipality,d.centreDistrict,d.centreState,d.centrePin].filter(Boolean).join(', ');
      const now=new Date().toISOString();
      const obj={
        id:nextApplicationCode(db),applicationDate:d.applicationDate||now.slice(0,10),
        name:String(d.name||'').trim(),fatherSpouse:String(d.fatherSpouse||'').trim(),dob:String(d.dob||''),gender:String(d.gender||'').trim(),
        phone:String(d.phone||'').trim(),whatsapp:String(d.whatsapp||'').trim(),email:String(d.email||'').trim(),address:permanentAddress,
        permanentVillage:String(d.permanentVillage||'').trim(),permanentPostOffice:String(d.permanentPostOffice||'').trim(),permanentPoliceStation:String(d.permanentPoliceStation||'').trim(),
        permanentGpWard:String(d.permanentGpWard||'').trim(),permanentBlockMunicipality:String(d.permanentBlockMunicipality||'').trim(),permanentDistrict:String(d.permanentDistrict||'').trim(),
        permanentState:String(d.permanentState||'').trim(),permanentPin:String(d.permanentPin||'').trim(),permanentAddressLine:String(d.permanentAddressLine||'').trim(),
        cscId:String(d.cscId||'').trim(),cscCentreName:String(d.cscCentreName||'').trim(),sameAsPermanentAddress:!!d.sameAsPermanentAddress,
        centreVillage:String(d.centreVillage||'').trim(),centrePostOffice:String(d.centrePostOffice||'').trim(),centrePoliceStation:String(d.centrePoliceStation||'').trim(),
        centreGpWard:String(d.centreGpWard||'').trim(),centreBlockMunicipality:String(d.centreBlockMunicipality||'').trim(),centreDistrict:String(d.centreDistrict||'').trim(),
        centreState:String(d.centreState||'').trim(),centrePin:String(d.centrePin||'').trim(),centreAddressLine:String(d.centreAddressLine||'').trim(),centreAddress,
        aadhaarNumber:aadhaar,aadhaarPath:saved.aadhaar?.path||'',aadhaarOriginalName:d.aadhaarFilename?safeName(d.aadhaarFilename):'',
        panNumber:pan,panPath:saved.pan?.path||'',panOriginalName:d.panFilename?safeName(d.panFilename):'',
        voterNumber:voter,voterPath:saved.voter?.path||'',voterOriginalName:d.voterFilename?safeName(d.voterFilename):'',
        identityType:aadhaar?'Aadhaar':pan?'PAN':voter?'Voter':'',
        identityNumber:aadhaar||pan||voter||'',
        identityProofPath:saved.aadhaar?.path||saved.pan?.path||saved.voter?.path||'',
        identityProofOriginalName:d.aadhaarFilename?safeName(d.aadhaarFilename):(d.panFilename?safeName(d.panFilename):(d.voterFilename?safeName(d.voterFilename):'')),
        occupation:'',membershipType:'General',designation:'Member',
        nomineeName:String(d.nomineeName||'').trim(),nomineeRelation:String(d.nomineeRelation||'').trim(),nomineePhone:String(d.nomineePhone||'').trim(),
        nomineeWhatsapp:String(d.nomineeWhatsapp||'').trim(),nomineeAddress:String(d.nomineeAddress||'').trim(),
        reasonForJoining:'',source:'Internal ERP',monthlyFee:moneyNum(db.setup.monthlyFee||0),joiningFee:moneyNum(db.setup.joiningFee||0),
        declaration:!!d.declaration,
        declarationText:d.declaration?"I hereby apply for membership in the organization. I declare that the information and documents provided are true and correct to the best of my knowledge.":'',
        photoPath:saved.photo?.path||'',status:'Pending',verificationNotes:'',committeeNotes:'',rejectionReason:'',memberId:'',
        profileComplete:false,
        history:[{status:'Pending',note:'Internal application created. Additional profile/KYC information may be completed later.',at:now}],
        createdAt:now
      };
      const complete=[obj.fatherSpouse,obj.dob,obj.whatsapp,obj.permanentVillage,obj.permanentPostOffice,obj.permanentPoliceStation,obj.permanentGpWard,obj.permanentBlockMunicipality,obj.permanentDistrict,obj.cscId,obj.cscCentreName,obj.centreVillage,obj.centrePostOffice,obj.centrePoliceStation,obj.centreGpWard,obj.centreBlockMunicipality,obj.centreDistrict,obj.photoPath,obj.aadhaarNumber,obj.aadhaarPath,obj.panNumber,obj.panPath,obj.voterNumber,obj.voterPath,obj.nomineeName,obj.nomineeRelation,obj.nomineePhone,obj.declaration];
      obj.profileComplete=complete.every(Boolean);

      db.membershipApplications.unshift(obj);
      audit(db,'Membership Application Submitted',`${obj.id} - ${obj.name}`);
      saveDB(db);
      return json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message||'Unable to create membership application'}));
  }

  if(/^\/api\/applications\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const app=db.membershipApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Application not found'});
    return json(res,200,app);
  }

  if(/^\/api\/applications\/[^/]+\/photo$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const app=db.membershipApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Application not found'});
    return body(req).then(d=>{
      if(!/\.(png|jpg|jpeg|webp)$/i.test(String(d.filename||'')))
        return json(res,400,{error:'Photo must be PNG, JPG, JPEG or WEBP'});
      const saved=saveDataUrl(d.dataUrl,safeName(d.filename),3*1024*1024);
      if(app.photoPath) deleteUploaded(app.photoPath);
      app.photoPath=saved.path;
      audit(db,'Application Photo Updated',`${app.id} - ${app.name}`);
      saveDB(db); json(res,200,{path:saved.path});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/applications\/[^/]+\/status$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const app=db.membershipApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Application not found'});
    return body(req).then(d=>{
      const next=String(d.status||'');
      const allowed={
        'Pending':['Under Verification','Rejected'],
        'Under Verification':['Approved','Rejected'],
        'Approved':['Payment Pending','Rejected'],
        'Payment Pending':['Rejected']
      };
      if(!(allowed[app.status]||[]).includes(next))
        return json(res,400,{error:`Invalid workflow change: ${app.status} → ${next}`});
      if(next==='Rejected' && !String(d.reason||'').trim())
        return json(res,400,{error:'Rejection reason is mandatory.'});
      if(next==='Under Verification') app.verificationNotes=String(d.notes||'').trim();
      if(next==='Approved') app.committeeNotes=String(d.notes||'').trim();
      if(next==='Rejected') app.rejectionReason=String(d.reason||'').trim();
      app.status=next;
      app.history.unshift({
        status:next,
        note:next==='Rejected'?app.rejectionReason:String(d.notes||'').trim(),
        at:new Date().toISOString()
      });
      audit(db,'Membership Workflow',`${app.id}: ${next}${next==='Rejected'?' - '+app.rejectionReason:''}`);
      saveDB(db); json(res,200,app);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/applications\/[^/]+\/activate$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const app=db.membershipApplications.find(x=>x.id===id);
    if(!app) return json(res,404,{error:'Application not found'});
    if(app.status!=='Payment Pending') return json(res,400,{error:'Application must be Payment Pending before activation.'});
    if(app.memberId) return json(res,409,{error:'Member ID already generated.'});
    return body(req).then(d=>{
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid joining fee amount required.'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const memberId=nextMemberCode(db);
      const member={
        id:memberId,name:app.name,fatherSpouse:app.fatherSpouse,dob:app.dob,gender:app.gender||'',
        phone:app.phone,whatsapp:app.whatsapp||'',email:app.email,address:app.address,photoPath:app.photoPath,
        joinDate:date,membershipType:app.membershipType,designation:app.designation||'Member',
        status:'Active',emergencyName:app.nomineeName,emergencyPhone:app.nomineePhone,
        emergencyRelation:app.nomineeRelation,monthlyFee:moneyNum(app.monthlyFee),
        occupation:app.occupation,identityType:app.identityType,identityNumber:app.identityNumber,
        cscId:app.cscId||'',cscCentreName:app.cscCentreName||'',cscCentreAddress:app.centreAddress||'',
        cscArea:app.centreVillage||'',cscBlock:app.centreBlockMunicipality||'',cscDistrict:app.centreDistrict||'',
        cscState:app.centreState||'',cscPin:app.centrePin||'',cscPhone:app.phone||'',cscEmail:app.email||'',
        sourceApplicationId:app.id
      };
      const receiptFY=d.financialYear||financialYear(date);
      const receipt={
        id:nextReceiptNo(db,receiptFY),memberId,personName:member.name,type:'Joining Fee',
        mode:d.mode||'Cash',amount,date,financialYear:receiptFY,
        notes:`Membership joining fee for ${app.id}`
      };
      db.members.unshift(member);
      db.collections.unshift(receipt);
      app.status='Active';
      app.memberId=memberId;
      app.joiningFeePaid=amount;
      app.joiningFeeMode=receipt.mode;
      app.joiningFeeDate=date;
      app.history.unshift({status:'Active',note:`Joining Fee ${amount} received. Member ID ${memberId} generated.`,at:new Date().toISOString()});
      audit(db,'Member Activated',`${app.id} → ${memberId} - ${member.name}`);
      saveDB(db);
      json(res,200,{application:app,member,receipt});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  const resources = {
    '/api/members':'members',
    '/api/collections':'collections',
    '/api/transactions':'transactions'
  };
  if(resources[pathname] && req.method==='GET'){
    const key=resources[pathname];
    if(key==='members') return json(res,200,db.members);
    return json(res,200,inFY(db[key],fy));
  }

  if(pathname==='/api/members' && req.method==='POST'){
    return body(req).then(d=>{
      const obj={
        id:nextMemberCode(db),
        name:String(d.name||'').trim(),
        fatherSpouse:String(d.fatherSpouse||'').trim(),
        dob:String(d.dob||''),
        phone:String(d.phone||'').trim(),
        email:String(d.email||'').trim(),
        address:String(d.address||'').trim(),
        photoPath:'',
        joinDate:d.joinDate||new Date().toISOString().slice(0,10),
        membershipType:String(d.membershipType||'General').trim(),
        designation:String(d.designation||'Member').trim(),
        status:d.status||'Active',
        emergencyName:String(d.emergencyName||'').trim(),
        emergencyPhone:String(d.emergencyPhone||'').trim(),
        emergencyRelation:String(d.emergencyRelation||'').trim(),
        cscCentreName:String(d.cscCentreName||'').trim(),
        cscId:String(d.cscId||'').trim(),
        cscCentreAddress:String(d.cscCentreAddress||'').trim(),
        cscArea:String(d.cscArea||'').trim(),
        cscBlock:String(d.cscBlock||'').trim(),
        cscDistrict:String(d.cscDistrict||'').trim(),
        cscState:String(d.cscState||'').trim(),
        cscPin:String(d.cscPin||'').trim(),
        cscPhone:String(d.cscPhone||'').trim(),
        cscEmail:String(d.cscEmail||'').trim(),
        cscLandmark:String(d.cscLandmark||'').trim(),
        cscServices:String(d.cscServices||'').trim(),
        publicCscVisible:!!d.publicCscVisible,
        monthlyFee:moneyNum(d.monthlyFee)
      };
      if(!obj.name) return json(res,400,{error:'Member name required'});
      db.members.unshift(obj);
      audit(db,'Member Added',`${obj.id} - ${obj.name}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }


  if(/^\/api\/members\/[^/]+$/.test(pathname) && req.method==='PUT'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const member=db.members.find(x=>x.id===id);
    if(!member) return json(res,404,{error:'Member not found'});
    return body(req).then(d=>{
      const fields=['name','fatherSpouse','dob','phone','email','address','joinDate','membershipType','designation','status','emergencyName','emergencyPhone','emergencyRelation','cscCentreName','cscId','cscCentreAddress','cscArea','cscBlock','cscDistrict','cscState','cscPin','cscPhone','cscEmail','cscLandmark','cscServices'];
      for(const k of fields) if(d[k]!==undefined) member[k]=String(d[k]).trim();
      if(d.publicCscVisible!==undefined) member.publicCscVisible=!!d.publicCscVisible;
      if(d.monthlyFee!==undefined) member.monthlyFee=moneyNum(d.monthlyFee);
      if(!member.name) return json(res,400,{error:'Member name required'});
      audit(db,'Member Updated',`${member.id} - ${member.name}`);
      saveDB(db); json(res,200,member);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/members\/[^/]+\/profile$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const member=db.members.find(x=>x.id===id);
    if(!member) return json(res,404,{error:'Member not found'});
    const collections=inFY(db.collections,fy).filter(x=>x.memberId===id);
    const subscription=collections.filter(x=>String(x.type).toLowerCase().includes('subscription')).reduce((s,x)=>s+moneyNum(x.amount),0);
    const donation=collections.filter(x=>String(x.type).toLowerCase().includes('donation')).reduce((s,x)=>s+moneyNum(x.amount),0);
    const otherCollection=collections.filter(x=>!String(x.type).toLowerCase().includes('subscription')&&!String(x.type).toLowerCase().includes('donation')).reduce((s,x)=>s+moneyNum(x.amount),0);
    const dueMonths=monthsDueForFY(member.joinDate,fy);
    const expected=dueMonths*moneyNum(member.monthlyFee);
    const arrears=Math.max(0,expected-subscription);
    const benefits=db.memberBenefits.filter(x=>x.memberId===id && (x.financialYear||financialYear(x.date))===fy);
    const benefitTotal=benefits.reduce((s,x)=>s+moneyNum(x.amount),0);
    const loans=inFY(db.loans,fy).filter(x=>x.memberId===id);
    const loanTotal=loans.reduce((s,x)=>s+moneyNum(x.disbursedAmount||0),0);
    const loanRepaid=loans.reduce((s,x)=>s+moneyNum(x.repaid),0);
    const loanOutstanding=loans.filter(x=>['Disbursed','Repayment'].includes(x.status)).reduce((s,x)=>s+loanOutstandingAmount(x),0);
    return json(res,200,{
      member,financialYear:fy,
      summary:{dueMonths,expectedSubscription:expected,totalSubscription:subscription,arrears,donation,otherCollection,benefitTotal,loanTotal,loanRepaid,loanOutstanding},
      collections,benefits,loans,nominees:member.nominees||[]
    });
  }

  if(/^\/api\/members\/[^/]+\/photo$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const member=db.members.find(x=>x.id===id);
    if(!member) return json(res,404,{error:'Member not found'});
    return body(req).then(d=>{
      if(!/\.(png|jpg|jpeg|webp)$/i.test(String(d.filename||''))) return json(res,400,{error:'Photo must be PNG, JPG, JPEG or WEBP'});
      const saved=saveDataUrl(d.dataUrl,safeName(d.filename),3*1024*1024);
      if(member.photoPath) deleteUploaded(member.photoPath);
      member.photoPath=saved.path;
      audit(db,'Member Photo Updated',`${member.id} - ${member.name}`);
      saveDB(db); json(res,200,{path:saved.path});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/members\/[^/]+\/nominees$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]),member=db.members.find(x=>x.id===id);if(!member)return json(res,404,{error:'Member not found'});
    return body(req).then(d=>{const share=Math.max(0,Math.min(100,moneyNum(d.sharePercent))),current=(member.nominees||[]).reduce((s,x)=>s+moneyNum(x.sharePercent),0);if(current+share>100.001)return json(res,400,{error:'Total nominee share cannot exceed 100%'});const obj={id:uid('NOM'),name:String(d.name||'').trim(),relation:String(d.relation||'').trim(),dob:String(d.dob||''),phone:String(d.phone||'').trim(),address:String(d.address||'').trim(),sharePercent:share,isPrimary:!!d.isPrimary,notes:String(d.notes||'').trim()};if(!obj.name||!obj.relation)return json(res,400,{error:'Nominee Name and Relation required'});if(obj.isPrimary)for(const n of member.nominees||[])n.isPrimary=false;member.nominees.push(obj);audit(db,'Nominee Added',`${member.id} ${obj.name}`,{recordType:'Nominee',recordId:obj.id});saveDB(db);json(res,200,obj);}).catch(e=>json(res,400,{error:e.message}));
  }
  if(/^\/api\/members\/[^/]+\/nominees\/[^/]+$/.test(pathname) && req.method==='DELETE'){const parts=pathname.split('/'),member=db.members.find(x=>x.id===decodeURIComponent(parts[3]));if(!member)return json(res,404,{error:'Member not found'});const nomId=decodeURIComponent(parts[5]);member.nominees=(member.nominees||[]).filter(x=>x.id!==nomId);audit(db,'Nominee Removed',`${member.id} ${nomId}`,{recordType:'Nominee',recordId:nomId});saveDB(db);return json(res,200,{ok:true});}

  if(/^\/api\/members\/[^/]+\/benefits$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const member=db.members.find(x=>x.id===id);
    if(!member) return json(res,404,{error:'Member not found'});
    return body(req).then(d=>{
      const date=d.date||new Date().toISOString().slice(0,10);
      const obj={
        id:uid('BEN'),memberId:id,type:String(d.type||'Financial Assistance').trim(),
        description:String(d.description||'').trim(),amount:moneyNum(d.amount),
        date,financialYear:d.financialYear||financialYear(date)
      };
      db.memberBenefits.unshift(obj);
      audit(db,'Member Benefit Added',`${member.id} - ${obj.type} ₹${obj.amount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname.startsWith('/api/member-benefits/') && req.method==='DELETE'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    db.memberBenefits=db.memberBenefits.filter(x=>x.id!==id);
    audit(db,'Member Benefit Deleted',id); saveDB(db);
    return json(res,200,{ok:true});
  }

  if(pathname==='/api/collections' && req.method==='POST'){
    return body(req).then(d=>{
      const member=db.members.find(x=>x.id===d.memberId);
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const obj={
        id:nextReceiptNo(db,fyValue),memberId:d.memberId||'',
        personName:member?.name||String(d.personName||'').trim(),
        type:d.type||'Monthly Membership Fee',mode:d.mode||'Cash',
        amount:moneyNum(d.amount),date,financialYear:fyValue,
        notes:String(d.notes||'')
      };
      if(!obj.personName||obj.amount<=0) return json(res,400,{error:'Name and valid amount required'});
      db.collections.unshift(obj); audit(db,'Collection Added',`${obj.personName} ₹${obj.amount} (${obj.financialYear})`); saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/transactions' && req.method==='POST'){
    return body(req).then(d=>{
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(date);
      const fundingPurpose=String(d.fundingPurpose||'').trim();
      if(fundingPurpose && !DONATION_PURPOSES.includes(fundingPurpose))
        return json(res,400,{error:'Invalid Fund / Donation Purpose'});
      const txnType=d.type||'Expense';
      const obj={
        id:txnType==='Income'?nextIncomeVoucherNo(db,fyValue):nextExpenseVoucherNo(db,fyValue),
        type:txnType,category:String(d.category||'Other'),
        source:String(d.source||'').trim(),
        paidTo:String(d.paidTo||'').trim(),
        purpose:String(d.purpose||d.description||'').trim(),
        approvedBy:String(d.approvedBy||'').trim(),
        description:String(d.description||d.purpose||d.remarks||''),
        remarks:String(d.remarks||d.description||''),
        mode:d.mode||'Cash',
        amount:moneyNum(d.amount),date,financialYear:fyValue,
        fundingPurpose,billPath:'',billOriginalName:''
      };
      if(obj.amount<=0) return json(res,400,{error:'Valid amount required'});
      db.transactions.unshift(obj); audit(db,`${obj.type} Added`,`${obj.category} ₹${obj.amount} (${obj.financialYear})`); saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/loans' && req.method==='GET'){
    const settings=db.loanSettings||{};
    const today=new Date().toISOString().slice(0,10);
    const loans=inFY(db.loans||[],fy)
      .map(l=>({
        ...l,
        totalRepayable:moneyNum(l.totalRepayable||moneyNum(l.disbursedAmount)+moneyNum(l.chargeAmount)),
        totalPaid:moneyNum(l.totalPaid||0),
        totalOutstanding:loanTotalOutstanding(l),
        installmentAmount:moneyNum(l.installmentAmount||0),
        repaymentStatus:loanRepaymentStatus(l,today)
      }))
      .sort((a,b)=>String(b.applicationDate||b.date||'').localeCompare(String(a.applicationDate||a.date||'')) || String(b.id).localeCompare(String(a.id)));

    const cashTotal=buildAccountLedger(db,fy,'cash').closingBalance
      +buildAccountLedger(db,fy,'bank').closingBalance
      +buildAccountLedger(db,fy,'upi').closingBalance;
    const policyRows=ensureFundPolicyForFY(db,fy);
    const loanFund=policyRows.find(x=>{
      const n=String(x.name||'').toLowerCase();
      return n.includes('loan fund') || n.includes('financial assistance');
    });
    const loanFundPercent=moneyNum(loanFund?.percent||0);
    const earmarkedAmount=cashTotal*loanFundPercent/100;
    const totalOutstanding=loans.filter(x=>['Disbursed','Repayment'].includes(x.status)).reduce((s,x)=>s+loanOutstandingAmount(x),0);
    const policyAvailable=Math.max(0,earmarkedAmount-totalOutstanding);

    return json(res,200,{
      financialYear:fy,
      settings,
      complianceReady:!!(settings.facilityEnabled&&settings.complianceConfirmed),
      policy:{
        fundHeadName:loanFund?.name||'Member Financial Assistance / Loan Fund',
        percent:loanFundPercent,
        currentEarmarkedAmount:earmarkedAmount,
        currentOutstanding:totalOutstanding,
        policyAvailable
      },
      summary:{
        totalApplications:loans.length,
        applied:loans.filter(x=>x.status==='Applied').length,
        verification:loans.filter(x=>x.status==='Verification').length,
        committeeApproval:loans.filter(x=>x.status==='Committee Approval').length,
        sanctioned:loans.filter(x=>x.status==='Sanctioned').length,
        active:loans.filter(x=>['Disbursed','Repayment'].includes(x.status)).length,
        closed:loans.filter(x=>x.status==='Closed').length,
        rejected:loans.filter(x=>x.status==='Rejected').length,
        totalDisbursed:loans.reduce((s,x)=>s+moneyNum(x.disbursedAmount),0),
        totalRepaid:loans.reduce((s,x)=>s+moneyNum(x.totalPaid||0),0),
        totalOutstanding,
        repaymentCurrent:loans.filter(x=>x.repaymentStatus==='Current' && ['Disbursed','Repayment'].includes(x.status)).length,
        repaymentDue:loans.filter(x=>x.repaymentStatus==='Due').length,
        repaymentOverdue:loans.filter(x=>x.repaymentStatus==='Overdue').length
      },
      loans
    });
  }

  if(pathname==='/api/loans/settings' && req.method==='GET'){
    return json(res,200,db.loanSettings||{});
  }

  if(pathname==='/api/loans/settings' && req.method==='POST'){
    return body(req).then(d=>{
      const complianceConfirmed=!!d.complianceConfirmed;
      const facilityEnabled=!!d.facilityEnabled;
      const complianceNote=String(d.complianceNote||'').trim();
      if(complianceConfirmed && !complianceNote)
        return json(res,400,{error:'Compliance / By-laws confirmation note is required'});
      db.loanSettings={
        facilityEnabled,
        complianceConfirmed,
        complianceNote,
        minMembershipMonths:Math.max(0,Number(d.minMembershipMonths||12)),
        requireSubscriptionClear:d.requireSubscriptionClear!==false,
        requireActiveMember:d.requireActiveMember!==false,
        requireNoOverdueLoan:d.requireNoOverdueLoan!==false,
        requireCommitteeApproval:d.requireCommitteeApproval!==false,
        guarantorRequired:!!d.guarantorRequired,
        permittedChargeEnabled:!!d.permittedChargeEnabled,
        permittedChargeComplianceConfirmed:!!d.permittedChargeComplianceConfirmed,
        permittedChargeNote:String(d.permittedChargeNote||'').trim(),
        defaultChargeRate:Math.max(0,moneyNum(d.defaultChargeRate)),
        confirmedAt:complianceConfirmed?new Date().toISOString():'',
        confirmedBy:complianceConfirmed?String(d.confirmedBy||db.setup?.ownerName||'Administrator').trim():''
      };
      if(db.loanSettings.permittedChargeComplianceConfirmed && !db.loanSettings.permittedChargeNote)
        return json(res,400,{error:'Permitted charge / interest compliance note is required when charge permission is confirmed'});
      audit(db,'Loan Compliance Settings Updated',complianceConfirmed?'Facility compliance confirmed':'Loan facility not confirmed / disabled');
      saveDB(db); json(res,200,db.loanSettings);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/loans/eligibility' && req.method==='GET'){
    const memberId=url.searchParams.get('memberId')||'';
    const onDate=url.searchParams.get('date')||new Date().toISOString().slice(0,10);
    const member=db.members.find(x=>x.id===memberId);
    if(!member) return json(res,404,{error:'Member not found'});
    const result=loanEligibility(db,member,onDate);
    return json(res,200,{member:{id:member.id,name:member.name,status:member.status,joinDate:member.joinDate},date:onDate,...result});
  }

  if(pathname==='/api/loans' && req.method==='POST'){
    return body(req).then(d=>{
      const settings=db.loanSettings||{};
      if(!settings.facilityEnabled || !settings.complianceConfirmed)
        return json(res,400,{error:'Loan/Financial Assistance facility is disabled until legal/by-laws compliance is confirmed in Loan Policy Settings.'});

      const member=db.members.find(x=>x.id===d.memberId);
      if(!member) return json(res,400,{error:'Select a valid member'});
      const applicationDate=d.applicationDate||new Date().toISOString().slice(0,10);
      const fyValue=d.financialYear||financialYear(applicationDate);
      const eligibility=loanEligibility(db,member,applicationDate);
      if(!eligibility.eligible){
        const failed=eligibility.checks.filter(x=>!x.passed).map(x=>x.label).join(', ');
        return json(res,400,{error:`Member is not eligible: ${failed}`});
      }

      const requestedAmount=moneyNum(d.requestedAmount);
      if(requestedAmount<=0) return json(res,400,{error:'Requested amount must be greater than zero'});
      const repaymentPeriod=Math.max(1,Number(d.repaymentPeriod||1));
      const purpose=String(d.purpose||'').trim();
      if(!purpose) return json(res,400,{error:'Loan / financial assistance purpose is required'});

      const guarantorName=String(d.guarantorName||'').trim();
      const guarantorPhone=String(d.guarantorPhone||'').trim();
      const guarantorMemberId=String(d.guarantorMemberId||'').trim();
      if(settings.guarantorRequired && !guarantorName && !guarantorMemberId)
        return json(res,400,{error:'Guarantor is required by current Loan Policy'});

      const obj={
        id:nextLoanApplicationNo(db,fyValue),
        memberId:member.id,memberName:member.name,
        applicationDate,date:applicationDate,financialYear:fyValue,
        requestedAmount,amount:requestedAmount,
        purpose,repaymentPeriod,
        guarantorName,guarantorPhone,guarantorMemberId,
        documents:[],
        status:'Applied',
        eligibilitySnapshot:eligibility,
        verificationNotes:'',verifiedBy:'',
        committeeNotes:'',approvedBy:'',
        sanctionedAmount:0,sanctionDate:'',
        chargeRate:0,chargeAmount:0,totalRepayable:0,installmentAmount:0,
        disbursedAmount:0,disbursementDate:'',disbursementMode:'',disbursementReference:'',
        firstInstallmentDate:'',maturityDate:'',
        totalPaid:0,principalRepaid:0,chargeRepaid:0,repaid:0,rejectionReason:'',
        history:[{status:'Applied',note:'Loan / financial assistance application submitted after eligibility check',at:new Date().toISOString()}],
        createdAt:new Date().toISOString()
      };
      db.loans.unshift(obj);
      audit(db,'Loan Application Submitted',`${obj.id} ${member.id} ${member.name} ₹${requestedAmount}`);
      saveDB(db); json(res,200,obj);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/loans\/[^/]+$/.test(pathname) && req.method==='GET'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const loan=db.loans.find(x=>x.id===id);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    const repayments=(db.loanRepayments||[]).filter(x=>x.loanId===id)
      .slice().sort((a,b)=>String(a.date).localeCompare(String(b.date)) || String(a.id).localeCompare(String(b.id)));
    const member=db.members.find(x=>x.id===loan.memberId);
    const today=new Date().toISOString().slice(0,10);
    const currentEligibility=member?loanEligibility(db,member,today):null;
    const schedule=loanInstallmentSchedule(loan,today);
    return json(res,200,{
      ...loan,repayments,currentEligibility,
      outstanding:loanOutstandingAmount(loan),
      totalOutstanding:loanTotalOutstanding(loan),
      repaymentStatus:loanRepaymentStatus(loan,today),
      schedule
    });
  }

  if(/^\/api\/loans\/[^/]+\/document$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const loan=db.loans.find(x=>x.id===id);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    if(['Closed','Rejected'].includes(loan.status))
      return json(res,400,{error:'Documents cannot be changed after case is closed'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'document');
      if(!/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i.test(filename))
        return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,filename,10*1024*1024);
      const doc={
        id:uid('LNDOC'),
        name:String(d.displayName||filename).trim(),
        type:String(d.documentType||'Supporting Document').trim(),
        originalName:filename,path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      loan.documents.unshift(doc);
      loan.history.unshift({status:loan.status,note:`Document uploaded: ${doc.name}`,at:new Date().toISOString()});
      audit(db,'Loan Document Uploaded',`${loan.id} - ${doc.name}`);
      saveDB(db); json(res,200,doc);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/loans\/[^/]+\/documents\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    const parts=pathname.split('/');
    const loanId=decodeURIComponent(parts[3]), docId=decodeURIComponent(parts[5]);
    const loan=db.loans.find(x=>x.id===loanId);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    if(['Closed','Rejected'].includes(loan.status))
      return json(res,400,{error:'Documents cannot be changed after case is closed'});
    const doc=(loan.documents||[]).find(x=>x.id===docId);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    loan.documents=loan.documents.filter(x=>x.id!==docId);
    loan.history.unshift({status:loan.status,note:`Document deleted: ${doc.name}`,at:new Date().toISOString()});
    audit(db,'Loan Document Deleted',`${loan.id} - ${doc.name}`);
    saveDB(db); return json(res,200,{ok:true});
  }

  if(/^\/api\/loans\/[^/]+\/status$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const loan=db.loans.find(x=>x.id===id);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    return body(req).then(d=>{
      const next=String(d.status||'');
      const allowed={
        'Applied':['Verification','Rejected'],
        'Verification':['Committee Approval','Rejected'],
        'Committee Approval':['Sanctioned','Rejected']
      };
      if(!(allowed[loan.status]||[]).includes(next))
        return json(res,400,{error:`Invalid loan workflow change: ${loan.status} → ${next}`});

      if(next==='Verification'){
        loan.verifiedBy=String(d.actionBy||'').trim();
        loan.verificationNotes=String(d.notes||'').trim();
      }
      if(next==='Committee Approval'){
        loan.verifiedBy=loan.verifiedBy||String(d.actionBy||'').trim();
        loan.verificationNotes=String(d.notes||loan.verificationNotes||'').trim();
        if((loan.documents||[]).length===0 && !loan.verificationNotes)
          return json(res,400,{error:'Add supporting document or verification note before Committee Approval'});
      }
      if(next==='Sanctioned'){
        const settings=db.loanSettings||{};
        if(!settings.facilityEnabled || !settings.complianceConfirmed)
          return json(res,400,{error:'Compliance confirmation is required before sanction'});
        const member=db.members.find(x=>x.id===loan.memberId);
        const eligibility=member?loanEligibility(db,member,new Date().toISOString().slice(0,10)):null;
        if(!eligibility?.eligible){
          const failed=(eligibility?.checks||[]).filter(x=>!x.passed).map(x=>x.label).join(', ');
          return json(res,400,{error:`Member is no longer eligible for sanction: ${failed||'Eligibility check failed'}`});
        }
        const sanctionedAmount=moneyNum(d.sanctionedAmount);
        if(sanctionedAmount<=0) return json(res,400,{error:'Sanctioned amount is required'});
        if(sanctionedAmount-moneyNum(loan.requestedAmount)>0.001)
          return json(res,400,{error:'Sanctioned amount cannot exceed requested amount'});
        const approvedBy=String(d.approvedBy||'').trim();
        if(settings.requireCommitteeApproval && !approvedBy)
          return json(res,400,{error:'Committee approval / Approved By is required'});
        const chargeRate=Math.max(0,moneyNum(d.chargeRate));
        if(chargeRate>0){
          if(!settings.permittedChargeEnabled || !settings.permittedChargeComplianceConfirmed)
            return json(res,400,{error:'Permitted charge / interest cannot be applied until separately enabled and compliance-confirmed in Loan Policy Settings'});
        }
        const approval=validateFinancialApproval(db,{amount:sanctionedAmount,context:'LoanSanction',date:d.sanctionDate||new Date().toISOString().slice(0,10),approvals:d.approvals||{},resolutionId:d.resolutionId||''});
        if(!approval.ok) return json(res,400,{error:approval.error});
        const resolution=approval.snapshot?.resolutionId?{
          resolutionId:approval.snapshot.resolutionId,resolutionNo:approval.snapshot.resolutionNo,resolutionTitle:approval.snapshot.resolutionTitle
        }:resolutionSnapshot(db,String(d.resolutionId||'').trim());
        if(d.resolutionId&&!resolution) return json(res,400,{error:'Loan sanction Resolution is not valid for this approval'});
        const chargeAmount=round2(sanctionedAmount*chargeRate/100);
        loan.sanctionedAmount=sanctionedAmount;
        loan.amount=sanctionedAmount;
        loan.chargeRate=chargeRate;
        loan.chargeAmount=chargeAmount;
        loan.totalRepayable=round2(sanctionedAmount+chargeAmount);
        loan.installmentAmount=round2(loan.totalRepayable/Math.max(1,loan.repaymentPeriod));
        loan.sanctionDate=d.sanctionDate||new Date().toISOString().slice(0,10);
        loan.approvedBy=approvalDisplayName(approval,approvedBy)||approvedBy;
        loan.committeeNotes=String(d.notes||'').trim();
        loan.approvalSnapshot=approval.required?approval.snapshot:null;
        if(resolution) Object.assign(loan,resolution);
        else { loan.resolutionId=''; loan.resolutionNo=''; loan.resolutionTitle=''; }
      }
      if(next==='Rejected'){
        const reason=String(d.reason||'').trim();
        if(!reason) return json(res,400,{error:'Rejection reason is mandatory'});
        loan.rejectionReason=reason;
      }

      loan.status=next;
      loan.history.unshift({
        status:next,
        note:next==='Rejected'?loan.rejectionReason:String(d.notes||'').trim(),
        at:new Date().toISOString()
      });
      audit(db,'Loan Workflow',`${loan.id}: ${next}`);
      saveDB(db); json(res,200,loan);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/loans\/[^/]+\/disburse$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const loan=db.loans.find(x=>x.id===id);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    if(loan.status!=='Sanctioned') return json(res,400,{error:'Loan must be Sanctioned before disbursement'});
    const settings=db.loanSettings||{};
    if(!settings.facilityEnabled || !settings.complianceConfirmed)
      return json(res,400,{error:'Compliance confirmation is required before disbursement'});

    return body(req).then(d=>{
      const amount=moneyNum(d.amount||loan.sanctionedAmount);
      if(Math.abs(amount-moneyNum(loan.sanctionedAmount))>0.001)
        return json(res,400,{error:'This version requires full disbursement of the sanctioned amount'});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=loan.financialYear||financialYear(date);
      if(financialYear(date)!==fyValue)
        return json(res,400,{error:'Disbursement date must belong to the loan application Financial Year'});
      const mode=String(d.mode||'Bank Transfer');
      const accountKey=accountKeyForMode(mode);
      const sourceLedger=buildAccountLedger(db,fyValue,accountKey);
      if(amount-sourceLedger.closingBalance>0.001)
        return json(res,400,{error:`Insufficient balance in ${sourceLedger.accountName}. Available: ${sourceLedger.closingBalance}`});

      const cashTotal=buildAccountLedger(db,fyValue,'cash').closingBalance
        +buildAccountLedger(db,fyValue,'bank').closingBalance
        +buildAccountLedger(db,fyValue,'upi').closingBalance;
      const policyRows=ensureFundPolicyForFY(db,fyValue);
      const fund=policyRows.find(x=>{
        const n=String(x.name||'').toLowerCase();
        return n.includes('loan fund') || n.includes('financial assistance');
      });
      if(fund){
        const earmarked=cashTotal*moneyNum(fund.percent)/100;
        const otherOutstanding=inFY(db.loans,fyValue)
          .filter(x=>x.id!==loan.id && ['Disbursed','Repayment'].includes(x.status))
          .reduce((s,x)=>s+loanOutstandingAmount(x),0);
        const policyAvailable=Math.max(0,earmarked-otherOutstanding);
        if(amount-policyAvailable>0.001)
          return json(res,400,{error:`Sanctioned amount exceeds current Loan Fund policy availability (${policyAvailable.toFixed(2)})`});
      }

      loan.disbursedAmount=amount;
      loan.amount=amount;
      loan.disbursementDate=date;
      loan.disbursementMode=mode;
      loan.disbursementReference=String(d.reference||'').trim();
      loan.firstInstallmentDate=addMonthsToDate(date,1);
      loan.maturityDate=addMonthsToDate(loan.firstInstallmentDate,Math.max(0,loan.repaymentPeriod-1));
      loan.totalRepayable=round2(moneyNum(loan.sanctionedAmount)+moneyNum(loan.chargeAmount));
      loan.installmentAmount=round2(loan.totalRepayable/Math.max(1,loan.repaymentPeriod));
      loan.totalPaid=0;loan.principalRepaid=0;loan.chargeRepaid=0;loan.repaid=0;
      loan.status='Disbursed';
      loan.history.unshift({
        status:'Disbursed',
        note:`₹${amount} disbursed via ${mode}${loan.disbursementReference?` / ${loan.disbursementReference}`:''}; maturity ${loan.maturityDate}`,
        at:new Date().toISOString()
      });
      audit(db,'Loan Disbursed',`${loan.id} ${loan.memberName} ₹${amount}`);
      saveDB(db); json(res,200,loan);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/loans\/[^/]+\/repay$/.test(pathname) && req.method==='POST'){
    const id=decodeURIComponent(pathname.split('/')[3]);
    const loan=db.loans.find(x=>x.id===id);
    if(!loan) return json(res,404,{error:'Loan application not found'});
    if(!['Disbursed','Repayment'].includes(loan.status))
      return json(res,400,{error:'Loan must be Disbursed before repayment'});
    return body(req).then(d=>{
      const outstanding=loanTotalOutstanding(loan);
      const amount=moneyNum(d.amount);
      if(amount<=0) return json(res,400,{error:'Valid repayment amount required'});
      if(amount-outstanding>0.001) return json(res,400,{error:`Repayment exceeds total outstanding (${outstanding})`});
      const date=d.date||new Date().toISOString().slice(0,10);
      const fyValue=financialYear(date);
      const components=allocateRepaymentComponents(loan,amount);
      const repayment={
        id:nextLoanRepaymentNo(db,fyValue),
        loanId:loan.id,memberId:loan.memberId,memberName:loan.memberName,
        amount:round2(amount),
        principalComponent:round2(components.principalComponent),
        chargeComponent:round2(components.chargeComponent),
        date,mode:d.mode||'Cash',financialYear:fyValue,
        reference:String(d.reference||'').trim(),
        remarks:String(d.remarks||'').trim()
      };
      db.loanRepayments.unshift(repayment);

      loan.totalPaid=round2(moneyNum(loan.totalPaid)+amount);
      loan.principalRepaid=round2(moneyNum(loan.principalRepaid)+repayment.principalComponent);
      loan.chargeRepaid=round2(moneyNum(loan.chargeRepaid)+repayment.chargeComponent);
      loan.repaid=loan.principalRepaid;

      let chargeIncomeVoucher='';
      if(repayment.chargeComponent>0){
        chargeIncomeVoucher=nextIncomeVoucherNo(db,fyValue);
        db.transactions.unshift({
          id:chargeIncomeVoucher,
          type:'Income',
          category:'Permitted Loan Charge / Interest',
          source:`${loan.id} - ${loan.memberName}`,
          description:`Permitted loan charge / interest component received with ${repayment.id}`,
          remarks:`Linked Loan Repayment ${repayment.id}`,
          mode:repayment.mode,
          amount:repayment.chargeComponent,
          date,financialYear:fyValue,
          fundingPurpose:'',
          skipCashBank:true,
          loanId:loan.id,
          loanRepaymentId:repayment.id
        });
        repayment.chargeIncomeVoucher=chargeIncomeVoucher;
      }

      if(loanTotalOutstanding(loan)<=0.001){
        loan.totalPaid=moneyNum(loan.totalRepayable);
        loan.principalRepaid=moneyNum(loan.disbursedAmount);
        loan.chargeRepaid=moneyNum(loan.chargeAmount);
        loan.repaid=loan.principalRepaid;
        loan.status='Closed';
      }else{
        loan.status='Repayment';
      }
      const repaymentStatus=loanRepaymentStatus(loan,date);
      loan.history.unshift({
        status:loan.status,
        note:`Repayment ${repayment.id} ₹${amount} (Principal ₹${repayment.principalComponent}, Permitted Charge ₹${repayment.chargeComponent}) via ${repayment.mode}; total outstanding ₹${loanTotalOutstanding(loan)}; schedule status ${repaymentStatus}`,
        at:new Date().toISOString()
      });
      audit(db,'Loan Repayment',`${repayment.id} ${loan.memberName} ₹${amount}`);
      saveDB(db);
      json(res,200,{
        loan,repayment,
        principalOutstanding:loanOutstandingAmount(loan),
        totalOutstanding:loanTotalOutstanding(loan),
        repaymentStatus,
        chargeIncomeVoucher
      });
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/funds' && req.method==='GET'){
    const rows=ensureFundPolicyForFY(db,fy);
    const cashBank=buildAccountLedger(db,fy,'cash').closingBalance
      + buildAccountLedger(db,fy,'bank').closingBalance
      + buildAccountLedger(db,fy,'upi').closingBalance;
    const totalPercent=rows.reduce((s,x)=>s+moneyNum(x.percent),0);
    const allocations=rows.map(x=>({
      ...x,
      allocatedAmount:cashBank*moneyNum(x.percent)/100
    }));
    const policyResolution=rows.find(x=>x.resolutionId)?.resolutionId||'';
    const policyRes=policyResolution?findResolution(db,policyResolution):null;
    return json(res,200,{
      financialYear:fy,
      availableFund:cashBank,
      totalPercent,
      valid:Math.abs(totalPercent-100)<0.0001,
      resolution:policyRes?{
        id:policyRes.resolution.id,
        resolutionNo:policyRes.resolution.resolutionNo,
        title:policyRes.resolution.title,
        category:policyRes.resolution.category
      }:null,
      allocations
    });
  }

  if(pathname==='/api/funds' && req.method==='POST'){
    return body(req).then(d=>{
      const resolution=resolutionSnapshot(db,String(d.resolutionId||'').trim());
      if(d.resolutionId && !resolution)
        return json(res,400,{error:'Fund Allocation Resolution must be from a Finalized meeting and Passed/Unanimous'});
      const rows=Array.isArray(d.allocations)?d.allocations:[];
      if(rows.length===0) return json(res,400,{error:'At least one fund allocation is required'});
      const cleaned=rows.map((x,i)=>({
        id:String(x.id||`FUND-${Date.now().toString().slice(-6)}-${i+1}`),
        name:String(x.name||'').trim(),
        percent:moneyNum(x.percent),
        financialYear:fy,
        notes:String(x.notes||'').trim(),
        ...(resolution||{resolutionId:'',resolutionNo:'',resolutionTitle:''})
      }));
      if(cleaned.some(x=>!x.name))
        return json(res,400,{error:'Every fund must have a name'});
      if(cleaned.some(x=>x.percent<0 || x.percent>100))
        return json(res,400,{error:'Each percentage must be between 0 and 100'});
      const total=cleaned.reduce((s,x)=>s+x.percent,0);
      if(Math.abs(total-100)>0.0001)
        return json(res,400,{error:`Total Allocation must be exactly 100%. Current total: ${total}%`});

      db.funds=db.funds.filter(x=>(x.financialYear||financialYear())!==fy);
      db.funds.push(...cleaned);
      audit(db,'Fund Allocation Policy Updated',`FY ${fy} allocation saved at 100%`);
      saveDB(db);
      json(res,200,{ok:true,totalPercent:100,allocations:cleaned});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/funds/reset' && req.method==='POST'){
    db.funds=db.funds.filter(x=>(x.financialYear||financialYear())!==fy);
    const rows=DEFAULT_FUND_ALLOCATION.map((f,i)=>({
      id:`FUND-${Date.now().toString().slice(-6)}-${i+1}`,
      name:f.name,percent:f.percent,financialYear:fy,notes:''
    }));
    db.funds.push(...rows);
    audit(db,'Fund Policy Reset',`FY ${fy} reset to default 100% structure`);
    saveDB(db);
    return json(res,200,{ok:true});
  }

  if(pathname==='/api/master-profile' && req.method==='GET'){
    return json(res,200,safeSetup(db.setup));
  }
  if(pathname==='/api/master-profile' && req.method==='POST'){
    return body(req).then(d=>{
      const fields=[
        'organizationName','establishmentDate','registrationNo','pan','tan',
        'registeredAddress','officeAddress','phone','email',
        'bankName','accountName','accountNumber','ifsc','branch','upiId',
        'objective','areaOfOperation','committeeTermStart','committeeTermEnd',
        'constitutionText'
      ];
      for(const k of fields) if(d[k]!==undefined) db.setup[k]=String(d[k]).trim();
      if(d.monthlyFee!==undefined) db.setup.monthlyFee=moneyNum(d.monthlyFee);
      if(d.joiningFee!==undefined) db.setup.joiningFee=moneyNum(d.joiningFee);
      if(d.annualFee!==undefined) db.setup.annualFee=moneyNum(d.annualFee);
      if(d.specialContributionDefault!==undefined) db.setup.specialContributionDefault=moneyNum(d.specialContributionDefault);
      audit(db,'Master Profile Updated','Organization master information updated');
      saveDB(db); json(res,200,safeSetup(db.setup));
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/upload-logo' && req.method==='POST'){
    return body(req).then(d=>{
      const allowed=/\.(png|jpg|jpeg|webp)$/i;
      if(!allowed.test(String(d.filename||''))) return json(res,400,{error:'Logo must be PNG, JPG, JPEG or WEBP'});
      const saved=saveDataUrl(d.dataUrl,safeName(d.filename),3*1024*1024);
      if(db.setup.logoPath) deleteUploaded(db.setup.logoPath);
      db.setup.logoPath=saved.path;
      audit(db,'Logo Updated',safeName(d.filename)); saveDB(db);
      json(res,200,{path:saved.path});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/upload-document' && req.method==='POST'){
    return body(req).then(d=>{
      const allowed=/\.(pdf|png|jpg|jpeg|webp|doc|docx)$/i;
      if(!allowed.test(String(d.filename||''))) return json(res,400,{error:'Allowed: PDF, PNG, JPG, WEBP, DOC, DOCX'});
      const saved=saveDataUrl(d.dataUrl,safeName(d.filename),10*1024*1024);
      const doc={
        id:uid('DOC'),name:String(d.displayName||d.filename||'Document').trim(),
        type:String(d.docType||'Official Document').trim(),
        originalName:safeName(d.filename),path:saved.path,size:saved.size,
        uploadedAt:new Date().toISOString()
      };
      db.setup.documents.unshift(doc);
      audit(db,'Document Uploaded',`${doc.type}: ${doc.name}`); saveDB(db); json(res,200,doc);
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname.startsWith('/api/documents/') && req.method==='DELETE'){
    const id=pathname.split('/')[3];
    const doc=db.setup.documents.find(x=>x.id===id);
    if(!doc) return json(res,404,{error:'Document not found'});
    deleteUploaded(doc.path);
    db.setup.documents=db.setup.documents.filter(x=>x.id!==id);
    audit(db,'Document Deleted',doc.name); saveDB(db); return json(res,200,{ok:true});
  }

  if(pathname==='/api/settings' && req.method==='GET'){
    return json(res,200,{ownerName:user.name,email:user.email,whatsapp:user.whatsapp||'',role:user.role});
  }
  if(pathname==='/api/settings' && req.method==='POST'){
    return body(req).then(d=>{
      const changes=[];
      if(d.ownerName!==undefined){const v=String(d.ownerName).trim();if(v&&v!==user.name){user.name=v;db.setup.ownerName=v;changes.push('Administrator Name');}}
      if(d.email!==undefined){const v=String(d.email).trim().toLowerCase();if(db.users.some(x=>x.id!==user.id&&x.email===v))return json(res,409,{error:'Email already used by another user'});if(v&&v!==user.email){user.email=v;db.setup.email=v;changes.push('Login Email');}}
      if(d.whatsapp!==undefined){
        const v=normalizeWhatsAppNumber(d.whatsapp||'',db.setup?.whatsappOtp?.defaultCountryCode||'91');
        if(v&&db.users.some(x=>x.id!==user.id&&normalizeWhatsAppNumber(x.whatsapp,db.setup?.whatsappOtp?.defaultCountryCode||'91')===v))return json(res,409,{error:'WhatsApp login number already used'});
        if(db.setup?.whatsappOtp?.enabled&&!v)return json(res,400,{error:'WhatsApp Login Number cannot be blank while WhatsApp OTP Login is enabled'});
        if(v!==user.whatsapp){user.whatsapp=v;db.setup.adminWhatsapp=v;changes.push('WhatsApp Login Number');}
      }
      if(d.newPassword){
        if(String(d.newPassword).length<6) return json(res,400,{error:'New password minimum 6 characters'});
        const hp=hashPassword(String(d.newPassword));user.passwordHash=hp.hash;user.salt=hp.salt;db.setup.passwordHash=hp.hash;db.setup.salt=hp.salt;changes.push('Password');
        db.sessions={};
      }
      user.updatedAt=new Date().toISOString();
      audit(db,'Administrator Settings Updated',`Changed: ${changes.join(', ')||'No material change'}`,{recordType:'User',recordId:user.id});saveDB(db);json(res,200,{ok:true});
    }).catch(e=>json(res,400,{error:e.message}));
  }


  if(pathname==='/api/whatsapp-otp-settings' && req.method==='GET'){
    if(user.role!=='Super Admin')return json(res,403,{error:'Only Super Admin can configure WhatsApp OTP Login'});
    const c=db.setup?.whatsappOtp||{};
    const active=(db.users||[]).filter(x=>x.status==='Active');
    const missing=active.filter(x=>!normalizeWhatsAppNumber(x.whatsapp,c.defaultCountryCode||'91')).map(x=>({id:x.id,name:x.name,role:x.role}));
    const normalized=active.map(x=>normalizeWhatsAppNumber(x.whatsapp,c.defaultCountryCode||'91')).filter(Boolean);
    const duplicates=[...new Set(normalized.filter((x,i,a)=>a.indexOf(x)!==i))];
    return json(res,200,{
      enabled:!!c.enabled,
      apiVersion:c.apiVersion||'v26.0',
      phoneNumberId:c.phoneNumberId||'',
      accessTokenConfigured:!!c.accessTokenEnc,
      accessTokenHint:c.accessTokenEnc?'Saved securely':'Not configured',
      templateName:c.templateName||'authentication_code_copy_code_button',
      templateLanguage:c.templateLanguage||'en_US',
      defaultCountryCode:c.defaultCountryCode||'91',
      expiryMinutes:Number(c.expiryMinutes||10),
      resendSeconds:Number(c.resendSeconds||60),
      maxAttempts:Number(c.maxAttempts||5),
      ready:whatsappOtpReady(db),
      localConfigValid:validateWhatsAppConfigShape(whatsappOtpConfig(db)).ok,
      configurationErrors:validateWhatsAppConfigShape(whatsappOtpConfig(db)).errors,
      activeUsers:active.length,
      missingUsers:missing,
      duplicateNumbers:duplicates
    });
  }

  if(pathname==='/api/whatsapp-otp-settings' && req.method==='POST'){
    if(user.role!=='Super Admin')return json(res,403,{error:'Only Super Admin can configure WhatsApp OTP Login'});
    return body(req).then(async d=>{
      const current=db.setup.whatsappOtp||{};
      const next={
        ...current,
        enabled:!!d.enabled,
        apiVersion:String(d.apiVersion||current.apiVersion||'v26.0').trim()||'v26.0',
        phoneNumberId:String(d.phoneNumberId||current.phoneNumberId||'').trim(),
        templateName:String(d.templateName||current.templateName||'authentication_code_copy_code_button').trim(),
        templateLanguage:String(d.templateLanguage||current.templateLanguage||'en_US').trim()||'en_US',
        defaultCountryCode:String(d.defaultCountryCode||current.defaultCountryCode||'91').replace(/[^\d]/g,'')||'91',
        expiryMinutes:Math.min(15,Math.max(3,Number(d.expiryMinutes||current.expiryMinutes||10))),
        resendSeconds:Math.min(300,Math.max(30,Number(d.resendSeconds||current.resendSeconds||60))),
        maxAttempts:Math.min(10,Math.max(3,Number(d.maxAttempts||current.maxAttempts||5)))
      };
      if(d.accessToken)next.accessTokenEnc=encryptSecret(String(d.accessToken).trim());
      if(d.clearAccessToken)next.accessTokenEnc='';

      const active=(db.users||[]).filter(x=>x.status==='Active');
      const missing=active.filter(x=>!normalizeWhatsAppNumber(x.whatsapp,next.defaultCountryCode));
      const nums=active.map(x=>normalizeWhatsAppNumber(x.whatsapp,next.defaultCountryCode)).filter(Boolean);
      const duplicates=[...new Set(nums.filter((x,i,a)=>a.indexOf(x)!==i))];

      const preview={
        enabled:next.enabled,
        apiVersion:next.apiVersion,
        phoneNumberId:next.phoneNumberId,
        accessToken:decryptSecret(next.accessTokenEnc||''),
        templateName:next.templateName,
        templateLanguage:next.templateLanguage,
        defaultCountryCode:next.defaultCountryCode,
        expiryMinutes:next.expiryMinutes,
        resendSeconds:next.resendSeconds,
        maxAttempts:next.maxAttempts
      };
      const shape=validateWhatsAppConfigShape(preview);
      if(next.enabled){
        if(!shape.ok)return json(res,400,{error:shape.errors.join(' ')});
        if(missing.length)
          return json(res,400,{error:`Cannot enable OTP Login. ${missing.length} active user(s) do not have a WhatsApp Login Number.`});
        if(duplicates.length)
          return json(res,400,{error:'Cannot enable OTP Login because duplicate WhatsApp Login Numbers exist.'});
        try{await validateWhatsAppMetaConfig(db,preview);}
        catch(err){return json(res,400,{error:`Meta configuration validation failed: ${err.message}`});}
      }
      db.setup.whatsappOtp=next;
      audit(db,'WhatsApp OTP Settings Updated',`Enabled: ${next.enabled?'Yes':'No'} · API ${next.apiVersion} · Template ${next.templateName}`,{recordType:'Security',recordId:'WHATSAPP-OTP'});
      saveDB(db);
      return json(res,200,{ok:true,enabled:next.enabled,ready:whatsappOtpReady(db)});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(pathname==='/api/whatsapp-otp-settings/validate' && req.method==='POST'){
    if(user.role!=='Super Admin')return json(res,403,{error:'Only Super Admin can validate WhatsApp OTP configuration'});
    return body(req).then(async d=>{
      const current=db.setup?.whatsappOtp||{};
      const accessToken=String(d.accessToken||'').trim() || decryptSecret(current.accessTokenEnc||'');
      const preview={
        enabled:!!d.enabled,
        apiVersion:String(d.apiVersion||current.apiVersion||'v26.0').trim()||'v26.0',
        phoneNumberId:String(d.phoneNumberId||current.phoneNumberId||'').trim(),
        accessToken,
        templateName:String(d.templateName||current.templateName||'authentication_code_copy_code_button').trim(),
        templateLanguage:String(d.templateLanguage||current.templateLanguage||'en_US').trim()||'en_US',
        defaultCountryCode:String(d.defaultCountryCode||current.defaultCountryCode||'91').replace(/[^\d]/g,'')||'91',
        expiryMinutes:Number(d.expiryMinutes||current.expiryMinutes||10),
        resendSeconds:Number(d.resendSeconds||current.resendSeconds||60),
        maxAttempts:Number(d.maxAttempts||current.maxAttempts||5)
      };
      const result=await validateWhatsAppMetaConfig(db,preview);
      return json(res,200,{ok:true,...result,message:'Meta WhatsApp configuration is valid.'});
    }).catch(e=>json(res,400,{error:e.message||'Meta configuration validation failed'}));
  }

  if(pathname==='/api/whatsapp-otp-settings/test' && req.method==='POST'){
    if(user.role!=='Super Admin')return json(res,403,{error:'Only Super Admin can test WhatsApp OTP'});
    return body(req).then(async d=>{
      const c=whatsappOtpConfig(db);
      const shape=validateWhatsAppConfigShape(c);
      if(!shape.ok)return json(res,400,{error:shape.errors.join(' ')});
      try{await validateWhatsAppMetaConfig(db);}
      catch(err){return json(res,400,{error:`Meta configuration validation failed: ${err.message}`});}
      const to=normalizeWhatsAppNumber(d.whatsapp||user.whatsapp,c.defaultCountryCode);
      if(!to)return json(res,400,{error:'Enter a WhatsApp number for the test.'});
      const otp=String(crypto.randomInt(100000,1000000));
      await sendWhatsAppOtp(db,to,otp);
      audit(db,'WhatsApp OTP Test Sent',`${maskedPhone(to)} · Template ${c.templateName}`,{recordType:'Security',recordId:'WHATSAPP-OTP'});
      saveDB(db);
      const out={ok:true,message:`Test OTP sent to ${maskedPhone(to)}`};
      if(process.env.WA_OTP_TEST_MODE==='1')out.debugOtp=otp;
      return json(res,200,out);
    }).catch(e=>json(res,502,{error:e.message||'Test OTP failed'}));
  }

  if(pathname==='/api/login-slides/manage' && req.method==='GET'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can manage login slider images'});
    const slides=(db.setup?.loginSlides||[])
      .slice()
      .sort((a,b)=>(Number(a.sortOrder||0)-Number(b.sortOrder||0)) || String(a.createdAt||'').localeCompare(String(b.createdAt||'')))
      .map(s=>({
        id:s.id,
        title:s.title||'',
        caption:s.caption||'',
        originalName:s.originalName||'',
        size:Number(s.size||0),
        sortOrder:Number(s.sortOrder||0),
        createdAt:s.createdAt||'',
        imageUrl:`/api/login-slider-image/${encodeURIComponent(s.id)}?v=${encodeURIComponent(s.updatedAt||s.createdAt||'')}`
      }));
    return json(res,200,{slides});
  }

  if(pathname==='/api/login-slides' && req.method==='POST'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can upload login slider images'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'slide');
      if(!/\.(png|jpg|jpeg|webp)$/i.test(filename)) return json(res,400,{error:'Slide image must be PNG, JPG, JPEG or WEBP'});
      if(!db.setup) return json(res,400,{error:'Setup required'});
      db.setup.loginSlides ||= [];
      const saved=saveDataUrl(d.dataUrl,filename,6*1024*1024);
      const obj={
        id:uid('SLD'),
        title:String(d.title||'Organization Management ERP').trim(),
        caption:String(d.caption||'Secure access for members, accounts, approvals and programs.').trim(),
        path:saved.path,
        originalName:filename,
        size:saved.size,
        sortOrder:Number(db.setup.loginSlides.length||0)+1,
        createdAt:new Date().toISOString(),
        updatedAt:new Date().toISOString()
      };
      db.setup.loginSlides.push(obj);
      audit(db,'Login Slider Image Uploaded',`${obj.id} ${obj.originalName}`,{recordType:'LoginSlider',recordId:obj.id});
      saveDB(db);
      return json(res,200,{ok:true,id:obj.id,imageUrl:`/api/login-slider-image/${encodeURIComponent(obj.id)}?v=${encodeURIComponent(obj.updatedAt)}`});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/login-slides\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can delete login slider images'});
    const id=decodeURIComponent(pathname.split('/')[3]);
    const list=db.setup?.loginSlides||[];
    const slide=list.find(x=>x.id===id);
    if(!slide) return json(res,404,{error:'Slide image not found'});
    if(slide.path) deleteUploaded(slide.path);
    db.setup.loginSlides=list.filter(x=>x.id!==id).map((x,i)=>({...x,sortOrder:i+1}));
    audit(db,'Login Slider Image Deleted',`${id} ${slide.originalName||slide.title||''}`,{recordType:'LoginSlider',recordId:id});
    saveDB(db);
    return json(res,200,{ok:true});
  }

  if(pathname==='/api/public-home-slides/manage' && req.method==='GET'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can manage Public Website slider images'});
    const slides=(db.setup?.publicHomeSlides||[])
      .slice()
      .sort((a,b)=>(Number(a.sortOrder||0)-Number(b.sortOrder||0)) || String(a.createdAt||'').localeCompare(String(b.createdAt||'')))
      .map(s=>({
        id:s.id,
        title:s.title||'',
        caption:s.caption||'',
        originalName:s.originalName||'',
        size:Number(s.size||0),
        sortOrder:Number(s.sortOrder||0),
        createdAt:s.createdAt||'',
        imageUrl:`/api/public-home-slide-image/${encodeURIComponent(s.id)}?v=${encodeURIComponent(s.updatedAt||s.createdAt||'')}`
      }));
    return json(res,200,{slides});
  }

  if(pathname==='/api/public-home-slides' && req.method==='POST'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can upload Public Website slider images'});
    return body(req).then(d=>{
      const filename=safeName(d.filename||'public-slide');
      if(!/\.(png|jpg|jpeg|webp)$/i.test(filename)) return json(res,400,{error:'Public slider image must be PNG, JPG, JPEG or WEBP'});
      if(!db.setup) return json(res,400,{error:'Setup required'});
      db.setup.publicHomeSlides ||= [];
      const saved=saveDataUrl(d.dataUrl,filename,8*1024*1024);
      const obj={
        id:uid('PUBSLD'),
        title:String(d.title||'CSC VLE Network').trim(),
        caption:String(d.caption||'Connecting citizens with trusted CSC services and local VLE centres.').trim(),
        path:saved.path,
        originalName:filename,
        size:saved.size,
        sortOrder:Number(db.setup.publicHomeSlides.length||0)+1,
        createdAt:new Date().toISOString(),
        updatedAt:new Date().toISOString()
      };
      db.setup.publicHomeSlides.push(obj);
      audit(db,'Public Website Slider Image Uploaded',`${obj.id} ${obj.originalName}`,{recordType:'PublicSlider',recordId:obj.id});
      saveDB(db);
      return json(res,200,{ok:true,id:obj.id,imageUrl:`/api/public-home-slide-image/${encodeURIComponent(obj.id)}?v=${encodeURIComponent(obj.updatedAt)}`});
    }).catch(e=>json(res,400,{error:e.message}));
  }

  if(/^\/api\/public-home-slides\/[^/]+$/.test(pathname) && req.method==='DELETE'){
    if(user.role!=='Super Admin') return json(res,403,{error:'Only Super Admin can delete Public Website slider images'});
    const id=decodeURIComponent(pathname.split('/')[3]);
    const list=db.setup?.publicHomeSlides||[];
    const slide=list.find(x=>x.id===id);
    if(!slide) return json(res,404,{error:'Public slider image not found'});
    if(slide.path) deleteUploaded(slide.path);
    db.setup.publicHomeSlides=list.filter(x=>x.id!==id).map((x,i)=>({...x,sortOrder:i+1}));
    audit(db,'Public Website Slider Image Deleted',`${id} ${slide.originalName||slide.title||''}`,{recordType:'PublicSlider',recordId:id});
    saveDB(db);
    return json(res,200,{ok:true});
  }

  if(pathname==='/api/backup' && req.method==='GET'){
    audit(db,'Backup Exported',`Organization backup downloaded for FY ${fy}`,{recordType:'Backup',recordId:fy});saveDB(db);
    const safe=structuredClone(db);safe.sessions={};
    if(safe.setup){safe.setup.passwordHash='';safe.setup.salt='';if(safe.setup.whatsappOtp)safe.setup.whatsappOtp.accessTokenEnc='';}
    for(const u of safe.users||[]){u.passwordHash='';u.salt='';}
    res.writeHead(200, {
      'Content-Type':'application/json',
      'Content-Disposition':`attachment; filename="organization-backup-${fy}.json"`
    });
    return res.end(JSON.stringify(safe,null,2));
  }

  if(pathname.startsWith('/api/') && req.method==='DELETE'){
    const parts=pathname.split('/').filter(Boolean), type=parts[1], id=parts[2];
    const map={members:'members',collections:'collections',transactions:'transactions',loans:'loans',funds:'funds',events:'events'};
    const key=map[type]; if(!key) return json(res,404,{error:'Not found'});
    if(key==='transactions'){
      const rec=db.transactions.find(x=>x.id===id);
      if(rec?.billPath) deleteUploaded(rec.billPath);
    }
    db[key]=db[key].filter(x=>x.id!==id);
    audit(db,'Record Deleted',`${type} ${id}`); saveDB(db); return json(res,200,{ok:true});
  }

  return json(res,404,{error:'Not found'});
}

function sendFile(res,file,cache='no-store, no-cache, must-revalidate, max-age=0'){
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404); return res.end('Not found');}
    const ext=path.extname(file).toLowerCase();
    const types={
      '.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8',
      '.js':'application/javascript; charset=utf-8','.png':'image/png',
      '.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp',
      '.pdf':'application/pdf','.doc':'application/msword',
      '.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    };
    res.writeHead(200, {'Content-Type':types[ext]||'application/octet-stream','Cache-Control':cache});
    res.end(data);
  });
}
function serveStatic(req,res,url){
  if(url.pathname.startsWith('/uploads/')){
    const db=loadDB(),u=sessionUser(req,db);
    if(!u){res.writeHead(401,{'Content-Type':'text/plain'});return res.end('Unauthorized');}
    const name=path.basename(url.pathname);
    return sendFile(res,path.join(UPLOAD_DIR,name),'private, no-cache');
  }
  let p=url.pathname==='/'?'/index.html':url.pathname;
  p=path.normalize(p).replace(/^(\.\.[\/\\])+/, '');
  const file=path.join(PUBLIC,p);
  if(!file.startsWith(PUBLIC)) {res.writeHead(403); return res.end('Forbidden');}
  return sendFile(res,file);
}

const server=http.createServer((req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(url.pathname.startsWith('/api/')) return api(req,res,url);
  return serveStatic(req,res,url);
});

server.listen(PORT,HOST,()=>{
  console.log(`\nOrganization Management System is running.`);
  console.log(`Local:   http://localhost:${PORT}`);
  const nets=os.networkInterfaces();
  for(const name of Object.keys(nets)){
    for(const n of nets[name]||[]){
      if(n.family==='IPv4' && !n.internal) console.log(`Network: http://${n.address}:${PORT}`);
    }
  }
  console.log(`Financial Year: ${financialYear()}`);
  console.log('\nKeep this window open while using the system.\n');
});
