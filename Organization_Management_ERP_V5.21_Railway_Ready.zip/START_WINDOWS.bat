@echo off
setlocal
TITLE Organization Management ERP V5.21
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is not installed on this computer.
  echo Please install Node.js LTS from https://nodejs.org/
  echo Then double-click START_WINDOWS.bat again.
  echo.
  pause
  exit /b 1
)

echo ==========================================================
echo  Organization Management ERP V5.21
echo ==========================================================
echo Starting local server first. Please wait...
echo.

rem Start the Node server BEFORE opening the browser.
start "OMS ERP Server" /min cmd /c "cd /d ""%~dp0"" && node server.js"

rem Wait until /api/status actually responds (maximum about 20 seconds).
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ok=$false; for($i=0;$i -lt 40;$i++){ try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:3000/api/status' -TimeoutSec 1; if($r.StatusCode -eq 200){$ok=$true; break} } catch {}; Start-Sleep -Milliseconds 500 }; if($ok){exit 0}else{exit 1}"

if errorlevel 1 (
  echo.
  echo ERROR: ERP server did not become ready on port 3000.
  echo Please check whether another program is already using port 3000.
  echo You can also close old Node.js ERP windows and try again.
  echo.
  pause
  exit /b 1
)

echo Server is ready.
echo Opening Chrome / default browser...
start "" "http://localhost:3000/?v=V5.21"

echo.
echo Public Website: http://localhost:3000
echo ERP Login:      http://localhost:3000/erp.html
 echo Use STOP_WINDOWS.bat when you want to stop the local server.
echo.
timeout /t 2 /nobreak >nul
endlocal
exit /b 0
