
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let activeFY=localStorage.getItem('oms_fy')||'';
let currentUser=null;
let appInfo={shortName:'OMS',appName:'Organization Management ERP',version:'V5.21',vendor:'CSC Digital Yoddha',subtitle:'Management ERP'};
let otpLoginState={challengeId:'',whatsapp:'',maskedPhone:'',resendAt:0,resendTimer:null};
let cache={applications:[],members:[],collections:[],transactions:[],loans:[],funds:[],events:[],notices:null,documentsData:null,certificatesData:null,remindersData:null,grievancesData:null,electionsData:null,vendorsData:null,budgetData:null,auditsData:null,dashboard:null,master:null,subscriptions:null,donations:null,incomes:null,expenses:null,cashbank:null,welfare:null,socialwork:null,assets:null,committees:null,meetings:null,approvalPolicy:null,accounting:null,portal:null,security:null};
let selectedAccountingLedger='income';
let selectedAccountingMember='';
let selectedAccountingEvent='';
let selectedAccountingFund='';
let selectedCashBankAccount='cash';
function currentLocalMonthKey(){
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
}

let selectedSubscriptionMonth=currentLocalMonthKey();
const DONATION_PURPOSES=['General Fund','Social Work','Medical Assistance','Education','Disaster Relief','Event','Infrastructure','Emergency Fund'];
const INCOME_CATEGORIES=['Joining Fee','Monthly Subscription','Annual Subscription','Donation','Event Collection','Sponsorship','Bank Interest','Permitted Loan Charge / Interest','Special Contribution','Other Legal Income'];
const EXPENSE_CATEGORIES=['Office Expense','Printing & Stationery','Meeting Expense','Event Expense','Social Work','Travel','Food','Rent','Electricity','Internet','Bank Charges','Member Welfare','Emergency Assistance','Legal/Professional Expense','Other Approved Expense'];
const WELFARE_TYPES=['Medical Emergency','Accident Assistance','Death Assistance','Family Emergency','Education Assistance','Natural Disaster Assistance','Business Emergency Support'];
const SOCIAL_WORK_TYPES=['Blood Donation','Health Camp','Food Distribution','Clothes Distribution','Educational Support','Disaster Relief','Tree Plantation','Awareness Camp','Other Social Work'];
const ASSET_CATEGORIES=['Computer','Printer','Furniture','Sound System','Projector','Tent','Vehicle','Land / Building','Electrical / Electronic Equipment','Office Equipment','Other Asset'];
const ASSET_CONDITIONS=['New','Excellent','Good','Fair','Poor','Damaged'];
const ASSET_STATUSES=['In Use','Stored','Under Repair','Disposed','Lost'];
const COMMITTEE_DESIGNATIONS=['President','Vice President','Secretary','Joint Secretary','Treasurer','Executive Member','General Member','Other'];
const RESOLUTION_CATEGORIES=['Loan Approval','Major Expense Approval','Asset Purchase Approval','Fund Allocation Change','General Resolution','Other'];
const VOTING_RESULTS=['Passed','Unanimous','Rejected','Tied','Not Voted'];
const DOCUMENT_CATEGORIES=['Governance','Registration','Member KYC','Finance','Tax / Statutory','Meeting / Resolution','Event','Social Work','Asset','Audit','Agreement / Vendor','Other'];
const DOCUMENT_AUDIENCES=['Internal','Committee','All Members','Specific Member'];
const CERTIFICATE_TYPES=['Member ID Card','Membership Certificate','Event Participation Certificate','Appreciation Certificate','General Certificate'];
const REMINDER_TYPES=['Member Due','Payment','Event','General'];
const GRIEVANCE_CATEGORIES=['Membership','Payment / Receipt','Subscription / Due','Welfare','Loan / Assistance','Event','Conduct / Discipline','Service','Other'];
const ELECTION_STATUSES=['Draft','Nomination Open','Voting Open','Closed','Published'];
const VENDOR_CATEGORIES=['Printing / Stationery','Catering','Venue / Tent','Sound / Light','Transport','IT / Technical','Professional Service','Construction / Repair','General Supplier','Other'];
const APPROVAL_CONTEXTS={Expense:'Expense',EventExpense:'Event Expense',SocialWorkExpense:'Social Work Expense',WelfarePayment:'Welfare Payment',AssetPurchase:'Asset Purchase',LoanSanction:'Loan Sanction'};
const REPORT_TYPES=[['members','Member List'],['joining','Joining Report'],['subscriptions','Monthly Subscription Report'],['due','Due Report'],['donations','Donation Report'],['income','Income Report'],['expense','Expense Report'],['cash','Cash Book'],['bank','Bank Book'],['events','Event Report'],['social','Social Work Report'],['welfare','Welfare Report'],['loans','Loan / Assistance Report'],['outstanding','Outstanding Report'],['assets','Asset Register'],['funds','Fund Allocation Report'],['annual','Annual Financial Summary']];
let selectedReportType=localStorage.getItem('oms_report_type')||'annual';
let currentReport=null;
let reportLoadToken=0;

async function api(url,opt={}){
  const o={headers:{'Content-Type':'application/json'},...opt};
  const r=await fetch(url,o);
  const ct=r.headers.get('content-type')||'';
  const d=ct.includes('json')?await r.json():await r.text();
  if(!r.ok) throw new Error(d.error||d||'Request failed');
  return d;
}
async function apiWithTimeout(url,opt={},timeoutMs=5000){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{return await api(url,{...opt,signal:controller.signal})}
  finally{clearTimeout(timer)}
}
async function waitForServer(attempts=15,delayMs=450){
  let lastError=null;
  for(let i=0;i<attempts;i++){
    try{return await apiWithTimeout('/api/status',{},2500)}
    catch(e){lastError=e;if(i<attempts-1)await new Promise(r=>setTimeout(r,delayMs))}
  }
  throw lastError||new Error('Local server is not responding');
}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2})}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1700)}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function badge(s){return `<span class="badge">${esc(s)}</span>`}
function dateToday(){return new Date().toISOString().slice(0,10)}
function parseDisplayDate(value){
  if(!value)return null;
  if(value instanceof Date)return Number.isNaN(value.getTime())?null:value;
  const s=String(value).trim();
  const m=s.match(/^(\d{4})-(\d{2})-(\d{2})(?:$|T|\s)/);
  if(m && s.length===10)return new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));
  const d=new Date(s);
  return Number.isNaN(d.getTime())?null:d;
}
function fmtDate(value){
  if(!value)return '—';
  const s=String(value).trim();
  const m=s.match(/^(\d{4})-(\d{2})-(\d{2})(?:$|T|\s)/);
  if(m)return `${m[3]}-${m[2]}-${m[1]}`;
  const d=parseDisplayDate(value);if(!d)return s;
  return `${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`;
}
function fmtTime(value){
  const d=parseDisplayDate(value);if(!d)return value?String(value):'—';
  return d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
}
function fmtDateTime(value){
  const d=parseDisplayDate(value);if(!d)return value?String(value):'—';
  return `${fmtDate(d)} ${fmtTime(d)}`;
}
function fyUrl(path){return `${path}${path.includes('?')?'&':'?'}fy=${encodeURIComponent(activeFY)}`}
function fileToDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})}
function applyAppBrand(info={}){
  appInfo={...appInfo,...info};
  document.title=`${appInfo.appName} ${appInfo.version}`;
  const set=(sel,val)=>{const el=$(sel); if(el) el.textContent=val};
  set('#appShortName', appInfo.shortName||'OMS');
  set('#appBrandName', appInfo.appName||'Organization Management ERP');
  set('#appBrandVersion', appInfo.version||'V5.21');
  set('#appAuthName', appInfo.appName||'Organization Management ERP');
  set('#appAuthVersion', appInfo.version||'V5.21');
  set('#appVendorText', appInfo.vendor||'CSC Digital Yoddha');
}


let authSlidesData=[];
let authSlideIndex=0;
let authSliderTimer=null;

const DEFAULT_AUTH_SLIDES=[
  {title:'Welcome back to your workspace',caption:'Keep members, accounts, approvals, programs and reports connected inside one secure system.',theme:'fallback-one'},
  {title:'Run the organization with clarity',caption:'Track subscriptions, donations, expenses, welfare support and committee decisions with confidence.',theme:'fallback-two'},
  {title:'Secure access for every role',caption:'Super Admin, President, Secretary, Treasurer, Committee Members and Members can use role-based access.',theme:'fallback-three'}
];

function escapeAttr(s){return String(s??'').replace(/"/g,'&quot;')}
function authSlides(){return Array.isArray(authSlidesData)&&authSlidesData.length?authSlidesData:DEFAULT_AUTH_SLIDES}
function stopAuthSlider(){if(authSliderTimer){clearInterval(authSliderTimer);authSliderTimer=null}}
function startAuthSlider(){
  stopAuthSlider();
  if(authSlides().length<2)return;
  authSliderTimer=setInterval(()=>setAuthSlide(authSlideIndex+1),4600);
}
function setAuthSlide(i){
  const slides=authSlides();
  if(!slides.length)return;
  authSlideIndex=(i+slides.length)%slides.length;
  const track=$('#authSlides');
  if(track)track.style.transform=`translateX(-${authSlideIndex*100}%)`;
  $$('#authSliderDots button').forEach((btn,idx)=>btn.classList.toggle('active',idx===authSlideIndex));
  const current=slides[authSlideIndex]||{};
  if($('#authSliderHeadline'))$('#authSliderHeadline').textContent=current.title||'Organization Management ERP';
  if($('#authSliderCaption'))$('#authSliderCaption').textContent=current.caption||'Secure access for your organization and members.';
}
function prevAuthSlide(){setAuthSlide(authSlideIndex-1);startAuthSlider()}
function nextAuthSlide(){setAuthSlide(authSlideIndex+1);startAuthSlider()}
window.prevAuthSlide=prevAuthSlide;
window.nextAuthSlide=nextAuthSlide;

function renderAuthSlides(data=[]){
  authSlidesData=Array.isArray(data)&&data.length?data:DEFAULT_AUTH_SLIDES;
  const slides=authSlides();
  const track=$('#authSlides'), dots=$('#authSliderDots');
  if(!track||!dots)return;
  track.innerHTML=slides.map((slide,idx)=>{
    const hasImage=!!slide.imageUrl;
    return `<div class="auth-slide ${hasImage?'has-image':''} ${!hasImage?(slide.theme||`fallback-${idx+1}`):''}" ${hasImage?`style="background-image:url('${escapeAttr(slide.imageUrl)}')"`:''}>
      ${hasImage?'<div class="auth-slide-shade"></div>':''}
      <div class="auth-slide-decor decor-a"></div>
      <div class="auth-slide-decor decor-b"></div>
      <div class="auth-slide-decor decor-c"></div>
    </div>`;
  }).join('');
  dots.innerHTML=slides.map((_,idx)=>`<button type="button" aria-label="Go to slide ${idx+1}" onclick="setAuthSlide(${idx});startAuthSlider()"></button>`).join('');
  authSlideIndex=0;
  setAuthSlide(0);
  startAuthSlider();
}
window.setAuthSlide=setAuthSlide;

async function loadAuthSlider(){
  try{
    const data=await apiWithTimeout('/api/login-slider',{},2500);
    renderAuthSlides(data.slides||[]);
  }catch(e){
    renderAuthSlides([]);
  }
}

async function init(){
  applyAppBrand(appInfo);
  loadAuthSlider();
  $('#today').textContent=`${fmtDate(new Date())} · ${fmtTime(new Date())}`;
  $('#setupForm').classList.add('hidden');
  $('#loginForm').classList.add('hidden');
  $('#otpRequestForm').classList.add('hidden');
  $('#otpVerifyForm').classList.add('hidden');
  $('#authTitle').textContent='Organization Management System';
  $('#authText').textContent='Connecting to local server...';
  $('#authMessage').innerHTML='<div class="startup-progress"><span></span> Starting local ERP server…</div>';
  try{
    const st=await waitForServer();
    if(st.appInfo) applyAppBrand(st.appInfo);
    $('#authMessage').innerHTML='';
    if(!st.configured){
      $('#authTitle').textContent='First Time Setup';
      $('#authText').textContent='Create the first administrator account for your Organization Management System.';
      $('#setupForm').classList.remove('hidden');
    }else{
      $('#authTitle').textContent=st.organization||'Organization Management System';
      if(st.authMode==='whatsapp_otp'){
        $('#authText').textContent='Secure WhatsApp OTP Login';
        $('#otpRequestForm').classList.remove('hidden');
      }else{
        $('#authText').textContent='Secure User Login';
        $('#loginForm').classList.remove('hidden');
      }
    }
    return st;
  }catch(e){
    $('#authText').textContent='Unable to connect to the local ERP server.';
    showAuthError('The server did not become ready. Use START_WINDOWS.bat and keep the server window running.');
    $('#authMessage').insertAdjacentHTML('beforeend','<button type="button" class="auth-retry-btn" onclick="boot()">Retry Connection</button>');
    return null;
  }
}
function showAuthError(m){$('#authMessage').innerHTML=`<div class="msg">${esc(m)}</div>`}

$('#setupForm').addEventListener('submit',async e=>{
  e.preventDefault(); const d=Object.fromEntries(new FormData(e.target));
  try{await api('/api/setup',{method:'POST',body:JSON.stringify(d)});location.reload()}catch(x){showAuthError(x.message)}
});
$('#loginForm').addEventListener('submit',async e=>{
  e.preventDefault(); const d=Object.fromEntries(new FormData(e.target));
  try{await api('/api/login',{method:'POST',body:JSON.stringify(d)});await enterApp()}catch(x){showAuthError(x.message)}
});


function otpCountdown(){
  const btn=$('#otpResendBtn');if(!btn)return;
  const left=Math.max(0,Math.ceil((otpLoginState.resendAt-Date.now())/1000));
  btn.disabled=left>0;
  btn.textContent=left>0?`Resend OTP (${left}s)`:'Resend OTP';
  if(left>0)otpLoginState.resendTimer=setTimeout(otpCountdown,1000);
}
function showOtpVerify(data){
  otpLoginState.challengeId=data.challengeId||'';
  otpLoginState.maskedPhone=data.maskedPhone||'';
  otpLoginState.resendAt=Date.now()+Number(data.resendAfterSeconds||60)*1000;
  $('#otpMaskedPhone').textContent=otpLoginState.maskedPhone;
  $('#otpRequestForm').classList.add('hidden');
  $('#otpVerifyForm').classList.remove('hidden');
  $('#otpVerifyForm').otp.value='';
  if(otpLoginState.resendTimer)clearTimeout(otpLoginState.resendTimer);
  otpCountdown();
  setTimeout(()=>$('#otpVerifyForm').otp.focus(),50);
}
function changeOtpNumber(){
  if(otpLoginState.resendTimer)clearTimeout(otpLoginState.resendTimer);
  otpLoginState={challengeId:'',whatsapp:'',maskedPhone:'',resendAt:0,resendTimer:null};
  $('#otpVerifyForm').classList.add('hidden');
  $('#otpRequestForm').classList.remove('hidden');
  $('#authMessage').innerHTML='';
}
async function resendOtp(){
  if(Date.now()<otpLoginState.resendAt)return;
  try{
    const d=await api('/api/whatsapp-otp/request',{method:'POST',body:JSON.stringify({whatsapp:otpLoginState.whatsapp})});
    showOtpVerify(d);
  }catch(e){showAuthError(e.message)}
}
window.changeOtpNumber=changeOtpNumber;
window.resendOtp=resendOtp;

$('#otpRequestForm').addEventListener('submit',async e=>{
  e.preventDefault();showAuthError('');
  const whatsapp=e.target.whatsapp.value.trim();
  try{
    const d=await api('/api/whatsapp-otp/request',{method:'POST',body:JSON.stringify({whatsapp})});
    otpLoginState.whatsapp=whatsapp;showOtpVerify(d);
  }catch(x){showAuthError(x.message)}
});
$('#otpVerifyForm').addEventListener('submit',async e=>{
  e.preventDefault();
  try{
    await api('/api/whatsapp-otp/verify',{method:'POST',body:JSON.stringify({challengeId:otpLoginState.challengeId,otp:e.target.otp.value})});
    if(otpLoginState.resendTimer)clearTimeout(otpLoginState.resendTimer);
    await enterApp();
  }catch(x){showAuthError(x.message)}
});

function canPage(page){return !!currentUser?.pages?.includes(page)}
function renderHeaderUser(){
  const u=currentUser||{};
  const member=u.memberProfile||null;
  const name=u.name||member?.name||'User';
  const role=u.role||'User';
  const memberLine=member
    ? `${member.id}${member.designation?` · ${member.designation}`:''}`
    : (u.memberId?u.memberId:(u.email||'Account'));

  if($('#headerUserName'))$('#headerUserName').textContent=name;
  if($('#headerUserRole'))$('#headerUserRole').textContent=role;
  if($('#headerUserMember'))$('#headerUserMember').textContent=memberLine;
  if($('#headerUserCard')){$('#headerUserCard').title=`${name} · ${role}${u.email?` · ${u.email}`:''}${u.mustChangePassword?' · Default password active':''}`;$('#headerUserCard').classList.toggle('password-change-due',!!u.mustChangePassword);}

  const img=$('#headerUserPhoto'), initial=$('#headerUserInitial');
  const photo=String(u.profilePhotoPath||'').trim();
  if(initial)initial.textContent=(name||'U').trim().slice(0,1).toUpperCase();

  if(img&&initial){
    if(photo){
      img.onload=()=>{img.classList.remove('hidden');initial.classList.add('hidden')};
      img.onerror=()=>{img.classList.add('hidden');initial.classList.remove('hidden')};
      img.src=photo+(photo.includes('?')?'&':'?')+'v='+Date.now();
    }else{
      img.removeAttribute('src');
      img.classList.add('hidden');
      initial.classList.remove('hidden');
    }
  }
}
function applyRoleUI(){
  $$('#mainNav .nav-link[data-page]').forEach(b=>b.classList.toggle('hidden',!canPage(b.dataset.page)));
  refreshNavGroups();
  renderHeaderUser();
  document.body.dataset.userRole=(currentUser?.role||'').toLowerCase().replace(/\s+/g,'-');
  filterNav($('#navSearch')?.value||'');
}
function firstAllowedPage(){return currentUser?.pages?.[0]||'memberportal'}
function secureVisibleActions(){
  const role=currentUser?.role,page=$('.page.active')?.id;if(!role||!page)return;
  if(role==='Super Admin'||role==='General Member')return;
  const mutationWords=/^(\+|Add |New |Create |Edit |Delete|Remove|Upload|Reset|Save |Pay |Disburse|Transfer|Record |Update )/i;
  const approvalWords=/(Approve|Sanction|Reject|Finalize|Resolution|Verification|Committee Review|Status)/i;
  page&&$(`#${page}`)?.querySelectorAll('button').forEach(btn=>{
    const t=btn.textContent.trim();
    if(role==='President'||role==='Committee Member'){
      if(mutationWords.test(t)&&!approvalWords.test(t))btn.classList.add('role-action-hidden');
    }else if(role==='Secretary'&&page==='assets'&&mutationWords.test(t))btn.classList.add('role-action-hidden');
    else if(role==='Treasurer'&&['master','members','meetings','approvals','funds'].includes(page)&&mutationWords.test(t))btn.classList.add('role-action-hidden');
  });
}
async function enterApp(){
  const me=await api('/api/me');
  if(me.appInfo) applyAppBrand(me.appInfo);
  currentUser={
    ...(me.user||{name:me.ownerName,email:me.email,role:'Super Admin',pages:[]}),
    profilePhotoPath:me.profilePhotoPath||'',
    memberProfile:me.memberProfile||null
  };
  $('#authScreen').classList.add('hidden');$('#app').classList.remove('hidden');
  $('#orgSide').textContent=me.organizationName;applyLogo(me.logoPath||'');applyRoleUI();
  await loadFYs();await loadAll();
  const active=$('.page.active')?.id;
  if(!active||!canPage(active))showPage(firstAllowedPage());else{showPage(active);secureVisibleActions()}
}
async function trySession(){try{await enterApp()}catch{}}
async function logout(){await api('/api/logout',{method:'POST'});location.reload()}
function openSelfPasswordModal(){
  const form=$('#selfPasswordForm');if(form)form.reset();
  $('#defaultPasswordNotice')?.classList.toggle('hidden',!currentUser?.mustChangePassword);
  $('#selfPasswordModal')?.classList.add('show');
}
function closeSelfPasswordModal(){$('#selfPasswordModal')?.classList.remove('show')}
window.openSelfPasswordModal=openSelfPasswordModal;
window.closeSelfPasswordModal=closeSelfPasswordModal;
$('#selfPasswordForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const d=Object.fromEntries(new FormData(e.target));
  if(d.newPassword!==d.confirmPassword)return alert('New Password and Confirm Password do not match.');
  try{
    await api('/api/my-password',{method:'POST',body:JSON.stringify({currentPassword:d.currentPassword,newPassword:d.newPassword})});
    currentUser.mustChangePassword=false;
    closeSelfPasswordModal();toast('Password changed successfully');
  }catch(err){alert(err.message)}
});

function applyLogo(path){
  const img=$('#orgLogo'), fallback=$('#orgLogoFallback');
  if(path){img.src=path+'?v='+Date.now();img.classList.remove('hidden');fallback.classList.add('hidden')}
  else{img.classList.add('hidden');fallback.classList.remove('hidden')}
}
async function loadFYs(){
  const f=await api('/api/financial-years');
  if(!activeFY || !f.years.includes(activeFY)) activeFY=f.current;
  localStorage.setItem('oms_fy',activeFY);
  $('#fySelect').innerHTML=f.years.map(y=>`<option value="${y}" ${y===activeFY?'selected':''}>${y}</option>`).join('');
}
$('#fySelect').addEventListener('change',async e=>{
  activeFY=e.target.value;selectedSubscriptionMonth=currentLocalMonthKey();localStorage.setItem('oms_fy',activeFY);await loadAll();toast(`Financial Year ${activeFY}`);
});

function closeSidebar(){
  $('#sidebar')?.classList.remove('open');
  $('#sidebarBackdrop')?.classList.remove('show');
  document.body.classList.remove('nav-open');
}
function toggleSidebar(){
  const side=$('#sidebar');if(!side)return;
  const willOpen=!side.classList.contains('open');
  side.classList.toggle('open',willOpen);
  $('#sidebarBackdrop')?.classList.toggle('show',willOpen);
  document.body.classList.toggle('nav-open',willOpen);
}
function navPageLinks(){return $$('#mainNav .nav-link[data-page]')}
function refreshNavGroups(){
  $$('#mainNav .nav-group').forEach(group=>{
    const links=[...group.querySelectorAll('.nav-link[data-page]')];
    const allowed=links.filter(x=>!x.classList.contains('hidden'));
    group.classList.toggle('hidden',allowed.length===0);
    const count=group.querySelector('.nav-group-meta em');
    if(count)count.textContent=allowed.length;
    if(!allowed.length)setNavGroupOpen(group,false);
  });
}
function setNavGroupOpen(group,open){
  if(!group)return;
  group.classList.toggle('open',!!open);
  const toggle=group.querySelector('.nav-group-toggle');
  if(toggle)toggle.setAttribute('aria-expanded',open?'true':'false');
}
function toggleNavGroup(groupName){
  const group=$(`#mainNav .nav-group[data-group="${groupName}"]`);
  if(!group||group.classList.contains('hidden'))return;
  const willOpen=!group.classList.contains('open');
  $$('#mainNav .nav-group').forEach(g=>{if(g!==group)setNavGroupOpen(g,false)});
  setNavGroupOpen(group,willOpen);
  if(willOpen)localStorage.setItem('oms_nav_group',groupName);
  else localStorage.removeItem('oms_nav_group');
}
function openNavGroupForPage(page){
  const link=$(`#mainNav .nav-link[data-page="${page}"]`);
  const group=link?.closest('.nav-group');
  if(!group)return;
  $$('#mainNav .nav-group').forEach(g=>setNavGroupOpen(g,g===group));
  localStorage.setItem('oms_nav_group',group.dataset.group||'');
}
function normalizeSavedNavGroup(name){
  const map={
    organization:'members',
    finance:'accounts',
    governance:'approval',
    operations:'programs',
    communication:'publication',
    reports:'report'
  };
  return map[name]||name;
}
function restoreNavGroup(){
  const active=$('#mainNav .nav-link.active[data-page]');
  if(active?.closest('.nav-group'))return openNavGroupForPage(active.dataset.page);
  const saved=normalizeSavedNavGroup(localStorage.getItem('oms_nav_group'));
  const group=saved?$(`#mainNav .nav-group[data-group="${saved}"]`):null;
  if(group&&!group.classList.contains('hidden'))setNavGroupOpen(group,true);
}
function filterNav(q=''){
  const term=String(q||'').trim().toLowerCase();
  const links=navPageLinks();

  links.forEach(link=>{
    if(currentUser&&!canPage(link.dataset.page)){
      link.classList.add('hidden');
      link.classList.remove('nav-filtered');
      return;
    }
    link.classList.remove('hidden');
    const group=link.closest('.nav-group');
    const groupText=group?.querySelector('.nav-group-toggle')?.textContent?.toLowerCase()||'';
    const haystack=`${link.textContent} ${link.dataset.keywords||''}`.toLowerCase();
    const match=!term||haystack.includes(term)||groupText.includes(term);
    link.classList.toggle('nav-filtered',!match);
  });

  refreshNavGroups();

  if(term){
    $$('#mainNav .nav-group').forEach(group=>{
      const matches=[...group.querySelectorAll('.nav-link[data-page]')].filter(x=>!x.classList.contains('hidden')&&!x.classList.contains('nav-filtered'));
      group.classList.toggle('nav-search-hidden',matches.length===0);
      setNavGroupOpen(group,matches.length>0);
    });
  }else{
    $$('#mainNav .nav-group').forEach(group=>group.classList.remove('nav-search-hidden'));
    $$('#mainNav .nav-group').forEach(group=>setNavGroupOpen(group,false));
    restoreNavGroup();
  }

  if($('#navEmpty')){
    const visible=links.some(b=>!b.classList.contains('hidden')&&!b.classList.contains('nav-filtered'));
    $('#navEmpty').classList.toggle('hidden',visible);
  }
}
function showPage(page){
  if(currentUser&&!canPage(page))return;
  const btn=$(`#mainNav .nav-link[data-page="${page}"]`);
  navPageLinks().forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');
  $$('#mainNav .nav-group').forEach(g=>g.classList.toggle('has-active',!!g.querySelector('.nav-link.active')));
  if(!String($('#navSearch')?.value||'').trim())openNavGroupForPage(page);
  $$('.page').forEach(x=>x.classList.remove('active'));const p=$('#'+page);if(p)p.classList.add('active');
  $('#pageTitle').textContent=btn?btn.textContent.trim():page;closeSidebar();
  window.scrollTo(0,0);
  render();setTimeout(secureVisibleActions,0);
}
navPageLinks().forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
$('#sidebarBackdrop')?.addEventListener('click',closeSidebar);
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')closeSidebar();
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){
    e.preventDefault();
    if(window.innerWidth<=920&&!$('#sidebar')?.classList.contains('open'))toggleSidebar();
    setTimeout(()=>$('#navSearch')?.focus(),40);
  }
});

async function loadAll(){
  if(currentUser?.role==='General Member'){
    const portal=await api(fyUrl('/api/my-portal'));
    cache={applications:[],members:[],collections:[],transactions:[],loans:[],funds:[],events:[],notices:null,documentsData:null,certificatesData:null,remindersData:null,grievancesData:null,electionsData:null,vendorsData:null,budgetData:null,auditsData:null,dashboard:null,master:null,subscriptions:null,donations:null,incomes:null,expenses:null,cashbank:null,welfare:null,socialwork:null,assets:null,committees:null,meetings:null,approvalPolicy:null,accounting:null,portal,security:null};
    $('#orgSide').textContent=portal.organization?.name||'Organization';applyLogo(portal.organization?.logoPath||'');render();return;
  }
  const get=(page,url,fallback)=>canPage(page)?api(url):Promise.resolve(fallback);
  let subscriptions=null;
  if(canPage('subscriptions')){
    subscriptions=await api(fyUrl('/api/subscriptions')+(selectedSubscriptionMonth?`&month=${encodeURIComponent(selectedSubscriptionMonth)}`:''));
    if(!selectedSubscriptionMonth)selectedSubscriptionMonth=subscriptions.selectedMonth;
  }
  const [dashboard,applications,members,collections,transactions,loans,funds,events,notices,documentsData,certificatesData,remindersData,grievancesData,electionsData,vendorsData,budgetData,auditsData,master,donations,incomes,expenses,cashbank,welfare,socialwork,assets,committees,meetings,approvalPolicy,accounting,usersInfo,auditInfo]=await Promise.all([
    get('dashboard',fyUrl('/api/dashboard'),null),get('applications','/api/applications',[]),get('members','/api/members',[]),get('collections',fyUrl('/api/collections'),[]),
    get('accounts',fyUrl('/api/transactions'),[]),get('loans',fyUrl('/api/loans'),null),get('funds',fyUrl('/api/funds'),null),get('events',fyUrl('/api/events'),null),get('notices',fyUrl('/api/notices'),null),
    get('documents',fyUrl('/api/document-library'),null),get('certificates',fyUrl('/api/issued-documents'),null),get('reminders',fyUrl('/api/reminders'),null),get('grievances',fyUrl('/api/grievances'),null),get('elections',fyUrl('/api/elections'),null),get('vendors','/api/vendors',null),get('budgetcontrol',fyUrl('/api/budget-control'),null),get('annualaudit',fyUrl('/api/annual-audits'),null),
    get('master','/api/master-profile',null),get('donations',fyUrl('/api/donations'),null),get('income',fyUrl('/api/incomes'),null),get('expense',fyUrl('/api/expenses'),null),
    get('cashbank',fyUrl('/api/cash-bank'),null),get('welfare',fyUrl('/api/welfare'),null),get('socialwork',fyUrl('/api/social-projects'),null),get('assets','/api/assets',null),
    get('committee','/api/committees',null),get('meetings',fyUrl('/api/meetings'),null),get('approvals','/api/approval-policy',null),get('accountingledger',fyUrl('/api/accounting-ledgers'),null),
    get('security','/api/users',null),get('security','/api/audit-log?limit=500',null)
  ]);
  cache={dashboard,applications,members,collections,transactions,loans,funds,events,notices,documentsData,certificatesData,remindersData,grievancesData,electionsData,vendorsData,budgetData,auditsData,master,subscriptions,donations,incomes,expenses,cashbank,welfare,socialwork,assets,committees,meetings,approvalPolicy,accounting,portal:null,security:usersInfo?{usersInfo,auditInfo}:null};
  if(master){$('#orgSide').textContent=master.organizationName||'Organization';applyLogo(master.logoPath||'')}
  render();
}
function render(){
  renderFYLabels();renderDashboard();renderMaster();renderApplications();renderMembers();renderSubscriptions();renderDonations();renderIncome();renderExpense();renderCashBank();renderWelfare();renderCollections();
  renderTransactions();renderLoans();renderFunds();renderEvents();renderNotices();renderDocumentLibrary();renderIssuedDocuments();renderReminders();renderGrievances();renderElections();renderVendors();renderBudgetControl();renderAnnualAudits();renderSocialWork();renderAssets();renderCommittee();renderMeetings();renderApprovalSystem();renderAccountingLedger();renderReports();renderMemberPortal();renderSecurity();loadSettings();
}
function renderFYLabels(){
  const t=`Financial Year ${activeFY} records`;
  $('#collectionsFYText').textContent=`${t} — annual fee, special contribution, joining fee and other receipts.`;
  $('#accountsFYText').textContent=`${t} — voucher-based account ledger.`;
  $('#loansFYText').textContent=`${t} — eligibility, verification, committee approval, sanction, disbursement and repayment.`;
  $('#fundsFYText').textContent=`${t} — percentage-wise capital allocation.`;
  $('#eventsFYText').textContent=`${t} — project budget, income, expense, participants, vendors, bills and final balance.`;
  if($('#noticesFYText'))$('#noticesFYText').textContent=`${t} — member notices, audience, priority and publish window.`;
  if($('#documentsFYText'))$('#documentsFYText').textContent=`${t} — official, governance, member, finance and audit documents.`;
  if($('#certificatesFYText'))$('#certificatesFYText').textContent=`${t} — issued Member ID Cards and certificates.`;
  if($('#remindersFYText'))$('#remindersFYText').textContent=`${t} — due, payment, event and general reminder queue.`;
  if($('#grievancesFYText'))$('#grievancesFYText').textContent=`${t} — member complaint, assignment and resolution workflow.`;
  if($('#electionsFYText'))$('#electionsFYText').textContent=`${t} — election positions, candidates, one-vote control and published results.`;
  if($('#budgetFYText'))$('#budgetFYText').textContent=`${t} — approved budget / target compared against accounting actual.`;
  if($('#annualAuditFYText'))$('#annualAuditFYText').textContent=`${t} — auditor record, findings, report and accounting snapshot.`;
  $('#socialWorkFYText').textContent=`${t} — social projects, budget, expense, beneficiaries, responsible members, photos and documents.`;
  $('#meetingsFYText').textContent=`${t} — meeting minutes, attendance, decisions, resolutions, voting and governance links.`;
  $('#accountingFYText').textContent=`${t} — opening balance, income, expense, closing balance and automatic sub-ledgers.`;
  $('#reportsFYText').textContent=`Financial Year ${activeFY} — registers, financial statements and management reports with PDF / Excel / Print export.`;
  if($('#memberPortalFYText'))$('#memberPortalFYText').textContent=`Financial Year ${activeFY} — your profile, payment, due, receipt and application records.`;
}
function dashboardColumnChart(rows,series,emptyText='No data'){
  if(!rows?.length)return `<div class="dashboard-chart-empty">${esc(emptyText)}</div>`;
  const max=Math.max(1,...rows.flatMap(r=>series.map(s=>Number(r[s.key]||0))));
  return `<div class="dashboard-column-chart">
    <div class="dashboard-bars">${rows.map(r=>`
      <div class="dashboard-bar-group" title="${esc(r.monthLabel||r.month||'')}">
        <div class="dashboard-bar-stack">${series.map(s=>{
          const value=Number(r[s.key]||0),height=value<=0?0:Math.max(3,value/max*100);
          return `<i class="${esc(s.cls||'')}" style="height:${height.toFixed(2)}%" title="${esc(s.label)}: ${money(value)}"></i>`;
        }).join('')}</div>
        <span>${esc(String(r.monthLabel||r.month||'').slice(0,3))}</span>
      </div>`).join('')}</div>
  </div>`;
}
function dashboardFundChart(rows){
  if(!rows?.length)return '<div class="dashboard-chart-empty">No fund allocation policy available.</div>';
  return `<div class="dashboard-fund-list">${rows.map((r,i)=>`
    <div class="dashboard-fund-row">
      <div class="dashboard-fund-meta"><b>${esc(r.name)}</b><span>${Number(r.percent||0).toFixed(2)}%</span></div>
      <div class="dashboard-fund-track"><i style="width:${Math.max(0,Math.min(100,Number(r.percent||0)))}%"></i></div>
      <small>${money(r.amount||0)}</small>
    </div>`).join('')}</div>`;
}
function renderDashboard(){
  if(!cache.dashboard)return;
  const d=cache.dashboard,s=d.stats||{},a=d.accounting||{},charts=d.charts||{};
  if($('#dashboardFYText')) $('#dashboardFYText').textContent=`Financial Year ${activeFY} · Dashboard as of ${d.asOfDate||'today'}`;

  const cards=[
    ['TOTAL MEMBERS',s.totalMembers||0,'All registered members','members'],
    ['ACTIVE MEMBERS',s.activeMembers||0,'Currently active members','members'],
    ['MONTHLY COLLECTION',money(s.monthCollection||0),'Current calendar month','subscriptions'],
    ['TOTAL DUE',money(s.totalDue||0),'Active member subscription due','subscriptions'],
    ['DONATIONS',money(s.donations||0),`FY ${activeFY}`,'donations'],
    ['CURRENT FUND',money(s.currentFund||0),`Cash + Bank + UPI (${money(s.upiBalance||0)} UPI)`,'cashbank'],
    ['CASH BALANCE',money(s.cashBalance||0),'Cash in Hand closing balance','cashbank'],
    ['BANK BALANCE',money(s.bankBalance||0),'Bank book closing balance','cashbank'],
    ['MONTHLY EXPENSE',money(s.monthExpense||0),'Current calendar month','expenses'],
    ['WELFARE ASSISTANCE',money(s.welfareAssistance||0),'Paid during selected FY','welfare'],
    ['LOAN / ASSISTANCE OUTSTANDING',money(s.loanOutstanding||0),'Principal receivable','loans'],
    ['UPCOMING EVENTS',s.upcomingEvents||0,'Planned / ongoing future events','events']
  ];
  $('#stats').innerHTML=cards.map((x,i)=>`<button class="dashboard-kpi card kpi-${i+1}" onclick="showPage('${x[3]}')"><span>${x[0]}</span><strong>${x[1]}</strong><small>${x[2]}</small></button>`).join('');

  $('#dashboardReconcileBadge').innerHTML=a.reconciled
    ? '<span class="dashboard-reconcile ok">✓ Reconciled</span>'
    : `<span class="dashboard-reconcile warn">Check ${money(a.reconciliationDifference||0)}</span>`;

  $('#finance').innerHTML=`
    <div class="dashboard-accounting-equation">
      <div><span>Opening Balance</span><b>${money(a.openingBalance||0)}</b></div>
      <i>+</i>
      <div><span>Total Income</span><b>${money(a.income||0)}</b></div>
      <i>−</i>
      <div><span>Total Expense</span><b>${money(a.expense||0)}</b></div>
      <i>=</i>
      <div class="closing"><span>Closing Fund Position</span><b>${money(a.closingBalance||0)}</b></div>
    </div>
    <div class="dashboard-accounting-foot">
      <span>Liquid Closing <b>${money(a.liquidClosing||0)}</b></span>
      <span>Loan Receivable <b>${money(a.loanReceivable||0)}</b></span>
    </div>`;

  $('#upcomingEvents').innerHTML=(d.upcoming||[]).map(e=>`
    <button class="dashboard-event-item" onclick="showPage('events')">
      <div class="dashboard-event-date"><b>${esc(String(e.startDate||'').slice(8,10)||'—')}</b><span>${esc(new Date((e.startDate||'')+'T00:00:00').toLocaleString('en-IN',{month:'short'}))}</span></div>
      <div><b>${esc(e.name)}</b><small>${esc(e.venue||'Venue not set')} · ${esc(e.status||'Planned')}</small></div>
    </button>`).join('')||'<div class="dashboard-chart-empty compact">No upcoming event in this Financial Year.</div>';

  $('#incomeExpenseChart').innerHTML=dashboardColumnChart(charts.incomeExpense||[],[
    {key:'income',label:'Income',cls:'income'},
    {key:'expense',label:'Expense',cls:'expense'}
  ]);
  $('#monthlyCollectionChart').innerHTML=dashboardColumnChart(charts.monthlyCollection||[],[
    {key:'amount',label:'Collection',cls:'collection'}
  ]);
  $('#fundDistributionChart').innerHTML=dashboardFundChart(charts.fundDistribution||[]);
  $('#subscriptionDueChart').innerHTML=dashboardColumnChart(charts.outstandingSubscription||[],[
    {key:'due',label:'Outstanding Due',cls:'due'}
  ],'No subscription due data');

  $('#activity').innerHTML=(d.audit||[]).map(a=>`<div class="activity"><i></i><div><b>${esc(a.action)}</b><small>${esc(a.detail)} · ${fmtDateTime(a.at)}</small></div></div>`).join('')||'<p>No activity yet.</p>';
}

function renderMaster(){
  if(!cache.master)return;
  const s=cache.master;
  const img=$('#masterLogo'), empty=$('#masterLogoEmpty');
  if(s.logoPath){img.src=s.logoPath+'?v='+Date.now();img.classList.remove('hidden');empty.classList.add('hidden')}
  else{img.classList.add('hidden');empty.classList.remove('hidden')}

  if(!$('#masterForm').dataset.loaded){
    $('#masterForm').innerHTML=`
      <h3 class="full section-title">Basic & Statutory Information</h3>
      <label>Organization Name<input name="organizationName" value="${esc(s.organizationName||'')}" required></label>
      <label>Establishment Date<input type="date" name="establishmentDate" value="${esc(s.establishmentDate||'')}"></label>
      <label>Registration No.<input name="registrationNo" value="${esc(s.registrationNo||'')}"></label>
      <label>PAN<input name="pan" value="${esc(s.pan||'')}" placeholder="If applicable"></label>
      <label>TAN<input name="tan" value="${esc(s.tan||'')}" placeholder="If applicable"></label>
      <label>Mobile<input name="phone" value="${esc(s.phone||'')}"></label>
      <label>Email<input type="email" name="email" value="${esc(s.email||'')}"></label>
      <h3 class="full section-title">Membership Fee Structure</h3>
      <label>Joining Fee<input type="number" name="joiningFee" value="${Number(s.joiningFee??500)}"></label>
      <label>Monthly Membership Fee<input type="number" name="monthlyFee" value="${Number(s.monthlyFee??200)}"></label>
      <label>Annual Fee<input type="number" name="annualFee" value="${Number(s.annualFee??0)}" placeholder="0 if not applicable"></label>
      <label>Special Contribution Default<input type="number" name="specialContributionDefault" value="${Number(s.specialContributionDefault??0)}" placeholder="Committee decision amount"></label>

      <label class="full">Registered Address<textarea name="registeredAddress">${esc(s.registeredAddress||'')}</textarea></label>
      <label class="full">Office Address<textarea name="officeAddress">${esc(s.officeAddress||'')}</textarea></label>

      <h3 class="full section-title">Bank & UPI Details</h3>
      <label>Bank Name<input name="bankName" value="${esc(s.bankName||'')}"></label>
      <label>Account Name<input name="accountName" value="${esc(s.accountName||'')}"></label>
      <label>Account Number<input name="accountNumber" value="${esc(s.accountNumber||'')}"></label>
      <label>IFSC<input name="ifsc" value="${esc(s.ifsc||'')}"></label>
      <label>Branch<input name="branch" value="${esc(s.branch||'')}"></label>
      <label>UPI ID<input name="upiId" value="${esc(s.upiId||'')}"></label>

      <h3 class="full section-title">Purpose, Area & Committee</h3>
      <label class="full">Organization Objective<textarea name="objective">${esc(s.objective||'')}</textarea></label>
      <label class="full">Area of Operation<textarea name="areaOfOperation">${esc(s.areaOfOperation||'')}</textarea></label>
      <label>Current Committee Term From<input type="date" name="committeeTermStart" value="${esc(s.committeeTermStart||'')}"></label>
      <label>Current Committee Term To<input type="date" name="committeeTermEnd" value="${esc(s.committeeTermEnd||'')}"></label>
      <label class="full">Constitution / By-laws<textarea class="large-textarea" name="constitutionText">${esc(s.constitutionText||'')}</textarea></label>
      <div class="actions"><button class="btn primary">Save Master Profile</button></div>`;
    $('#masterForm').dataset.loaded='1';
    $('#masterForm').onsubmit=async e=>{
      e.preventDefault();
      try{
        await api('/api/master-profile',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
        toast('Master Profile saved');$('#masterForm').dataset.loaded='';await loadAll();
      }catch(x){alert(x.message)}
    };
  }

  $('#documentList').innerHTML=(s.documents||[]).map(d=>`
    <div class="doc-item">
      <div class="doc-icon">▤</div>
      <div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB · ${fmtDate(d.uploadedAt)}</small></div>
      <a class="mini" href="${esc(d.path)}" target="_blank">Open</a>
      <button class="mini danger" onclick="deleteDocument('${d.id}')">Delete</button>
    </div>`).join('')||'<div class="empty-docs">No official documents uploaded yet.</div>';
}
async function uploadLogo(){
  const f=$('#logoFile').files[0]; if(!f)return alert('Select a logo file first.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api('/api/upload-logo',{method:'POST',body:JSON.stringify({filename:f.name,dataUrl})});
    $('#logoFile').value='';toast('Logo uploaded');await loadAll();
  }catch(e){alert(e.message)}
}
async function uploadDocument(){
  const f=$('#docFile').files[0]; if(!f)return alert('Select a document file.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api('/api/upload-document',{method:'POST',body:JSON.stringify({
      filename:f.name,dataUrl,docType:$('#docType').value,displayName:$('#docName').value||f.name
    })});
    $('#docFile').value='';$('#docName').value='';toast('Document uploaded');await loadAll();
  }catch(e){alert(e.message)}
}
async function deleteDocument(id){
  if(!confirm('Delete this official document?'))return;
  try{await api(`/api/documents/${id}`,{method:'DELETE'});toast('Document deleted');await loadAll()}catch(e){alert(e.message)}
}


function workflowBadge(status){
  const cls=String(status).toLowerCase().replace(/\s+/g,'-');
  return `<span class="workflow-badge ${cls}">${esc(status)}</span>`;
}
function renderApplications(){
  const list=cache.applications||[];
  const statuses=['Pending','Under Verification','Approved','Payment Pending','Active','Rejected'];
  $('#applicationStats').innerHTML=statuses.map(st=>`<div class="app-stat"><span>${st}</span><b>${list.filter(x=>x.status===st).length}</b></div>`).join('');
  $('#applicationRows').innerHTML=list.map(a=>`
    <tr>
      <td><b>${esc(a.id)}</b></td>
      <td>${a.photoPath?`<img class="member-thumb" src="${esc(a.photoPath)}" alt=""> `:''}${esc(a.name)}</td>
      <td>${esc(a.phone)}</td>
      <td>${esc(a.identityType)}<br><small>${esc(a.identityNumber)}</small></td>
      <td>${esc(fmtDate(a.applicationDate))}</td>
      <td>${money(a.joiningFee)}</td>
      <td>${workflowBadge(a.status)}</td>
      <td>${a.memberId?`<b>${esc(a.memberId)}</b>`:'—'}</td>
      <td><button class="mini" onclick="viewApplication('${a.id}')">Open</button></td>
    </tr>`).join('')||'<tr><td colspan="9">No membership applications yet.</td></tr>';
}

function openApplicationForm(){
  $('#applicationForm').innerHTML=`
    <div class="full internal-application-note">
      <b>Mandatory: Full Name, Gender, Mobile Number and Email ID only.</b>
      <span>All other profile, address and KYC details can be added later by an authorized Admin.</span>
    </div>
    <h3 class="full section-title">Personal Information</h3>
    <label>Full Name *<input name="name" required></label>
    <label>Father’s / Guardian’s Name<input name="fatherSpouse"></label>
    <label>Date of Birth<input type="date" name="dob"></label>
    <label>Gender *<select name="gender" required>
      <option value="">Select Gender</option>
      <option>Male</option><option>Female</option><option>Other</option><option>Prefer not to say</option>
    </select></label>
    <label>Mobile Number *<input name="phone" inputmode="tel" required></label>
    <label>WhatsApp Number<input name="whatsapp" inputmode="tel"></label>
    <label class="full">Email ID *<input type="email" name="email" required></label>

    <h3 class="full section-title">Permanent Address</h3>
    <label>Village<input name="permanentVillage"></label>
    <label>Post Office<input name="permanentPostOffice"></label>
    <label>Police Station<input name="permanentPoliceStation"></label>
    <label>GP / Ward No.<input name="permanentGpWard"></label>
    <label>Block / Municipality<input name="permanentBlockMunicipality"></label>
    <label>District<input name="permanentDistrict"></label>
    <label>State<input name="permanentState" value="West Bengal"></label>
    <label>PIN Code<input name="permanentPin" inputmode="numeric"></label>
    <label class="full">Address / Landmark<input name="permanentAddressLine"></label>

    <h3 class="full section-title">CSC Centre Information</h3>
    <label>CSC ID<input name="cscId"></label>
    <label>CSC Centre Name<input name="cscCentreName"></label>
    <label class="full erp-same-address-check">
      <input type="checkbox" name="sameAsPermanentAddress">
      <span><b>Same as Permanent Address</b><small>Copy Permanent Address fields to CSC Centre Address.</small></span>
    </label>
    <label>Village<input name="centreVillage"></label>
    <label>Post Office<input name="centrePostOffice"></label>
    <label>Police Station<input name="centrePoliceStation"></label>
    <label>GP / Ward No.<input name="centreGpWard"></label>
    <label>Block / Municipality<input name="centreBlockMunicipality"></label>
    <label>District<input name="centreDistrict"></label>
    <label>State<input name="centreState" value="West Bengal"></label>
    <label>PIN Code<input name="centrePin" inputmode="numeric"></label>
    <label class="full">Centre Address / Landmark<input name="centreAddressLine"></label>

    <h3 class="full section-title">Applicant Photo & KYC Documents</h3>
    <label class="full erp-file-field">Applicant Photo<input type="file" name="photo" accept=".png,.jpg,.jpeg,.webp"><small>Passport-style 3.5 × 4.5 cm · PNG/JPG/WEBP · Max 3 MB</small></label>
    <div class="full erp-kyc-grid">
      <div class="erp-kyc-card">
        <label>Aadhaar Card No.<input name="aadhaarNumber" inputmode="numeric" maxlength="12"></label>
        <label>Aadhaar Card Upload<input type="file" name="aadhaarFile" accept=".pdf,.png,.jpg,.jpeg,.webp"><small>Max 6 MB</small></label>
      </div>
      <div class="erp-kyc-card">
        <label>PAN Card No.<input name="panNumber" maxlength="10" placeholder="ABCDE1234F"></label>
        <label>PAN Card Upload<input type="file" name="panFile" accept=".pdf,.png,.jpg,.jpeg,.webp"><small>Max 6 MB</small></label>
      </div>
      <div class="erp-kyc-card">
        <label>Voter Card No.<input name="voterNumber"></label>
        <label>Voter Card Upload<input type="file" name="voterFile" accept=".pdf,.png,.jpg,.jpeg,.webp"><small>Max 6 MB</small></label>
      </div>
    </div>

    <h3 class="full section-title">Nominee / Emergency Contact</h3>
    <label>Name<input name="nomineeName"></label>
    <label>Relation<input name="nomineeRelation"></label>
    <label>Mobile<input name="nomineePhone" inputmode="tel"></label>
    <label>WhatsApp<input name="nomineeWhatsapp" inputmode="tel"></label>
    <label class="full">Address<input name="nomineeAddress"></label>

    <h3 class="full section-title">Declaration</h3>
    <div class="full erp-declaration-box">
      <p>I hereby apply for membership in the organization. I declare that the information and documents provided in this application are true and correct to the best of my knowledge.</p>
      <p>I agree to follow the organization’s Constitution, Rules & Regulations, maintain discipline and transparency, and cooperate in organizational and social-welfare activities.</p>
      <p>I understand that submission of this application does not automatically confirm membership. My application will be subject to document verification, committee review, approval and completion of the applicable joining process.</p>
      <label class="declaration-check"><input type="checkbox" name="declaration"> I have read and accept the above Declaration.</label>
    </div>

    <div class="actions">
      <button type="button" class="btn" onclick="closeApplicationModal()">Cancel</button>
      <button class="btn primary">Submit Application</button>
    </div>`;

  const form=$('#applicationForm');
  const same=form.querySelector('[name="sameAsPermanentAddress"]');
  const copyAddress=()=>{
    const map={
      permanentVillage:'centreVillage',
      permanentPostOffice:'centrePostOffice',
      permanentPoliceStation:'centrePoliceStation',
      permanentGpWard:'centreGpWard',
      permanentBlockMunicipality:'centreBlockMunicipality',
      permanentDistrict:'centreDistrict',
      permanentState:'centreState',
      permanentPin:'centrePin',
      permanentAddressLine:'centreAddressLine'
    };
    for(const [from,to] of Object.entries(map)){
      if(form.elements[from]&&form.elements[to])form.elements[to].value=form.elements[from].value||'';
    }
  };
  same.addEventListener('change',()=>{if(same.checked)copyAddress()});
  ['permanentVillage','permanentPostOffice','permanentPoliceStation','permanentGpWard','permanentBlockMunicipality','permanentDistrict','permanentState','permanentPin','permanentAddressLine'].forEach(n=>{
    form.elements[n]?.addEventListener('input',()=>{if(same.checked)copyAddress()});
  });

  $('#applicationModal').classList.add('show');

  $('#applicationForm').onsubmit=async e=>{
    e.preventDefault();
    const f=e.target;
    if(same.checked)copyAddress();

    const photo=f.photo.files?.[0];
    const aadhaarFile=f.aadhaarFile.files?.[0];
    const panFile=f.panFile.files?.[0];
    const voterFile=f.voterFile.files?.[0];

    const aadhaar=String(f.aadhaarNumber.value||'').replace(/\D/g,'');
    const pan=String(f.panNumber.value||'').trim().toUpperCase();
    const voter=String(f.voterNumber.value||'').trim().toUpperCase();

    if(aadhaar && !/^\d{12}$/.test(aadhaar))return alert('Aadhaar Card Number must contain exactly 12 digits when entered.');
    if(pan && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan))return alert('Enter a valid PAN Card Number, for example ABCDE1234F.');
    if(voter && voter.length<6)return alert('Enter a valid Voter Card / EPIC Number.');

    try{
      const [photoDataUrl,aadhaarDataUrl,panDataUrl,voterDataUrl]=await Promise.all([
        photo?fileToDataURL(photo,3*1024*1024):Promise.resolve(''),
        aadhaarFile?fileToDataURL(aadhaarFile,6*1024*1024):Promise.resolve(''),
        panFile?fileToDataURL(panFile,6*1024*1024):Promise.resolve(''),
        voterFile?fileToDataURL(voterFile,6*1024*1024):Promise.resolve('')
      ]);

      const d=Object.fromEntries(new FormData(f));
      d.sameAsPermanentAddress=!!same.checked;
      d.declaration=!!f.querySelector('[name="declaration"]').checked;
      d.aadhaarNumber=aadhaar;
      d.panNumber=pan;
      d.voterNumber=voter;
      d.photoFilename=photo?.name||''; d.photoDataUrl=photoDataUrl;
      d.aadhaarFilename=aadhaarFile?.name||''; d.aadhaarDataUrl=aadhaarDataUrl;
      d.panFilename=panFile?.name||''; d.panDataUrl=panDataUrl;
      d.voterFilename=voterFile?.name||''; d.voterDataUrl=voterDataUrl;
      d.applicationDate=dateToday();

      const a=await api('/api/applications',{method:'POST',body:JSON.stringify(d)});
      closeApplicationModal();
      toast(`Application ${a.id} created`);
      await loadAll();
      await viewApplication(a.id);
    }catch(x){alert(x.message)}
  };
}
function closeApplicationModal(){$('#applicationModal').classList.remove('show')}

async function viewApplication(id){
  try{
    const a=await api(`/api/applications/${encodeURIComponent(id)}`);
    const timeline=(a.history||[]).slice().reverse();
    $('#applicationViewBody').innerHTML=`
      <div class="application-head">
        <div class="application-photo">
          ${a.photoPath?`<img src="${esc(a.photoPath)}" alt="">`:`<div>${esc((a.name||'?').slice(0,1).toUpperCase())}</div>`}
          ${!['Active','Rejected'].includes(a.status)?`<input id="applicationPhotoFile" type="file" accept=".png,.jpg,.jpeg,.webp"><button class="mini" onclick="uploadApplicationPhoto('${a.id}')">Upload Photo</button>`:''}
        </div>
        <div>
          <span class="member-id-chip">${esc(a.id)}</span>
          <h2>${esc(a.name)}</h2>
          <p>${workflowBadge(a.status)} ${a.memberId?` &nbsp; Member ID: <b>${esc(a.memberId)}</b>`:''}</p>
          ${a.rejectionReason?`<div class="rejection-box"><b>Rejected Reason:</b> ${esc(a.rejectionReason)}</div>`:''}
        </div>
      </div>

      <div class="profile-detail-grid">
        ${detail('Father / Spouse',a.fatherSpouse)}
        ${detail('Date of Birth',a.dob)}
        ${detail('Gender',a.gender)}
        ${detail('Occupation',a.occupation)}
        ${detail('Mobile',a.phone)}
        ${detail('WhatsApp',a.whatsapp)}
        ${detail('Email',a.email)}
        ${detail('Application Date',a.applicationDate)}
        <div class="detail-section-title full">Permanent Address</div>
        ${detail('Village',a.permanentVillage)} ${detail('Post Office',a.permanentPostOffice)}
        ${detail('Police Station',a.permanentPoliceStation)} ${detail('GP / Ward No.',a.permanentGpWard)}
        ${detail('Block / Municipality',a.permanentBlockMunicipality)} ${detail('District',a.permanentDistrict)}
        ${detail('State',a.permanentState)} ${detail('PIN Code',a.permanentPin)}
        ${detail('Address / Landmark',a.permanentAddressLine,'full')}
        <div class="detail-section-title full">CSC Centre Information</div>
        ${detail('CSC ID',a.cscId)} ${detail('CSC Centre Name',a.cscCentreName)}
        ${detail('Same as Permanent Address',a.sameAsPermanentAddress?'Yes':'No')}
        ${detail('Centre Village',a.centreVillage)} ${detail('Centre Post Office',a.centrePostOffice)}
        ${detail('Centre Police Station',a.centrePoliceStation)} ${detail('Centre GP / Ward No.',a.centreGpWard)}
        ${detail('Centre Block / Municipality',a.centreBlockMunicipality)} ${detail('Centre District',a.centreDistrict)}
        ${detail('Centre State',a.centreState)} ${detail('Centre PIN',a.centrePin)}
        ${detail('Centre Address / Landmark',a.centreAddressLine,'full')}
        <div class="detail-section-title full">KYC Documents</div>
        ${detail('Aadhaar Card No.',a.aadhaarNumber)}
        ${a.aadhaarPath?`<div class="detail"><span>Aadhaar Upload</span><b><a href="${esc(a.aadhaarPath)}" target="_blank" rel="noopener">${esc(a.aadhaarOriginalName||'Open Aadhaar')}</a></b></div>`:''}
        ${detail('PAN Card No.',a.panNumber)}
        ${a.panPath?`<div class="detail"><span>PAN Upload</span><b><a href="${esc(a.panPath)}" target="_blank" rel="noopener">${esc(a.panOriginalName||'Open PAN')}</a></b></div>`:''}
        ${detail('Voter Card No.',a.voterNumber)}
        ${a.voterPath?`<div class="detail"><span>Voter Upload</span><b><a href="${esc(a.voterPath)}" target="_blank" rel="noopener">${esc(a.voterOriginalName||'Open Voter Card')}</a></b></div>`:''}
        <div class="detail-section-title full">Nominee / Emergency Contact</div>
        ${detail('Name',a.nomineeName)} ${detail('Relation',a.nomineeRelation)}
        ${detail('Mobile',a.nomineePhone)} ${detail('WhatsApp',a.nomineeWhatsapp)}
        ${detail('Address',a.nomineeAddress,'full')}
        ${detail('Membership Type',a.membershipType)}
        ${detail('Monthly Subscription',money(a.monthlyFee))}
        ${detail('Joining Fee',money(a.joiningFee))}
        ${detail('Application Source',a.source||'Internal ERP')}
        ${detail('Declaration',a.declarationText,'full')}
      </div>

      <div class="approval-panel">
        <h3>Approval Workflow</h3>
        <div class="workflow-actions">${applicationActions(a)}</div>
      </div>

      <div class="timeline-block">
        <h3>Application History</h3>
        ${timeline.map(h=>`<div class="timeline-item"><span></span><div><b>${esc(h.status)}</b><small>${esc(h.note||'')} · ${fmtDateTime(h.at)}</small></div></div>`).join('')}
      </div>`;
    $('#applicationViewModal').classList.add('show');
  }catch(e){alert(e.message)}
}
function applicationActions(a){
  if(a.status==='Pending') return `<button class="btn primary" onclick="changeApplicationStatus('${a.id}','Under Verification')">Start Verification</button><button class="btn reject" onclick="rejectApplication('${a.id}')">Reject</button>`;
  if(a.status==='Under Verification') return `<button class="btn primary" onclick="changeApplicationStatus('${a.id}','Approved')">Committee Approve</button><button class="btn reject" onclick="rejectApplication('${a.id}')">Reject</button>`;
  if(a.status==='Approved') return `<button class="btn primary" onclick="changeApplicationStatus('${a.id}','Payment Pending')">Send for Joining Fee</button><button class="btn reject" onclick="rejectApplication('${a.id}')">Reject</button>`;
  if(a.status==='Payment Pending') return `<button class="btn primary" onclick="activateApplication('${a.id}',${Number(a.joiningFee||0)})">Receive Joining Fee & Activate</button><button class="btn reject" onclick="rejectApplication('${a.id}')">Reject</button>`;
  if(a.status==='Active') return `<div class="success-box">✓ Joining completed. Member ID <b>${esc(a.memberId)}</b> generated and member is Active.</div>`;
  if(a.status==='Rejected') return `<div class="rejection-box">Application rejected and reason saved permanently.</div>`;
  return '';
}
async function changeApplicationStatus(id,status){
  let notes='';
  if(status==='Under Verification') notes=prompt('Verification note (optional):','Documents/identity verification started.')||'';
  if(status==='Approved') notes=prompt('Committee approval note / resolution reference (optional):','Approved by committee.')||'';
  if(status==='Payment Pending') notes='Committee approved. Joining fee payment requested.';
  try{
    await api(`/api/applications/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status,notes})});
    toast(status);await loadAll();await viewApplication(id);
  }catch(e){alert(e.message)}
}
async function rejectApplication(id){
  const reason=prompt('Rejection reason (mandatory):','');
  if(reason===null)return;
  if(!reason.trim())return alert('Rejection reason is mandatory.');
  try{
    await api(`/api/applications/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status:'Rejected',reason})});
    toast('Application rejected');await loadAll();await viewApplication(id);
  }catch(e){alert(e.message)}
}
async function activateApplication(id,defaultFee){
  const amount=prompt('Joining Fee Amount:',String(defaultFee||0));if(amount===null)return;
  if(Number(amount)<=0)return alert('Valid joining fee amount required.');
  const mode=prompt('Payment Mode: Cash / UPI / Bank Transfer / Cheque','Cash');if(mode===null)return;
  try{
    const r=await api(`/api/applications/${encodeURIComponent(id)}/activate`,{method:'POST',body:JSON.stringify({
      amount:Number(amount),mode,date:dateToday(),financialYear:activeFY
    })});
    toast(`Member ID ${r.member.id} generated`);await loadAll();await viewApplication(id);
  }catch(e){alert(e.message)}
}
async function uploadApplicationPhoto(id){
  const f=$('#applicationPhotoFile').files[0];if(!f)return alert('Select applicant photo.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/applications/${encodeURIComponent(id)}/photo`,{method:'POST',body:JSON.stringify({filename:f.name,dataUrl})});
    toast('Applicant photo uploaded');await loadAll();await viewApplication(id);
  }catch(e){alert(e.message)}
}
function closeApplicationView(){$('#applicationViewModal').classList.remove('show')}

function renderMembers(){
  $('#memberRows').innerHTML=cache.members.map(x=>`
    <tr>
      <td>${x.photoPath?`<img class="member-thumb" src="${esc(x.photoPath)}" alt="">`:`<div class="member-thumb empty">${esc((x.name||'?').slice(0,1).toUpperCase())}</div>`}</td>
      <td><b>${esc(x.id)}</b></td>
      <td>${esc(x.name)}</td>
      <td>${esc(x.membershipType||'General')}</td>
      <td>${esc(x.designation||'Member')}</td>
      <td>${esc(x.phone)}</td>
      <td>${money(x.monthlyFee)}</td>
      <td>${badge(x.status)}</td>
      <td><button class="mini" onclick="viewMember('${x.id}')">Profile</button> <button class="mini" onclick="openForm('member','${x.id}')">Edit</button> <button class="mini danger" onclick="del('members','${x.id}')">Delete</button></td>
    </tr>`).join('')||'<tr><td colspan="9">No members.</td></tr>';
}

function renderSubscriptions(){
  const d=cache.subscriptions;if(!d)return;
  const mSel=$('#subscriptionMonth');
  if(mSel){
    mSel.innerHTML=d.months.map(m=>`<option value="${m.key}" ${m.key===d.selectedMonth?'selected':''}>${esc(m.label)}</option>`).join('');
    mSel.onchange=async e=>{
      selectedSubscriptionMonth=e.target.value;
      cache.subscriptions=await api(fyUrl('/api/subscriptions')+`&month=${encodeURIComponent(selectedSubscriptionMonth)}`);
      renderSubscriptions();
    };
  }
  $('#subscriptionMonthTitle').textContent=d.months.find(x=>x.key===d.selectedMonth)?.label||d.selectedMonth;
  $('#subscriptionFYTitle').textContent=`Financial Year ${d.financialYear}`;
  const s=d.summary;
  $('#subscriptionStats').innerHTML=[
    ['TOTAL MEMBERS',s.totalMembers],
    ['PAID',s.paid],
    ['UNPAID',s.unpaid],
    ['PARTIAL PAID',s.partialPaid],
    ['TOTAL COLLECTION',money(s.totalCollection)],
    ['TOTAL DUE',money(s.totalDue)]
  ].map(x=>`<div class="subscription-stat card"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');
  $('#subscriptionRows').innerHTML=d.members.map(x=>`
    <tr>
      <td><b>${esc(x.memberId)}</b></td>
      <td>${esc(x.name)}<br><small>${esc(x.designation||'Member')}</small></td>
      <td>${money(x.payable)}</td>
      <td><b>${money(x.paid)}</b></td>
      <td><b>${money(x.due)}</b></td>
      <td>${subscriptionStatusBadge(x.status)}</td>
      <td>${x.paymentDate?esc(x.paymentDate):'—'}</td>
      <td>${x.paymentMode?esc(x.paymentMode):'—'}</td>
      <td><button class="mini" onclick="viewSubscriptionLedger('${x.memberId}')">Ledger</button>${x.due>0?` <button class="mini" onclick="openSubscriptionPayment('${x.memberId}','${d.selectedMonth}')">Pay</button>`:''}</td>
    </tr>`).join('')||'<tr><td colspan="9">No member subscription data for this month.</td></tr>';
}
function subscriptionStatusBadge(status){
  const cls=String(status).toLowerCase().replace(/\s+/g,'-');
  return `<span class="subscription-badge ${cls}">${esc(status)}</span>`;
}
async function viewSubscriptionLedger(memberId){
  try{
    const p=await api(fyUrl(`/api/subscriptions/member/${encodeURIComponent(memberId)}`));
    const m=p.member,s=p.summary;
    $('#subscriptionLedgerBody').innerHTML=`
      <div class="member-ledger-head">
        <div>
          <span class="member-id-chip">${esc(m.id)}</span>
          <h2>${esc(m.name)}</h2>
          <p>${esc(m.membershipType||'General')} · ${esc(m.designation||'Member')} · Monthly Rate ${money(m.monthlyFee)}</p>
        </div>
        <button class="btn primary" onclick="closeSubscriptionLedger();openSubscriptionPayment('${m.id}')">+ Receive Subscription</button>
      </div>
      <div class="subscription-ledger-summary">
        <div><span>Total Payable</span><b>${money(s.totalPayable)}</b></div>
        <div><span>Total Paid</span><b>${money(s.totalPaid)}</b></div>
        <div><span>Total Due</span><b>${money(s.totalDue)}</b></div>
      </div>
      <div class="mini-table-wrap"><table class="mini-table subscription-ledger-table"><thead><tr>
        <th>Month</th><th>Payable</th><th>Paid</th><th>Due</th><th>Status</th><th>Payment Date</th><th>Mode</th>
      </tr></thead><tbody>
        ${p.ledger.map(x=>`<tr>
          <td><b>${esc(x.monthLabel)}</b></td>
          <td>${money(x.payable)}</td>
          <td>${money(x.paid)}</td>
          <td>${money(x.due)}</td>
          <td>${subscriptionStatusBadge(x.status)}</td>
          <td>${x.paymentDate?esc(x.paymentDate):'—'}</td>
          <td>${x.paymentMode?esc(x.paymentMode):'—'}</td>
        </tr>`).join('')}
      </tbody></table></div>`;
    $('#subscriptionLedgerModal').classList.add('show');
  }catch(e){alert(e.message)}
}
function closeSubscriptionLedger(){$('#subscriptionLedgerModal').classList.remove('show')}

async function openSubscriptionPayment(memberId='',startMonth=''){
  try{
    const d=cache.subscriptions||await api(fyUrl('/api/subscriptions'));
    const members=cache.members.filter(x=>x.status==='Active'||x.status==='Inactive'||x.status==='Suspended'||x.status==='Resigned');
    const chosenMember=memberId||members[0]?.id||'';
    const chosenMonth=startMonth||d.selectedMonth||d.months[0]?.key||'';
    const build=async()=>{
      const mid=$('#subPayMember')?.value||chosenMember;
      const start=$('#subPayStart')?.value||chosenMonth;
      const cnt=Number($('#subPayCount')?.value||1);
      if(!mid)return;
      const p=await api(fyUrl(`/api/subscriptions/member/${encodeURIComponent(mid)}`));
      const idx=p.ledger.findIndex(x=>x.month===start);
      const selected=p.ledger.slice(idx,idx+cnt);
      const due=selected.reduce((s,x)=>s+Number(x.due||0),0);
      $('#subPayDueInfo').innerHTML=`Selected Due: <b>${money(due)}</b> &nbsp; | &nbsp; Months: ${selected.map(x=>esc(x.monthLabel)).join(', ')}`;
      if($('#subPayAmount') && !$('#subPayAmount').dataset.touched) $('#subPayAmount').value=due>0?due:'';
    };
    $('#subscriptionPaymentForm').innerHTML=`
      <div class="full info-strip"><b>Multi-month Payment:</b> 1 / 3 / 6 / 12 months can be paid together. Partial amount is also allowed.</div>
      <label>Member<select name="memberId" id="subPayMember" required>${members.map(m=>`<option value="${m.id}" ${m.id===chosenMember?'selected':''}>${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
      <label>Start Month<select name="startMonth" id="subPayStart">${d.months.map(m=>`<option value="${m.key}" ${m.key===chosenMonth?'selected':''}>${esc(m.label)}</option>`).join('')}</select></label>
      <label>Pay For<select name="monthsCount" id="subPayCount"><option value="1">1 Month</option><option value="3">3 Months</option><option value="6">6 Months</option><option value="12">12 Months</option></select></label>
      <label>Payment Amount<input type="number" step="0.01" name="amount" id="subPayAmount" required></label>
      <div class="full subscription-due-info" id="subPayDueInfo"></div>
      <label>Payment Date<input type="date" name="date" value="${dateToday()}" required></label>
      <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
      <label class="full">Notes<textarea name="notes"></textarea></label>
      <div class="actions"><button class="btn primary">Receive & Generate Receipt</button></div>`;
    $('#subscriptionPaymentModal').classList.add('show');
    for(const id of ['subPayMember','subPayStart','subPayCount']) $('#'+id).onchange=()=>{delete $('#subPayAmount').dataset.touched;build()};
    $('#subPayAmount').oninput=()=>{$('#subPayAmount').dataset.touched='1'};
    await build();
    $('#subscriptionPaymentForm').onsubmit=async e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(e.target));
      data.monthsCount=Number(data.monthsCount);data.amount=Number(data.amount);
      try{
        const r=await api(fyUrl('/api/subscriptions/payment'),{method:'POST',body:JSON.stringify(data)});
        closeSubscriptionPayment();toast(`Receipt ${r.receipt.id} generated`);
        selectedSubscriptionMonth=data.startMonth;
        await loadAll();
        printReceipt(r.receipt.id);
      }catch(x){alert(x.message)}
    };
  }catch(e){alert(e.message)}
}
function closeSubscriptionPayment(){$('#subscriptionPaymentModal').classList.remove('show')}






function renderWelfare(){
  const d=cache.welfare;if(!d)return;
  const s=d.summary,p=d.policy;
  $('#welfareStats').innerHTML=[
    ['APPLICATIONS',s.totalApplications,`Pending ${s.pending}`],
    ['IN VERIFICATION',s.verification,`Committee Review ${s.committeeReview}`],
    ['APPROVED',s.approved,`Outstanding ${money(s.outstandingApproved)}`],
    ['PAID CASES',s.paid,`Paid ${money(s.totalPaid)}`],
    ['REJECTED',s.rejected,'Reason retained in history'],
    ['TOTAL APPROVED',money(s.totalApproved),`Requested ${money(s.totalRequested)}`]
  ].map(x=>`<div class="welfare-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  const usage=p.currentEarmarkedAmount>0?Math.min(100,(s.totalPaid/p.currentEarmarkedAmount)*100):0;
  $('#welfarePolicyBox').innerHTML=`
    <div class="metric"><span>Fund Head</span><b>${esc(p.fundHeadName)}</b></div>
    <div class="metric"><span>Policy Allocation</span><b>${Number(p.welfarePercent||0)}%</b></div>
    <div class="metric"><span>Current Earmarked Amount</span><b>${money(p.currentEarmarkedAmount)}</b></div>
    <div class="metric"><span>Welfare Paid — FY ${activeFY}</span><b>${money(s.totalPaid)}</b></div>
    <div class="fund usage-fund"><div class="fund-top"><b>Paid vs Current Earmarked</b><span>${usage.toFixed(1)}%</span></div><div class="progress"><span style="width:${usage}%"></span></div></div>
    <small class="muted">The earmarked amount is calculated live from the Fund Allocation policy; it is not a separate bank account.</small>`;

  $('#welfareTypeList').innerHTML=(d.types||WELFARE_TYPES).map(x=>`<div class="welfare-type-item"><i>♥</i><span>${esc(x)}</span></div>`).join('');

  $('#welfareApplicationRows').innerHTML=d.applications.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b><br><small>${esc(fmtDate(x.applicationDate))}</small></td>
      <td><b>${esc(x.memberName)}</b><br><small>${esc(x.memberId)}</small></td>
      <td>${esc(x.welfareType)}</td>
      <td>${money(x.requestedAmount)}</td>
      <td>${x.approvedAmount?money(x.approvedAmount):'—'}</td>
      <td>${x.paidAmount?money(x.paidAmount):'—'}</td>
      <td>${welfareStatusBadge(x.status)}</td>
      <td>${(x.documents||[]).length}</td>
      <td><button class="mini" onclick="viewWelfareApplication('${x.id}')">Open</button></td>
    </tr>`).join('')||'<tr><td colspan="9">No welfare applications in this Financial Year.</td></tr>';

  $('#welfareLedgerRows').innerHTML=d.payments.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td>
      <td>${esc(x.memberName)}<br><small>${esc(x.memberId)}</small></td>
      <td>${esc(x.welfareType)}</td><td><b>${money(x.amount)}</b></td>
      <td>${esc(x.mode)}</td><td><b>${esc(x.expenseVoucherNo)}</b></td>
      <td>${esc(x.approvedBy||'—')}${x.approvalSnapshot?`<br><small>${esc(x.approvalSnapshot.rangeText||'Policy Approval')}</small>`:''}</td><td>${esc(x.reference||'—')}</td>
    </tr>`).join('')||'<tr><td colspan="9">No welfare payments in this Financial Year.</td></tr>';
}
function welfareStatusBadge(status){
  const cls=String(status).toLowerCase().replace(/\s+/g,'-');
  return `<span class="welfare-badge ${cls}">${esc(status)}</span>`;
}
function openWelfareApplicationForm(){
  const members=cache.members.filter(x=>x.status==='Active');
  if(!members.length)return alert('No Active Member available. Add/activate a member first.');
  $('#welfareApplicationForm').innerHTML=`
    <div class="full info-strip"><b>Workflow:</b> Application → Document Verification → Committee Review → Approved / Rejected → Payment → Welfare Ledger</div>
    <label>Member<select name="memberId" required>${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Assistance Type<select name="welfareType">${WELFARE_TYPES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Requested Amount<input type="number" step="0.01" name="requestedAmount" required></label>
    <label>Incident / Need Date<input type="date" name="incidentDate"></label>
    <label>Application Date<input type="date" name="applicationDate" value="${dateToday()}" required></label>
    <label class="full">Reason / Purpose<textarea name="reason" required placeholder="Why assistance is required"></textarea></label>
    <label class="full">Additional Details<textarea name="details" placeholder="Medical, family, education, accident or other details"></textarea></label>
    <div class="actions"><button class="btn primary">Submit Welfare Application</button></div>`;
  $('#welfareApplicationModal').classList.add('show');
  $('#welfareApplicationForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.requestedAmount=Number(data.requestedAmount);data.financialYear=activeFY;
    try{
      const a=await api('/api/welfare/applications',{method:'POST',body:JSON.stringify(data)});
      closeWelfareApplicationForm();toast(`Welfare application ${a.id} created`);await loadAll();await viewWelfareApplication(a.id);
    }catch(x){alert(x.message)}
  };
}
function closeWelfareApplicationForm(){$('#welfareApplicationModal').classList.remove('show')}
async function viewWelfareApplication(id){
  try{
    const a=await api(`/api/welfare/applications/${encodeURIComponent(id)}`);
    const history=(a.history||[]).slice().reverse();
    $('#welfareViewBody').innerHTML=`
      <div class="welfare-view-head">
        <div>
          <span class="member-id-chip">${esc(a.id)}</span>
          <h2>${esc(a.memberName)}</h2>
          <p>${esc(a.memberId)} · ${esc(a.welfareType)} · ${welfareStatusBadge(a.status)}</p>
        </div>
        ${a.status==='Approved'?`<button class="btn primary" onclick="openWelfarePayment('${a.id}')">Pay Assistance</button>`:''}
      </div>

      ${a.rejectionReason?`<div class="rejection-box"><b>Rejection Reason:</b> ${esc(a.rejectionReason)}</div>`:''}

      <div class="profile-summary-grid welfare-summary-grid">
        <div class="profile-stat"><span>Requested</span><b>${money(a.requestedAmount)}</b><small>${esc(fmtDate(a.applicationDate))}</small></div>
        <div class="profile-stat"><span>Approved</span><b>${money(a.approvedAmount||0)}</b><small>${esc(a.approvedBy||'Not approved yet')}</small></div>
        <div class="profile-stat"><span>Paid</span><b>${money(a.paidAmount||0)}</b><small>Outstanding ${money(Math.max(0,Number(a.approvedAmount||0)-Number(a.paidAmount||0)))}</small></div>
      </div>

      <div class="profile-detail-grid">
        ${detail('Member',`${a.memberId} - ${a.memberName}`)}
        ${detail('Mobile',a.memberMobile)}
        ${detail('Assistance Type',a.welfareType)}
        ${detail('Incident / Need Date',a.incidentDate)}
        ${detail('Application Date',a.applicationDate)}
        ${detail('Status',a.status)}
        ${detail('Reason / Purpose',a.reason,'full')}
        ${detail('Additional Details',a.details,'full')}
        ${a.verificationBy?detail('Verified By',a.verificationBy):''}
        ${a.verificationNotes?detail('Verification Notes',a.verificationNotes,'full'):''}
        ${a.approvedBy?detail('Approved By',a.approvedBy):''}
        ${a.committeeNotes?detail('Committee Notes',a.committeeNotes,'full'):''}
      </div>

      ${l.schedule?.length?`<div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Installment Schedule / Repayment Ledger</h3><p>Principal → permitted charge/interest → installment → paid → due → status.</p></div></div>
        <div class="mini-table-wrap"><table class="mini-table loan-schedule-table"><thead><tr>
          <th>#</th><th>Due Date</th><th>Principal</th><th>Charge / Interest</th><th>Installment</th><th>Paid</th><th>Due</th><th>Status</th>
        </tr></thead><tbody>
          ${l.schedule.map(x=>`<tr><td>${x.installmentNo}</td><td><b>${esc(fmtDate(x.dueDate))}</b></td><td>${money(x.principalPayable)}</td><td>${money(x.chargePayable)}</td><td><b>${money(x.installmentAmount)}</b></td><td>${money(x.paid)}</td><td>${money(x.due)}</td><td>${installmentStatusBadge(x.status)}</td></tr>`).join('')}
        </tbody></table></div>
      </div>`:''}

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Supporting Documents</h3><p>Medical paper, estimate, death certificate, accident proof, education document, etc.</p></div>
          ${!['Paid','Rejected'].includes(a.status)?`<button class="mini" onclick="uploadWelfareDocument('${a.id}')">+ Upload Document</button>`:''}
        </div>
        ${!['Paid','Rejected'].includes(a.status)?`<div class="welfare-doc-upload"><select id="welfareDocType"><option>Supporting Document</option><option>Medical Document</option><option>Estimate / Quotation</option><option>Identity / Relationship Proof</option><option>Death Certificate</option><option>Education Document</option><option>Disaster / Accident Proof</option><option>Committee Reference</option></select><input id="welfareDocName" placeholder="Document display name"><input id="welfareDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></div>`:''}
        <div class="document-list">${(a.documents||[]).map(d=>`
          <div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB</small></div>
          <a class="mini" href="${esc(d.path)}" target="_blank">Open</a>
          ${!['Paid','Rejected'].includes(a.status)?`<button class="mini danger" onclick="deleteWelfareDocument('${a.id}','${d.id}')">Delete</button>`:''}</div>`).join('')||'<div class="empty-docs">No supporting documents uploaded.</div>'}
        </div>
      </div>

      <div class="approval-panel">
        <h3>Welfare Approval Workflow</h3>
        <div class="workflow-actions">${welfareActions(a)}</div>
      </div>

      ${(a.payments||[]).length?`<div class="profile-ledger-block"><div class="profile-block-head"><div><h3>Payment History</h3></div></div>
      <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Payment No.</th><th>Date</th><th>Amount</th><th>Mode</th><th>Expense Voucher</th><th>Reference</th></tr></thead><tbody>
      ${a.payments.map(p=>`<tr><td>${esc(p.id)}</td><td>${esc(fmtDate(p.date))}</td><td>${money(p.amount)}</td><td>${esc(p.mode)}</td><td>${esc(p.expenseVoucherNo)}</td><td>${esc(p.reference||'—')}</td></tr>`).join('')}
      </tbody></table></div></div>`:''}

      <div class="timeline-block">
        <h3>Application History</h3>
        ${history.map(h=>`<div class="timeline-item"><span></span><div><b>${esc(h.status)}</b><small>${esc(h.note||'')} · ${fmtDateTime(h.at)}</small></div></div>`).join('')}
      </div>`;
    $('#welfareViewModal').classList.add('show');
  }catch(e){alert(e.message)}
}
function welfareActions(a){
  if(a.status==='Pending') return `<button class="btn primary" onclick="changeWelfareStatus('${a.id}','Document Verification')">Start Document Verification</button><button class="btn reject" onclick="rejectWelfare('${a.id}')">Reject</button>`;
  if(a.status==='Document Verification') return `<button class="btn primary" onclick="changeWelfareStatus('${a.id}','Committee Review')">Send to Committee Review</button><button class="btn reject" onclick="rejectWelfare('${a.id}')">Reject</button>`;
  if(a.status==='Committee Review') return `<button class="btn primary" onclick="approveWelfare('${a.id}',${Number(a.requestedAmount||0)})">Approve Assistance</button><button class="btn reject" onclick="rejectWelfare('${a.id}')">Reject</button>`;
  if(a.status==='Approved') return `<div class="success-box">✓ Approved for ${money(a.approvedAmount)} by ${esc(a.approvedBy||'Committee')}.</div><button class="btn primary" onclick="openWelfarePayment('${a.id}')">Pay Assistance</button>`;
  if(a.status==='Paid') return `<div class="success-box">✓ Payment completed and posted to Welfare Ledger + Expense/Cash-Bank accounts.</div>`;
  if(a.status==='Rejected') return `<div class="rejection-box">Application rejected. Reason and history retained.</div>`;
  return '';
}
async function changeWelfareStatus(id,status){
  let actionBy='',notes='';
  if(status==='Document Verification'){
    actionBy=prompt('Verification started by:',cache.master?.ownerName||'')||'';
    notes=prompt('Verification note (optional):','Documents to be verified.')||'';
  }
  if(status==='Committee Review'){
    actionBy=prompt('Verified by:',cache.master?.ownerName||'')||'';
    notes=prompt('Verification findings / note:','Documents verified and placed before committee.')||'';
  }
  try{
    await api(`/api/welfare/applications/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status,actionBy,notes})});
    toast(status);await loadAll();await viewWelfareApplication(id);
  }catch(e){alert(e.message)}
}
async function approveWelfare(id,requested){
  const approvedAmount=prompt(`Approved Amount (maximum ${requested}):`,String(requested));if(approvedAmount===null)return;
  const approvedBy=prompt('Approved By / Committee Resolution:',cache.master?.ownerName||'');if(approvedBy===null)return;
  const notes=prompt('Committee Review Note / Resolution Reference:','Approved by committee.')||'';
  try{
    await api(`/api/welfare/applications/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({
      status:'Approved',approvedAmount:Number(approvedAmount),approvedBy,notes
    })});
    toast('Welfare assistance approved');await loadAll();await viewWelfareApplication(id);
  }catch(e){alert(e.message)}
}
async function rejectWelfare(id){
  const reason=prompt('Rejection reason (mandatory):','');if(reason===null)return;
  if(!reason.trim())return alert('Rejection reason is mandatory.');
  try{
    await api(`/api/welfare/applications/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status:'Rejected',reason})});
    toast('Welfare application rejected');await loadAll();await viewWelfareApplication(id);
  }catch(e){alert(e.message)}
}
async function uploadWelfareDocument(id){
  const f=$('#welfareDocFile')?.files?.[0];if(!f)return alert('Select a supporting document.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/welfare/applications/${encodeURIComponent(id)}/document`,{method:'POST',body:JSON.stringify({
      filename:f.name,dataUrl,documentType:$('#welfareDocType').value,displayName:$('#welfareDocName').value||f.name
    })});
    toast('Welfare document uploaded');await loadAll();await viewWelfareApplication(id);
  }catch(e){alert(e.message)}
}
async function deleteWelfareDocument(appId,docId){
  if(!confirm('Delete this supporting document?'))return;
  try{
    await api(`/api/welfare/applications/${encodeURIComponent(appId)}/documents/${encodeURIComponent(docId)}`,{method:'DELETE'});
    toast('Document deleted');await loadAll();await viewWelfareApplication(appId);
  }catch(e){alert(e.message)}
}
function closeWelfareView(){$('#welfareViewModal').classList.remove('show')}
function openWelfarePayment(id){
  const a=cache.welfare?.applications?.find(x=>x.id===id);
  if(!a)return alert('Application not found.');
  const remaining=Math.max(0,Number(a.approvedAmount||0)-Number(a.paidAmount||0));
  $('#welfarePaymentForm').innerHTML=`
    <div class="full info-strip"><b>${esc(a.memberId)} - ${esc(a.memberName)}</b><br>${esc(a.welfareType)} · Approved ${money(a.approvedAmount)} · Outstanding ${money(remaining)}</div>
    <label>Payment Amount<input type="number" step="0.01" name="amount" value="${remaining}" required></label>
    <label>Payment Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Reference / UTR<input name="reference"></label>
    <label class="full">Remarks<textarea name="remarks"></textarea></label>
    <div class="full welfare-payment-note">When the payment is saved, a <b>Member Welfare Expense Voucher</b> is created automatically and the amount is deducted from the selected Cash/Bank/UPI ledger.</div>
    <div class="actions"><button class="btn primary">Pay & Post to Welfare Ledger</button></div>`;
  $('#welfarePaymentModal').classList.add('show');
  $('#welfarePaymentForm').onsubmit=async e=>{
    e.preventDefault();
    let data=Object.fromEntries(new FormData(e.target));
    data.amount=Number(data.amount);data.financialYear=activeFY;
    data=await applyFinancialApprovalPrompt(data,'WelfarePayment');if(!data)return;
    try{
      const r=await api(`/api/welfare/applications/${encodeURIComponent(id)}/payment`,{method:'POST',body:JSON.stringify(data)});
      closeWelfarePayment();toast(`Welfare payment ${r.payment.id} posted`);await loadAll();await viewWelfareApplication(id);
    }catch(x){alert(x.message)}
  };
}
function closeWelfarePayment(){$('#welfarePaymentModal').classList.remove('show')}

function renderCashBank(){
  const d=cache.cashbank;if(!d)return;
  const s=d.summary;
  $('#cashBankStats').innerHTML=[
    [d.settings.cash.name,money(s.cashBalance),'Cash in Hand'],
    [d.settings.bank.name,money(s.bankBalance),'Bank'],
    [d.settings.upi.name,money(s.upiBalance),'UPI / Other'],
    ['TOTAL AVAILABLE',money(s.totalBalance),`Financial Year ${activeFY}`]
  ].map(x=>`<div class="cashbank-stat card"><span>${esc(x[0])}</span><b>${x[1]}</b><small>${esc(x[2])}</small></div>`).join('');

  const select=$('#cashBankAccountSelect');
  select.innerHTML=['cash','bank','upi'].map(k=>`<option value="${k}" ${k===selectedCashBankAccount?'selected':''}>${esc(d.settings[k].name)}</option>`).join('');
  select.onchange=e=>{selectedCashBankAccount=e.target.value;renderCashBank()};
  const ledger=d.accounts[selectedCashBankAccount];
  $('#cashBankAccountName').textContent=ledger.accountName;
  $('#cashBankAccountBalance').textContent=`Opening ${money(ledger.openingBalance)} · Closing ${money(ledger.closingBalance)}`;
  $('#cashBankLedgerRows').innerHTML=[
    `<tr class="opening-row"><td>—</td><td>OPEN</td><td>Opening Balance</td><td>Opening</td><td>—</td><td>—</td><td><b>${money(ledger.openingBalance)}</b></td></tr>`,
    ...ledger.rows.map(x=>`<tr>
      <td>${esc(fmtDate(x.date))}</td><td><b>${esc(x.ref)}</b></td><td>${esc(x.particular)}</td>
      <td>${cashBankTypeBadge(x.type)}</td>
      <td class="money-in">${x.inflow?money(x.inflow):'—'}</td>
      <td class="money-out">${x.outflow?money(x.outflow):'—'}</td>
      <td><b>${money(x.balance)}</b></td>
    </tr>`)
  ].join('');

  $('#fundTransferRows').innerHTML=d.transfers.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td>
      <td>${esc(d.settings[x.fromAccount]?.name||x.fromAccount)}</td>
      <td>${esc(d.settings[x.toAccount]?.name||x.toAccount)}</td>
      <td><b>${money(x.amount)}</b></td>
      <td>${esc(x.reference||'—')}</td><td>${esc(x.remarks||'—')}</td>
      <td><button class="mini danger" onclick="deleteFundTransfer('${x.id}')">Delete</button></td>
    </tr>`).join('')||'<tr><td colspan="8">No fund transfers in this Financial Year.</td></tr>';
}
function cashBankTypeBadge(type){
  const cls=String(type).toLowerCase().replace(/\s+/g,'-');
  return `<span class="cashbank-badge ${cls}">${esc(type)}</span>`;
}
function openFundTransfer(){
  const d=cache.cashbank;if(!d)return;
  $('#fundTransferForm').innerHTML=`
    <div class="full info-strip"><b>Internal Fund Transfer:</b> This is not Income or Expense. It only moves balance from one account to another.</div>
    <label>From Account<select name="fromAccount" id="transferFrom">${['cash','bank','upi'].map(k=>`<option value="${k}">${esc(d.settings[k].name)} — ${money(d.accounts[k].closingBalance)}</option>`).join('')}</select></label>
    <label>To Account<select name="toAccount" id="transferTo">${['bank','cash','upi'].map(k=>`<option value="${k}">${esc(d.settings[k].name)}</option>`).join('')}</select></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Reference<input name="reference" placeholder="Deposit slip / UTR / reference no."></label>
    <label class="full">Remarks<textarea name="remarks" placeholder="Transfer details"></textarea></label>
    <div class="actions"><button class="btn primary">Transfer Fund</button></div>`;
  const sync=()=>{
    const from=$('#transferFrom').value;
    const to=$('#transferTo');
    [...to.options].forEach(o=>o.disabled=o.value===from);
    if(to.value===from){
      const alt=[...to.options].find(o=>!o.disabled);
      if(alt)to.value=alt.value;
    }
  };
  $('#transferFrom').onchange=sync;sync();
  $('#fundTransferModal').classList.add('show');
  $('#fundTransferForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.amount=Number(data.amount);data.financialYear=activeFY;
    try{
      const tr=await api(fyUrl('/api/fund-transfers'),{method:'POST',body:JSON.stringify(data)});
      closeFundTransfer();toast(`Fund transfer ${tr.id} saved`);await loadAll();
    }catch(x){alert(x.message)}
  };
}
function closeFundTransfer(){$('#fundTransferModal').classList.remove('show')}
async function deleteFundTransfer(id){
  if(!confirm('Delete this fund transfer? Balances will be recalculated.'))return;
  try{
    await api(`/api/fund-transfers/${encodeURIComponent(id)}`,{method:'DELETE'});
    toast('Fund transfer deleted');await loadAll();
  }catch(e){alert(e.message)}
}
function openCashBankSettings(){
  const d=cache.cashbank;if(!d)return;
  $('#cashBankSettingsForm').innerHTML=`
    <div class="full info-strip"><b>Financial Year ${activeFY}:</b> Enter only the actual opening balance at the start of the Financial Year. Do not enter transfers here.</div>
    <h3 class="full section-title">Cash in Hand</h3>
    <label>Account Name<input name="cashName" value="${esc(d.settings.cash.name)}"></label>
    <label>Opening Balance<input type="number" step="0.01" name="cashOpening" value="${Number(d.settings.cash.openingBalance||0)}"></label>
    <h3 class="full section-title">Bank Account</h3>
    <label>Account Name<input name="bankName" value="${esc(d.settings.bank.name)}"></label>
    <label>Opening Balance<input type="number" step="0.01" name="bankOpening" value="${Number(d.settings.bank.openingBalance||0)}"></label>
    <h3 class="full section-title">UPI / Other Account</h3>
    <label>Account Name<input name="upiName" value="${esc(d.settings.upi.name)}"></label>
    <label>Opening Balance<input type="number" step="0.01" name="upiOpening" value="${Number(d.settings.upi.openingBalance||0)}"></label>
    <div class="actions"><button class="btn primary">Save Account Settings</button></div>`;
  $('#cashBankSettingsModal').classList.add('show');
  $('#cashBankSettingsForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    try{
      await api(fyUrl('/api/cash-bank/settings'),{method:'POST',body:JSON.stringify(data)});
      closeCashBankSettings();toast('Opening balances / account settings saved');await loadAll();
    }catch(x){alert(x.message)}
  };
}
function closeCashBankSettings(){$('#cashBankSettingsModal').classList.remove('show')}

async function applyFinancialApprovalPrompt(data,context,amountField='amount',dateField='date'){
  const amount=Number(data[amountField]||0),date=data[dateField]||dateToday();
  let req;
  try{req=await api(`/api/approval-requirement?amount=${encodeURIComponent(amount)}&context=${encodeURIComponent(context)}&date=${encodeURIComponent(date)}`)}
  catch(e){alert(e.message);return null}
  if(!req.required)return data;

  data.approvals={};
  for(const designation of req.designations||[]){
    const rows=req.approvers?.[designation]||[];
    if(!rows.length){alert(`No active ${designation} found in Committee Management for ${date}.`);return null}
    const hint=rows.map(x=>`${x.memberId} - ${x.memberName}`).join('\n');
    const val=prompt(`${designation} approval required for ${req.rangeText}.\nEnter approver Member ID:\n${hint}`,rows[0].memberId);
    if(val===null)return null;
    data.approvals[designation]=val.trim();
  }
  if(req.requireResolution&&!data.resolutionId){
    const rows=(cache.meetings?.resolutions||[]).filter(r=>r.category===req.resolutionCategory);
    if(!rows.length){alert(`A Finalized Passed/Unanimous "${req.resolutionCategory}" Resolution is required.`);return null}
    const hint=rows.map(r=>`${r.id} - ${r.title}`).join('\n');
    const val=prompt(`Committee Resolution required for ${req.rangeText}.\nEnter Resolution ID:\n${hint}`,rows[0].id);
    if(val===null)return null;
    data.resolutionId=val.trim();
  }
  return data;
}
function usableResolutionOptions(category='',selected=''){
  const rows=(cache.meetings?.resolutions||[]).filter(r=>!category||r.category===category);
  return `<option value="">No Resolution Linked</option>`+rows.map(r=>`<option value="${esc(r.id)}" ${r.id===selected?'selected':''}>${esc(r.resolutionNo)} · ${esc(r.category)} · ${esc(r.title)}</option>`).join('');
}
function promptResolutionId(category=''){
  const rows=(cache.meetings?.resolutions||[]).filter(r=>!category||r.category===category);
  if(!rows.length)return '';
  const text=rows.slice(0,15).map(r=>`${r.id} — ${r.title}`).join('\n');
  const val=prompt(`Resolution ID (optional):\n\n${text}`,'');
  return val===null?null:String(val||'').trim();
}
function renderExpense(){
  const d=cache.expenses;if(!d)return;
  const s=d.summary;
  $('#expenseStats').innerHTML=[
    ['TOTAL EXPENSE',money(s.totalExpense)],
    ['TOTAL VOUCHERS',s.totalEntries],
    ['WITH BILL',s.withBill],
    ['WITHOUT BILL',s.withoutBill]
  ].map(x=>`<div class="expense-stat card"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');

  const max=Math.max(1,...d.categorySummary.map(x=>Number(x.amount||0)));
  $('#expenseCategoryList').innerHTML=d.categorySummary.map(x=>`
    <div class="expense-category-item">
      <div class="expense-cat-top"><b>${esc(x.category)}</b><span>${money(x.amount)} · ${x.count} voucher</span></div>
      <div class="progress"><span style="width:${Math.max(2,Number(x.amount||0)/max*100)}%"></span></div>
    </div>`).join('');

  $('#expenseRows').innerHTML=d.rows.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td>
      <td>${esc(fmtDate(x.date))}</td>
      <td>${esc(x.category)}</td>
      <td>${esc(x.paidTo||'—')}</td>
      <td>${esc(x.purpose||'—')}${x.fundingPurpose?`<br><small>Fund: ${esc(x.fundingPurpose)}</small>`:''}${x.resolutionNo?`<br><small>Resolution: ${esc(x.resolutionNo)}</small>`:''}</td>
      <td>${esc(x.paymentMode||'—')}</td>
      <td><b>${money(x.amount)}</b></td>
      <td>${esc(x.approvedBy||'—')}</td>
      <td>${x.billPath?`<a class="mini bill-link" href="${esc(x.billPath)}" target="_blank">Open Bill</a>`:'<span class="no-bill">No Bill</span>'}</td>
      <td><button class="mini" onclick="printExpenseVoucher('${x.id}')">Voucher</button> <button class="mini danger" onclick="del('transactions','${x.id}')">Delete</button></td>
    </tr>`).join('')||'<tr><td colspan="10">No expense records in this Financial Year.</td></tr>';
}
function openExpenseForm(){
  $('#expenseForm').innerHTML=`
    <div class="full info-strip"><b>Automatic Voucher:</b> Saving automatically generates a Financial Year-wise Expense Voucher.</div>
    <label>Expense Category<select name="category">${EXPENSE_CATEGORIES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Paid To<input name="paidTo" placeholder="Person / Vendor / Institution" required></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="paymentMode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Approved By / Manual Note<input name="approvedBy" placeholder="Required when policy is OFF; verified approvers are recorded automatically when policy is ON"></label>
    <label>Fund / Donation Purpose<select name="fundingPurpose"><option value="">Not Tagged / General Account</option>${DONATION_PURPOSES.map(p=>`<option>${esc(p)}</option>`).join('')}</select></label>
    <label>Committee Resolution<select name="resolutionId">${usableResolutionOptions('Major Expense Approval')}</select></label>
    <label>Bill / Invoice<input id="expenseBillFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></label>
    <label class="full">Purpose<textarea name="purpose" placeholder="Why this expense was made" required></textarea></label>
    <label class="full">Remarks<textarea name="remarks" placeholder="Bill no., approval reference, additional remarks"></textarea></label>
    <div class="actions"><button class="btn primary">Save Expense & Generate Voucher</button></div>`;
  $('#expenseModal').classList.add('show');
  $('#expenseForm').onsubmit=async e=>{
    e.preventDefault();
    let data=Object.fromEntries(new FormData(e.target));
    data.amount=Number(data.amount);data.financialYear=activeFY;
    data=await applyFinancialApprovalPrompt(data,'Expense');if(!data)return;
    const bill=$('#expenseBillFile').files[0];
    try{
      if(bill){
        if(bill.size>10*1024*1024) throw new Error('Bill file maximum 10 MB.');
        data.billFilename=bill.name;
        data.billDataUrl=await fileToDataURL(bill);
      }
      const row=await api('/api/expenses',{method:'POST',body:JSON.stringify(data)});
      closeExpenseForm();toast(`Expense voucher ${row.id} generated`);await loadAll();
      printExpenseVoucher(row.id);
    }catch(x){alert(x.message)}
  };
}
function closeExpenseForm(){$('#expenseModal').classList.remove('show')}
function printExpenseVoucher(id){
  const x=cache.expenses?.rows?.find(r=>r.id===id);
  if(!x)return alert('Expense voucher not found.');
  const org=cache.master||{};
  const w=window.open('','_blank','width=820,height=760');
  const logo=org.logoPath?`<img src="${esc(org.logoPath)}" style="max-height:70px;max-width:100px;object-fit:contain">`:'';
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(x.id)}</title>
  <style>
  body{font-family:Arial,sans-serif;margin:0;padding:30px;color:#111}.voucher{max-width:720px;margin:auto;border:2px solid #111;padding:24px}
  .head{display:flex;gap:16px;align-items:center;border-bottom:2px solid #111;padding-bottom:14px}.head h1{font-size:22px;margin:0}.head p{margin:4px 0;font-size:12px}
  .title{text-align:center;font-size:18px;font-weight:bold;margin:18px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.row{padding:8px 0;border-bottom:1px dotted #aaa}.row b{display:block;font-size:11px;text-transform:uppercase;color:#555;margin-bottom:4px}
  .amount{font-size:22px;font-weight:bold}.foot{display:flex;justify-content:space-between;margin-top:42px;font-size:12px}.sig{border-top:1px solid #111;padding-top:6px;min-width:170px;text-align:center}
  @media print{button{display:none}}
  </style></head><body><div class="voucher">
  <div class="head">${logo}<div><h1>${esc(org.organizationName||'Organization')}</h1><p>${esc(org.registeredAddress||org.officeAddress||'')}</p></div></div>
  <div class="title">EXPENSE VOUCHER</div>
  <div class="grid">
    <div class="row"><b>Voucher Number</b>${esc(x.id)}</div>
    <div class="row"><b>Financial Year</b>${esc(activeFY)}</div>
    <div class="row"><b>Date</b>${esc(fmtDate(x.date))}</div>
    <div class="row"><b>Category</b>${esc(x.category)}</div>
    <div class="row"><b>Paid To</b>${esc(x.paidTo||'—')}</div>
    <div class="row"><b>Payment Mode</b>${esc(x.paymentMode||'—')}</div>
    <div class="row" style="grid-column:1/-1"><b>Purpose</b>${esc(x.purpose||'—')}</div>
    ${x.fundingPurpose?`<div class="row" style="grid-column:1/-1"><b>Fund / Donation Purpose</b>${esc(x.fundingPurpose)}</div>`:''}
    <div class="row"><b>Approved By</b>${esc(x.approvedBy||'—')}</div>
    <div class="row"><b>Bill Attached</b>${x.billPath?'Yes - '+esc(x.billOriginalName||'Bill'):'No'}</div>
    <div class="row" style="grid-column:1/-1"><b>Resolution</b>${esc(x.resolutionNo||'—')} ${x.resolutionTitle?'· '+esc(x.resolutionTitle):''}</div>
    <div class="row" style="grid-column:1/-1"><b>Amount</b><span class="amount">${money(x.amount)}</span></div>
    <div class="row" style="grid-column:1/-1"><b>Remarks</b>${esc(x.remarks||'—')}</div>
  </div>
  <div class="foot"><div class="sig">Paid / Received By</div><div class="sig">Approved Signature</div></div>
  </div><div style="text-align:center;margin-top:15px"><button onclick="window.print()">Print Voucher</button></div></body></html>`);
  w.document.close();
}

function renderIncome(){
  const d=cache.incomes;if(!d)return;
  const s=d.summary;
  $('#incomeStats').innerHTML=[
    ['TOTAL INCOME',money(s.totalIncome)],
    ['RECEIPT-BASED',money(s.receiptIncome)],
    ['VOUCHER-BASED',money(s.voucherIncome)],
    ['TOTAL ENTRIES',s.totalEntries]
  ].map(x=>`<div class="income-stat card"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');

  const max=Math.max(1,...d.categorySummary.map(x=>Number(x.amount||0)));
  $('#incomeCategoryList').innerHTML=d.categorySummary.map(x=>`
    <div class="income-category-item">
      <div class="income-cat-top"><b>${esc(x.category)}</b><span>${money(x.amount)} · ${x.count} entry</span></div>
      <div class="progress"><span style="width:${Math.max(2,Number(x.amount||0)/max*100)}%"></span></div>
    </div>`).join('');

  $('#incomeRows').innerHTML=d.rows.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td>
      <td>${esc(fmtDate(x.date))}</td>
      <td>${esc(x.category)}</td>
      <td>${esc(x.source||'—')}</td>
      <td>${esc(x.paymentMode||'—')}</td>
      <td><b>${money(x.amount)}</b></td>
      <td>${esc(x.remarks||'—')}</td>
      <td>${x.recordType==='Receipt'?'<span class="income-type receipt">Receipt</span>':'<span class="income-type voucher">Voucher</span>'}</td>
      <td>${x.recordType==='Receipt'?`<button class="mini" onclick="printReceipt('${x.id}')">Receipt</button>`:`<button class="mini danger" onclick="del('transactions','${x.id}')">Delete</button>`}</td>
    </tr>`).join('')||'<tr><td colspan="9">No income records in this Financial Year.</td></tr>';
}
function openIncomeForm(){
  $('#incomeForm').innerHTML=`
    <div class="full info-strip"><b>Automatic Voucher:</b> Saving automatically generates a Financial Year-wise Income Voucher.</div>
    <label>Income Category<select name="category">${['Event Collection','Sponsorship','Bank Interest','Other Legal Income'].map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Source<input name="source" placeholder="Person / Institution / Bank / Event" required></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="paymentMode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Fund / Donation Purpose<select name="fundingPurpose"><option value="">Not Tagged / General Account</option>${DONATION_PURPOSES.map(p=>`<option>${esc(p)}</option>`).join('')}</select></label>
    <label class="full">Remarks<textarea name="remarks" placeholder="Income details / reference / remarks"></textarea></label>
    <div class="actions"><button class="btn primary">Save Income & Generate Voucher</button></div>`;
  $('#incomeModal').classList.add('show');
  $('#incomeForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.amount=Number(data.amount);data.financialYear=activeFY;
    try{
      const row=await api('/api/incomes',{method:'POST',body:JSON.stringify(data)});
      closeIncomeForm();toast(`Income voucher ${row.id} generated`);await loadAll();
    }catch(x){alert(x.message)}
  };
}
function closeIncomeForm(){$('#incomeModal').classList.remove('show')}

function renderDonations(){
  const d=cache.donations;if(!d)return;
  const s=d.summary;
  $('#donationStats').innerHTML=[
    ['TOTAL DONATION',money(s.totalDonation)],
    ['MEMBER DONATION',money(s.memberDonation)],
    ['EXTERNAL DONATION',money(s.externalDonation)],
    ['TOTAL DONORS',s.totalDonors],
    ['PURPOSE-WISE SPENT',money(s.totalPurposeSpent)],
    ['PURPOSE BALANCE',money(s.purposeBalance)]
  ].map(x=>`<div class="donation-stat card"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');

  $('#donationPurposeRows').innerHTML=d.purposeSummary.map(x=>`
    <tr>
      <td><b>${esc(x.purpose)}</b></td>
      <td>${money(x.received)}</td>
      <td>${money(x.spent)}</td>
      <td><b class="${x.balance<0?'negative-balance':''}">${money(x.balance)}</b></td>
    </tr>`).join('');

  $('#donationRows').innerHTML=d.donations.map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td>
      <td>${esc(fmtDate(x.date))}</td>
      <td>${donationTypeBadge(x.donationType||'External Donation')}</td>
      <td>${esc(x.personName)}</td>
      <td>${esc(x.donorMobile||'—')}</td>
      <td>${esc(x.donationPurpose||'General Fund')}</td>
      <td>${esc(x.mode)}</td>
      <td><b>${money(x.amount)}</b></td>
      <td><button class="mini" onclick="printReceipt('${x.id}')">Receipt</button> <button class="mini danger" onclick="del('collections','${x.id}')">Delete</button></td>
    </tr>`).join('')||'<tr><td colspan="9">No donations in this Financial Year.</td></tr>';
}
function donationTypeBadge(type){
  const cls=type==='Member Donation'?'member-donation':'external-donation';
  return `<span class="donation-type-badge ${cls}">${esc(type)}</span>`;
}
function openDonationForm(){
  const members=cache.members.filter(x=>x.status==='Active'||x.status==='Inactive'||x.status==='Suspended');
  $('#donationForm').innerHTML=`
    <div class="full info-strip"><b>Automatic Receipt:</b> Saving a donation automatically generates a Financial Year-wise Receipt Number.</div>
    <label>Donation Type<select name="donationType" id="donationType">
      <option>Member Donation</option><option>External Donation</option>
    </select></label>
    <label id="donationMemberField">Member<select name="memberId" id="donationMember">${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label id="externalDonorNameField" class="hidden-field">Donor / Institution Name<input name="donorName"></label>
    <label id="externalDonorMobileField" class="hidden-field">Mobile<input name="donorMobile"></label>
    <label>Donation Purpose<select name="donationPurpose">${DONATION_PURPOSES.map(p=>`<option>${esc(p)}</option>`).join('')}</select></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label class="full">Notes / Reference<textarea name="notes"></textarea></label>
    <div class="actions"><button class="btn primary">Save Donation & Generate Receipt</button></div>`;

  const updateFields=()=>{
    const memberMode=$('#donationType').value==='Member Donation';
    $('#donationMemberField').classList.toggle('hidden-field',!memberMode);
    $('#externalDonorNameField').classList.toggle('hidden-field',memberMode);
    $('#externalDonorMobileField').classList.toggle('hidden-field',memberMode);
  };
  $('#donationType').onchange=updateFields;updateFields();

  $('#donationModal').classList.add('show');
  $('#donationForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.amount=Number(data.amount);data.financialYear=activeFY;
    try{
      const receipt=await api('/api/donations',{method:'POST',body:JSON.stringify(data)});
      closeDonationForm();toast(`Donation receipt ${receipt.id} generated`);
      await loadAll();printReceipt(receipt.id);
    }catch(x){alert(x.message)}
  };
}
function closeDonationForm(){$('#donationModal').classList.remove('show')}

function renderCollections(){
  $('#collectionRows').innerHTML=cache.collections.map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td><td>${esc(x.personName)}</td><td>${esc(x.type)}</td><td>${esc(x.mode)}</td><td><b>${money(x.amount)}</b></td><td><button class="mini" onclick="printReceipt('${x.id}')">Receipt</button> <button class="mini danger" onclick="del('collections','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="7">No records in this Financial Year.</td></tr>';
}
function renderTransactions(){
  $('#transactionRows').innerHTML=cache.transactions.map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td><td>${badge(x.type)}</td><td>${esc(x.category)}</td><td>${x.fundingPurpose?esc(x.fundingPurpose):'—'}</td><td>${esc(x.description)}</td><td>${esc(x.mode)}</td><td><b>${money(x.amount)}</b></td><td><button class="mini danger" onclick="del('transactions','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="9">No records in this Financial Year.</td></tr>';
}
function loanStatusBadge(status){
  const cls=String(status||'').toLowerCase().replace(/\s+/g,'-');
  return `<span class="loan-badge ${cls}">${esc(status)}</span>`;
}
function repaymentStatusBadge(status){
  const cls=String(status||'Current').toLowerCase();
  return `<span class="repayment-status-badge ${cls}">${esc(status||'Current')}</span>`;
}
function installmentStatusBadge(status){
  const cls=String(status||'Upcoming').toLowerCase();
  return `<span class="installment-status-badge ${cls}">${esc(status||'Upcoming')}</span>`;
}
function renderLoans(){
  const d=cache.loans;if(!d)return;
  const settings=d.settings||{},s=d.summary||{},p=d.policy||{};
  $('#loanComplianceBanner').innerHTML=d.complianceReady
    ? `<div class="loan-compliance ready"><b>✓ Facility Enabled</b><span>Admin/Committee has recorded a compliance confirmation. Software does not itself determine legal permission.</span></div>`
    : `<div class="loan-compliance blocked"><b>⚠ Loan / Financial Assistance Facility Not Enabled</b><span>Before using this workflow, confirm that your registration type, Constitution/By-laws and applicable law permit member financial assistance/loan activity, then record that confirmation in Compliance & Eligibility Policy.</span></div>`;

  $('#loanStats').innerHTML=[
    ['APPLICATIONS',s.totalApplications||0,`Applied ${s.applied||0}`],
    ['IN REVIEW',(s.verification||0)+(s.committeeApproval||0),`Verification ${s.verification||0} · Committee ${s.committeeApproval||0}`],
    ['SANCTIONED',s.sanctioned||0,'Awaiting disbursement'],
    ['ACTIVE LOANS',s.active||0,`Current ${s.repaymentCurrent||0} · Due ${s.repaymentDue||0} · Overdue ${s.repaymentOverdue||0}`],
    ['TOTAL DISBURSED',money(s.totalDisbursed||0),`Repaid ${money(s.totalRepaid||0)}`],
    ['CLOSED / REJECTED',`${s.closed||0} / ${s.rejected||0}`,'Completed / Rejected']
  ].map(x=>`<div class="loan-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  const policyRows=[
    ['Facility Enabled',settings.facilityEnabled?'Yes':'No'],
    ['Legal / By-laws Confirmation',settings.complianceConfirmed?'Confirmed':'Not Confirmed'],
    ['Minimum Membership',`${Number(settings.minMembershipMonths||12)} months`],
    ['Active Member Required',settings.requireActiveMember?'Yes':'No'],
    ['Subscription Due Must Be Zero',settings.requireSubscriptionClear?'Yes':'No'],
    ['No Overdue Previous Loan',settings.requireNoOverdueLoan?'Yes':'No'],
    ['Committee Approval Required',settings.requireCommitteeApproval?'Yes':'No'],
    ['Guarantor Required',settings.guarantorRequired?'Yes':'Optional'],
    ['Permitted Charge / Interest',settings.permittedChargeEnabled?(settings.permittedChargeComplianceConfirmed?`Enabled · ${Number(settings.defaultChargeRate||0)}% default`:'Enabled but NOT compliance-confirmed'):'Disabled']
  ];
  $('#loanEligibilityPolicy').innerHTML=policyRows.map(x=>`<div class="metric"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')+
    (settings.complianceNote?`<div class="loan-policy-note"><b>Compliance Note</b><span>${esc(settings.complianceNote)}</span></div>`:'');

  $('#loanFundPosition').innerHTML=`
    <div class="metric"><span>Fund Head</span><b>${esc(p.fundHeadName||'Member Financial Assistance / Loan Fund')}</b></div>
    <div class="metric"><span>Policy Allocation</span><b>${Number(p.percent||0)}%</b></div>
    <div class="metric"><span>Current Earmarked Amount</span><b>${money(p.currentEarmarkedAmount||0)}</b></div>
    <div class="metric"><span>Current Loan Outstanding</span><b>${money(p.currentOutstanding||0)}</b></div>
    <div class="metric"><span>Policy Available</span><b>${money(p.policyAvailable||0)}</b></div>
    <small class="muted">Disbursement is principal movement, not Expense. Repayment is principal return, not Income.</small>`;

  $('#loanRows').innerHTML=(d.loans||[]).map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b><br><small>${esc(x.applicationDate||x.date||'')}</small></td>
      <td><b>${esc(x.memberName)}</b><br><small>${esc(x.memberId)}</small></td>
      <td>${x.disbursedAmount?money(x.disbursedAmount):x.sanctionedAmount?money(x.sanctionedAmount):'—'}</td>
      <td>${x.chargeAmount?`${money(x.chargeAmount)}<br><small>${Number(x.chargeRate||0)}%</small>`:'₹0'}</td>
      <td><b>${x.totalRepayable?money(x.totalRepayable):'—'}</b></td>
      <td>${x.installmentAmount?`${money(x.installmentAmount)}<br><small>${Number(x.repaymentPeriod||0)} mo.</small>`:'—'}</td>
      <td>${money(x.totalPaid||0)}</td>
      <td><b>${money(x.totalOutstanding||0)}</b></td>
      <td>${repaymentStatusBadge(x.repaymentStatus||'Current')}</td>
      <td>${loanStatusBadge(x.status)}</td>
      <td><button class="mini" onclick="viewLoanCase('${x.id}')">Open</button></td>
    </tr>`).join('')||'<tr><td colspan="11">No loan / financial assistance applications in this Financial Year.</td></tr>';
}
function openLoanPolicySettings(){
  const s=cache.loans?.settings||{};
  $('#loanPolicyForm').innerHTML=`
    <div class="full loan-legal-warning">
      <b>Compliance Gate</b>
      <p>This software does not determine whether member lending is lawful for an organization. Verify the registration type, Constitution/By-laws and applicable law/professional advice before giving the confirmations below. Without confirmation, Application, Sanction and Disbursement remain blocked.</p>
    </div>
    <label class="full declaration-check"><input type="checkbox" name="facilityEnabled" ${s.facilityEnabled?'checked':''}> Enable Member Loan / Financial Assistance facility</label>
    <label class="full declaration-check"><input type="checkbox" name="complianceConfirmed" ${s.complianceConfirmed?'checked':''}> I confirm that the governing documents / applicable rules authorize this member financial assistance/loan facility</label>
    <label class="full">Compliance / By-laws / Resolution Note<textarea name="complianceNote" placeholder="Registration / By-laws clause / committee resolution / professional advice reference">${esc(s.complianceNote||'')}</textarea></label>
    <label>Confirmed By<input name="confirmedBy" value="${esc(s.confirmedBy||cache.master?.ownerName||'')}"></label>
    <label>Minimum Membership (Months)<input type="number" min="0" name="minMembershipMonths" value="${Number(s.minMembershipMonths??12)}"></label>
    <label class="declaration-check"><input type="checkbox" name="requireActiveMember" ${s.requireActiveMember!==false?'checked':''}> Active Member required</label>
    <label class="declaration-check"><input type="checkbox" name="requireSubscriptionClear" ${s.requireSubscriptionClear!==false?'checked':''}> Subscription due must be zero</label>
    <label class="declaration-check"><input type="checkbox" name="requireNoOverdueLoan" ${s.requireNoOverdueLoan!==false?'checked':''}> No previous overdue loan</label>
    <label class="declaration-check"><input type="checkbox" name="requireCommitteeApproval" ${s.requireCommitteeApproval!==false?'checked':''}> Committee approval required</label>
    <label class="declaration-check"><input type="checkbox" name="guarantorRequired" ${s.guarantorRequired?'checked':''}> Guarantor mandatory</label>
    <h3 class="full section-title">Permitted Charge / Interest — Separate Compliance Gate</h3>
    <label class="full declaration-check"><input type="checkbox" name="permittedChargeEnabled" ${s.permittedChargeEnabled?'checked':''}> Enable the permitted charge / interest option</label>
    <label class="full declaration-check"><input type="checkbox" name="permittedChargeComplianceConfirmed" ${s.permittedChargeComplianceConfirmed?'checked':''}> I separately confirm that this charge/interest is permitted by law/by-laws</label>
    <label>Default Flat Charge / Interest Rate %<input type="number" min="0" step="0.01" name="defaultChargeRate" value="${Number(s.defaultChargeRate||0)}"></label>
    <label class="full">Charge / Interest Compliance Note<textarea name="permittedChargeNote" placeholder="Applicable clause / resolution / professional advice reference">${esc(s.permittedChargeNote||'')}</textarea></label>
    <div class="actions"><button class="btn primary">Save Loan Policy</button></div>`;
  $('#loanPolicyModal').classList.add('show');
  $('#loanPolicyForm').onsubmit=async e=>{
    e.preventDefault();
    const fd=new FormData(e.target);
    const data={
      facilityEnabled:e.target.facilityEnabled.checked,
      complianceConfirmed:e.target.complianceConfirmed.checked,
      complianceNote:fd.get('complianceNote')||'',
      confirmedBy:fd.get('confirmedBy')||'',
      minMembershipMonths:Number(fd.get('minMembershipMonths')||12),
      requireActiveMember:e.target.requireActiveMember.checked,
      requireSubscriptionClear:e.target.requireSubscriptionClear.checked,
      requireNoOverdueLoan:e.target.requireNoOverdueLoan.checked,
      requireCommitteeApproval:e.target.requireCommitteeApproval.checked,
      guarantorRequired:e.target.guarantorRequired.checked,
      permittedChargeEnabled:e.target.permittedChargeEnabled.checked,
      permittedChargeComplianceConfirmed:e.target.permittedChargeComplianceConfirmed.checked,
      permittedChargeNote:fd.get('permittedChargeNote')||'',
      defaultChargeRate:Number(fd.get('defaultChargeRate')||0)
    };
    try{
      await api('/api/loans/settings',{method:'POST',body:JSON.stringify(data)});
      closeLoanPolicySettings();toast('Loan compliance & eligibility policy saved');await loadAll();
    }catch(x){alert(x.message)}
  };
}
function closeLoanPolicySettings(){$('#loanPolicyModal').classList.remove('show')}

async function loanEligibilityHtml(memberId,date){
  if(!memberId)return '<div class="eligibility-empty">Select a member to check eligibility.</div>';
  try{
    const e=await api(`/api/loans/eligibility?memberId=${encodeURIComponent(memberId)}&date=${encodeURIComponent(date||dateToday())}`);
    return `<div class="loan-eligibility-result ${e.eligible?'eligible':'ineligible'}">
      <div class="eligibility-title"><b>${e.eligible?'✓ Eligible':'✕ Not Eligible'}</b><span>${esc(e.member.id)} - ${esc(e.member.name)}</span></div>
      <div class="eligibility-checks">${e.checks.map(c=>`<div class="${c.passed?'pass':'fail'}"><i>${c.passed?'✓':'✕'}</i><span><b>${esc(c.label)}</b><small>${esc(c.detail)}</small></span></div>`).join('')}</div>
    </div>`;
  }catch(e){return `<div class="eligibility-empty">${esc(e.message)}</div>`}
}
async function openLoanApplicationForm(){
  const settings=cache.loans?.settings||{};
  if(!settings.facilityEnabled || !settings.complianceConfirmed){
    alert('Loan/Financial Assistance facility is blocked. First complete Compliance & Eligibility Policy.');
    openLoanPolicySettings();return;
  }
  const members=cache.members.filter(x=>x.status==='Active'||!settings.requireActiveMember);
  if(!members.length)return alert('No eligible member available.');
  $('#loanApplicationForm').innerHTML=`
    <div class="full info-strip"><b>Workflow:</b> Applied → Verification → Committee Approval → Sanctioned → Disbursed → Repayment → Closed</div>
    <label>Member<select name="memberId" id="loanAppMember">${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Application Date<input type="date" name="applicationDate" id="loanAppDate" value="${dateToday()}" required></label>
    <div class="full" id="loanEligibilityPreview"></div>
    <label>Requested Amount<input type="number" step="0.01" name="requestedAmount" required></label>
    <label>Repayment Period<select name="repaymentPeriod"><option value="3">3 Months</option><option value="6">6 Months</option><option value="12" selected>12 Months</option><option value="18">18 Months</option><option value="24">24 Months</option><option value="36">36 Months</option></select></label>
    <label class="full">Purpose<textarea name="purpose" required placeholder="Member need / permitted financial assistance purpose"></textarea></label>
    <h3 class="full section-title">Guarantor ${settings.guarantorRequired?'(Required)':'(If required)'}</h3>
    <label>Guarantor Member ID<input name="guarantorMemberId" placeholder="Optional member ID"></label>
    <label>Guarantor Name<input name="guarantorName" ${settings.guarantorRequired?'required':''}></label>
    <label>Guarantor Mobile<input name="guarantorPhone"></label>
    <div class="actions"><button class="btn primary">Submit Loan Application</button></div>`;
  $('#loanApplicationModal').classList.add('show');
  const refresh=async()=>{$('#loanEligibilityPreview').innerHTML=await loanEligibilityHtml($('#loanAppMember').value,$('#loanAppDate').value)};
  $('#loanAppMember').onchange=refresh;$('#loanAppDate').onchange=refresh;await refresh();
  $('#loanApplicationForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.requestedAmount=Number(data.requestedAmount);data.repaymentPeriod=Number(data.repaymentPeriod);data.financialYear=activeFY;
    try{
      const loan=await api('/api/loans',{method:'POST',body:JSON.stringify(data)});
      closeLoanApplicationForm();toast(`Loan application ${loan.id} submitted`);await loadAll();await viewLoanCase(loan.id);
    }catch(x){alert(x.message)}
  };
}
function closeLoanApplicationForm(){$('#loanApplicationModal').classList.remove('show')}

async function viewLoanCase(id){
  try{
    const l=await api(`/api/loans/${encodeURIComponent(id)}`);
    const history=(l.history||[]).slice().reverse();
    $('#loanViewBody').innerHTML=`
      <div class="loan-view-head">
        <div>
          <span class="member-id-chip">${esc(l.id)}</span>
          <h2>${esc(l.memberName)}</h2>
          <p>${esc(l.memberId)} · ${loanStatusBadge(l.status)}</p>
        </div>
        <div class="head-actions">${loanPrimaryActions(l)}</div>
      </div>

      ${l.rejectionReason?`<div class="rejection-box"><b>Rejection Reason:</b> ${esc(l.rejectionReason)}</div>`:''}

      <div class="profile-summary-grid loan-repayment-summary">
        <div class="profile-stat"><span>Principal</span><b>${money(l.disbursedAmount||l.sanctionedAmount||0)}</b><small>Sanctioned / Disbursed principal</small></div>
        <div class="profile-stat"><span>Permitted Charge / Interest</span><b>${money(l.chargeAmount||0)}</b><small>${Number(l.chargeRate||0)}% flat · only if permitted</small></div>
        <div class="profile-stat"><span>Total Repayable</span><b>${money(l.totalRepayable||0)}</b><small>${Number(l.repaymentPeriod||0)} installment(s)</small></div>
        <div class="profile-stat"><span>Installment</span><b>${money(l.installmentAmount||0)}</b><small>Last installment may adjust rounding</small></div>
        <div class="profile-stat"><span>Total Paid</span><b>${money(l.totalPaid||0)}</b><small>Principal ${money(l.principalRepaid||0)} · Charge ${money(l.chargeRepaid||0)}</small></div>
        <div class="profile-stat"><span>Total Outstanding</span><b>${money(l.totalOutstanding||0)}</b><small>${repaymentStatusBadge(l.repaymentStatus||'Current')} · Maturity ${esc(fmtDate(l.maturityDate||'—'))}</small></div>
      </div>

      <div class="profile-detail-grid">
        ${detail('Purpose',l.purpose,'full')}
        ${detail('Guarantor Member ID',l.guarantorMemberId)}
        ${detail('Guarantor Name',l.guarantorName)}
        ${detail('Guarantor Mobile',l.guarantorPhone)}
        ${l.verifiedBy?detail('Verified By',l.verifiedBy):''}
        ${l.verificationNotes?detail('Verification Notes',l.verificationNotes,'full'):''}
        ${l.approvedBy?detail('Approved By / Committee',l.approvedBy):''}
        ${l.resolutionNo?detail('Approval Resolution',`${l.resolutionNo} - ${l.resolutionTitle||''}`):''}
        ${l.approvalSnapshot?detail('Financial Approval',`${l.approvalSnapshot.policyName} Rev ${l.approvalSnapshot.policyRevision} · ${l.approvalSnapshot.rangeText}`):''}
        ${l.committeeNotes?detail('Committee Notes',l.committeeNotes,'full'):''}
        ${l.disbursementMode?detail('Disbursement Mode',l.disbursementMode):''}
        ${l.disbursementReference?detail('Disbursement Reference',l.disbursementReference):''}
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Eligibility Snapshot at Application</h3><p>Eligibility check at the time the application is submitted.</p></div></div>
        <div class="eligibility-checks">${(l.eligibilitySnapshot?.checks||[]).map(c=>`<div class="${c.passed?'pass':'fail'}"><i>${c.passed?'✓':'✕'}</i><span><b>${esc(c.label)}</b><small>${esc(c.detail)}</small></span></div>`).join('')||'<div>No eligibility snapshot available.</div>'}</div>
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Supporting Documents</h3><p>Application, guarantor, purpose/need proof and committee reference.</p></div>
        ${!['Closed','Rejected'].includes(l.status)?`<button class="mini" onclick="uploadLoanDocument('${l.id}')">+ Upload Document</button>`:''}</div>
        ${!['Closed','Rejected'].includes(l.status)?`<div class="loan-doc-upload"><select id="loanDocType"><option>Supporting Document</option><option>Application Form</option><option>Guarantor Document</option><option>Need / Purpose Proof</option><option>Identity Document</option><option>Committee Resolution</option><option>Other Document</option></select><input id="loanDocName" placeholder="Document display name"><input id="loanDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></div>`:''}
        <div class="document-list">${(l.documents||[]).map(d=>`
          <div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB</small></div>
          <a class="mini" href="${esc(d.path)}" target="_blank">Open</a>
          ${!['Closed','Rejected'].includes(l.status)?`<button class="mini danger" onclick="deleteLoanDocument('${l.id}','${d.id}')">Delete</button>`:''}</div>`).join('')||'<div class="empty-docs">No supporting documents uploaded.</div>'}
        </div>
      </div>

      <div class="approval-panel">
        <h3>Loan Approval Workflow</h3>
        <div class="workflow-actions">${loanWorkflowActions(l)}</div>
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Installment Payment Receipts</h3><p>Principal component is principal return; legally permitted charge/interest component is separately recognized as Income without double-posting Cash/Bank.</p></div></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Receipt No.</th><th>Date</th><th>Total Paid</th><th>Principal</th><th>Charge / Interest</th><th>Mode</th><th>Reference</th><th>Receipt</th></tr></thead><tbody>
          ${(l.repayments||[]).map(r=>`<tr><td><b>${esc(r.id)}</b></td><td>${esc(fmtDate(r.date))}</td><td>${money(r.amount)}</td><td>${money(r.principalComponent||0)}</td><td>${money(r.chargeComponent||0)}</td><td>${esc(r.mode)}</td><td>${esc(r.reference||'—')}</td><td><button class="mini" onclick="printLoanRepayment('${l.id}','${r.id}')">Receipt</button></td></tr>`).join('')||'<tr><td colspan="8">No repayments yet.</td></tr>'}
        </tbody></table></div>
      </div>

      <div class="timeline-block">
        <h3>Case History</h3>
        ${history.map(h=>`<div class="timeline-item"><span></span><div><b>${esc(h.status)}</b><small>${esc(h.note||'')} · ${fmtDateTime(h.at)}</small></div></div>`).join('')}
      </div>`;
    $('#loanViewModal').classList.add('show');
  }catch(e){alert(e.message)}
}
function loanPrimaryActions(l){
  if(l.status==='Sanctioned')return `<button class="btn primary" onclick="openLoanDisbursement('${l.id}')">Disburse</button>`;
  if(['Disbursed','Repayment'].includes(l.status) && Number(l.outstanding||0)>0)return `<button class="btn primary" onclick="openLoanRepayment('${l.id}')">Receive Repayment</button>`;
  return '';
}
function loanWorkflowActions(l){
  if(l.status==='Applied')return `<button class="btn primary" onclick="changeLoanStatus('${l.id}','Verification')">Start Verification</button><button class="btn reject" onclick="rejectLoan('${l.id}')">Reject</button>`;
  if(l.status==='Verification')return `<button class="btn primary" onclick="changeLoanStatus('${l.id}','Committee Approval')">Send to Committee Approval</button><button class="btn reject" onclick="rejectLoan('${l.id}')">Reject</button>`;
  if(l.status==='Committee Approval')return `<button class="btn primary" onclick="sanctionLoan('${l.id}',${Number(l.requestedAmount||0)})">Sanction Loan</button><button class="btn reject" onclick="rejectLoan('${l.id}')">Reject</button>`;
  if(l.status==='Sanctioned')return `<div class="success-box">✓ Sanctioned ${money(l.sanctionedAmount)} by ${esc(l.approvedBy||'Committee')}.</div><button class="btn primary" onclick="openLoanDisbursement('${l.id}')">Disburse</button>`;
  if(l.status==='Disbursed')return `<div class="success-box">✓ Loan disbursed. Repayment can now be received.</div>`;
  if(l.status==='Repayment')return `<div class="success-box">Repayment in progress · Outstanding ${money(l.outstanding||0)}.</div>`;
  if(l.status==='Closed')return `<div class="success-box">✓ Loan fully repaid and closed.</div>`;
  if(l.status==='Rejected')return `<div class="rejection-box">Application rejected. Reason and history retained.</div>`;
  return '';
}
async function changeLoanStatus(id,status){
  let actionBy='',notes='';
  if(status==='Verification'){
    actionBy=prompt('Verification started by:',cache.master?.ownerName||'')||'';
    notes=prompt('Verification note (optional):','Eligibility and supporting documents to be verified.')||'';
  }
  if(status==='Committee Approval'){
    actionBy=prompt('Verified by:',cache.master?.ownerName||'')||'';
    notes=prompt('Verification findings / note:','Eligibility and documents verified; placed before committee.')||'';
  }
  try{
    await api(`/api/loans/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status,actionBy,notes})});
    toast(status);await loadAll();await viewLoanCase(id);
  }catch(e){alert(e.message)}
}
async function sanctionLoan(id,requested){
  const sanctionedAmount=prompt(`Sanctioned Principal Amount (maximum ${requested}):`,String(requested));if(sanctionedAmount===null)return;
  const settings=cache.loans?.settings||{};
  const defaultRate=settings.permittedChargeEnabled&&settings.permittedChargeComplianceConfirmed?Number(settings.defaultChargeRate||0):0;
  const chargeRate=prompt('Permitted Flat Charge / Interest Rate % (enter 0 if not applicable):',String(defaultRate));if(chargeRate===null)return;
  if(Number(chargeRate)>0 && (!settings.permittedChargeEnabled || !settings.permittedChargeComplianceConfirmed)){
    return alert('Permitted charge / interest is not compliance-confirmed in Loan Policy Settings.');
  }
  let approvalData={sanctionedAmount:Number(sanctionedAmount),sanctionDate:dateToday(),resolutionId:''};
  approvalData=await applyFinancialApprovalPrompt(approvalData,'LoanSanction','sanctionedAmount','sanctionDate');if(!approvalData)return;
  const approvedBy=prompt('Approved By / Committee Note:',cache.master?.ownerName||'');if(approvedBy===null)return;
  const notes=prompt('Committee approval / sanction note:','Approved by committee subject to governing rules.')||'';
  try{
    await api(`/api/loans/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({
      status:'Sanctioned',sanctionedAmount:Number(sanctionedAmount),chargeRate:Number(chargeRate||0),approvedBy,notes,sanctionDate:dateToday(),
      resolutionId:approvalData.resolutionId||'',approvals:approvalData.approvals||{}
    })});
    toast('Loan sanctioned');await loadAll();await viewLoanCase(id);
  }catch(e){alert(e.message)}
}
async function rejectLoan(id){
  const reason=prompt('Rejection reason (mandatory):','');if(reason===null)return;
  if(!reason.trim())return alert('Rejection reason is mandatory.');
  try{
    await api(`/api/loans/${encodeURIComponent(id)}/status`,{method:'POST',body:JSON.stringify({status:'Rejected',reason})});
    toast('Loan application rejected');await loadAll();await viewLoanCase(id);
  }catch(e){alert(e.message)}
}
async function uploadLoanDocument(id){
  const f=$('#loanDocFile')?.files?.[0];if(!f)return alert('Select a supporting document.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/loans/${encodeURIComponent(id)}/document`,{method:'POST',body:JSON.stringify({
      filename:f.name,dataUrl,documentType:$('#loanDocType').value,displayName:$('#loanDocName').value||f.name
    })});
    toast('Loan document uploaded');await loadAll();await viewLoanCase(id);
  }catch(e){alert(e.message)}
}
async function deleteLoanDocument(loanId,docId){
  if(!confirm('Delete this supporting document?'))return;
  try{
    await api(`/api/loans/${encodeURIComponent(loanId)}/documents/${encodeURIComponent(docId)}`,{method:'DELETE'});
    toast('Document deleted');await loadAll();await viewLoanCase(loanId);
  }catch(e){alert(e.message)}
}
function closeLoanView(){$('#loanViewModal').classList.remove('show')}

function openLoanDisbursement(id){
  const l=cache.loans?.loans?.find(x=>x.id===id);if(!l)return alert('Loan not found.');
  const cb=cache.cashbank;
  $('#loanDisbursementForm').innerHTML=`
    <div class="full info-strip"><b>${esc(l.id)} · ${esc(l.memberName)}</b><br>Sanctioned: ${money(l.sanctionedAmount)} · Period: ${Number(l.repaymentPeriod)} months</div>
    <label>Disbursement Amount<input type="number" name="amount" value="${Number(l.sanctionedAmount||0)}" readonly></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Payment Mode<select name="mode"><option>Bank Transfer</option><option>UPI</option><option>Cash</option><option>Cheque</option></select></label>
    <label>Reference / UTR / Cheque No.<input name="reference"></label>
    <div class="full loan-account-position">Cash ${money(cb?.summary?.cashBalance||0)} · Bank ${money(cb?.summary?.bankBalance||0)} · UPI ${money(cb?.summary?.upiBalance||0)} · Loan Fund Policy Available ${money(cache.loans?.policy?.policyAvailable||0)}</div>
    <div class="full loan-principal-note"><b>Accounting:</b> Disbursement is an outflow in the Cash/Bank/UPI ledger, but it is not counted as an Expense.</div>
    <div class="actions"><button class="btn primary">Confirm Disbursement</button></div>`;
  $('#loanDisbursementModal').classList.add('show');
  $('#loanDisbursementForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));data.amount=Number(data.amount);
    try{
      await api(`/api/loans/${encodeURIComponent(id)}/disburse`,{method:'POST',body:JSON.stringify(data)});
      closeLoanDisbursement();toast('Loan disbursed');await loadAll();await viewLoanCase(id);
    }catch(x){alert(x.message)}
  };
}
function closeLoanDisbursement(){$('#loanDisbursementModal').classList.remove('show')}

function openLoanRepayment(id){
  const l=cache.loans?.loans?.find(x=>x.id===id);if(!l)return alert('Loan not found.');
  const outstanding=Number(l.totalOutstanding||Math.max(0,Number(l.totalRepayable||0)-Number(l.totalPaid||0)));
  $('#loanRepaymentForm').innerHTML=`
    <div class="full info-strip"><b>${esc(l.id)} · ${esc(l.memberName)}</b><br>Total Repayable ${money(l.totalRepayable||0)} · Paid ${money(l.totalPaid||0)} · Outstanding ${money(outstanding)} · ${repaymentStatusBadge(l.repaymentStatus||'Current')}</div>
    <label>Installment / Repayment Amount<input type="number" step="0.01" name="amount" max="${outstanding}" value="${Math.min(outstanding,Number(l.installmentAmount||0))||''}" required></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Reference / UTR<input name="reference"></label>
    <label class="full">Remarks<textarea name="remarks"></textarea></label>
    <div class="full loan-principal-note"><b>Accounting:</b> The principal portion is not Income. If a charge/interest is legally permitted, only that component goes to Income Management; the payment is posted once in the Cash/Bank ledger.</div>
    <div class="actions"><button class="btn primary">Receive Repayment</button></div>`;
  $('#loanRepaymentModal').classList.add('show');
  $('#loanRepaymentForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));data.amount=Number(data.amount);
    try{
      const r=await api(`/api/loans/${encodeURIComponent(id)}/repay`,{method:'POST',body:JSON.stringify(data)});
      closeLoanRepayment();toast(`Repayment ${r.repayment.id} saved`);await loadAll();await viewLoanCase(id);
    }catch(x){alert(x.message)}
  };
}
function closeLoanRepayment(){$('#loanRepaymentModal').classList.remove('show')}

async function printLoanRepayment(loanId,repaymentId){
  try{
    const l=await api(`/api/loans/${encodeURIComponent(loanId)}`);
    const r=(l.repayments||[]).find(x=>x.id===repaymentId);if(!r)return alert('Repayment receipt not found.');
    const org=cache.master||{};
    const w=window.open('','_blank','width=800,height=720');
    const logo=org.logoPath?`<img src="${esc(org.logoPath)}" style="max-height:65px;max-width:100px;object-fit:contain">`:'';
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(r.id)}</title><style>
    body{font-family:Arial,sans-serif;padding:30px}.box{max-width:700px;margin:auto;border:2px solid #111;padding:24px}.head{display:flex;gap:16px;align-items:center;border-bottom:2px solid #111;padding-bottom:12px}.head h1{font-size:21px;margin:0}.head p{margin:4px 0;font-size:12px}.title{text-align:center;font-weight:bold;font-size:18px;margin:18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.row{padding:8px 0;border-bottom:1px dotted #aaa}.row b{display:block;font-size:11px;color:#555;text-transform:uppercase;margin-bottom:4px}.amt{font-size:22px;font-weight:bold}.foot{display:flex;justify-content:space-between;margin-top:40px}.sig{border-top:1px solid #111;min-width:170px;text-align:center;padding-top:6px;font-size:12px}@media print{button{display:none}}</style></head><body><div class="box">
    <div class="head">${logo}<div><h1>${esc(org.organizationName||'Organization')}</h1><p>${esc(org.registeredAddress||org.officeAddress||'')}</p></div></div>
    <div class="title">LOAN REPAYMENT RECEIPT</div><div class="grid">
    <div class="row"><b>Repayment No.</b>${esc(r.id)}</div><div class="row"><b>Date</b>${esc(fmtDate(r.date))}</div>
    <div class="row"><b>Loan Application No.</b>${esc(l.id)}</div><div class="row"><b>Member</b>${esc(l.memberId)} - ${esc(l.memberName)}</div>
    <div class="row"><b>Payment Mode</b>${esc(r.mode)}</div><div class="row"><b>Reference</b>${esc(r.reference||'—')}</div>
    <div class="row"><b>Principal Component</b>${money(r.principalComponent||0)}</div><div class="row"><b>Permitted Charge / Interest</b>${money(r.chargeComponent||0)}</div>
    <div class="row" style="grid-column:1/-1"><b>Total Amount Received</b><span class="amt">${money(r.amount)}</span></div>
    <div class="row"><b>Total Repayable</b>${money(l.totalRepayable||0)}</div><div class="row"><b>Outstanding After Current Ledger</b>${money(l.totalOutstanding||0)}</div>
    <div class="row" style="grid-column:1/-1"><b>Remarks</b>${esc(r.remarks||'Installment / repayment received')}</div></div>
    <div class="foot"><span>Computer Generated Receipt</span><div class="sig">Authorized Signature</div></div></div>
    <div style="text-align:center;margin-top:15px"><button onclick="window.print()">Print Receipt</button></div></body></html>`);
    w.document.close();
  }catch(e){alert(e.message)}
}

function renderFunds(){
  const d=cache.funds;if(!d)return;
  const available=Number(d.availableFund||0);
  $('#fundPolicyFY').textContent=activeFY;
  $('#fundPolicyStats').innerHTML=[
    ['AVAILABLE FUND',money(available),'Cash + Bank + UPI / Other'],
    ['TOTAL ALLOCATION',`${Number(d.totalPercent||0).toFixed(2).replace(/\.00$/,'')}%`,d.valid?'Valid policy':'Must equal 100%'],
    ['FUND HEADS',(d.allocations||[]).length,'Editable by Admin / Committee'],
    ['UNALLOCATED / EXCESS',money(available*(100-Number(d.totalPercent||0))/100),d.valid?'₹0 when policy is valid':'Adjust percentages']
  ].map(x=>`<div class="fund-policy-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#fundPolicyRows').innerHTML=(d.allocations||[]).map((x,i)=>fundPolicyRowHtml(x,i,available)).join('');
  const fr=$('#fundResolutionSelect');
  if(fr)fr.innerHTML=usableResolutionOptions('Fund Allocation Change',d.resolution?.id||'');
  updateFundPolicyTotals();
}
function fundPolicyRowHtml(x,i,available){
  return `<tr data-fund-id="${esc(x.id||'')}">
    <td><input class="fund-name-input" value="${esc(x.name||'')}" placeholder="Fund / Reserve Name"></td>
    <td><div class="percent-input-wrap"><input class="fund-percent-input" type="number" min="0" max="100" step="0.01" value="${Number(x.percent||0)}" oninput="updateFundPolicyTotals()"><span>%</span></div></td>
    <td class="fund-allocated-amount">${money(available*Number(x.percent||0)/100)}</td>
    <td><input class="fund-notes-input" value="${esc(x.notes||'')}" placeholder="Resolution / policy note"></td>
    <td><button class="mini danger" onclick="removeFundPolicyRow(this)">Remove</button></td>
  </tr>`;
}
function updateFundPolicyTotals(){
  const rows=[...document.querySelectorAll('#fundPolicyRows tr')];
  const available=Number(cache.funds?.availableFund||0);
  let total=0;
  rows.forEach(tr=>{
    const pct=Number(tr.querySelector('.fund-percent-input')?.value||0);
    total+=pct;
    const amount=tr.querySelector('.fund-allocated-amount');
    if(amount) amount.textContent=money(available*pct/100);
  });
  $('#fundPolicyTotal').textContent=`${Number(total.toFixed(2))}%`;
  $('#fundPolicyAmountTotal').textContent=money(available*total/100);
  const valid=Math.abs(total-100)<0.0001;
  $('#fundPolicyValidation').innerHTML=valid
    ? '<span class="allocation-valid">✓ Allocation valid — Total 100%</span>'
    : `<span class="allocation-invalid">⚠ Total must be 100% — currently ${Number(total.toFixed(2))}%</span>`;
  const stats=$('#fundPolicyStats');
  if(stats){
    const cards=stats.querySelectorAll('.fund-policy-stat');
    if(cards[1]){
      cards[1].querySelector('b').textContent=`${Number(total.toFixed(2))}%`;
      cards[1].querySelector('small').textContent=valid?'Valid policy':'Must equal 100%';
    }
    if(cards[3]){
      cards[3].querySelector('b').textContent=money(available*(100-total)/100);
      cards[3].querySelector('small').textContent=valid?'₹0 when policy is valid':'Adjust percentages';
    }
  }
  return {total,valid};
}
function addFundPolicyRow(){
  const tbody=$('#fundPolicyRows');
  const idx=tbody.querySelectorAll('tr').length;
  tbody.insertAdjacentHTML('beforeend',fundPolicyRowHtml({id:'',name:'',percent:0,notes:''},idx,Number(cache.funds?.availableFund||0)));
  updateFundPolicyTotals();
}
function removeFundPolicyRow(btn){
  const row=btn.closest('tr');
  if(document.querySelectorAll('#fundPolicyRows tr').length<=1)return alert('At least one fund head is required.');
  row.remove();updateFundPolicyTotals();
}
async function saveFundPolicy(){
  const check=updateFundPolicyTotals();
  if(!check.valid)return alert(`Total Allocation must be exactly 100%. Current total: ${Number(check.total.toFixed(2))}%`);
  const allocations=[...document.querySelectorAll('#fundPolicyRows tr')].map(tr=>({
    id:tr.dataset.fundId||'',
    name:tr.querySelector('.fund-name-input').value.trim(),
    percent:Number(tr.querySelector('.fund-percent-input').value||0),
    notes:tr.querySelector('.fund-notes-input').value.trim()
  }));
  if(allocations.some(x=>!x.name))return alert('Every fund/reserve must have a name.');
  try{
    await api(fyUrl('/api/funds'),{method:'POST',body:JSON.stringify({allocations,resolutionId:$('#fundResolutionSelect')?.value||''})});
    toast('Fund Allocation Policy saved at 100%');await loadAll();
  }catch(e){alert(e.message)}
}
async function resetFundPolicy(){
  if(!confirm(`Reset FY ${activeFY} allocation to the default 100% structure?`))return;
  try{
    await api(fyUrl('/api/funds/reset'),{method:'POST'});
    toast('Default Fund Allocation restored');await loadAll();
  }catch(e){alert(e.message)}
}
function eventStatusBadge(status){
  const cls=String(status||'Planned').toLowerCase();
  return `<span class="event-status-badge ${cls}">${esc(status||'Planned')}</span>`;
}
function renderEvents(){
  const d=cache.events;if(!d)return;
  const s=d.summary||{};
  $('#eventProjectStats').innerHTML=[
    ['TOTAL EVENTS',s.totalEvents||0,`Planned ${s.planned||0} · Ongoing ${s.ongoing||0}`],
    ['TOTAL BUDGET',money(s.totalBudget||0),`FY ${activeFY}`],
    ['TOTAL INCOME',money(s.totalIncome||0),'Event-linked income'],
    ['TOTAL EXPENSE',money(s.totalExpense||0),'Event-linked expense'],
    ['NET BALANCE',money(s.netBalance||0),Number(s.netBalance||0)>=0?'Surplus':'Deficit'],
    ['COMPLETED',s.completed||0,'Closed events/projects']
  ].map(x=>`<div class="event-project-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#eventProjectRows').innerHTML=(d.events||[]).map(e=>{
    const b=e.summary||{};
    return `<tr>
      <td><b>${esc(e.id)}</b></td>
      <td><b>${esc(e.name)}</b><br><small>${esc(e.venue||'')}</small></td>
      <td>${esc(e.startDate||'')}${e.endDate&&e.endDate!==e.startDate?` → ${esc(fmtDate(e.endDate))}`:''}</td>
      <td>${money(e.budget||0)}</td>
      <td><b>${money(b.totalIncome||0)}</b></td>
      <td><b>${money(b.totalExpense||0)}</b></td>
      <td><b class="${Number(b.finalBalance||0)<0?'negative-balance':'positive-balance'}">${money(b.finalBalance||0)}</b></td>
      <td>${b.participants||0}</td><td>${b.vendors||0}</td>
      <td>${eventStatusBadge(e.status)}</td>
      <td><button class="mini" onclick="viewEventProject('${e.id}')">Open</button></td>
    </tr>`;
  }).join('')||'<tr><td colspan="11">No events/projects in this Financial Year.</td></tr>';
}
function openEventForm(){
  $('#eventForm').innerHTML=`
    <label>Event / Project Name<input name="name" required placeholder="Annual VLE Meet 2027"></label>
    <label>Status<select name="status"><option>Planned</option><option>Ongoing</option><option>Completed</option><option>Cancelled</option></select></label>
    <label>Start Date<input type="date" name="startDate" value="${dateToday()}" required></label>
    <label>End Date<input type="date" name="endDate" value="${dateToday()}"></label>
    <label>Event Budget<input type="number" step="0.01" name="budget" value="0"></label>
    <label>Venue<input name="venue"></label>
    <label>Registration Capacity<input type="number" min="0" name="capacity" value="0"><small>0 = unlimited</small></label>
    <label>Registration Deadline<input type="date" name="registrationDeadline"></label>
    <label class="declaration-check"><input type="checkbox" name="registrationOpen"> Member Portal Registration Open</label>
    <label class="full">Description / Objective<textarea name="description"></textarea></label>
    <div class="actions"><button class="btn primary">Create Event / Project</button></div>`;
  $('#eventFormModal').classList.add('show');
  $('#eventForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.budget=Number(data.budget||0);data.capacity=Number(data.capacity||0);data.registrationOpen=e.target.registrationOpen.checked;data.financialYear=activeFY;
    try{
      const evt=await api('/api/events',{method:'POST',body:JSON.stringify(data)});
      closeEventForm();toast(`Event ${evt.id} created`);await loadAll();await viewEventProject(evt.id);
    }catch(x){alert(x.message)}
  };
}
function closeEventForm(){$('#eventFormModal').classList.remove('show')}

async function viewEventProject(id){
  try{
    const e=await api(`/api/events/${encodeURIComponent(id)}`);
    const s=e.summary||{};
    $('#eventViewBody').innerHTML=`
      <div class="event-project-head">
        <div>
          <span class="member-id-chip">${esc(e.id)}</span>
          <h2>${esc(e.name)}</h2>
          <p>${esc(fmtDate(e.startDate))}${e.endDate&&e.endDate!==e.startDate?` → ${esc(fmtDate(e.endDate))}`:''} · ${esc(e.venue||'No venue')} · ${eventStatusBadge(e.status)}</p>
        </div>
        <div class="head-actions">
          <button class="btn" onclick="editEventProject('${e.id}')">Edit</button>
          <button class="btn primary" onclick="openEventIncome('${e.id}')">+ Income</button>
          <button class="btn primary" onclick="openEventExpense('${e.id}')">+ Expense</button>
        </div>
      </div>

      <div class="event-financial-summary">
        <div><span>Event Budget</span><b>${money(e.budget||0)}</b><small>Budget left / variance ${money(s.budgetVariance||0)}</small></div>
        <div><span>Total Income</span><b>${money(s.totalIncome||0)}</b><small>All event-linked receipts/vouchers</small></div>
        <div><span>Total Expense</span><b>${money(s.totalExpense||0)}</b><small>All event-linked expense vouchers</small></div>
        <div class="${Number(s.finalBalance||0)<0?'deficit':'surplus'}"><span>Final Balance</span><b>${money(s.finalBalance||0)}</b><small>${Number(s.finalBalance||0)>=0?'Surplus':'Deficit'}</small></div>
      </div>

      <div class="event-income-breakdown">
        <div><span>Collection</span><b>${money(s.collection||0)}</b></div>
        <div><span>Donation</span><b>${money(s.donation||0)}</b></div>
        <div><span>Sponsorship</span><b>${money(s.sponsorship||0)}</b></div>
        <div><span>Member Contribution</span><b>${money(s.memberContribution||0)}</b></div>
      </div>

      <div class="profile-detail-grid">
        ${detail('Venue',e.venue)}
        ${detail('Financial Year',e.financialYear)}
        ${detail('Status',e.status)}
        ${detail('Budget',money(e.budget||0))}
        ${detail('Registration',e.registrationOpen?`Open · ${(e.registrations||[]).filter(r=>r.status!=='Cancelled').length}${e.capacity?' / '+e.capacity:''}${e.registrationDeadline?' · Deadline '+e.registrationDeadline:''}`:'Closed')}
        ${detail('Description / Objective',e.description,'full')}
      </div>

      <div class="event-tabs">
        <button class="active" onclick="switchEventTab(this,'event-finance-tab')">Finance</button>
        <button onclick="switchEventTab(this,'event-participants-tab')">Participants (${(e.participants||[]).length})</button>
        <button onclick="switchEventTab(this,'event-registrations-tab')">Registrations (${(e.registrations||[]).filter(r=>r.status!=='Cancelled').length})</button>
        <button onclick="switchEventTab(this,'event-vendors-tab')">Vendors (${(e.vendors||[]).length})</button>
        <button onclick="switchEventTab(this,'event-documents-tab')">Photos / Documents (${(e.documents||[]).length})</button>
      </div>

      <div id="event-finance-tab" class="event-tab-panel active">
        <div class="two event-ledger-two">
          <div class="profile-ledger-block">
            <div class="profile-block-head"><div><h3>Event Income Ledger</h3></div><button class="mini" onclick="openEventIncome('${e.id}')">+ Income</button></div>
            <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Receipt/Voucher</th><th>Date</th><th>Type</th><th>Source</th><th>Mode</th><th>Amount</th><th>Action</th></tr></thead><tbody>
            ${(e.incomes||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td><td>${esc(x.type)}</td><td>${esc(x.source)}</td><td>${esc(x.mode)}</td><td>${money(x.amount)}</td><td>${x.recordType==='Receipt'?`<button class="mini" onclick="printReceipt('${x.id}')">Receipt</button>`:'Voucher'}</td></tr>`).join('')||'<tr><td colspan="7">No event income.</td></tr>'}
            </tbody></table></div>
          </div>
          <div class="profile-ledger-block">
            <div class="profile-block-head"><div><h3>Event Expense Ledger</h3></div><button class="mini" onclick="openEventExpense('${e.id}')">+ Expense</button></div>
            <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Voucher</th><th>Date</th><th>Paid To</th><th>Purpose</th><th>Amount</th><th>Bill</th></tr></thead><tbody>
            ${(e.expenses||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td><td>${esc(x.paidTo)}</td><td>${esc(x.purpose)}</td><td>${money(x.amount)}</td><td>${x.billPath?`<a class="mini bill-link" href="${esc(x.billPath)}" target="_blank">Open</a>`:'—'}</td></tr>`).join('')||'<tr><td colspan="6">No event expenses.</td></tr>'}
            </tbody></table></div>
          </div>
        </div>
        <div class="event-final-box ${Number(s.finalBalance||0)<0?'deficit':'surplus'}">
          <span>Total Income</span><b>${money(s.totalIncome||0)}</b><i>−</i><span>Total Expense</span><b>${money(s.totalExpense||0)}</b><i>=</i><span>${Number(s.finalBalance||0)>=0?'Surplus':'Deficit'}</span><strong>${money(s.finalBalance||0)}</strong>
        </div>
      </div>

      <div id="event-participants-tab" class="event-tab-panel">
        <div class="profile-block-head"><div><h3>Participants</h3></div><button class="mini" onclick="addEventParticipant('${e.id}')">+ Participant</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Name</th><th>Member ID</th><th>Mobile</th><th>Role</th><th>Notes</th><th></th></tr></thead><tbody>
        ${(e.participants||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.memberId||'—')}</td><td>${esc(x.mobile||'—')}</td><td>${esc(x.role||'Participant')}</td><td>${esc(x.notes||'—')}</td><td><button class="mini danger" onclick="deleteEventParticipant('${e.id}','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6">No participants added.</td></tr>'}
        </tbody></table></div>
      </div>

      <div id="event-registrations-tab" class="event-tab-panel">
        <div class="profile-block-head"><div><h3>Event Registrations</h3><p>Member Portal / admin registration list.</p></div><button class="mini" onclick="addEventRegistration('${e.id}')">+ Register Member</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Registration No.</th><th>Member</th><th>Phone</th><th>Date</th><th>Source</th><th>Status</th><th>Action</th></tr></thead><tbody>
        ${(e.registrations||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.memberId)} - ${esc(x.memberName)}</td><td>${esc(x.phone||'—')}</td><td>${esc(x.date||'')}</td><td>${esc(x.source||'')}</td><td>${badge(x.status)}</td><td>${x.status==='Registered'?`<button class="mini" onclick="updateEventRegistration('${e.id}','${x.id}','Attended')">Mark Attended</button><button class="mini danger" onclick="updateEventRegistration('${e.id}','${x.id}','Cancelled')">Cancel</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="7">No registrations.</td></tr>'}
        </tbody></table></div>
      </div>

      <div id="event-vendors-tab" class="event-tab-panel">
        <div class="profile-block-head"><div><h3>Vendors / Service Providers</h3></div><button class="mini" onclick="addEventVendor('${e.id}')">+ Vendor</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Vendor</th><th>Mobile</th><th>Service</th><th>Contract Amount</th><th>Notes</th><th></th></tr></thead><tbody>
        ${(e.vendors||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.mobile||'—')}</td><td>${esc(x.service||'—')}</td><td>${money(x.contractAmount||0)}</td><td>${esc(x.notes||'—')}</td><td><button class="mini danger" onclick="deleteEventVendor('${e.id}','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6">No vendors added.</td></tr>'}
        </tbody></table></div>
      </div>

      <div id="event-documents-tab" class="event-tab-panel">
        <div class="profile-block-head"><div><h3>Photos / Documents</h3><p>Event photos, permission, quotation, report, invitation or other files.</p></div><button class="mini" onclick="uploadEventDocument('${e.id}')">+ Upload</button></div>
        <div class="event-doc-upload"><select id="eventDocType"><option>Event Photo</option><option>Permission / Approval</option><option>Quotation</option><option>Invitation / Poster</option><option>Event Report</option><option>Other Document</option></select><input id="eventDocName" placeholder="Display name"><input id="eventDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></div>
        <div class="document-list">${(e.documents||[]).map(d=>`<div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB</small></div><a class="mini" href="${esc(d.path)}" target="_blank">Open</a><button class="mini danger" onclick="deleteEventDocument('${e.id}','${d.id}')">Delete</button></div>`).join('')||'<div class="empty-docs">No event photos/documents uploaded.</div>'}</div>
      </div>`;
    $('#eventViewModal').classList.add('show');
  }catch(err){alert(err.message)}
}
function switchEventTab(btn,id){
  const modal=$('#eventViewBody');
  modal.querySelectorAll('.event-tabs button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
  modal.querySelectorAll('.event-tab-panel').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');
}
function closeEventView(){$('#eventViewModal').classList.remove('show')}

async function editEventProject(id){
  const e=await api(`/api/events/${encodeURIComponent(id)}`);
  const name=prompt('Event / Project Name:',e.name);if(name===null)return;
  const budget=prompt('Event Budget:',String(e.budget||0));if(budget===null)return;
  const status=prompt('Status: Planned / Ongoing / Completed / Cancelled',e.status);if(status===null)return;
  const venue=prompt('Venue:',e.venue||'');if(venue===null)return;
  const capacity=prompt('Registration Capacity (0 = unlimited):',String(e.capacity||0));if(capacity===null)return;
  const registrationDeadline=prompt('Registration Deadline (YYYY-MM-DD, blank if none):',e.registrationDeadline||'');if(registrationDeadline===null)return;
  const registrationOpen=confirm(`Member Portal Registration currently ${e.registrationOpen?'OPEN':'CLOSED'}. Click OK to keep/set OPEN; Cancel to set CLOSED.`);
  try{
    await api(`/api/events/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({name,budget:Number(budget),status,venue,capacity:Number(capacity||0),registrationDeadline,registrationOpen})});
    toast('Event updated');await loadAll();await viewEventProject(id);
  }catch(err){alert(err.message)}
}

function openEventIncome(id){
  const members=cache.members||[];
  $('#eventIncomeForm').innerHTML=`
    <div class="full info-strip"><b>Linked Accounting:</b> Event income also appears automatically in main Collections / Donation / Income Management; no duplicate record is created.</div>
    <label>Income Type<select name="incomeType"><option>Collection</option><option>Donation</option><option>Sponsorship</option><option>Member Contribution</option></select></label>
    <label>Member (optional)<select name="memberId"><option value="">External / General Source</option>${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Source / Donor / Sponsor<input name="source"></label>
    <label>Mobile<input name="mobile"></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label class="full">Remarks<textarea name="remarks"></textarea></label>
    <div class="actions"><button class="btn primary">Save Event Income</button></div>`;
  $('#eventIncomeModal').classList.add('show');
  $('#eventIncomeForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));data.amount=Number(data.amount);
    try{
      const r=await api(`/api/events/${encodeURIComponent(id)}/income`,{method:'POST',body:JSON.stringify(data)});
      closeEventIncome();toast(`${data.incomeType} saved`);await loadAll();await viewEventProject(id);
      if(String(r.id||'').startsWith('RCPT-')) printReceipt(r.id);
    }catch(err){alert(err.message)}
  };
}
function closeEventIncome(){$('#eventIncomeModal').classList.remove('show')}

function openEventExpense(id){
  $('#eventExpenseForm').innerHTML=`
    <div class="full info-strip"><b>Linked Accounting:</b> Event expense is posted automatically to Expense Management + Cash/Bank ledger.</div>
    <label>Expense Category<select name="category">${EXPENSE_CATEGORIES.map(x=>`<option ${x==='Event Expense'?'selected':''}>${esc(x)}</option>`).join('')}</select></label>
    <label>Paid To<input name="paidTo" required></label>
    <label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Approved By / Manual Note<input name="approvedBy"></label>
    <label>Bill / Invoice<input id="eventExpenseBill" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></label>
    <label class="full">Purpose<textarea name="purpose" required></textarea></label>
    <label class="full">Remarks<textarea name="remarks"></textarea></label>
    <div class="actions"><button class="btn primary">Save Expense & Generate Voucher</button></div>`;
  $('#eventExpenseModal').classList.add('show');
  $('#eventExpenseForm').onsubmit=async e=>{
    e.preventDefault();
    let data=Object.fromEntries(new FormData(e.target));data.amount=Number(data.amount);
    data=await applyFinancialApprovalPrompt(data,'EventExpense');if(!data)return;
    const bill=$('#eventExpenseBill').files[0];
    try{
      if(bill){
        if(bill.size>10*1024*1024) throw new Error('Bill maximum 10 MB.');
        data.billFilename=bill.name;data.billDataUrl=await fileToDataURL(bill);
      }
      const r=await api(`/api/events/${encodeURIComponent(id)}/expense`,{method:'POST',body:JSON.stringify(data)});
      closeEventExpense();toast(`Expense voucher ${r.id} generated`);await loadAll();await viewEventProject(id);
      printExpenseVoucher(r.id);
    }catch(err){alert(err.message)}
  };
}
function closeEventExpense(){$('#eventExpenseModal').classList.remove('show')}

async function addEventRegistration(id){const hint=(cache.members||[]).filter(x=>x.status==='Active').slice(0,25).map(m=>`${m.id} - ${m.name}`).join('\n');const memberId=prompt(`Member ID:\n${hint}`,'');if(memberId===null)return;const notes=prompt('Registration Notes:','')||'';try{await api(`/api/events/${encodeURIComponent(id)}/registrations`,{method:'POST',body:JSON.stringify({memberId:memberId.trim(),notes})});toast('Member registered');await loadAll();await viewEventProject(id)}catch(e){alert(e.message)}}
async function updateEventRegistration(eventId,registrationId,status){try{await api(`/api/events/${encodeURIComponent(eventId)}/registrations/${encodeURIComponent(registrationId)}`,{method:'PUT',body:JSON.stringify({status})});toast('Registration updated');await loadAll();await viewEventProject(eventId)}catch(e){alert(e.message)}}
async function addEventParticipant(id){
  const memberId=prompt('Member ID (optional; leave blank for external participant):','');if(memberId===null)return;
  const name=prompt('Participant Name:',memberId?'':'');if(name===null)return;
  const mobile=prompt('Mobile:','')||'';
  const role=prompt('Role / Participation Type:','Participant')||'Participant';
  const notes=prompt('Notes:','')||'';
  try{
    await api(`/api/events/${encodeURIComponent(id)}/participants`,{method:'POST',body:JSON.stringify({memberId,name,mobile,role,notes})});
    toast('Participant added');await loadAll();await viewEventProject(id);
  }catch(err){alert(err.message)}
}
async function deleteEventParticipant(eventId,participantId){
  if(!confirm('Delete participant?'))return;
  try{
    await api(`/api/events/${encodeURIComponent(eventId)}/participants/${encodeURIComponent(participantId)}`,{method:'DELETE'});
    toast('Participant deleted');await loadAll();await viewEventProject(eventId);
  }catch(err){alert(err.message)}
}

async function addEventVendor(id){
  const vendors=cache.vendorsData?.rows||[];const hint=vendors.slice(0,20).map(v=>`${v.id} - ${v.name}`).join('\n');
  const vendorId=prompt(`Vendor Master ID (optional; blank for manual):\n${hint}`,'');if(vendorId===null)return;
  const name=vendorId?'':prompt('Vendor / Service Provider Name:','');if(name===null)return;
  const mobile=vendorId?'':(prompt('Mobile:','')||'');
  const service=prompt('Service / Item:','')||'';
  const contractAmount=prompt('Contract / Estimated Amount:','0');if(contractAmount===null)return;
  const notes=prompt('Notes:','')||'';
  try{
    await api(`/api/events/${encodeURIComponent(id)}/vendors`,{method:'POST',body:JSON.stringify({vendorId:vendorId.trim(),name,mobile,service,contractAmount:Number(contractAmount),notes})});
    toast('Vendor added');await loadAll();await viewEventProject(id);
  }catch(err){alert(err.message)}
}
async function deleteEventVendor(eventId,vendorId){
  if(!confirm('Delete vendor?'))return;
  try{
    await api(`/api/events/${encodeURIComponent(eventId)}/vendors/${encodeURIComponent(vendorId)}`,{method:'DELETE'});
    toast('Vendor deleted');await loadAll();await viewEventProject(eventId);
  }catch(err){alert(err.message)}
}

async function uploadEventDocument(id){
  const f=$('#eventDocFile')?.files?.[0];if(!f)return alert('Select a photo/document.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/events/${encodeURIComponent(id)}/document`,{method:'POST',body:JSON.stringify({
      filename:f.name,dataUrl,documentType:$('#eventDocType').value,displayName:$('#eventDocName').value||f.name
    })});
    toast('Event file uploaded');await loadAll();await viewEventProject(id);
  }catch(err){alert(err.message)}
}
async function deleteEventDocument(eventId,docId){
  if(!confirm('Delete this event file?'))return;
  try{
    await api(`/api/events/${encodeURIComponent(eventId)}/documents/${encodeURIComponent(docId)}`,{method:'DELETE'});
    toast('File deleted');await loadAll();await viewEventProject(eventId);
  }catch(err){alert(err.message)}
}

function noticeStatusBadge(status){const cls=String(status||'Draft').toLowerCase();return `<span class="notice-status ${cls}">${esc(status||'Draft')}</span>`}
function noticePriorityBadge(priority){const cls=String(priority||'Normal').toLowerCase();return `<span class="notice-priority ${cls}">${esc(priority||'Normal')}</span>`}
function renderNotices(){
  const d=cache.notices;if(!d||!canPage('notices'))return;const s=d.summary||{};
  $('#noticeStats').innerHTML=[['TOTAL',s.total||0],['PUBLISHED',s.published||0],['DRAFT',s.draft||0],['ARCHIVED',s.archived||0],['URGENT LIVE',s.urgent||0]].map(x=>`<div class="card notice-stat"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');
  $('#noticeRows').innerHTML=(d.notices||[]).map(n=>`<tr><td><b>${esc(n.noticeNo)}</b></td><td>${esc(n.date||'')}</td><td><b>${esc(n.title)}</b><br><small>${esc((n.body||'').slice(0,100))}</small></td><td>${noticePriorityBadge(n.priority)}</td><td>${esc(n.audience)}${n.memberId?`<br><small>${esc(n.memberId)}</small>`:''}</td><td>${esc(n.publishFrom||'—')} ${n.publishUntil?'→ '+esc(n.publishUntil):'→ Open'}</td><td>${noticeStatusBadge(n.status)}</td><td>${n.attachmentPath?`<a class="mini" href="${esc(n.attachmentPath)}" target="_blank">Open</a>`:'—'}</td><td>${currentUser?.role==='Super Admin'||currentUser?.role==='Secretary'?`<button class="mini" onclick="openNoticeForm('${n.id}')">Edit</button>`:'View only'}</td></tr>`).join('')||'<tr><td colspan="9">No notices in this Financial Year.</td></tr>';
}
function openNoticeForm(id=''){
  if(!['Super Admin','Secretary'].includes(currentUser?.role||''))return alert('Only Super Admin or Secretary can manage notices.');
  const n=id?(cache.notices?.notices||[]).find(x=>x.id===id):null,opt=(v,c)=>v===c?'selected':'';
  $('#noticeForm').innerHTML=`${n?`<div class="full info-strip"><b>${esc(n.noticeNo)}</b></div>`:''}<label>Notice Title<input name="title" value="${esc(n?.title||'')}" required></label><label>Notice Date<input type="date" name="date" value="${esc(n?.date||dateToday())}" required></label><label>Priority<select name="priority"><option ${opt('Normal',n?.priority||'Normal')}>Normal</option><option ${opt('Important',n?.priority)}>Important</option><option ${opt('Urgent',n?.priority)}>Urgent</option></select></label><label>Status<select name="status"><option ${opt('Draft',n?.status||'Draft')}>Draft</option><option ${opt('Published',n?.status)}>Published</option><option ${opt('Archived',n?.status)}>Archived</option></select></label><label>Audience<select name="audience" id="noticeAudience"><option ${opt('All Members',n?.audience||'All Members')}>All Members</option><option ${opt('Active Members',n?.audience)}>Active Members</option><option ${opt('Committee Members',n?.audience)}>Committee Members</option><option ${opt('Specific Member',n?.audience)}>Specific Member</option></select></label><label>Specific Member<select name="memberId"><option value="">Not Specific</option>${(cache.members||[]).map(m=>`<option value="${esc(m.id)}" ${opt(m.id,n?.memberId)}>${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label><label>Publish From<input type="date" name="publishFrom" value="${esc(n?.publishFrom||n?.date||dateToday())}"></label><label>Publish Until<input type="date" name="publishUntil" value="${esc(n?.publishUntil||'')}"></label><label>Attachment<input id="noticeAttachmentFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></label>${n?.attachmentPath?`<label class="declaration-check"><input type="checkbox" name="removeAttachment"> Remove existing attachment</label>`:''}<label class="full">Notice / Announcement<textarea name="body" required>${esc(n?.body||'')}</textarea></label><div class="actions"><button class="btn primary">${n?'Update Notice':'Create Notice'}</button></div>`;
  $('#noticeFormModal').classList.add('show');
  $('#noticeForm').onsubmit=async e=>{e.preventDefault();let data=Object.fromEntries(new FormData(e.target));data.financialYear=activeFY;data.removeAttachment=!!e.target.removeAttachment?.checked;const f=$('#noticeAttachmentFile').files[0];try{if(f){if(f.size>10*1024*1024)throw new Error('Attachment maximum 10 MB.');data.attachmentFilename=f.name;data.attachmentDataUrl=await fileToDataURL(f)}if(n)await api(`/api/notices/${encodeURIComponent(n.id)}`,{method:'PUT',body:JSON.stringify(data)});else await api('/api/notices',{method:'POST',body:JSON.stringify(data)});closeNoticeForm();toast(n?'Notice updated':'Notice created');await loadAll()}catch(err){alert(err.message)}};
}
function closeNoticeForm(){$('#noticeFormModal').classList.remove('show')}

function advancedStatsHtml(items){return items.map(x=>`<div class="advanced-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]||''}</small></div>`).join('')}
function closeAdvancedForm(){$('#advancedFormModal').classList.remove('show')}
function closeAdvancedView(){$('#advancedViewModal').classList.remove('show')}
function openAdvancedForm(title,html,onSubmit){$('#advancedFormTitle').textContent=title;$('#advancedForm').innerHTML=html;$('#advancedFormModal').classList.add('show');$('#advancedForm').onsubmit=onSubmit}
function openAdvancedView(title,html){$('#advancedViewTitle').textContent=title;$('#advancedViewBody').innerHTML=html;$('#advancedViewModal').classList.add('show')}

function renderDocumentLibrary(){const d=cache.documentsData;if(!d)return;$('#documentStats').innerHTML=advancedStatsHtml([['TOTAL DOCUMENTS',d.summary?.total||0,'Selected FY'],['MEMBER LINKED',d.summary?.memberLinked||0,'KYC/member documents'],['WITH EXPIRY',(d.rows||[]).filter(x=>x.expiryDate).length,'Expiry tracked']]);$('#documentLibraryRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.title)}</td><td>${esc(x.category)}</td><td>${esc(x.documentNo||'—')}</td><td>${esc(x.date||'')}</td><td>${esc(fmtDate(x.expiryDate||'—'))}</td><td>${esc(x.audience)}</td><td>${esc(x.memberId||'—')}</td><td>${esc(x.version||'1.0')}</td><td><a class="mini" href="${esc(x.path)}" target="_blank">Open</a></td><td><button class="mini danger" onclick="deleteDocumentLibrary('${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="11">No documents.</td></tr>'}
function openDocumentLibraryForm(){const members=cache.members||[];openAdvancedForm('Upload Document',`<label>Title<input name="title" required></label><label>Category<select name="category">${DOCUMENT_CATEGORIES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Document No.<input name="documentNo"></label><label>Date<input type="date" name="date" value="${dateToday()}"></label><label>Expiry Date<input type="date" name="expiryDate"></label><label>Audience<select name="audience">${DOCUMENT_AUDIENCES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Linked Member<select name="memberId"><option value="">Not Member-specific</option>${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label><label>Version<input name="version" value="1.0"></label><label>File<input id="advancedDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx,.xls,.xlsx" required></label><label class="full">Description<textarea name="description"></textarea></label><div class="actions"><button class="btn primary">Upload</button></div>`,async e=>{e.preventDefault();const f=$('#advancedDocFile').files[0];if(!f)return;try{let data=Object.fromEntries(new FormData(e.target));data.filename=f.name;data.dataUrl=await fileToDataURL(f);data.financialYear=activeFY;await api('/api/document-library',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Document uploaded');await loadAll()}catch(err){alert(err.message)}})}
async function deleteDocumentLibrary(id){if(!confirm('Delete this document?'))return;try{await api(`/api/document-library/${encodeURIComponent(id)}`,{method:'DELETE'});toast('Document deleted');await loadAll()}catch(e){alert(e.message)}}

function renderIssuedDocuments(){const d=cache.certificatesData;if(!d)return;$('#certificateStats').innerHTML=advancedStatsHtml([['TOTAL ISSUED',d.summary?.total||0,'Selected FY'],['MEMBER ID',d.summary?.idCards||0,'ID Card issues'],['CERTIFICATES',d.summary?.certificates||0,'Certificates issued']]);$('#issuedDocumentRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.certificateNo)}</b></td><td>${esc(x.type)}</td><td>${esc(x.member?.id||x.memberId)}<br><small>${esc(x.member?.name||'')}</small></td><td>${esc(x.event?.name||'—')}</td><td>${esc(fmtDate(x.issueDate))}</td><td>${esc(x.title)}</td><td>${esc(x.issuedBy||'')}</td><td><button class="mini" onclick="printIssuedDocument('${x.id}')">Print</button><button class="mini danger" onclick="deleteIssuedDocument('${x.id}')">Cancel</button></td></tr>`).join('')||'<tr><td colspan="8">No issued documents.</td></tr>'}
function openCertificateIssueForm(){const members=cache.members||[],events=cache.events?.events||[];openAdvancedForm('Issue Certificate / ID',`<label>Type<select name="type">${CERTIFICATE_TYPES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Member<select name="memberId" required>${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label><label>Event (for participation certificate)<select name="eventId"><option value="">Not applicable</option>${events.map(x=>`<option value="${x.id}">${esc(x.id)} - ${esc(x.name)}</option>`).join('')}</select></label><label>Issue Date<input type="date" name="issueDate" value="${dateToday()}"></label><label class="full">Title<input name="title" placeholder="Certificate title"></label><label class="full">Notes<textarea name="notes"></textarea></label><div class="actions"><button class="btn primary">Issue & Print</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target));data.financialYear=activeFY;const r=await api('/api/issued-documents',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast(r.certificateNo+' issued');await loadAll();printIssuedDocument(r.id)}catch(err){alert(err.message)}})}
async function deleteIssuedDocument(id){if(!confirm('Cancel this issued document record?'))return;try{await api(`/api/issued-documents/${encodeURIComponent(id)}`,{method:'DELETE'});toast('Issued record cancelled');await loadAll()}catch(e){alert(e.message)}}
function printIssuedDocument(id,portal=false){const rows=portal?(cache.portal?.issuedDocuments||[]):(cache.certificatesData?.rows||[]);const x=rows.find(r=>r.id===id);if(!x)return alert('Issued document not found');const member=portal?cache.portal.profile:x.member;if(!member)return alert('Member details unavailable');const org=portal?cache.portal.organization:(cache.master||{}),eventName=x.eventName||x.event?.name||'';const w=window.open('','_blank','width=900,height=700');if(x.type==='Member ID Card'){w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(x.certificateNo)}</title><style>@page{size:86mm 55mm;margin:0}body{margin:0;font-family:Arial}.card{width:86mm;height:55mm;box-sizing:border-box;padding:5mm;border:1px solid #222;position:relative}.head{display:flex;gap:3mm;align-items:center;border-bottom:1px solid #999;padding-bottom:2mm}.logo{width:12mm;height:12mm;object-fit:contain}.photo{width:20mm;height:24mm;object-fit:cover;border:1px solid #999}.body{display:grid;grid-template-columns:22mm 1fr;gap:3mm;padding-top:3mm}.org{font-size:11pt;font-weight:700}.small{font-size:7pt}.name{font-size:12pt;font-weight:800}.id{font-size:8pt;font-weight:700}.foot{position:absolute;bottom:3mm;right:4mm;font-size:6pt}</style></head><body><div class="card"><div class="head">${org.logoPath?`<img class="logo" src="${esc(org.logoPath)}">`:''}<div><div class="org">${esc(org.organizationName||org.name||'Organization')}</div><div class="small">MEMBER ID CARD · ${esc(x.certificateNo)}</div></div></div><div class="body">${member.photoPath?`<img class="photo" src="${esc(member.photoPath)}">`:'<div class="photo"></div>'}<div><div class="name">${esc(member.name)}</div><div class="id">${esc(member.id)}</div><div class="small">${esc(member.membershipType||'Member')} · ${esc(member.status||'')}</div><div class="small">Join: ${esc(member.joinDate||'')}</div><div class="small">Mobile: ${esc(member.phone||'')}</div></div></div><div class="foot">Issued ${esc(fmtDate(x.issueDate))}</div></div><script>window.onload=()=>window.print()<\/script></body></html>`)}else{w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(x.certificateNo)}</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Georgia,serif;text-align:center;padding:18mm;border:8px double #333;box-sizing:border-box;min-height:180mm}h1{font-size:30pt;margin:8mm 0}h2{font-size:22pt}.name{font-size:28pt;font-weight:700;margin:8mm}.text{font-size:14pt;line-height:1.7}.meta{margin-top:15mm;display:flex;justify-content:space-between;font-family:Arial;font-size:9pt}</style></head><body>${org.logoPath?`<img src="${esc(org.logoPath)}" style="height:22mm;max-width:35mm;object-fit:contain">`:''}<h2>${esc(org.organizationName||org.name||'Organization')}</h2><h1>${esc(x.title||x.type)}</h1><div class="text">This is to certify that</div><div class="name">${esc(member.name)}</div><div class="text">Member ID <b>${esc(member.id)}</b>${eventName?` has participated in <b>${esc(eventName)}</b>`:' is a valued member of the organization'}.</div><div class="meta"><span>${esc(x.certificateNo)} · ${esc(fmtDate(x.issueDate))}</span><span>Authorized Signatory</span></div><script>window.onload=()=>window.print()<\/script></body></html>`)}w.document.close()}

function renderReminders(){const d=cache.remindersData;if(!d)return;$('#reminderStats').innerHTML=advancedStatsHtml([['TOTAL',d.summary?.total||0,'Reminder records'],['PENDING',d.summary?.pending||0,'Awaiting contact'],['SENT / LOGGED',d.summary?.sent||0,'Marked sent'],['PENDING DUE',money(d.summary?.dueAmount||0),'Due reminder amount']]);$('#reminderRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.type)}</td><td>${esc(x.memberName||x.memberId||'—')}</td><td>${esc(x.phone||'—')}</td><td>${esc(x.channel)}</td><td>${x.dueAmount?money(x.dueAmount):'—'}</td><td>${esc(fmtDate(x.scheduledDate))}</td><td>${badge(x.status)}</td><td><small>${esc(x.message)}</small></td><td>${x.status==='Pending'?`<button class="mini" onclick="openReminderChannel('${x.id}','WhatsApp')">WhatsApp</button><button class="mini" onclick="openReminderChannel('${x.id}','SMS')">SMS</button><button class="mini" onclick="markReminderSent('${x.id}')">Mark Sent</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="10">No reminders.</td></tr>'}
function openReminderForm(){const members=cache.members||[];openAdvancedForm('New Reminder',`<label>Type<select name="type">${REMINDER_TYPES.map(x=>`<option>${x}</option>`).join('')}</select></label><label>Member<select name="memberId"><option value="">General / external</option>${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label><label>Phone<input name="phone"></label><label>Channel<select name="channel"><option>WhatsApp</option><option>SMS</option><option>Both</option></select></label><label>Scheduled Date<input type="date" name="scheduledDate" value="${dateToday()}"></label><label>Due Amount<input type="number" step="0.01" name="dueAmount" value="0"></label><label class="full">Message<textarea name="message" required></textarea></label><div class="actions"><button class="btn primary">Save Reminder</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target));data.financialYear=activeFY;await api('/api/reminders',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Reminder created');await loadAll()}catch(err){alert(err.message)}})}
async function generateDueReminders(){if(!confirm('Generate pending reminders for all Active Members with subscription due?'))return;try{const r=await api(fyUrl('/api/reminders/generate-dues'),{method:'POST',body:JSON.stringify({asOfDate:dateToday(),channel:'WhatsApp'})});toast(`${r.created} due reminders generated`);await loadAll()}catch(e){alert(e.message)}}
function reminderPhone(p){let n=String(p||'').replace(/\D/g,'');if(n.length===10)n='91'+n;return n}
function openReminderChannel(id,channel){const r=(cache.remindersData?.rows||[]).find(x=>x.id===id);if(!r)return;const phone=reminderPhone(r.phone),msg=encodeURIComponent(r.message||'');if(channel==='WhatsApp')window.open(`https://wa.me/${phone}?text=${msg}`,'_blank');else window.location.href=`sms:${phone}?body=${msg}`}
async function markReminderSent(id){try{await api(`/api/reminders/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({status:'Sent'})});toast('Reminder marked sent');await loadAll()}catch(e){alert(e.message)}}

function renderGrievances(){const d=cache.grievancesData;if(!d)return;$('#grievanceStats').innerHTML=advancedStatsHtml([['TOTAL',d.summary?.total||0,'Selected FY'],['OPEN',d.summary?.open||0,'Awaiting review'],['IN REVIEW',d.summary?.inReview||0,'Assigned / processing'],['RESOLVED',d.summary?.resolved||0,'Closed'],['URGENT',d.summary?.urgent||0,'Open urgent cases']]);$('#grievanceRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.memberId)}<br><small>${esc(x.memberName)}</small></td><td>${esc(x.category)}</td><td>${esc(x.subject)}</td><td>${esc(x.priority)}</td><td>${badge(x.status)}</td><td>${esc(x.assignedTo||'—')}</td><td>${fmtDate(x.createdAt)}</td><td><button class="mini" onclick="viewGrievance('${x.id}')">Open</button></td></tr>`).join('')||'<tr><td colspan="9">No grievances.</td></tr>'}
function viewGrievance(id){const g=(cache.grievancesData?.rows||[]).find(x=>x.id===id);if(!g)return;openAdvancedView(`Grievance ${g.id}`,`<div class="profile-detail-grid">${detail('Member',`${g.memberId} - ${g.memberName}`)}${detail('Category',g.category)}${detail('Priority',g.priority)}${detail('Status',g.status)}${detail('Subject',g.subject,'full')}${detail('Description',g.description,'full')}${detail('Assigned To',g.assignedTo)}${detail('Response',g.response,'full')}${detail('Resolution',g.resolution,'full')}</div>${g.attachmentPath?`<a class="btn" target="_blank" href="${esc(g.attachmentPath)}">Open Attachment</a>`:''}<div class="actions"><button class="btn primary" onclick="updateGrievance('${g.id}')">Update Workflow</button></div>`)}
async function updateGrievance(id){const g=(cache.grievancesData?.rows||[]).find(x=>x.id===id);if(!g)return;const status=prompt('Status: Open / In Review / Resolved / Rejected',g.status);if(status===null)return;const assignedTo=prompt('Assigned To:',g.assignedTo||'')??g.assignedTo;const response=prompt('Response / Communication:',g.response||'')??g.response;const resolution=prompt('Resolution / Closure Note:',g.resolution||'')??g.resolution;try{await api(`/api/grievances/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({status,assignedTo,response,resolution})});closeAdvancedView();toast('Grievance updated');await loadAll()}catch(e){alert(e.message)}}

function renderElections(){const d=cache.electionsData;if(!d)return;$('#electionStats').innerHTML=advancedStatsHtml([['TOTAL ELECTIONS',d.summary?.total||0,'Selected FY'],['DRAFT',d.summary?.draft||0,'Preparation'],['VOTING OPEN',d.summary?.votingOpen||0,'Member voting active'],['PUBLISHED',d.summary?.published||0,'Results published']]);$('#electionCards').innerHTML=(d.rows||[]).map(e=>`<div class="card advanced-module-card"><div class="advanced-card-head"><div><span>${esc(e.id)}</span><h3>${esc(e.title)}</h3></div>${badge(e.status)}</div><p>${esc(e.electionDate||'Date not set')} · ${(e.positions||[]).length} position(s)</p><div class="advanced-card-actions"><button class="mini" onclick="viewElection('${e.id}')">Open</button><button class="mini" onclick="changeElectionStatus('${e.id}')">Change Status</button><button class="mini" onclick="addElectionPosition('${e.id}')">+ Position</button></div></div>`).join('')||'<div class="empty-docs">No elections.</div>'}
function openElectionForm(){openAdvancedForm('New Election',`<label>Election Title<input name="title" required></label><label>Election Date<input type="date" name="electionDate" value="${dateToday()}"></label><label>Nomination Start<input type="date" name="nominationStart"></label><label>Nomination End<input type="date" name="nominationEnd"></label><label>Voting Start<input type="date" name="votingStart"></label><label>Voting End<input type="date" name="votingEnd"></label><label class="full">Notes<textarea name="notes"></textarea></label><div class="actions"><button class="btn primary">Create Election</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target));data.financialYear=activeFY;await api('/api/elections',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Election created');await loadAll()}catch(err){alert(err.message)}})}
function viewElection(id){const e=(cache.electionsData?.rows||[]).find(x=>x.id===id);if(!e)return;openAdvancedView(e.title,`<div class="profile-detail-grid">${detail('Election ID',e.id)}${detail('Date',e.electionDate)}${detail('Status',e.status)}${detail('Nomination',`${e.nominationStart||'—'} → ${e.nominationEnd||'—'}`)}${detail('Voting',`${e.votingStart||'—'} → ${e.votingEnd||'—'}`)}${detail('Notes',e.notes,'full')}</div><div class="election-position-list">${(e.positions||[]).map(p=>`<div class="election-position-card"><div class="profile-block-head"><div><h3>${esc(p.name)}</h3><p>${p.seats} seat(s) · ${p.voterCount||0} voter(s)</p></div><button class="mini" onclick="addElectionCandidate('${e.id}','${p.id}')">+ Candidate</button></div><table class="mini-table"><thead><tr><th>Member</th><th>Manifesto</th><th>Status</th><th>Votes</th></tr></thead><tbody>${(p.candidates||[]).map(c=>`<tr><td>${esc(c.memberId)} - ${esc(c.memberName)}</td><td>${esc(c.manifesto||'—')}</td><td>${esc(c.status)}</td><td>${c.votes===null?'Hidden':c.votes}</td></tr>`).join('')||'<tr><td colspan="4">No candidates.</td></tr>'}</tbody></table></div>`).join('')||'<div class="empty-docs">No positions.</div>'}</div>`)}
async function changeElectionStatus(id){const e=(cache.electionsData?.rows||[]).find(x=>x.id===id);const status=prompt('Status: Draft / Nomination Open / Voting Open / Closed / Published',e?.status||'Draft');if(status===null)return;try{await api(`/api/elections/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({status})});toast('Election status updated');await loadAll()}catch(e){alert(e.message)}}
async function addElectionPosition(id){const name=prompt('Position Name:','President');if(name===null)return;const seats=prompt('Number of Seats:','1');if(seats===null)return;try{await api(`/api/elections/${encodeURIComponent(id)}/positions`,{method:'POST',body:JSON.stringify({name,seats:Number(seats)})});toast('Position added');await loadAll();viewElection(id)}catch(e){alert(e.message)}}
async function addElectionCandidate(electionId,positionId){const hint=(cache.members||[]).filter(x=>x.status==='Active').slice(0,20).map(m=>`${m.id} - ${m.name}`).join('\n');const memberId=prompt(`Candidate Member ID:\n${hint}`,'');if(memberId===null)return;const manifesto=prompt('Manifesto / Note:','')||'';try{await api(`/api/elections/${encodeURIComponent(electionId)}/positions/${encodeURIComponent(positionId)}/candidates`,{method:'POST',body:JSON.stringify({memberId:memberId.trim(),manifesto})});toast('Candidate added');await loadAll();viewElection(electionId)}catch(e){alert(e.message)}}

function renderVendors(){const d=cache.vendorsData;if(!d)return;$('#vendorStats').innerHTML=advancedStatsHtml([['TOTAL VENDORS',d.summary?.total||0,'Master records'],['ACTIVE',d.summary?.active||0,'Available'],['INACTIVE',d.summary?.inactive||0,'Not active'],['BLACKLISTED',d.summary?.blacklisted||0,'Blocked']]);$('#vendorRows').innerHTML=(d.rows||[]).map(v=>`<tr><td><b>${esc(v.id)}</b></td><td><b>${esc(v.name)}</b><br><small>${esc(v.contactPerson||'')}</small></td><td>${esc(v.category)}</td><td>${esc(v.phone||'—')}<br><small>${esc(v.email||'')}</small></td><td>${esc(v.gstin||v.pan||'—')}</td><td>${esc(v.bankName||v.upiId||'—')}</td><td>${v.rating?`${'★'.repeat(Math.round(v.rating))} ${v.rating}/5`:'—'}</td><td>${badge(v.status)}</td><td><button class="mini" onclick="openVendorForm('${v.id}')">Edit</button></td></tr>`).join('')||'<tr><td colspan="9">No vendors.</td></tr>'}
function openVendorForm(id=''){const v=id?(cache.vendorsData?.rows||[]).find(x=>x.id===id):null;openAdvancedForm(v?'Edit Vendor':'Add Vendor',`<label>Vendor Name<input name="name" value="${esc(v?.name||'')}" required></label><label>Category<select name="category">${VENDOR_CATEGORIES.map(x=>`<option ${x===v?.category?'selected':''}>${esc(x)}</option>`).join('')}</select></label><label>Contact Person<input name="contactPerson" value="${esc(v?.contactPerson||'')}"></label><label>Phone<input name="phone" value="${esc(v?.phone||'')}"></label><label>Email<input name="email" value="${esc(v?.email||'')}"></label><label>GSTIN<input name="gstin" value="${esc(v?.gstin||'')}"></label><label>PAN<input name="pan" value="${esc(v?.pan||'')}"></label><label>Bank Name<input name="bankName" value="${esc(v?.bankName||'')}"></label><label>Account No.<input name="accountNumber" value="${esc(v?.accountNumber||'')}"></label><label>IFSC<input name="ifsc" value="${esc(v?.ifsc||'')}"></label><label>UPI ID<input name="upiId" value="${esc(v?.upiId||'')}"></label><label>Status<select name="status"><option ${v?.status==='Active'?'selected':''}>Active</option><option ${v?.status==='Inactive'?'selected':''}>Inactive</option><option ${v?.status==='Blacklisted'?'selected':''}>Blacklisted</option></select></label><label>Rating (0-5)<input type="number" min="0" max="5" step="0.5" name="rating" value="${Number(v?.rating||0)}"></label><label class="full">Address<textarea name="address">${esc(v?.address||'')}</textarea></label><label class="full">Notes<textarea name="notes">${esc(v?.notes||'')}</textarea></label><div class="actions"><button class="btn primary">${v?'Update':'Save'} Vendor</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target));await api(v?`/api/vendors/${encodeURIComponent(v.id)}`:'/api/vendors',{method:v?'PUT':'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Vendor saved');await loadAll()}catch(err){alert(err.message)}})}

function renderBudgetControl(){const d=cache.budgetData;if(!d)return;$('#budgetStats').innerHTML=advancedStatsHtml([['EXPENSE BUDGET',money(d.summary?.expenseBudget||0),`Actual ${money(d.summary?.expenseActual||0)}`],['EXPENSE VARIANCE',money((d.summary?.expenseBudget||0)-(d.summary?.expenseActual||0)),'Positive = under budget'],['INCOME TARGET',money(d.summary?.incomeTarget||0),`Actual ${money(d.summary?.incomeActual||0)}`],['INCOME VARIANCE',money((d.summary?.incomeActual||0)-(d.summary?.incomeTarget||0)),'Positive = above target']]);$('#budgetRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.type)}</td><td>${esc(x.category)}</td><td>${money(x.amount)}</td><td><b>${money(x.actual)}</b></td><td class="${x.variance<0?'negative-balance':'positive-balance'}"><b>${money(x.variance)}</b></td><td>${Number(x.utilization||0).toFixed(1)}%</td><td>${esc(x.notes||'—')}</td><td><button class="mini danger" onclick="deleteBudgetHead('${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="9">No budget heads.</td></tr>'}
function openBudgetForm(){const d=cache.budgetData||{};openAdvancedForm('Add Budget Head',`<label>Type<select name="type" id="budgetTypeInput"><option>Expense</option><option>Income</option></select></label><label>Category<select name="category" id="budgetCategoryInput">${(d.expenseCategories||[]).map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Budget / Target Amount<input type="number" min="0" step="0.01" name="amount" required></label><label class="full">Notes<textarea name="notes"></textarea></label><div class="actions"><button class="btn primary">Save Budget Head</button></div>`,async e=>{e.preventDefault();try{await api(fyUrl('/api/budget-control'),{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});closeAdvancedForm();toast('Budget head saved');await loadAll()}catch(err){alert(err.message)}});$('#budgetTypeInput').onchange=e=>{$('#budgetCategoryInput').innerHTML=((e.target.value==='Income'?d.incomeCategories:d.expenseCategories)||[]).map(x=>`<option>${esc(x)}</option>`).join('')}}
async function deleteBudgetHead(id){if(!confirm('Delete budget head?'))return;try{await api(`/api/budget-control/${encodeURIComponent(id)}`,{method:'DELETE'});toast('Budget head deleted');await loadAll()}catch(e){alert(e.message)}}

function renderAnnualAudits(){const d=cache.auditsData;if(!d)return;const f=d.financialSnapshot||{};$('#annualAuditStats').innerHTML=advancedStatsHtml([['AUDIT RECORDS',d.summary?.total||0,'Selected FY'],['IN PROGRESS',d.summary?.inProgress||0,'Current audits'],['COMPLETED',d.summary?.completed||0,'Completed'],['AUDIT TRAIL',d.auditTrailCount||0,'System actions in FY']]);$('#annualAuditFinancial').innerHTML=`<div class="security-section-head"><div><h3>Annual Financial Snapshot</h3><p>Accounting Ledger reconciliation used by auditor.</p></div></div><div class="advanced-financial-strip"><div><span>Opening</span><b>${money(f.openingBalance||0)}</b></div><div><span>Income</span><b>${money(f.income||0)}</b></div><div><span>Expense</span><b>${money(f.expense||0)}</b></div><div><span>Closing</span><b>${money(f.closingBalance||0)}</b></div><div><span>Reconciliation</span><b>${f.reconciled?'✓ Reconciled':money(f.reconciliationDifference||0)}</b></div></div>`;$('#annualAuditRows').innerHTML=(d.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.auditor)}</td><td>${esc(x.firm||'—')}</td><td>${esc(x.periodStart)} → ${esc(x.periodEnd)}</td><td>${badge(x.status)}</td><td>${esc(fmtDate(x.reportDate||'—'))}</td><td>${x.reportPath?`<a class="mini" target="_blank" href="${esc(x.reportPath)}">Open Report</a>`:'—'}</td><td><button class="mini" onclick="editAnnualAudit('${x.id}')">Update</button></td></tr>`).join('')||'<tr><td colspan="8">No annual audit records.</td></tr>'}
function openAnnualAuditForm(){openAdvancedForm('Create Annual Audit',`<label>Auditor Name<input name="auditor" required></label><label>Firm / Organization<input name="firm"></label><label>Period Start<input type="date" name="periodStart"></label><label>Period End<input type="date" name="periodEnd"></label><label class="full">Initial Observations<textarea name="observations"></textarea></label><div class="actions"><button class="btn primary">Create Audit</button></div>`,async e=>{e.preventDefault();try{await api(fyUrl('/api/annual-audits'),{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});closeAdvancedForm();toast('Audit record created');await loadAll()}catch(err){alert(err.message)}})}
function editAnnualAudit(id){const x=(cache.auditsData?.rows||[]).find(a=>a.id===id);if(!x)return;openAdvancedForm('Update Annual Audit',`<label>Auditor<input name="auditor" value="${esc(x.auditor)}"></label><label>Firm<input name="firm" value="${esc(x.firm||'')}"></label><label>Status<select name="status"><option ${x.status==='Planned'?'selected':''}>Planned</option><option ${x.status==='In Progress'?'selected':''}>In Progress</option><option ${x.status==='Completed'?'selected':''}>Completed</option></select></label><label>Report Date<input type="date" name="reportDate" value="${esc(x.reportDate||'')}"></label><label>Audit Report<input id="annualAuditFile" type="file" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"></label><label class="full">Observations<textarea name="observations">${esc(x.observations||'')}</textarea></label><label class="full">Findings<textarea name="findings">${esc(x.findings||'')}</textarea></label><label class="full">Recommendations<textarea name="recommendations">${esc(x.recommendations||'')}</textarea></label><div class="actions"><button class="btn primary">Update Audit</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target)),f=$('#annualAuditFile').files[0];if(f){data.reportFilename=f.name;data.reportDataUrl=await fileToDataURL(f)}await api(`/api/annual-audits/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify(data)});closeAdvancedForm();toast('Audit updated');await loadAll()}catch(err){alert(err.message)}})}

async function portalRegisterEvent(id){try{await api(`/api/my-portal/events/${encodeURIComponent(id)}/register`,{method:'POST',body:JSON.stringify({notes:''})});toast('Event registration completed');await loadAll()}catch(e){alert(e.message)}}
async function portalCancelEventRegistration(id){if(!confirm('Cancel your event registration?'))return;try{await api(`/api/my-portal/events/${encodeURIComponent(id)}/register`,{method:'DELETE'});toast('Registration cancelled');await loadAll()}catch(e){alert(e.message)}}
function openPortalNomineeForm(){openAdvancedForm('Add Nominee',`<label>Name<input name="name" required></label><label>Relation<input name="relation" required></label><label>Date of Birth<input type="date" name="dob"></label><label>Phone<input name="phone"></label><label>Share %<input type="number" min="0" max="100" step="0.01" name="sharePercent" value="100"></label><label class="declaration-check"><input type="checkbox" name="isPrimary"> Primary Nominee</label><label class="full">Address<textarea name="address"></textarea></label><label class="full">Notes<textarea name="notes"></textarea></label><div class="actions"><button class="btn primary">Save Nominee</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target));data.isPrimary=e.target.isPrimary.checked;await api('/api/my-portal/nominees',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Nominee saved');await loadAll()}catch(err){alert(err.message)}})}
async function deletePortalNominee(id){if(!confirm('Remove this nominee?'))return;try{await api(`/api/my-portal/nominees/${encodeURIComponent(id)}`,{method:'DELETE'});toast('Nominee removed');await loadAll()}catch(e){alert(e.message)}}
function openPortalGrievanceForm(){openAdvancedForm('Submit Grievance',`<label>Category<select name="category">${GRIEVANCE_CATEGORIES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Priority<select name="priority"><option>Normal</option><option>Important</option><option>Urgent</option></select></label><label class="full">Subject<input name="subject" required></label><label class="full">Description<textarea name="description" required></textarea></label><label>Attachment<input id="portalGrievanceFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></label><div class="actions"><button class="btn primary">Submit Grievance</button></div>`,async e=>{e.preventDefault();try{const data=Object.fromEntries(new FormData(e.target)),f=$('#portalGrievanceFile').files[0];data.financialYear=activeFY;if(f){data.attachmentFilename=f.name;data.attachmentDataUrl=await fileToDataURL(f)}await api('/api/my-portal/grievances',{method:'POST',body:JSON.stringify(data)});closeAdvancedForm();toast('Grievance submitted');await loadAll()}catch(err){alert(err.message)}})}
async function portalVote(electionId,positionId,candidateId){if(!confirm('Confirm your vote? Vote cannot be changed after submission.'))return;try{await api(`/api/my-portal/elections/${encodeURIComponent(electionId)}/vote`,{method:'POST',body:JSON.stringify({positionId,candidateId})});toast('Vote recorded');await loadAll()}catch(e){alert(e.message)}}

function socialStatusBadge(status){
  const cls=String(status||'Planned').toLowerCase();
  return `<span class="social-status-badge ${cls}">${esc(status||'Planned')}</span>`;
}
function renderSocialWork(){
  const d=cache.socialwork;if(!d)return;
  const s=d.summary||{};
  $('#socialWorkStats').innerHTML=[
    ['TOTAL PROJECTS',s.totalProjects||0,`Planned ${s.planned||0} · Ongoing ${s.ongoing||0}`],
    ['TOTAL BUDGET',money(s.totalBudget||0),`FY ${activeFY}`],
    ['TOTAL EXPENSE',money(s.totalExpense||0),'Linked expense vouchers'],
    ['BUDGET BALANCE',money(s.budgetBalance||0),Number(s.budgetBalance||0)>=0?'Within total budget':'Overall budget exceeded'],
    ['BENEFICIARIES',s.totalBeneficiaries||0,'Total recorded beneficiaries'],
    ['COMPLETED',s.completed||0,'Completed projects']
  ].map(x=>`<div class="social-work-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#socialTypeSummary').innerHTML=(d.typeSummary||[]).map(x=>`
    <div class="social-type-item"><div><b>${esc(x.type)}</b><span>${x.projects} project(s) · ${x.beneficiaries} beneficiaries</span></div><strong>${money(x.expense)}</strong></div>`).join('');

  $('#socialProjectRows').innerHTML=(d.projects||[]).map(p=>{
    const x=p.summary||{};
    return `<tr>
      <td><b>${esc(p.id)}</b></td><td><b>${esc(p.projectName)}</b></td><td>${esc(p.socialWorkType)}</td>
      <td>${esc(p.date||'')}</td><td>${esc(p.location||'—')}</td><td>${money(p.budget||0)}</td>
      <td><b>${money(x.totalExpense||0)}</b></td>
      <td><b class="${Number(x.budgetBalance||0)<0?'negative-balance':'positive-balance'}">${money(x.budgetBalance||0)}</b></td>
      <td>${Number(p.beneficiaryCount||0)}</td><td>${x.responsibleMembers||0}</td>
      <td>${socialStatusBadge(p.status)}</td><td><button class="mini" onclick="viewSocialProject('${p.id}')">Open</button></td>
    </tr>`;
  }).join('')||'<tr><td colspan="12">No social work projects in this Financial Year.</td></tr>';
}
function openSocialProjectForm(){
  $('#socialProjectForm').innerHTML=`
    <label>Project Name<input name="projectName" required placeholder="Blood Donation Camp - Panskura"></label>
    <label>Social Work Type<select name="socialWorkType">${SOCIAL_WORK_TYPES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label>
    <label>Location<input name="location" required></label>
    <label>Budget<input type="number" step="0.01" name="budget" value="0"></label>
    <label>Beneficiary Count<input type="number" min="0" name="beneficiaryCount" value="0"></label>
    <label>Status<select name="status"><option>Planned</option><option>Ongoing</option><option>Completed</option><option>Cancelled</option></select></label>
    <label class="full">Description / Objective<textarea name="description"></textarea></label>
    <div class="actions"><button class="btn primary">Create Social Work Project</button></div>`;
  $('#socialProjectFormModal').classList.add('show');
  $('#socialProjectForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    data.budget=Number(data.budget||0);data.beneficiaryCount=Number(data.beneficiaryCount||0);data.financialYear=activeFY;
    try{
      const p=await api('/api/social-projects',{method:'POST',body:JSON.stringify(data)});
      closeSocialProjectForm();toast(`Social project ${p.id} created`);await loadAll();await viewSocialProject(p.id);
    }catch(err){alert(err.message)}
  };
}
function closeSocialProjectForm(){$('#socialProjectFormModal').classList.remove('show')}
async function viewSocialProject(id){
  try{
    const p=await api(`/api/social-projects/${encodeURIComponent(id)}`);
    const s=p.summary||{};
    $('#socialProjectViewBody').innerHTML=`
      <div class="social-project-head">
        <div><span class="member-id-chip">${esc(p.id)}</span><h2>${esc(p.projectName)}</h2>
        <p>${esc(p.socialWorkType)} · ${esc(p.date||'')} · ${esc(p.location||'No location')} · ${socialStatusBadge(p.status)}</p></div>
        <div class="head-actions"><button class="btn" onclick="editSocialProject('${p.id}')">Edit</button><button class="btn primary" onclick="openSocialExpense('${p.id}')">+ Expense</button></div>
      </div>
      <div class="social-financial-summary">
        <div><span>Budget</span><b>${money(p.budget||0)}</b><small>Approved / planned budget</small></div>
        <div><span>Total Expense</span><b>${money(s.totalExpense||0)}</b><small>Linked expense vouchers</small></div>
        <div class="${Number(s.budgetBalance||0)<0?'over-budget':'within-budget'}"><span>Budget Balance</span><b>${money(s.budgetBalance||0)}</b><small>${Number(s.budgetBalance||0)>=0?'Available within budget':'Budget exceeded'}</small></div>
        <div><span>Beneficiaries</span><b>${Number(p.beneficiaryCount||0)}</b><small>Recorded beneficiary count</small></div>
      </div>
      <div class="profile-detail-grid">
        ${detail('Social Work Type',p.socialWorkType)}${detail('Date',p.date)}${detail('Location',p.location)}${detail('Status',p.status)}
        ${detail('Responsible Members',(p.responsibleMembers||[]).length)}${detail('Photos / Documents',(p.documents||[]).length)}
        ${detail('Description / Objective',p.description,'full')}
      </div>
      <div class="event-tabs">
        <button class="active" onclick="switchSocialTab(this,'social-expense-tab')">Expense Ledger</button>
        <button onclick="switchSocialTab(this,'social-responsible-tab')">Responsible Members (${(p.responsibleMembers||[]).length})</button>
        <button onclick="switchSocialTab(this,'social-documents-tab')">Photos / Documents (${(p.documents||[]).length})</button>
      </div>
      <div id="social-expense-tab" class="social-tab-panel active">
        <div class="profile-block-head"><div><h3>Project Expense Ledger</h3><p>Linked entries from Expense Management + Cash/Bank ledger.</p></div><button class="mini" onclick="openSocialExpense('${p.id}')">+ Expense</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Voucher</th><th>Date</th><th>Category</th><th>Paid To</th><th>Purpose</th><th>Mode</th><th>Amount</th><th>Approved By</th><th>Bill</th></tr></thead><tbody>
        ${(p.expenses||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(fmtDate(x.date))}</td><td>${esc(x.category)}</td><td>${esc(x.paidTo)}</td><td>${esc(x.purpose)}</td><td>${esc(x.mode)}</td><td><b>${money(x.amount)}</b></td><td>${esc(x.approvedBy||'—')}</td><td>${x.billPath?`<a class="mini bill-link" href="${esc(x.billPath)}" target="_blank">Open</a>`:'—'}</td></tr>`).join('')||'<tr><td colspan="9">No project expenses.</td></tr>'}
        </tbody></table></div>
      </div>
      <div id="social-responsible-tab" class="social-tab-panel">
        <div class="profile-block-head"><div><h3>Responsible Members</h3><p>Project coordination / responsibility record.</p></div><button class="mini" onclick="addSocialResponsibleMember('${p.id}')">+ Add Member</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Member ID</th><th>Name</th><th>Mobile</th><th>Role</th><th>Notes</th><th></th></tr></thead><tbody>
        ${(p.responsibleMembers||[]).map(x=>`<tr><td><b>${esc(x.memberId)}</b></td><td>${esc(x.name)}</td><td>${esc(x.mobile||'—')}</td><td>${esc(x.role||'Responsible Member')}</td><td>${esc(x.notes||'—')}</td><td><button class="mini danger" onclick="deleteSocialResponsibleMember('${p.id}','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6">No responsible members assigned.</td></tr>'}
        </tbody></table></div>
      </div>
      <div id="social-documents-tab" class="social-tab-panel">
        <div class="profile-block-head"><div><h3>Photos / Documents</h3><p>Project photos, permission, beneficiary list, report, quotation or supporting files.</p></div><button class="mini" onclick="uploadSocialDocument('${p.id}')">+ Upload</button></div>
        <div class="social-doc-upload"><select id="socialDocType"><option>Project Photo</option><option>Permission / Approval</option><option>Beneficiary List</option><option>Project Report</option><option>Quotation / Estimate</option><option>Supporting Document</option><option>Other Document</option></select><input id="socialDocName" placeholder="Display name"><input id="socialDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></div>
        <div class="document-list">${(p.documents||[]).map(d=>`<div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB</small></div><a class="mini" href="${esc(d.path)}" target="_blank">Open</a><button class="mini danger" onclick="deleteSocialDocument('${p.id}','${d.id}')">Delete</button></div>`).join('')||'<div class="empty-docs">No photos/documents uploaded.</div>'}</div>
      </div>`;
    $('#socialProjectViewModal').classList.add('show');
  }catch(err){alert(err.message)}
}
function switchSocialTab(btn,id){
  const box=$('#socialProjectViewBody');
  box.querySelectorAll('.event-tabs button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
  box.querySelectorAll('.social-tab-panel').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');
}
function closeSocialProjectView(){$('#socialProjectViewModal').classList.remove('show')}
async function editSocialProject(id){
  const p=await api(`/api/social-projects/${encodeURIComponent(id)}`);
  const projectName=prompt('Project Name:',p.projectName);if(projectName===null)return;
  const budget=prompt('Budget:',String(p.budget||0));if(budget===null)return;
  const beneficiaryCount=prompt('Beneficiary Count:',String(p.beneficiaryCount||0));if(beneficiaryCount===null)return;
  const status=prompt('Status: Planned / Ongoing / Completed / Cancelled',p.status);if(status===null)return;
  const location=prompt('Location:',p.location||'');if(location===null)return;
  try{
    await api(`/api/social-projects/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({projectName,budget:Number(budget),beneficiaryCount:Number(beneficiaryCount),status,location})});
    toast('Social project updated');await loadAll();await viewSocialProject(id);
  }catch(err){alert(err.message)}
}
function openSocialExpense(id){
  $('#socialExpenseForm').innerHTML=`
    <div class="full info-strip"><b>Linked Accounting:</b> Project expense is posted automatically to Expense Management + Cash/Bank ledger and reflected under the relevant fund purpose.</div>
    <label>Expense Category<select name="category">${EXPENSE_CATEGORIES.map(x=>`<option ${x==='Social Work'?'selected':''}>${esc(x)}</option>`).join('')}</select></label>
    <label>Paid To<input name="paidTo" required></label><label>Amount<input type="number" step="0.01" name="amount" required></label>
    <label>Payment Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Date<input type="date" name="date" value="${dateToday()}" required></label><label>Approved By / Manual Note<input name="approvedBy"></label>
    <label>Bill / Invoice<input id="socialExpenseBill" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></label>
    <label class="full">Purpose<textarea name="purpose" required></textarea></label><label class="full">Remarks<textarea name="remarks"></textarea></label>
    <div class="actions"><button class="btn primary">Save Expense & Generate Voucher</button></div>`;
  $('#socialExpenseModal').classList.add('show');
  $('#socialExpenseForm').onsubmit=async e=>{
    e.preventDefault();
    let data=Object.fromEntries(new FormData(e.target));data.amount=Number(data.amount);
    data=await applyFinancialApprovalPrompt(data,'SocialWorkExpense');if(!data)return;
    const bill=$('#socialExpenseBill').files[0];
    try{
      if(bill){if(bill.size>10*1024*1024)throw new Error('Bill maximum 10 MB.');data.billFilename=bill.name;data.billDataUrl=await fileToDataURL(bill)}
      const r=await api(`/api/social-projects/${encodeURIComponent(id)}/expense`,{method:'POST',body:JSON.stringify(data)});
      closeSocialExpense();toast(`Expense voucher ${r.id} generated`);await loadAll();await viewSocialProject(id);printExpenseVoucher(r.id);
    }catch(err){alert(err.message)}
  };
}
function closeSocialExpense(){$('#socialExpenseModal').classList.remove('show')}
async function addSocialResponsibleMember(id){
  const available=(cache.members||[]).filter(x=>x.status==='Active');
  if(!available.length)return alert('No Active Member available.');
  const hint=available.slice(0,12).map(x=>`${x.id}: ${x.name}`).join('\n');
  const memberId=prompt(`Enter Member ID:\n\n${hint}`,'');if(memberId===null)return;
  const role=prompt('Responsibility / Role:','Project Coordinator')||'Responsible Member';
  const notes=prompt('Notes:','')||'';
  try{
    await api(`/api/social-projects/${encodeURIComponent(id)}/responsible-members`,{method:'POST',body:JSON.stringify({memberId:memberId.trim(),role,notes})});
    toast('Responsible member assigned');await loadAll();await viewSocialProject(id);
  }catch(err){alert(err.message)}
}
async function deleteSocialResponsibleMember(projectId,responsibleId){
  if(!confirm('Remove this responsible member from project?'))return;
  try{
    await api(`/api/social-projects/${encodeURIComponent(projectId)}/responsible-members/${encodeURIComponent(responsibleId)}`,{method:'DELETE'});
    toast('Responsible member removed');await loadAll();await viewSocialProject(projectId);
  }catch(err){alert(err.message)}
}
async function uploadSocialDocument(id){
  const f=$('#socialDocFile')?.files?.[0];if(!f)return alert('Select a photo/document.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/social-projects/${encodeURIComponent(id)}/document`,{method:'POST',body:JSON.stringify({filename:f.name,dataUrl,documentType:$('#socialDocType').value,displayName:$('#socialDocName').value||f.name})});
    toast('Social work file uploaded');await loadAll();await viewSocialProject(id);
  }catch(err){alert(err.message)}
}
async function deleteSocialDocument(projectId,docId){
  if(!confirm('Delete this project file?'))return;
  try{
    await api(`/api/social-projects/${encodeURIComponent(projectId)}/documents/${encodeURIComponent(docId)}`,{method:'DELETE'});
    toast('File deleted');await loadAll();await viewSocialProject(projectId);
  }catch(err){alert(err.message)}
}

function assetConditionBadge(condition){
  const cls=String(condition||'Good').toLowerCase().replace(/\s+/g,'-');
  return `<span class="asset-condition-badge ${cls}">${esc(condition||'Good')}</span>`;
}
function assetStatusBadge(status){
  const cls=String(status||'In Use').toLowerCase().replace(/\s+/g,'-');
  return `<span class="asset-status-badge ${cls}">${esc(status||'In Use')}</span>`;
}
let approvalDraftRules=[];
function renderApprovalSystem(){
  const d=cache.approvalPolicy;if(!d)return;
  const p=d.policy||{},c=d.committee;
  $('#approvalStats').innerHTML=[
    ['POLICY STATUS',p.enabled?'ENABLED':'DISABLED',p.enabled?'Enforcement active':'Review sample rules before enabling'],
    ['POLICY',esc(p.policyName||'Financial Approval Policy'),`Revision ${Number(p.revision||1)}`],
    ['EFFECTIVE DATE',p.effectiveDate||'Not set',p.updatedAt?`Updated ${fmtDate(p.updatedAt)}`:''],
    ['CURRENT COMMITTEE',c?esc(c.name):'None',c?`${esc(c.termStart||'')} → ${esc(c.termEnd||'')}`:'Designation approval unavailable'],
    ['RULES',(p.rules||[]).length,'Final slab must be No Limit']
  ].map(x=>`<div class="approval-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#approvalRuleRows').innerHTML=(p.rules||[]).map((r,i)=>{
    const prev=i?Number(p.rules[i-1].upTo||0):0;
    const range=r.upTo===null||r.upTo===''?`Above ${money(prev)}`:`${money(i?prev+0.01:0)} – ${money(r.upTo)}`;
    return `<tr><td><b>${range}</b></td><td>${(r.designations||[]).length?(r.designations||[]).map(x=>`<span class="approval-role-chip">${esc(x)}</span>`).join(' '):'—'}</td><td>${r.requireResolution?'<span class="approval-resolution-chip">Required</span>':'Not Required'}</td></tr>`;
  }).join('');

  $('#approvalModuleBadges').innerHTML=Object.entries(APPROVAL_CONTEXTS).map(([k,label])=>`<span class="${p.modules?.[k]!==false?'on':'off'}">${p.modules?.[k]!==false?'✓':'×'} ${esc(label)}</span>`).join('');

  $('#recentApprovalRows').innerHTML=(d.recentApprovals||[]).map(x=>{
    const a=x.approval||{},approved=(a.approvers||[]).map(y=>`${y.designation}: ${y.memberName}`).join(' + ')||a.resolutionApprovedBy||'Resolution';
    return `<tr><td>${esc(fmtDate(x.date||'—'))}</td><td>${esc(x.type)}</td><td><b>${esc(x.id)}</b></td><td>${esc(x.subject||'')}</td><td>${money(x.amount||0)}</td><td>${esc(a.rangeText||'')}</td><td>${esc(approved)}</td><td>${esc(a.resolutionNo||'—')}</td></tr>`;
  }).join('')||'<tr><td colspan="8">No policy-enforced approval records yet.</td></tr>';
}
function openApprovalPolicyForm(){
  const p=cache.approvalPolicy?.policy||{};
  approvalDraftRules=(p.rules||[]).map(x=>({...x,designations:[...(x.designations||[])]}));
  $('#approvalPolicyForm').innerHTML=`
    <div class="approval-policy-grid">
      <label>Policy Name<input name="policyName" value="${esc(p.policyName||'Financial Approval Policy')}" required></label>
      <label>Effective Date<input type="date" name="effectiveDate" value="${esc(p.effectiveDate||'')}"></label>
      <label class="approval-enable"><input type="checkbox" name="enabled" ${p.enabled?'checked':''}> Enable server-side Financial Approval enforcement</label>
    </div>
    <div class="approval-policy-warning"><b>Sample only:</b> Change the ₹2,000 / ₹10,000 limits according to the organization's approved policy.</div>
    <h3>Modules</h3>
    <div class="approval-module-editor">${Object.entries(APPROVAL_CONTEXTS).map(([k,label])=>`<label><input type="checkbox" name="module_${k}" ${p.modules?.[k]!==false?'checked':''}> ${esc(label)}</label>`).join('')}</div>
    <div class="approval-rule-editor-head"><h3>Approval Slabs</h3><button type="button" class="mini" onclick="addApprovalPolicyRule()">+ Add Slab</button></div>
    <div class="table-wrap"><table class="approval-rule-editor"><thead><tr><th>Up To Amount</th><th>Required Designation(s)</th><th>Resolution</th><th></th></tr></thead><tbody id="approvalRuleEditorRows"></tbody></table></div>
    <div class="approval-policy-note">Limits must be increasing. Last row must be <b>No Limit</b>.</div>
    <div class="actions"><button class="btn primary">Save Approval Policy</button></div>`;
  renderApprovalRuleEditor();
  $('#approvalPolicyModal').classList.add('show');
  $('#approvalPolicyForm').onsubmit=async e=>{
    e.preventDefault();const f=e.target,fd=new FormData(f);
    const rules=[...f.querySelectorAll('#approvalRuleEditorRows tr')].map((tr,i)=>({
      id:tr.dataset.ruleId||`APR-RULE-${String(i+1).padStart(3,'0')}`,
      upTo:tr.querySelector('.approval-up-to').value===''?null:Number(tr.querySelector('.approval-up-to').value),
      designations:[...tr.querySelector('.approval-designations').selectedOptions].map(o=>o.value),
      requireResolution:tr.querySelector('.approval-require-resolution').checked
    }));
    const modules={};Object.keys(APPROVAL_CONTEXTS).forEach(k=>modules[k]=f.querySelector(`[name="module_${k}"]`).checked);
    try{
      await api('/api/approval-policy',{method:'POST',body:JSON.stringify({enabled:f.enabled.checked,policyName:fd.get('policyName'),effectiveDate:fd.get('effectiveDate'),modules,rules,updatedBy:cache.master?.ownerName||'Administrator'})});
      closeApprovalPolicyForm();toast('Approval Policy updated');await loadAll();
    }catch(err){alert(err.message)}
  };
}
function renderApprovalRuleEditor(){
  const tbody=$('#approvalRuleEditorRows');if(!tbody)return;
  tbody.innerHTML=approvalDraftRules.map((r,i)=>`<tr data-rule-id="${esc(r.id||'')}">
    <td><input class="approval-up-to" type="number" min="0" step="0.01" value="${r.upTo===null||r.upTo===''?'':Number(r.upTo)}" placeholder="No Limit"></td>
    <td><select class="approval-designations" multiple size="5">${COMMITTEE_DESIGNATIONS.filter(x=>x!=='General Member').map(d=>`<option value="${esc(d)}" ${(r.designations||[]).includes(d)?'selected':''}>${esc(d)}</option>`).join('')}</select></td>
    <td><label class="declaration-check"><input class="approval-require-resolution" type="checkbox" ${r.requireResolution?'checked':''}> Required</label></td>
    <td><button type="button" class="mini danger" onclick="removeApprovalPolicyRule(${i})">Delete</button></td>
  </tr>`).join('');
}
function addApprovalPolicyRule(){approvalDraftRules.push({id:'',upTo:null,designations:['Treasurer'],requireResolution:false});renderApprovalRuleEditor()}
function removeApprovalPolicyRule(i){if(approvalDraftRules.length<=1)return alert('At least one slab is required.');approvalDraftRules.splice(i,1);renderApprovalRuleEditor()}
function closeApprovalPolicyForm(){$('#approvalPolicyModal').classList.remove('show')}

function meetingStatusBadge(status){
  const cls=String(status||'Draft').toLowerCase();
  return `<span class="meeting-status-badge ${cls}">${esc(status||'Draft')}</span>`;
}
function votingBadge(result){
  const cls=String(result||'Not Voted').toLowerCase().replace(/\s+/g,'-');
  return `<span class="voting-badge ${cls}">${esc(result||'Not Voted')}</span>`;
}
function renderMeetings(){
  const d=cache.meetings;if(!d)return;
  const s=d.summary||{};
  $('#meetingStats').innerHTML=[
    ['TOTAL MEETINGS',s.totalMeetings||0,`Draft ${s.draft||0} · Finalized ${s.finalized||0}`],
    ['RESOLUTIONS',s.totalResolutions||0,`Passed ${s.passed||0}`],
    ['PASSED / UNANIMOUS',s.passed||0,'Available for governance links'],
    ['REJECTED',s.rejected||0,'Voting result retained'],
    ['ATTENDANCE',s.totalAttendance||0,'Total present-member entries']
  ].map(x=>`<div class="meeting-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#meetingRows').innerHTML=(d.meetings||[]).map(m=>`
    <tr>
      <td><b>${esc(m.meetingNo)}</b></td><td>${esc(fmtDate(m.date))}</td>
      <td><b>${esc(m.title)}</b><br><small>${esc((m.agenda||'').slice(0,90))}</small></td>
      <td>${esc(m.committeeName||'—')}</td><td>${m.attendeeCount||0}</td><td>${m.resolutionCount||0}</td><td>${m.passedResolutions||0}</td>
      <td>${esc(m.approvedBy||'—')}</td><td>${meetingStatusBadge(m.status)}</td><td>${m.documentCount||0}</td>
      <td><button class="mini" onclick="viewMeeting('${m.id}')">Open</button></td>
    </tr>`).join('')||'<tr><td colspan="11">No meetings in this Financial Year.</td></tr>';

  $('#usableResolutionRows').innerHTML=(d.resolutions||[]).map(r=>`
    <tr><td><b>${esc(r.resolutionNo)}</b></td><td>${esc(r.meetingNo)}<br><small>${esc(r.meetingTitle)}</small></td><td>${esc(fmtDate(r.date))}</td><td>${esc(r.category)}</td><td>${esc(r.title)}</td><td>${votingBadge(r.votingResult)}</td><td>${esc(r.approvedBy||'—')}</td></tr>
  `).join('')||'<tr><td colspan="7">No finalized Passed/Unanimous resolutions available.</td></tr>';
}
function openMeetingForm(id=''){
  const m=id?(cache.meetings?.meetings||[]).find(x=>x.id===id):null;
  if(m?.status==='Finalized')return alert('Finalized meeting is read-only.');
  $('#meetingForm').innerHTML=`
    ${m?`<div class="full info-strip"><b>Meeting No.:</b> ${esc(m.meetingNo)}</div>`:'<div class="full info-strip"><b>Meeting No.</b> will be generated automatically Financial Year-wise.</div>'}
    <label>Meeting Date<input type="date" name="date" value="${esc(m?.date||dateToday())}" required></label>
    <label>Meeting Title<input name="title" value="${esc(m?.title||'')}" required placeholder="Executive Committee Meeting"></label>
    <label class="full">Agenda<textarea name="agenda" required>${esc(m?.agenda||'')}</textarea></label>
    <label class="full">Discussion<textarea name="discussion">${esc(m?.discussion||'')}</textarea></label>
    <label class="full">Decisions<textarea name="decisions">${esc(m?.decisions||'')}</textarea></label>
    <label>Approved By<input name="approvedBy" value="${esc(m?.approvedBy||'')}" placeholder="President / Secretary / Chairperson"></label>
    <label class="full">Notes<textarea name="notes">${esc(m?.notes||'')}</textarea></label>
    <div class="actions"><button class="btn primary">${m?'Update Meeting':'Create Meeting'}</button></div>`;
  $('#meetingFormModal').classList.add('show');
  $('#meetingForm').onsubmit=async e=>{
    e.preventDefault();const data=Object.fromEntries(new FormData(e.target));data.financialYear=activeFY;
    try{
      const row=m?await api(`/api/meetings/${encodeURIComponent(m.id)}`,{method:'PUT',body:JSON.stringify(data)}):await api('/api/meetings',{method:'POST',body:JSON.stringify(data)});
      closeMeetingForm();toast(m?'Meeting updated':`Meeting ${row.meetingNo} created`);await loadAll();await viewMeeting(row.id);
    }catch(err){alert(err.message)}
  };
}
function closeMeetingForm(){$('#meetingFormModal').classList.remove('show')}
async function viewMeeting(id){
  try{
    const m=await api(`/api/meetings/${encodeURIComponent(id)}`);
    const locked=m.status==='Finalized';
    $('#meetingViewBody').innerHTML=`
      <div class="meeting-view-head">
        <div><span class="member-id-chip">${esc(m.meetingNo)}</span><h2>${esc(m.title)}</h2><p>${esc(fmtDate(m.date))} · ${esc(m.committeeName||'No committee snapshot')} · ${meetingStatusBadge(m.status)}</p></div>
        <div class="head-actions">${!locked?`<button class="btn" onclick="openMeetingForm('${m.id}')">Edit Minutes</button><button class="btn primary" onclick="finalizeMeeting('${m.id}')">Finalize Meeting</button>`:''}<button class="btn" onclick="printMeetingMinutes('${m.id}')">Print Minutes</button></div>
      </div>
      ${locked?`<div class="finalized-meeting-banner"><b>✓ Finalized Governance Record</b><span>Finalized by ${esc(m.finalizedBy||m.approvedBy||'—')} ${m.finalizedAt?`· ${fmtDateTime(m.finalizedAt)}`:''}. Record is read-only.</span></div>`:''}
      <div class="profile-detail-grid">${detail('Agenda',m.agenda,'full')}${detail('Discussion',m.discussion||'Not recorded','full')}${detail('Decisions',m.decisions||'Not recorded','full')}${detail('Approved By',m.approvedBy)}${detail('Current Committee Snapshot',m.committeeName||'—')}${detail('Notes',m.notes,'full')}</div>
      <div class="meeting-tabs">
        <button class="active" onclick="switchMeetingTab(this,'meeting-attendance-tab')">Attendance (${(m.attendees||[]).length})</button>
        <button onclick="switchMeetingTab(this,'meeting-resolution-tab')">Resolutions (${(m.resolutions||[]).length})</button>
        <button onclick="switchMeetingTab(this,'meeting-doc-tab')">Minutes / Documents (${(m.documents||[]).length})</button>
      </div>
      <div id="meeting-attendance-tab" class="meeting-tab-panel active">
        <div class="profile-block-head"><div><h3>Present Members</h3><p>Meeting attendance register.</p></div>${!locked?`<button class="mini" onclick="openMeetingAttendeeForm('${m.id}')">+ Add Present Member</button>`:''}</div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Member ID</th><th>Name</th><th>Mobile</th><th>Role</th><th>Notes</th><th></th></tr></thead><tbody>
        ${(m.attendees||[]).map(a=>`<tr><td><b>${esc(a.memberId)}</b></td><td>${esc(a.memberName)}</td><td>${esc(a.memberMobile||'—')}</td><td>${esc(a.role||'Present Member')}</td><td>${esc(a.notes||'—')}</td><td>${!locked?`<button class="mini danger" onclick="deleteMeetingAttendee('${m.id}','${a.id}')">Remove</button>`:'Recorded'}</td></tr>`).join('')||'<tr><td colspan="6">No attendance recorded.</td></tr>'}
        </tbody></table></div>
      </div>
      <div id="meeting-resolution-tab" class="meeting-tab-panel">
        <div class="profile-block-head"><div><h3>Resolutions</h3><p>Resolution No., voting and cross-module link status.</p></div>${!locked?`<button class="mini" onclick="openResolutionForm('${m.id}')">+ Add Resolution</button>`:''}</div>
        <div class="resolution-card-list">${(m.resolutions||[]).map(r=>`
          <div class="resolution-card">
            <div class="resolution-card-head"><div><span>${esc(r.resolutionNo)}</span><h4>${esc(r.title)}</h4></div>${votingBadge(r.votingResult)}</div>
            <div class="resolution-meta"><b>${esc(r.category)}</b> · Approved By ${esc(r.approvedBy||'—')} · Votes For ${Number(r.votesFor||0)} / Against ${Number(r.votesAgainst||0)} / Abstain ${Number(r.abstain||0)}</div>
            <p>${esc(r.decision)}</p>${r.notes?`<small>${esc(r.notes)}</small>`:''}
            <div class="resolution-links"><b>Linked Records:</b> ${(r.links||[]).length?(r.links||[]).map(x=>`<span>${esc(x.type)}: ${esc(x.id)}</span>`).join(''):'<span>None</span>'}</div>
            ${!locked && !(r.links||[]).length?`<button class="mini danger" onclick="deleteMeetingResolution('${m.id}','${r.id}')">Delete Resolution</button>`:''}
          </div>`).join('')||'<div class="empty-docs">No resolutions recorded.</div>'}</div>
      </div>
      <div id="meeting-doc-tab" class="meeting-tab-panel">
        <div class="profile-block-head"><div><h3>Minutes PDF / Documents</h3><p>Minutes, notice, attendance sheet, signed resolution or supporting files.</p></div>${!locked?`<button class="mini" onclick="uploadMeetingDocument('${m.id}')">+ Upload</button>`:''}</div>
        ${!locked?`<div class="meeting-doc-upload"><select id="meetingDocType"><option>Minutes PDF / Document</option><option>Meeting Notice</option><option>Attendance Sheet</option><option>Signed Resolution</option><option>Agenda Document</option><option>Supporting Document</option></select><input id="meetingDocName" placeholder="Display name"><input id="meetingDocFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"></div>`:''}
        <div class="document-list">${(m.documents||[]).map(d=>`<div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(d.name)}</b><small>${esc(d.type)} · ${Math.max(1,Math.round((d.size||0)/1024))} KB</small></div><a class="mini" href="${esc(d.path)}" target="_blank">Open</a>${!locked?`<button class="mini danger" onclick="deleteMeetingDocument('${m.id}','${d.id}')">Delete</button>`:''}</div>`).join('')||'<div class="empty-docs">No minutes/documents uploaded.</div>'}</div>
      </div>`;
    $('#meetingViewModal').classList.add('show');
  }catch(err){alert(err.message)}
}
function switchMeetingTab(btn,id){
  const box=$('#meetingViewBody');box.querySelectorAll('.meeting-tabs button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
  box.querySelectorAll('.meeting-tab-panel').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');
}
function closeMeetingView(){$('#meetingViewModal').classList.remove('show')}
function openMeetingAttendeeForm(id){
  const members=(cache.members||[]).filter(x=>x.status==='Active');
  if(!members.length)return alert('No Active Member available.');
  $('#meetingAttendeeForm').innerHTML=`
    <label>Member<select name="memberId">${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Attendance Role<input name="role" value="Present Member"></label>
    <label class="full">Notes<textarea name="notes"></textarea></label>
    <div class="actions"><button class="btn primary">Add to Attendance</button></div>`;
  $('#meetingAttendeeModal').classList.add('show');
  $('#meetingAttendeeForm').onsubmit=async e=>{
    e.preventDefault();
    try{await api(`/api/meetings/${encodeURIComponent(id)}/attendees`,{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});closeMeetingAttendeeForm();toast('Present member added');await loadAll();await viewMeeting(id)}catch(err){alert(err.message)}
  };
}
function closeMeetingAttendeeForm(){$('#meetingAttendeeModal').classList.remove('show')}
async function deleteMeetingAttendee(meetingId,attendeeId){
  if(!confirm('Remove this attendance entry?'))return;
  try{await api(`/api/meetings/${encodeURIComponent(meetingId)}/attendees/${encodeURIComponent(attendeeId)}`,{method:'DELETE'});toast('Attendance entry removed');await loadAll();await viewMeeting(meetingId)}catch(err){alert(err.message)}
}
function openResolutionForm(meetingId){
  $('#resolutionForm').innerHTML=`
    <label>Resolution Category<select name="category">${RESOLUTION_CATEGORIES.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Voting Result<select name="votingResult">${VOTING_RESULTS.map(x=>`<option ${x==='Passed'?'selected':''}>${esc(x)}</option>`).join('')}</select></label>
    <label class="full">Resolution Title<input name="title" required></label>
    <label class="full">Decision / Resolution Text<textarea name="decision" required></textarea></label>
    <label>Votes For<input type="number" min="0" name="votesFor" value="0"></label>
    <label>Votes Against<input type="number" min="0" name="votesAgainst" value="0"></label>
    <label>Abstain<input type="number" min="0" name="abstain" value="0"></label>
    <label>Approved By<input name="approvedBy" required></label>
    <label class="full">Notes<textarea name="notes"></textarea></label>
    <div class="actions"><button class="btn primary">Save Resolution</button></div>`;
  $('#resolutionFormModal').classList.add('show');
  $('#resolutionForm').onsubmit=async e=>{
    e.preventDefault();const data=Object.fromEntries(new FormData(e.target));data.votesFor=Number(data.votesFor||0);data.votesAgainst=Number(data.votesAgainst||0);data.abstain=Number(data.abstain||0);
    try{const r=await api(`/api/meetings/${encodeURIComponent(meetingId)}/resolutions`,{method:'POST',body:JSON.stringify(data)});closeResolutionForm();toast(`Resolution ${r.resolutionNo} saved`);await loadAll();await viewMeeting(meetingId)}catch(err){alert(err.message)}
  };
}
function closeResolutionForm(){$('#resolutionFormModal').classList.remove('show')}
async function deleteMeetingResolution(meetingId,resolutionId){
  if(!confirm('Delete this draft resolution?'))return;
  try{await api(`/api/meetings/${encodeURIComponent(meetingId)}/resolutions/${encodeURIComponent(resolutionId)}`,{method:'DELETE'});toast('Resolution deleted');await loadAll();await viewMeeting(meetingId)}catch(err){alert(err.message)}
}
async function uploadMeetingDocument(id){
  const f=$('#meetingDocFile')?.files?.[0];if(!f)return alert('Select a minutes/document file.');
  try{const dataUrl=await fileToDataURL(f);await api(`/api/meetings/${encodeURIComponent(id)}/document`,{method:'POST',body:JSON.stringify({filename:f.name,dataUrl,documentType:$('#meetingDocType').value,displayName:$('#meetingDocName').value||f.name})});toast('Meeting document uploaded');await loadAll();await viewMeeting(id)}catch(err){alert(err.message)}
}
async function deleteMeetingDocument(meetingId,docId){
  if(!confirm('Delete this meeting document?'))return;
  try{await api(`/api/meetings/${encodeURIComponent(meetingId)}/documents/${encodeURIComponent(docId)}`,{method:'DELETE'});toast('Meeting document deleted');await loadAll();await viewMeeting(meetingId)}catch(err){alert(err.message)}
}
async function finalizeMeeting(id){
  const m=await api(`/api/meetings/${encodeURIComponent(id)}`);
  const approvedBy=prompt('Approved By:',m.approvedBy||cache.master?.ownerName||'');if(approvedBy===null)return;
  const finalizedBy=prompt('Finalized / Recorded By:',approvedBy);if(finalizedBy===null)return;
  if(!confirm('Finalize this meeting? After finalization, minutes, attendance, resolutions and documents become read-only.'))return;
  try{await api(`/api/meetings/${encodeURIComponent(id)}/finalize`,{method:'POST',body:JSON.stringify({approvedBy,finalizedBy})});toast('Meeting finalized');await loadAll();await viewMeeting(id)}catch(err){alert(err.message)}
}
async function printMeetingMinutes(id){
  try{
    const m=await api(`/api/meetings/${encodeURIComponent(id)}`),org=cache.master||{},w=window.open('','_blank','width=900,height=850');
    const logo=org.logoPath?`<img src="${esc(org.logoPath)}" style="max-height:65px;max-width:100px;object-fit:contain">`:'';
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(m.meetingNo)} Minutes</title><style>
    body{font-family:Arial,sans-serif;padding:28px;color:#111}.sheet{max-width:820px;margin:auto}.head{display:flex;gap:15px;align-items:center;border-bottom:2px solid #111;padding-bottom:12px}.head h1{margin:0;font-size:21px}.head p{margin:3px 0;font-size:12px}.title{text-align:center;margin:18px 0}.meta{display:grid;grid-template-columns:1fr 1fr;gap:8px 20px}.box{border:1px solid #bbb;padding:12px;margin:12px 0}.box h3{margin:0 0 8px;font-size:14px}.box p{white-space:pre-wrap;line-height:1.5}.tbl{width:100%;border-collapse:collapse;font-size:12px}.tbl th,.tbl td{border:1px solid #bbb;padding:7px;text-align:left}.res{page-break-inside:avoid;border:1px solid #777;padding:11px;margin:10px 0}.res h4{margin:0 0 6px}.sign{display:flex;justify-content:space-between;margin-top:45px}.sign div{border-top:1px solid #111;padding-top:5px;min-width:180px;text-align:center}@media print{button{display:none}}</style></head><body><div class="sheet">
    <div class="head">${logo}<div><h1>${esc(org.organizationName||'Organization')}</h1><p>${esc(org.registeredAddress||org.officeAddress||'')}</p></div></div>
    <div class="title"><h2>MEETING MINUTES</h2><b>${esc(m.meetingNo)}</b></div>
    <div class="meta"><div><b>Date:</b> ${esc(fmtDate(m.date))}</div><div><b>Meeting:</b> ${esc(m.title)}</div><div><b>Committee:</b> ${esc(m.committeeName||'—')}</div><div><b>Approved By:</b> ${esc(m.approvedBy||'—')}</div></div>
    <div class="box"><h3>Agenda</h3><p>${esc(m.agenda)}</p></div>
    <div class="box"><h3>Present Members</h3><table class="tbl"><tr><th>Member ID</th><th>Name</th><th>Role</th></tr>${(m.attendees||[]).map(a=>`<tr><td>${esc(a.memberId)}</td><td>${esc(a.memberName)}</td><td>${esc(a.role||'Present Member')}</td></tr>`).join('')}</table></div>
    <div class="box"><h3>Discussion</h3><p>${esc(m.discussion||'')}</p></div><div class="box"><h3>Decisions</h3><p>${esc(m.decisions||'')}</p></div>
    <div class="box"><h3>Resolutions</h3>${(m.resolutions||[]).map(r=>`<div class="res"><h4>${esc(r.resolutionNo)} — ${esc(r.title)}</h4><b>${esc(r.category)} · Voting: ${esc(r.votingResult)}</b><p>${esc(r.decision)}</p><small>Votes For ${Number(r.votesFor||0)} · Against ${Number(r.votesAgainst||0)} · Abstain ${Number(r.abstain||0)} · Approved By ${esc(r.approvedBy||'—')}</small></div>`).join('')||'No resolutions.'}</div>
    <div class="sign"><div>Chairperson / President</div><div>Secretary / Minutes Recorder</div></div></div><div style="text-align:center;margin-top:15px"><button onclick="window.print()">Print / Save as PDF</button></div></body></html>`);
    w.document.close();
  }catch(err){alert(err.message)}
}

function committeeStatusBadge(status){
  const cls=String(status||'Current').toLowerCase();
  return `<span class="committee-status-badge ${cls}">${esc(status||'Current')}</span>`;
}
function committeeRoleBadge(status){
  const cls=String(status||'Active').toLowerCase();
  return `<span class="committee-role-badge ${cls}">${esc(status||'Active')}</span>`;
}
function renderCommittee(){
  const d=cache.committees;if(!d)return;
  const s=d.summary||{},c=d.current;
  $('#committeeStats').innerHTML=[
    ['CURRENT COMMITTEE',c?esc(c.name):'None',c?c.id:'Form a new committee'],
    ['CURRENT TERM',c?`${esc(c.termStart)} → ${esc(c.termEnd)}`:'—',c?.termLabel||''],
    ['ACTIVE ROLES',s.currentRoles||0,c?`${c.summary?.officeBearers||0} office bearer(s)`:'No current committee'],
    ['ARCHIVED COMMITTEES',s.archivedCommittees||0,'History permanently retained'],
    ['TOTAL COMMITTEES',s.totalCommittees||0,'Current + archived']
  ].map(x=>`<div class="committee-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#newCommitteeBtn').disabled=!!c;
  $('#newCommitteeBtn').title=c?'Archive the Current Committee before forming a new one':'Form New Committee';

  if(!c){
    $('#currentCommitteeArea').innerHTML=`<div class="card section no-current-committee"><h3>No Current Committee</h3><p>Old committees may remain archived while a new Current Committee is created.</p><button class="btn primary" onclick="openCommitteeForm()">+ Form New Committee</button></div>`;
  }else{
    const expired=s.currentTermExpired;
    $('#currentCommitteeArea').innerHTML=`
      ${expired?`<div class="committee-expiry-warning"><b>⚠ Committee Term Ended</b><span>Term End: ${esc(c.termEnd)}. Archive this committee before forming the next committee.</span></div>`:''}
      <div class="card section current-committee-card">
        <div class="current-committee-head">
          <div><span class="member-id-chip">${esc(c.id)}</span><h2>${esc(c.name)}</h2><p>Formation ${esc(fmtDate(c.formationDate))} · Term ${esc(c.termStart)} → ${esc(c.termEnd)} ${c.termLabel?`· ${esc(c.termLabel)}`:''}</p></div>
          <div class="head-actions"><button class="btn" onclick="openCommitteeForm('${c.id}')">Edit Committee</button><button class="btn primary" onclick="openCommitteeMemberForm('${c.id}')">+ Assign Member</button><button class="btn reject" onclick="archiveCommittee('${c.id}')">Archive Committee</button></div>
        </div>
        ${c.notes?`<div class="committee-note">${esc(c.notes)}</div>`:''}
        <div class="committee-structure-grid">
          ${['President','Vice President','Secretary','Joint Secretary','Treasurer'].map(des=>{
            const rows=(c.members||[]).filter(x=>x.designation===des && x.roleStatus==='Active');
            return `<div class="committee-position"><span>${esc(des)}</span>${rows.length?rows.map(x=>`<b>${esc(x.memberName)}</b><small>${esc(x.memberId)} · ${esc(fmtDate(x.startDate))}${x.endDate?` → ${esc(fmtDate(x.endDate))}`:''}</small>`).join(''):'<em>Vacant</em>'}</div>`;
          }).join('')}
        </div>
        <div class="committee-section-head"><div><h3>Committee Member / Designation Register</h3><p>Role tenure history with Start Date and End Date.</p></div></div>
        <div class="table-wrap"><table><thead><tr><th>Member ID</th><th>Member</th><th>Designation</th><th>Start Date</th><th>End Date</th><th>Role Status</th><th>Notes</th><th>Action</th></tr></thead><tbody>
          ${(c.members||[]).map(x=>`<tr><td><b>${esc(x.memberId)}</b></td><td>${esc(x.memberName)}<br><small>${esc(x.memberMobile||'')}</small></td><td><b>${esc(x.designation)}</b></td><td>${esc(fmtDate(x.startDate||'—'))}</td><td>${esc(fmtDate(x.endDate||'—'))}</td><td>${committeeRoleBadge(x.roleStatus)}</td><td>${esc(x.notes||x.endReason||'—')}</td><td>${x.roleStatus==='Active'?`<button class="mini danger" onclick="endCommitteeRole('${c.id}','${x.id}')">End Role</button>`:'History'}</td></tr>`).join('')||'<tr><td colspan="8">No committee members assigned yet.</td></tr>'}
        </tbody></table></div>
      </div>`;
  }

  $('#archivedCommitteeRows').innerHTML=(d.archived||[]).map(x=>`
    <tr>
      <td><b>${esc(x.id)}</b></td>
      <td><b>${esc(x.name)}</b></td>
      <td>${esc(fmtDate(x.formationDate||'—'))}</td>
      <td>${esc(x.termStart||'—')} → ${esc(x.termEnd||'—')}<br><small>${esc(x.termLabel||'')}</small></td>
      <td>${x.summary?.totalRoles||0}</td>
      <td>${x.archivedAt?fmtDate(x.archivedAt):'—'}</td>
      <td>${esc(x.archivedBy||'—')}</td>
      <td>${esc(x.archiveReason||'—')}</td>
      <td><button class="mini" onclick="viewCommittee('${x.id}')">Open History</button></td>
    </tr>`).join('')||'<tr><td colspan="9">No archived committee history yet.</td></tr>';
}
function openCommitteeForm(id=''){
  const c=id?(cache.committees?.committees||[]).find(x=>x.id===id):null;
  if(c?.status==='Archived')return alert('Archived committee history is read-only.');
  if(!c && cache.committees?.current)return alert('Archive the Current Committee before forming a new committee.');
  $('#committeeForm').innerHTML=`
    ${c?`<div class="full info-strip"><b>Committee ID:</b> ${esc(c.id)}</div>`:'<div class="full info-strip"><b>History Rule:</b> One Current Committee at a time. Previous committee must be Archived; it is never deleted.</div>'}
    <label>Committee Name<input name="name" required value="${esc(c?.name||'Executive Committee')}" placeholder="Executive Committee 2026-2028"></label>
    <label>Committee Formation Date<input type="date" name="formationDate" required value="${esc(c?.formationDate||dateToday())}"></label>
    <label>Term / Session Label<input name="termLabel" value="${esc(c?.termLabel||'')}" placeholder="2026-2028 / 2 Years"></label>
    <label>Term Start Date<input type="date" name="termStart" required value="${esc(c?.termStart||dateToday())}"></label>
    <label>Term End Date<input type="date" name="termEnd" required value="${esc(c?.termEnd||'')}"></label>
    <label class="full">Committee Formation / Resolution Notes<textarea name="notes" placeholder="General Body / Executive resolution reference">${esc(c?.notes||'')}</textarea></label>
    <div class="actions"><button class="btn primary">${c?'Update Committee':'Create Current Committee'}</button></div>`;
  $('#committeeFormModal').classList.add('show');
  $('#committeeForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    try{
      if(c)await api(`/api/committees/${encodeURIComponent(c.id)}`,{method:'PUT',body:JSON.stringify(data)});
      else await api('/api/committees',{method:'POST',body:JSON.stringify(data)});
      closeCommitteeForm();toast(c?'Committee updated':'Current Committee formed');await loadAll();
    }catch(err){alert(err.message)}
  };
}
function closeCommitteeForm(){$('#committeeFormModal').classList.remove('show')}
function openCommitteeMemberForm(committeeId){
  const c=cache.committees?.committees?.find(x=>x.id===committeeId);
  if(!c||c.status==='Archived')return alert('Current committee not available.');
  const members=(cache.members||[]).filter(x=>x.status==='Active');
  if(!members.length)return alert('No Active Member available.');
  $('#committeeMemberForm').innerHTML=`
    <div class="full info-strip"><b>${esc(c.id)} · ${esc(c.name)}</b><br>Committee Term: ${esc(c.termStart)} → ${esc(c.termEnd)}</div>
    <label>Member<select name="memberId">${members.map(m=>`<option value="${m.id}">${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Designation<select name="designation">${COMMITTEE_DESIGNATIONS.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label>
    <label>Role Start Date<input type="date" name="startDate" value="${esc(c.termStart||dateToday())}" required></label>
    <label>Role End Date<input type="date" name="endDate" value=""></label>
    <label class="full">Notes<textarea name="notes" placeholder="Election / nomination / resolution note"></textarea></label>
    <div class="actions"><button class="btn primary">Assign Committee Role</button></div>`;
  $('#committeeMemberModal').classList.add('show');
  $('#committeeMemberForm').onsubmit=async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(e.target));
    try{
      await api(`/api/committees/${encodeURIComponent(committeeId)}/members`,{method:'POST',body:JSON.stringify(data)});
      closeCommitteeMemberForm();toast('Committee member assigned');await loadAll();
    }catch(err){alert(err.message)}
  };
}
function closeCommitteeMemberForm(){$('#committeeMemberModal').classList.remove('show')}
async function endCommitteeRole(committeeId,roleId){
  const endDate=prompt('Role End Date:',dateToday());if(endDate===null)return;
  const reason=prompt('Reason / Note:','Role tenure ended')||'Role tenure ended';
  try{
    await api(`/api/committees/${encodeURIComponent(committeeId)}/members/${encodeURIComponent(roleId)}/end`,{method:'POST',body:JSON.stringify({endDate,reason})});
    toast('Committee role ended; history retained');await loadAll();
  }catch(err){alert(err.message)}
}
async function archiveCommittee(id){
  const c=cache.committees?.committees?.find(x=>x.id===id);if(!c)return;
  const archiveDate=prompt('Archive / Committee End Date:',c.termEnd||dateToday());if(archiveDate===null)return;
  const archivedBy=prompt('Archived By / Resolution Authority:',cache.master?.ownerName||'Administrator');if(archivedBy===null)return;
  const reason=prompt('Archive Reason:','Committee term completed');if(reason===null)return;
  if(!reason.trim())return alert('Archive reason is required.');
  if(!confirm(`Archive ${c.name}? This committee will become read-only history and will NOT be deleted.`))return;
  try{
    await api(`/api/committees/${encodeURIComponent(id)}/archive`,{method:'POST',body:JSON.stringify({archiveDate,archivedBy,reason})});
    toast('Committee archived; full history retained');await loadAll();
  }catch(err){alert(err.message)}
}
async function viewCommittee(id){
  try{
    const c=await api(`/api/committees/${encodeURIComponent(id)}`);
    const history=(c.history||[]).slice().reverse();
    $('#committeeViewBody').innerHTML=`
      <div class="committee-view-head"><div><span class="member-id-chip">${esc(c.id)}</span><h2>${esc(c.name)}</h2><p>${committeeStatusBadge(c.status)} · Formation ${esc(fmtDate(c.formationDate))} · Term ${esc(c.termStart)} → ${esc(c.termEnd)}</p></div></div>
      ${c.status==='Archived'?`<div class="archived-banner"><b>Archived Committee History</b><span>${esc(c.archiveReason||'Committee archived')} · By ${esc(c.archivedBy||'—')} ${c.archivedAt?`· ${fmtDateTime(c.archivedAt)}`:''}</span></div>`:''}
      <div class="profile-summary-grid">
        <div class="profile-stat"><span>Total Roles</span><b>${c.summary?.totalRoles||0}</b><small>All designations retained</small></div>
        <div class="profile-stat"><span>Office Bearers</span><b>${c.summary?.officeBearers||0}</b><small>President / VP / Secretary / JS / Treasurer</small></div>
        <div class="profile-stat"><span>Executive Members</span><b>${c.summary?.executiveMembers||0}</b><small>Executive structure</small></div>
        <div class="profile-stat"><span>General Members</span><b>${c.summary?.generalMembers||0}</b><small>Committee register</small></div>
      </div>
      <div class="profile-detail-grid">${detail('Formation Date',c.formationDate)}${detail('Term / Session',c.termLabel)}${detail('Term Start',c.termStart)}${detail('Term End',c.termEnd)}${detail('Notes',c.notes,'full')}</div>
      <div class="profile-ledger-block"><div class="profile-block-head"><div><h3>Member / Designation History</h3><p>Archived records are read-only.</p></div></div>
      <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Member ID</th><th>Member</th><th>Designation</th><th>Start</th><th>End</th><th>Status</th><th>Notes / End Reason</th></tr></thead><tbody>
      ${(c.members||[]).map(x=>`<tr><td><b>${esc(x.memberId)}</b></td><td>${esc(x.memberName)}</td><td>${esc(x.designation)}</td><td>${esc(fmtDate(x.startDate||'—'))}</td><td>${esc(fmtDate(x.endDate||'—'))}</td><td>${committeeRoleBadge(x.roleStatus)}</td><td>${esc(x.endReason||x.notes||'—')}</td></tr>`).join('')||'<tr><td colspan="7">No member records.</td></tr>'}
      </tbody></table></div></div>
      <div class="timeline-block"><h3>Committee History Log</h3>${history.map(h=>`<div class="timeline-item"><span></span><div><b>${esc(h.action||'Activity')}</b><small>${esc(h.detail||'')} · ${fmtDateTime(h.at)}</small></div></div>`).join('')||'<p>No history log.</p>'}</div>`;
    $('#committeeViewModal').classList.add('show');
  }catch(err){alert(err.message)}
}
function closeCommitteeView(){$('#committeeViewModal').classList.remove('show')}

function renderAssets(){
  const d=cache.assets;if(!d)return;
  const s=d.summary||{};
  $('#assetStats').innerHTML=[
    ['TOTAL ASSETS',s.totalAssets||0,'Organization-wide register'],
    ['PURCHASE VALUE',money(s.totalPurchaseValue||0),'Original / historical value'],
    ['IN USE',s.inUse||0,`Stored ${s.stored||0}`],
    ['UNDER REPAIR',s.underRepair||0,'Maintenance attention'],
    ['DISPOSED / LOST',`${s.disposed||0} / ${s.lost||0}`,'Inactive asset records retained'],
    ['WITH BILL',s.withBill||0,'Purchase bill attached']
  ].map(x=>`<div class="asset-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#assetCategorySummary').innerHTML=(d.categorySummary||[]).map(x=>`
    <div class="asset-category-item">
      <div><b>${esc(x.category)}</b><span>${x.count} asset(s) · ${x.inUse} in use</span></div>
      <strong>${money(x.purchaseValue)}</strong>
    </div>`).join('');

  $('#assetRows').innerHTML=(d.assets||[]).map(a=>`
    <tr>
      <td><b>${esc(a.id)}</b></td>
      <td><b>${esc(a.assetName)}</b>${a.assetDetails?`<br><small>${esc(a.assetDetails)}</small>`:''}</td>
      <td>${esc(a.category)}</td>
      <td>${esc(fmtDate(a.purchaseDate||'—'))}</td>
      <td><b>${money(a.purchaseValue||0)}</b></td>
      <td>${esc(a.currentLocation||'—')}</td>
      <td>${esc(a.custodianName||'—')}${a.custodianMemberId?`<br><small>${esc(a.custodianMemberId)}</small>`:''}</td>
      <td>${assetConditionBadge(a.condition)}</td>
      <td>${assetStatusBadge(a.status)}</td>
      <td>${a.billPath?`<a class="mini bill-link" href="${esc(a.billPath)}" target="_blank">Open Bill</a>`:'—'}</td>
      <td><button class="mini" onclick="viewAsset('${a.id}')">Open</button></td>
    </tr>`).join('')||'<tr><td colspan="11">No assets registered yet.</td></tr>';
}
function openAssetForm(editId=''){
  const a=editId?(cache.assets?.assets||[]).find(x=>x.id===editId):null;
  const members=cache.members||[];
  const opt=(v,cur)=>v===cur?'selected':'';
  $('#assetForm').innerHTML=`
    ${a?`<div class="full info-strip"><b>Asset ID:</b> ${esc(a.id)}</div>`:''}
    <label>Asset Name<input name="assetName" value="${esc(a?.assetName||'')}" required placeholder="Office Computer / Epson Printer / Club Sound System"></label>
    <label>Category<select name="category">${ASSET_CATEGORIES.map(x=>`<option ${opt(x,a?.category)}>${esc(x)}</option>`).join('')}</select></label>
    <label>Purchase Date<input type="date" name="purchaseDate" value="${esc(a?.purchaseDate||'')}"></label>
    <label>Purchase Value<input type="number" min="0" step="0.01" name="purchaseValue" value="${Number(a?.purchaseValue||0)}"></label>
    <label>Supplier / Vendor<input name="vendor" value="${esc(a?.vendor||'')}"></label>
    <label>Current Location<input name="currentLocation" value="${esc(a?.currentLocation||'')}" placeholder="Office / Store Room / Member custody / Site"></label>
    <label>Custodian Member<select name="custodianMemberId"><option value="">Manual / No Member</option>${members.map(m=>`<option value="${m.id}" ${opt(m.id,a?.custodianMemberId)}>${esc(m.id)} - ${esc(m.name)}</option>`).join('')}</select></label>
    <label>Custodian Name<input name="custodianName" value="${esc(a?.custodianName||'')}" placeholder="Use when custodian is not a registered member"></label>
    <label>Condition<select name="condition">${ASSET_CONDITIONS.map(x=>`<option ${opt(x,a?.condition||'Good')}>${esc(x)}</option>`).join('')}</select></label>
    <label>Status<select name="status">${ASSET_STATUSES.map(x=>`<option ${opt(x,a?.status||'In Use')}>${esc(x)}</option>`).join('')}</select></label>
    <label>Purchase Bill / Invoice<input id="assetBillFile" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"></label>
    <label>Purchase Resolution<select name="resolutionId">${usableResolutionOptions('Asset Purchase Approval',a?.resolutionId||'')}</select></label>
    <label class="full">Asset Details / Model / Serial / Registration / Plot Details<textarea name="assetDetails">${esc(a?.assetDetails||'')}</textarea></label>
    <label class="full">Notes<textarea name="notes">${esc(a?.notes||'')}</textarea></label>
    <div class="full asset-accounting-note"><b>Accounting note:</b> Saving an asset register value does not create an automatic Expense. If an actual purchase expense is required, use a separate approved voucher in Expense Management.</div>
    <div class="actions"><button class="btn primary">${a?'Update Asset':'Save Asset'}</button></div>`;
  $('#assetFormModal').classList.add('show');
  $('#assetForm').onsubmit=async e=>{
    e.preventDefault();
    let data=Object.fromEntries(new FormData(e.target));data.purchaseValue=Number(data.purchaseValue||0);
    if(!a){data=await applyFinancialApprovalPrompt(data,'AssetPurchase','purchaseValue','purchaseDate');if(!data)return;}
    const bill=$('#assetBillFile').files[0];
    try{
      if(bill){
        if(bill.size>10*1024*1024)throw new Error('Bill maximum 10 MB.');
        data.billFilename=bill.name;data.billDataUrl=await fileToDataURL(bill);
      }
      if(a) await api(`/api/assets/${encodeURIComponent(a.id)}`,{method:'PUT',body:JSON.stringify(data)});
      else await api('/api/assets',{method:'POST',body:JSON.stringify(data)});
      closeAssetForm();toast(a?'Asset updated':'Asset registered');await loadAll();
      if(a)await viewAsset(a.id);
    }catch(err){alert(err.message)}
  };
}
function closeAssetForm(){$('#assetFormModal').classList.remove('show')}
async function viewAsset(id){
  try{
    const a=await api(`/api/assets/${encodeURIComponent(id)}`);
    $('#assetViewBody').innerHTML=`
      <div class="asset-view-head">
        <div><span class="member-id-chip">${esc(a.id)}</span><h2>${esc(a.assetName)}</h2><p>${esc(a.category)} · ${assetConditionBadge(a.condition)} · ${assetStatusBadge(a.status)}</p></div>
        <div class="head-actions"><button class="btn" onclick="openAssetForm('${a.id}')">Edit</button><button class="btn reject" onclick="deleteAsset('${a.id}')">Delete Asset</button></div>
      </div>
      <div class="asset-value-strip">
        <div><span>Purchase Date</span><b>${esc(fmtDate(a.purchaseDate||'—'))}</b></div>
        <div><span>Purchase Value</span><b>${money(a.purchaseValue||0)}</b></div>
        <div><span>Current Location</span><b>${esc(a.currentLocation||'—')}</b></div>
        <div><span>Custodian</span><b>${esc(a.custodianName||'—')}</b><small>${esc(a.custodianMemberId||'')}</small></div>
      </div>
      <div class="profile-detail-grid">
        ${detail('Supplier / Vendor',a.vendor)}
        ${detail('Condition',a.condition)}
        ${detail('Status',a.status)}
        ${detail('Bill / Invoice',a.billOriginalName||'No bill attached')}
        ${detail('Purchase Resolution',a.resolutionNo?`${a.resolutionNo} - ${a.resolutionTitle||''}`:'Not linked')}
        ${detail('Financial Approval',a.approvalSnapshot?`${a.approvalSnapshot.policyName} Rev ${a.approvalSnapshot.policyRevision} · ${a.approvalSnapshot.rangeText}`:'Policy not enforced / historical asset')}
        ${detail('Asset Details / Model / Serial',a.assetDetails,'full')}
        ${detail('Notes',a.notes,'full')}
      </div>
      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Purchase Bill / Invoice</h3><p>PDF or image purchase proof.</p></div></div>
        ${a.billPath?`<div class="doc-item"><div class="doc-icon">▤</div><div class="doc-info"><b>${esc(a.billOriginalName||'Asset Bill')}</b><small>Purchase bill / invoice</small></div><a class="mini" href="${esc(a.billPath)}" target="_blank">Open Bill</a><button class="mini danger" onclick="removeAssetBill('${a.id}')">Remove Bill</button></div>`:'<div class="empty-docs">No bill attached. Use Edit Asset to upload one.</div>'}
      </div>`;
    $('#assetViewModal').classList.add('show');
  }catch(err){alert(err.message)}
}
function closeAssetView(){$('#assetViewModal').classList.remove('show')}
async function removeAssetBill(id){
  if(!confirm('Remove the attached purchase bill?'))return;
  try{
    await api(`/api/assets/${encodeURIComponent(id)}/bill`,{method:'DELETE'});
    toast('Asset bill removed');await loadAll();await viewAsset(id);
  }catch(err){alert(err.message)}
}
async function deleteAsset(id){
  if(!confirm('Delete this asset record? Attached bill will also be deleted.'))return;
  try{
    await api(`/api/assets/${encodeURIComponent(id)}`,{method:'DELETE'});
    closeAssetView();toast('Asset deleted');await loadAll();
  }catch(err){alert(err.message)}
}

function accountingTable(head,rows){
  $('#accountingLedgerHead').innerHTML=`<tr>${head.map(x=>`<th>${x}</th>`).join('')}</tr>`;
  $('#accountingLedgerRows').innerHTML=rows||`<tr><td colspan="${head.length}">No ledger entries.</td></tr>`;
}
function accountingTypeBadge(type){
  const cls=String(type||'').toLowerCase().replace(/[^a-z0-9]+/g,'-');
  return `<span class="accounting-type-badge ${cls}">${esc(type||'Entry')}</span>`;
}
function renderAccountingLedger(){
  const d=cache.accounting;if(!d)return;
  const o=d.overview||{};
  $('#accountingStats').innerHTML=[
    ['OPENING FUND BALANCE',money(o.openingBalance||0),`Liquid ${money(o.openingLiquid||0)} + Loan Receivable ${money(o.openingLoanReceivable||0)}`],
    ['INCOME',money(o.income||0),`${d.incomeLedger?.rows?.length||0} recognized income entries`],
    ['EXPENSE',money(o.expense||0),`${d.expenseLedger?.rows?.length||0} expense vouchers`],
    ['CLOSING FUND BALANCE',money(o.closingBalance||0),'Opening + Income − Expense'],
    ['LIQUID CASH / BANK',money(o.liquidClosing||0),'Cash + Bank + UPI / Other'],
    ['LOAN RECEIVABLE',money(o.closingLoanReceivable||0),'Outstanding principal asset']
  ].map(x=>`<div class="accounting-stat card"><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');

  $('#accountingFormulaCard').innerHTML=`
    <span>CORE ACCOUNTING FORMULA</span>
    <div class="accounting-equation"><b>${money(o.openingBalance||0)}</b><i>+</i><b>${money(o.income||0)}</b><i>−</i><b>${money(o.expense||0)}</b><i>=</i><strong>${money(o.closingBalance||0)}</strong></div>
    <small>Opening Balance + Income − Expense = Closing Balance</small>`;
  $('#accountingReconcileCard').innerHTML=`
    <span>RECONCILIATION</span>
    <div class="accounting-equation compact"><b>${money(o.liquidClosing||0)}</b><i>+</i><b>${money(o.closingLoanReceivable||0)}</b><i>=</i><strong>${money(o.reconciledClosing||0)}</strong></div>
    <small>Liquid Cash/Bank + Loan Principal Receivable ${o.reconciled?'<em class="reconcile-ok">✓ Reconciled</em>':`<em class="reconcile-bad">Difference ${money(o.reconciliationDifference||0)}</em>`}</small>`;

  const typeSel=$('#accountingLedgerSelect');
  typeSel.value=selectedAccountingLedger;
  typeSel.onchange=e=>{selectedAccountingLedger=e.target.value;renderSelectedAccountingLedger()};

  const members=d.memberLedgers||[];
  if(!selectedAccountingMember||!members.some(x=>x.memberId===selectedAccountingMember)) selectedAccountingMember=members[0]?.memberId||'';
  $('#accountingMemberSelect').innerHTML=members.map(x=>`<option value="${esc(x.memberId)}" ${x.memberId===selectedAccountingMember?'selected':''}>${esc(x.memberId)} - ${esc(x.memberName)}</option>`).join('');
  $('#accountingMemberSelect').onchange=e=>{selectedAccountingMember=e.target.value;renderSelectedAccountingLedger()};

  const events=d.eventLedgers||[];
  if(!selectedAccountingEvent||!events.some(x=>x.eventId===selectedAccountingEvent)) selectedAccountingEvent=events[0]?.eventId||'';
  $('#accountingEventSelect').innerHTML=events.map(x=>`<option value="${esc(x.eventId)}" ${x.eventId===selectedAccountingEvent?'selected':''}>${esc(x.eventId)} - ${esc(x.eventName)}</option>`).join('');
  $('#accountingEventSelect').onchange=e=>{selectedAccountingEvent=e.target.value;renderSelectedAccountingLedger()};

  const funds=d.fundLedger?.funds||[];
  if(!selectedAccountingFund||!funds.some(x=>x.name===selectedAccountingFund)) selectedAccountingFund=funds[0]?.name||'';
  $('#accountingFundSelect').innerHTML=funds.map(x=>`<option value="${esc(x.name)}" ${x.name===selectedAccountingFund?'selected':''}>${esc(x.name)} (${Number(x.percent||0)}%)</option>`).join('');
  $('#accountingFundSelect').onchange=e=>{selectedAccountingFund=e.target.value;renderSelectedAccountingLedger()};

  renderSelectedAccountingLedger();
}
function renderSelectedAccountingLedger(){
  const d=cache.accounting;if(!d)return;
  const memberWrap=$('#accountingMemberFilterWrap'),eventWrap=$('#accountingEventFilterWrap'),fundWrap=$('#accountingFundFilterWrap');
  memberWrap.classList.toggle('hidden',selectedAccountingLedger!=='member');
  eventWrap.classList.toggle('hidden',selectedAccountingLedger!=='event');
  fundWrap.classList.toggle('hidden',selectedAccountingLedger!=='fund');
  const title=$('#accountingLedgerTitle'),meta=$('#accountingLedgerMeta');
  meta.textContent='';

  if(selectedAccountingLedger==='income'){
    title.textContent='Income Ledger';meta.textContent=`Total ${money(d.incomeLedger?.total||0)}`;
    accountingTable(['Date','Ref No.','Category','Particulars','Mode','Amount','Running Income'],(d.incomeLedger?.rows||[]).map(x=>`<tr><td>${esc(fmtDate(x.date))}</td><td><b>${esc(x.ref)}</b></td><td>${esc(x.category)}</td><td>${esc(x.particular)}</td><td>${esc(x.mode||'—')}</td><td class="money-in"><b>${money(x.amount)}</b></td><td><b>${money(x.runningTotal)}</b></td></tr>`).join(''));
    return;
  }
  if(selectedAccountingLedger==='expense'){
    title.textContent='Expense Ledger';meta.textContent=`Total ${money(d.expenseLedger?.total||0)}`;
    accountingTable(['Date','Voucher','Category','Paid To','Purpose','Mode','Amount','Running Expense'],(d.expenseLedger?.rows||[]).map(x=>`<tr><td>${esc(fmtDate(x.date))}</td><td><b>${esc(x.ref)}</b></td><td>${esc(x.category)}</td><td>${esc(x.paidTo||'—')}</td><td>${esc(x.purpose||'—')}</td><td>${esc(x.mode||'—')}</td><td class="money-out"><b>${money(x.amount)}</b></td><td><b>${money(x.runningTotal)}</b></td></tr>`).join(''));
    return;
  }
  if(selectedAccountingLedger==='member'){
    const m=(d.memberLedgers||[]).find(x=>x.memberId===selectedAccountingMember);
    title.textContent=m?`Member Ledger — ${m.memberName}`:'Member Ledger';
    meta.textContent=m?`Paid to Org ${money(m.summary.paidToOrganization)} · Paid to Member ${money(m.summary.paidToMember)} · Subscription Due ${money(m.summary.subscriptionDue)} · Loan Outstanding ${money(m.summary.closingLoanOutstanding)}`:'';
    accountingTable(['Date','Ref','Type','Particulars','Paid to Org','Paid to Member','Benefit Memo','Net Cash Movement'],m?(m.rows||[]).map(x=>`<tr><td>${esc(fmtDate(x.date))}</td><td><b>${esc(x.ref)}</b></td><td>${accountingTypeBadge(x.type)}</td><td>${esc(x.particular||'')}</td><td class="money-in">${x.inflow?money(x.inflow):'—'}</td><td class="money-out">${x.outflow?money(x.outflow):'—'}</td><td>${x.memoAmount?money(x.memoAmount):'—'}</td><td><b>${money(x.netCashMovement)}</b></td></tr>`).join(''):'');
    return;
  }
  if(selectedAccountingLedger==='donation'){
    const x=d.donationLedger||{};title.textContent='Donation Ledger';meta.textContent=`Opening ${money(x.openingBalance||0)} · Received ${money(x.received||0)} · Spent ${money(x.spent||0)} · Closing ${money(x.closingBalance||0)}`;
    accountingTable(['Date','Ref','Purpose','Particulars','Received','Spent','Balance'],(x.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${esc(r.purpose)}</td><td>${esc(r.particular)}</td><td class="money-in">${r.received?money(r.received):'—'}</td><td class="money-out">${r.spent?money(r.spent):'—'}</td><td><b>${money(r.balance)}</b></td></tr>`).join(''));
    return;
  }
  if(['cash','bank','upi'].includes(selectedAccountingLedger)){
    const book=selectedAccountingLedger==='cash'?d.cashBook:selectedAccountingLedger==='bank'?d.bankBook:d.upiBook;
    title.textContent=selectedAccountingLedger==='cash'?'Cash Book':selectedAccountingLedger==='bank'?'Bank Book':'UPI / Other Book';meta.textContent=`${book.accountName} · Opening ${money(book.openingBalance)} · Closing ${money(book.closingBalance)}`;
    const rows=[`<tr class="opening-row"><td>—</td><td>OPEN</td><td>Opening Balance</td><td>Opening</td><td>—</td><td>—</td><td><b>${money(book.openingBalance)}</b></td></tr>`,...(book.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${esc(r.particular)}</td><td>${accountingTypeBadge(r.type)}</td><td class="money-in">${r.inflow?money(r.inflow):'—'}</td><td class="money-out">${r.outflow?money(r.outflow):'—'}</td><td><b>${money(r.balance)}</b></td></tr>`)].join('');
    accountingTable(['Date','Ref','Particulars','Type','In','Out','Running Balance'],rows);return;
  }
  if(selectedAccountingLedger==='event'){
    const e=(d.eventLedgers||[]).find(x=>x.eventId===selectedAccountingEvent);title.textContent=e?`Event Ledger — ${e.eventName}`:'Event Ledger';meta.textContent=e?`Budget ${money(e.budget)} · Income ${money(e.income)} · Expense ${money(e.expense)} · ${e.surplusDeficit>=0?'Surplus':'Deficit'} ${money(Math.abs(e.surplusDeficit))}`:'';
    accountingTable(['Date','Ref','Type','Particulars','In','Out','Running Balance'],e?(e.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${accountingTypeBadge(r.type)}</td><td>${esc(r.particular||'')}</td><td class="money-in">${r.inflow?money(r.inflow):'—'}</td><td class="money-out">${r.outflow?money(r.outflow):'—'}</td><td><b>${money(r.balance)}</b></td></tr>`).join(''):'');return;
  }
  if(selectedAccountingLedger==='welfare'){
    const w=d.welfareLedger||{},s=w.summary||{};title.textContent='Welfare Ledger';meta.textContent=`Approved ${money(s.approved||0)} · Paid ${money(s.paid||0)} · Outstanding ${money(s.approvedOutstanding||0)}`;
    accountingTable(['Date','Payment No.','Application','Member','Assistance Type','Mode','Paid','Running Paid'],(w.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${esc(r.applicationId)}</td><td>${esc(r.memberName||r.memberId)}</td><td>${esc(r.type||'—')}</td><td>${esc(r.mode||'—')}</td><td class="money-out"><b>${money(r.amount)}</b></td><td><b>${money(r.runningPaid)}</b></td></tr>`).join(''));return;
  }
  if(selectedAccountingLedger==='loan'){
    const l=d.loanLedger||{},s=l.summary||{};title.textContent='Loan / Financial Assistance Ledger';meta.textContent=`Opening Outstanding ${money(s.openingOutstanding||0)} · Disbursed ${money(s.disbursed||0)} · Principal Recovered ${money(s.principalRecovered||0)} · Closing Outstanding ${money(s.closingOutstanding||0)}`;
    accountingTable(['Date','Ref','Member','Type','Principal Disbursed','Principal Recovered','Permitted Charge Income','Cash In','Principal Outstanding'],(l.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${esc(r.memberName||r.memberId)}</td><td>${accountingTypeBadge(r.type)}</td><td class="money-out">${r.principalOut?money(r.principalOut):'—'}</td><td class="money-in">${r.principalRecovered?money(r.principalRecovered):'—'}</td><td>${r.chargeIncome?money(r.chargeIncome):'—'}</td><td class="money-in">${r.cashIn?money(r.cashIn):'—'}</td><td><b>${money(r.principalOutstanding)}</b></td></tr>`).join(''));return;
  }
  if(selectedAccountingLedger==='fund'){
    const f=(d.fundLedger?.funds||[]).find(x=>x.name===selectedAccountingFund);title.textContent=f?`Fund-wise Ledger — ${f.name}`:'Fund-wise Ledger';meta.textContent=f?`${Number(f.percent||0)}% · Opening ${money(f.opening)} · In ${money(f.inflow)} · Out ${money(f.outflow)} · Closing ${money(f.closing)} · Policy Target ${money(f.policyTarget)} · Variance ${money(f.varianceToPolicy)}`:'';
    accountingTable(['Date','Ref','Type','Particulars','In','Out','Running Fund Balance'],f?(f.rows||[]).map(r=>`<tr><td>${esc(fmtDate(r.date))}</td><td><b>${esc(r.ref)}</b></td><td>${accountingTypeBadge(r.type)}</td><td>${esc(r.particular||'')}</td><td class="money-in">${r.inflow?money(r.inflow):'—'}</td><td class="money-out">${r.outflow?money(r.outflow):'—'}</td><td><b>${money(r.balance)}</b></td></tr>`).join(''):'');return;
  }
}
function printAccountingLedger(){
  const panel=$('#accountingLedgerPanel'),title=$('#accountingLedgerTitle')?.textContent||'Accounting Ledger',meta=$('#accountingLedgerMeta')?.textContent||'';
  if(!panel)return;
  const org=cache.master||{},w=window.open('','_blank','width=1000,height=850');
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font-family:Arial,sans-serif;padding:28px;color:#111}h1{font-size:21px;margin:0}.org{border-bottom:2px solid #111;padding-bottom:10px;margin-bottom:14px}.org p,.meta{font-size:12px;color:#444}.meta{margin:8px 0 16px}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #bbb;padding:6px;text-align:left}th{background:#eee}.money-in{color:#065f46}.money-out{color:#991b1b}@media print{button{display:none}}</style></head><body><div class="org"><h1>${esc(org.organizationName||'Organization')}</h1><p>Financial Year ${esc(activeFY)} · ${esc(title)}</p></div><div class="meta">${esc(meta)}</div>${panel.innerHTML}<div style="margin-top:20px;text-align:center"><button onclick="window.print()">Print / Save as PDF</button></div></body></html>`);
  w.document.close();
}

function reportDisplayValue(value,kind='text'){
  if(kind==='money')return money(value);
  if(kind==='number')return Number(value||0).toLocaleString('en-IN',{maximumFractionDigits:2});
  if(kind==='date')return esc(fmtDate(value));
  if(kind==='datetime'||kind==='dateTime')return esc(fmtDateTime(value));
  if(typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value))return esc(fmtDate(value));
  if(typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T/.test(value))return esc(fmtDateTime(value));
  return esc(value??'');
}
function reportFileName(){
  const title=(currentReport?.title||'Report').replace(/[^a-z0-9]+/gi,'_').replace(/^_+|_+$/g,'');
  return `${title}_${activeFY}`;
}
function setupReportPicker(){
  const select=$('#reportTypeSelect');if(!select)return;
  if(!REPORT_TYPES.some(x=>x[0]===selectedReportType))selectedReportType='annual';
  select.innerHTML=REPORT_TYPES.map(([key,label])=>`<option value="${key}" ${key===selectedReportType?'selected':''}>${esc(label)}</option>`).join('');
  $('#reportQuickGrid').innerHTML=REPORT_TYPES.map(([key,label],i)=>`<button class="report-quick ${key===selectedReportType?'active':''}" onclick="selectReportType('${key}')"><span>${String(i+1).padStart(2,'0')}</span>${esc(label)}</button>`).join('');
  $('#reportActiveFY').textContent=activeFY;
}
function renderReports(){
  setupReportPicker();
  if(!$('#reports')?.classList.contains('active'))return;
  loadSelectedReport();
}
async function selectReportType(type){
  if(!REPORT_TYPES.some(x=>x[0]===type))return;
  selectedReportType=type;localStorage.setItem('oms_report_type',type);currentReport=null;
  setupReportPicker();await loadSelectedReport();
}
async function loadSelectedReport(){
  const token=++reportLoadToken;
  const title=$('#reportPreviewTitle'),meta=$('#reportPreviewMeta');
  if(title)title.textContent='Loading report…';if(meta)meta.textContent=`Financial Year ${activeFY}`;
  $('#reportSummaryGrid').innerHTML='<div class="card report-summary loading">Loading…</div>';
  $('#reportPreviewTable thead').innerHTML='';$('#reportPreviewTable tbody').innerHTML='<tr><td class="report-loading-cell">Preparing report…</td></tr>';
  try{
    const data=await api(fyUrl('/api/reports')+`&type=${encodeURIComponent(selectedReportType)}`);
    if(token!==reportLoadToken)return;
    currentReport=data;renderSelectedReportPreview();
  }catch(e){
    if(token!==reportLoadToken)return;
    currentReport=null;title.textContent='Report Error';meta.textContent=e.message;$('#reportSummaryGrid').innerHTML='';$('#reportPreviewTable tbody').innerHTML=`<tr><td class="report-loading-cell">${esc(e.message)}</td></tr>`;
  }
}
function filteredReportRows(){
  const rows=currentReport?.rows||[],q=String($('#reportSearchInput')?.value||'').trim().toLowerCase();
  if(!q)return rows;
  return rows.filter(r=>Object.values(r).some(v=>String(v??'').toLowerCase().includes(q)));
}
function renderSelectedReportPreview(){
  const r=currentReport;if(!r)return;
  $('#reportPreviewTitle').textContent=r.title||'Report';
  $('#reportPreviewMeta').textContent=`Financial Year ${r.financialYear} · As of ${fmtDate(r.asOfDate)} · Generated ${fmtDateTime(r.generatedAt)}`;
  $('#reportSummaryGrid').innerHTML=(r.summary||[]).map(x=>`<div class="card report-summary"><span>${esc(x.label)}</span><b>${reportDisplayValue(x.value,x.kind)}</b></div>`).join('')||'<div class="card report-summary"><span>Rows</span><b>'+Number((r.rows||[]).length).toLocaleString('en-IN')+'</b></div>';
  $('#reportNotes').innerHTML=(r.notes||[]).map(n=>`<div>ⓘ ${esc(n)}</div>`).join('');
  const cols=r.columns||[],rows=filteredReportRows();
  $('#reportPreviewTable thead').innerHTML=`<tr>${cols.map(c=>`<th>${esc(c.label)}</th>`).join('')}</tr>`;
  $('#reportPreviewTable tbody').innerHTML=rows.map(row=>`<tr>${cols.map(c=>`<td class="${c.kind==='money'?'report-money':''}">${reportDisplayValue(row[c.key],c.kind)}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${Math.max(1,cols.length)}" class="report-loading-cell">No records found.</td></tr>`;
  $('#reportRowCount').textContent=`Showing ${rows.length.toLocaleString('en-IN')} of ${(r.rows||[]).length.toLocaleString('en-IN')} row(s)`;
  setupReportPicker();
}
function reportPrintableDocument(pdfMode=false){
  const r=currentReport,org=cache.master||{};if(!r)return '';
  const cols=r.columns||[],rows=r.rows||[];
  const summary=(r.summary||[]).map(x=>`<div><span>${esc(x.label)}</span><b>${reportDisplayValue(x.value,x.kind)}</b></div>`).join('');
  const notes=(r.notes||[]).map(n=>`<p>• ${esc(n)}</p>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(r.title)} - ${esc(activeFY)}</title><style>
    @page{size:auto;margin:12mm}body{font-family:Arial,sans-serif;color:#111;margin:0;font-size:10px}.org{border-bottom:2px solid #111;padding-bottom:9px;margin-bottom:12px}.org h1{margin:0;font-size:20px}.org p{margin:3px 0;color:#444}.report-title{text-align:center;margin:12px 0}.report-title h2{margin:0 0 4px;font-size:17px}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:10px 0}.summary>div{border:1px solid #bbb;padding:7px}.summary span,.summary b{display:block}.summary span{font-size:8px;color:#555;text-transform:uppercase}.summary b{margin-top:3px;font-size:11px}.notes{border:1px solid #ddd;background:#fafafa;padding:5px 8px;margin:8px 0}.notes p{margin:3px 0}table{width:100%;border-collapse:collapse;font-size:8.5px}th,td{border:1px solid #999;padding:4px;vertical-align:top}th{background:#eee}.foot{margin-top:10px;color:#555;display:flex;justify-content:space-between}.pdf-note{padding:8px;background:#fff7ed;border:1px solid #fed7aa;margin-bottom:8px;font-size:10px}@media print{.pdf-note{display:none}}
  </style></head><body>${pdfMode?'<div class="pdf-note"><b>PDF:</b> In the print dialog choose <b>Save as PDF</b> as the printer/destination.</div>':''}<div class="org"><h1>${esc(org.organizationName||'Organization')}</h1><p>${esc(org.registeredAddress||org.officeAddress||'')}</p><p>${esc(org.phone||'')} ${org.email?'· '+esc(org.email):''}</p></div><div class="report-title"><h2>${esc(r.title)}</h2><div>Financial Year ${esc(r.financialYear)} · As of ${esc(fmtDate(r.asOfDate||'—'))}</div></div>${summary?`<div class="summary">${summary}</div>`:''}${notes?`<div class="notes">${notes}</div>`:''}<table><thead><tr>${cols.map(c=>`<th>${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${cols.map(c=>`<td>${reportDisplayValue(row[c.key],c.kind)}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${Math.max(1,cols.length)}">No records.</td></tr>`}</tbody></table><div class="foot"><span>Generated by ${esc(appInfo.appName)} ${esc(appInfo.version)}</span><span>${fmtDateTime(r.generatedAt)}</span></div></body></html>`;
}
function printSelectedReport(pdfMode=false){
  if(!currentReport)return alert('Generate a report first.');
  const w=window.open('','_blank','width=1100,height=850');if(!w)return alert('Popup blocked. Please allow popups for this local ERP.');
  w.document.write(reportPrintableDocument(pdfMode));w.document.close();w.focus();setTimeout(()=>w.print(),350);
}
function excelSafeValue(value){
  if(value===null||value===undefined)return '';
  if(typeof value==='number')return value;
  let s=String(value);if(/^[=+\-@]/.test(s))s="'"+s;return s;
}
function exportSelectedReportExcel(){
  const r=currentReport;if(!r)return alert('Generate a report first.');
  const org=cache.master||{},cols=r.columns||[],rows=r.rows||[];
  const cell=v=>esc(excelSafeValue(v));
  const summary=(r.summary||[]).map(x=>`<tr><td>${cell(x.label)}</td><td>${typeof x.value==='number'?x.value:cell(x.value)}</td></tr>`).join('');
  const table=`<table border="1"><tr><th colspan="${Math.max(2,cols.length)}">${esc(org.organizationName||'Organization')}</th></tr><tr><td colspan="${Math.max(2,cols.length)}">${esc(r.title)} · Financial Year ${esc(r.financialYear)} · As of ${esc(fmtDate(r.asOfDate||'—'))}</td></tr>${summary?`<tr><td colspan="${Math.max(2,cols.length)}"><b>Summary</b></td></tr>${summary}`:''}<tr>${cols.map(c=>`<th>${esc(c.label)}</th>`).join('')}</tr>${rows.map(row=>`<tr>${cols.map(c=>{const v=row[c.key];return `<td>${typeof v==='number'?v:cell(v)}</td>`}).join('')}</tr>`).join('')}</table>`;
  const html=`<!doctype html><html><head><meta charset="utf-8"></head><body>${table}</body></html>`;
  const blob=new Blob(['\ufeff',html],{type:'application/vnd.ms-excel;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=reportFileName()+'.xls';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Excel report exported');
}

function switchMemberPortalTab(btn,id){
  const page=$('#memberportal');if(!page)return;
  page.querySelectorAll('.member-portal-nav button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
  page.querySelectorAll('.member-portal-tab').forEach(x=>x.classList.remove('active'));$('#'+id)?.classList.add('active');
}
function memberPortalPriorityBadge(p){const cls=String(p||'Normal').toLowerCase();return `<span class="portal-priority ${cls}">${esc(p||'Normal')}</span>`}
function renderMemberPortal(){
  const d=cache.portal;if(!d||!canPage('memberportal'))return;const p=d.profile||{},s=d.subscription||{},m=d.membership||{},don=d.donation||{};
  $('#memberPortalProfile').innerHTML=`<div class="card member-portal-profile"><div class="member-portal-avatar">${p.photoPath?`<img src="${esc(p.photoPath)}">`:'<span>👤</span>'}</div><div class="member-portal-profile-main"><span class="member-id-chip">${esc(p.id)}</span><h2>${esc(p.name)}</h2><p>${esc(p.membershipType)} · ${esc(p.designation)} · ${badge(p.status)}</p><small>${esc(p.phone||'')} ${p.email?'· '+esc(p.email):''}</small></div><div class="member-portal-status-box"><span>MEMBERSHIP STATUS</span><b>${esc(m.status||p.status||'')}</b><small>Joined ${esc(m.joinDate||p.joinDate||'—')}</small></div></div>`;
  $('#memberPortalStats').innerHTML=[
    ['FY PAYABLE',money(s.payable||0)],['PAID',money(s.paid||0)],['TOTAL DUE',money(s.due||0)],['DONATION',money(don.total||0)],
    ['RECEIPTS',(d.receipts||[]).length],['NOTICES',(d.notices||[]).length],['EVENTS',(d.events||[]).length],['LOAN / ASSISTANCE',(d.loans||[]).length]
  ].map(x=>`<div class="card member-portal-stat"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');

  $('#memberPortalMembership').innerHTML=`<div class="portal-membership-grid"><div><span>Status</span><b>${badge(m.status||'—')}</b></div><div><span>Membership Type</span><b>${esc(m.membershipType||'—')}</b></div><div><span>Designation</span><b>${esc(m.designation||'—')}</b></div><div><span>Joining Date</span><b>${esc(fmtDate(m.joinDate||'—'))}</b></div><div><span>Membership Age</span><b>${Number(m.membershipMonths||0)} months</b></div><div><span>Monthly Fee</span><b>${money(m.monthlyFee||0)}</b></div></div>`;
  $('#memberPortalJoining').innerHTML=(d.joining||[]).map(x=>`<div class="member-app-item"><b>${esc(x.id)}</b><span>${esc(x.status)} · ${esc(x.membershipType||'')} · Joining Fee ${money(x.joiningFee||0)}</span>${x.rejectionReason?`<small>${esc(x.rejectionReason)}</small>`:''}</div>`).join('')||'<div class="empty-docs">No joining application record.</div>';
  $('#memberPortalProfileDetails').innerHTML=`${detail('Father / Spouse',p.fatherSpouse)}${detail('Date of Birth',p.dob)}${detail('Mobile',p.phone)}${detail('Email',p.email)}${detail('Address',p.address,'full')}${detail('Emergency Contact',p.emergencyName?`${p.emergencyName} · ${p.emergencyPhone||''} · ${p.emergencyRelation||''}`:'—','full')}`;

  $('#memberPortalSubscriptionRows').innerHTML=(s.ledger||[]).map(x=>`<tr><td>${esc(x.monthLabel||x.month)}</td><td>${money(x.payable)}</td><td>${money(x.paid)}</td><td><b>${money(x.due)}</b></td><td>${badge(x.status)}</td><td>${esc(fmtDate(x.paymentDate||'—'))}</td><td>${esc(x.mode||'—')}</td></tr>`).join('')||'<tr><td colspan="7">No subscription ledger.</td></tr>';
  $('#memberPortalDonationRows').innerHTML=(don.rows||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.date||'')}</td><td>${esc(x.purpose||'General Fund')}</td><td>${esc(x.mode||'')}</td><td><b>${money(x.amount)}</b></td><td><button class="mini" onclick="printPortalReceipt('${x.id}')">Receipt</button></td></tr>`).join('')||'<tr><td colspan="6">No member-linked donations in this Financial Year.</td></tr>';
  $('#memberPortalReceiptRows').innerHTML=(d.receipts||[]).map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.date||'')}</td><td>${esc(x.type||'')}</td><td>${esc(x.mode||'')}</td><td><b>${money(x.amount)}</b></td><td><button class="mini" onclick="printPortalReceipt('${x.id}')">Print</button></td></tr>`).join('')||'<tr><td colspan="6">No receipts in this Financial Year.</td></tr>';

  $('#memberPortalWelfareCards').innerHTML=(d.welfare||[]).map(x=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(x.id)}</b><span>${esc(x.welfareType)}</span></div>${badge(x.status)}</div><div class="portal-record-money"><span>Requested <b>${money(x.requestedAmount)}</b></span><span>Approved <b>${money(x.approvedAmount)}</b></span><span>Paid <b>${money(x.paidAmount)}</b></span><span>Approved Outstanding <b>${money(x.outstandingApproved)}</b></span></div>${x.purpose?`<p>${esc(x.purpose)}</p>`:''}${x.rejectionReason?`<small class="portal-warning-text">${esc(x.rejectionReason)}</small>`:''}</div>`).join('')||'<div class="empty-docs">No welfare application.</div>';

  $('#memberPortalLoanCards').innerHTML=(d.loans||[]).map(x=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(x.id)}</b><span>${esc(x.purpose||'Financial Assistance')}</span></div><div>${badge(x.status)} ${badge(x.repaymentStatus)}</div></div><div class="portal-record-money"><span>Requested <b>${money(x.requestedAmount)}</b></span><span>Sanctioned <b>${money(x.sanctionedAmount)}</b></span><span>Total Paid <b>${money(x.totalPaid)}</b></span><span>Outstanding <b>${money(x.outstanding)}</b></span></div>${x.nextInstallment?`<div class="portal-next-due"><b>Next / Current Installment:</b> #${x.nextInstallment.installmentNo} · Due ${esc(fmtDate(x.nextInstallment.dueDate))} · ${money(x.nextInstallment.due)} · ${esc(x.nextInstallment.status)}</div>`:''}</div>`).join('')||'<div class="empty-docs">No financial assistance / loan record.</div>';

  $('#memberPortalEventCards').innerHTML=(d.events||[]).map(x=>`<div class="portal-event-card"><div class="portal-event-date"><b>${esc(String(x.startDate||'').slice(8,10)||'—')}</b><span>${x.startDate?new Date(x.startDate+'T00:00:00').toLocaleString('en-IN',{month:'short'}):'—'}</span></div><div><div class="portal-record-head"><div><b>${esc(x.name)}</b><span>${esc(x.startDate||'')} ${x.endDate&&x.endDate!==x.startDate?'→ '+esc(x.endDate):''}</span></div>${badge(x.status)}</div><p>${esc(x.venue||'Venue not announced')}</p>${x.description?`<small>${esc(x.description)}</small>`:''}<div class="portal-event-participation ${x.participating?'yes':'no'}">${x.participating?`✓ Participant: ${esc(x.participantRole||'Participant')}`:(x.registered?`✓ Registration: ${esc(x.registrationStatus)}`:'Not registered')}</div>${x.registrationOpen&&!x.registered?`<button class="mini" onclick="portalRegisterEvent('${x.id}')">Register</button>`:''}${x.registered&&x.registrationStatus==='Registered'?`<button class="mini danger" onclick="portalCancelEventRegistration('${x.id}')">Cancel Registration</button>`:''}<small>Registration ${x.registrationCount||0}${x.capacity?` / ${x.capacity}`:''}${x.registrationDeadline?` · Deadline ${esc(x.registrationDeadline)}`:''}</small></div></div>`).join('')||'<div class="empty-docs">No organization events in this Financial Year.</div>';

  $('#memberPortalNoticeCards').innerHTML=(d.notices||[]).map(x=>`<div class="portal-notice-card ${String(x.priority||'Normal').toLowerCase()}"><div class="portal-notice-head"><div><span>${esc(x.noticeNo)}</span><h4>${esc(x.title)}</h4></div>${memberPortalPriorityBadge(x.priority)}</div><div class="portal-notice-meta">${esc(x.date||'')} · ${esc(x.audience||'All Members')}</div><p>${esc(x.body)}</p>${x.attachmentPath?`<a class="btn portal-notice-file" href="${esc(x.attachmentPath)}" target="_blank">Open Attachment · ${esc(x.attachmentOriginalName||'Document')}</a>`:''}</div>`).join('')||'<div class="empty-docs">No published notice for you in this Financial Year.</div>';
  $('#memberPortalNomineeCards').innerHTML=(d.nominees||[]).map(n=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(n.name)}</b><span>${esc(n.relation)} ${n.isPrimary?'· Primary':''}</span></div><span>${Number(n.sharePercent||0).toFixed(2)}%</span></div><p>${esc(n.phone||'No phone')}</p><button class="mini danger" onclick="deletePortalNominee('${n.id}')">Remove</button></div>`).join('')||'<div class="empty-docs">No nominees added.</div>';
  $('#memberPortalGrievanceCards').innerHTML=(d.grievances||[]).map(g=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(g.id)} · ${esc(g.subject)}</b><span>${esc(g.category)} · ${fmtDate(g.createdAt)}</span></div>${badge(g.status)}</div><p>${esc(g.description)}</p>${g.response?`<small><b>Response:</b> ${esc(g.response)}</small>`:''}${g.resolution?`<small><b>Resolution:</b> ${esc(g.resolution)}</small>`:''}</div>`).join('')||'<div class="empty-docs">No grievances submitted.</div>';
  $('#memberPortalCertificateRows').innerHTML=(d.issuedDocuments||[]).map(x=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(x.certificateNo)} · ${esc(x.type)}</b><span>${esc(fmtDate(x.issueDate))} ${x.eventName?'· '+esc(x.eventName):''}</span></div><button class="mini" onclick="printIssuedDocument('${x.id}',true)">Print</button></div><p>${esc(x.title||'')}</p></div>`).join('')||'<div class="empty-docs">No certificate / ID issued in this FY.</div>';
  $('#memberPortalReminderCards').innerHTML=(d.reminders||[]).map(x=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(x.type)}</b><span>${esc(fmtDate(x.scheduledDate))} · ${esc(x.channel)}</span></div>${badge(x.status)}</div><p>${esc(x.message)}</p>${x.dueAmount?`<strong>${money(x.dueAmount)}</strong>`:''}</div>`).join('')||'<div class="empty-docs">No reminders.</div>';
  $('#memberPortalElectionCards').innerHTML=(d.elections||[]).map(e=>`<div class="portal-record-card"><div class="portal-record-head"><div><b>${esc(e.title)}</b><span>${esc(fmtDate(e.electionDate))} · ${esc(e.status)}</span></div>${badge(e.status)}</div>${(e.positions||[]).map(p=>`<div class="portal-election-position"><b>${esc(p.name)}</b>${p.hasVoted?'<span class="portal-voted">✓ Vote submitted</span>':(e.status==='Voting Open'?`<div class="portal-candidate-list">${(p.candidates||[]).filter(c=>c.status==='Approved').map(c=>`<button class="mini" onclick="portalVote('${e.id}','${p.id}','${c.id}')">Vote: ${esc(c.memberName)}</button>`).join('')}</div>`:'')} ${e.status==='Published'?`<div class="portal-election-results">${(p.candidates||[]).map(c=>`<span>${esc(c.memberName)}: <b>${Number(c.votes||0)}</b></span>`).join('')}</div>`:''}</div>`).join('')}</div>`).join('')||'<div class="empty-docs">No elections available.</div>';
}
function printMemberPortalStatement(){
  const d=cache.portal;if(!d)return;const p=d.profile||{},s=d.subscription||{},org=d.organization||{},w=window.open('','_blank','width=900,height=850');if(!w)return alert('Popup blocked.');
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(p.id)} Member Statement</title><style>body{font-family:Arial;padding:26px;color:#111}.sheet{max-width:820px;margin:auto}.head{text-align:center;border-bottom:2px solid #111;padding-bottom:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px 20px;margin:15px 0}.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.sum div{border:1px solid #aaa;padding:9px}.sum span,.sum b{display:block}.sum span{font-size:10px;color:#555}.tbl{width:100%;border-collapse:collapse;font-size:11px;margin-top:12px}.tbl th,.tbl td{border:1px solid #aaa;padding:6px;text-align:left}h3{margin-top:22px}@media print{button{display:none}}</style></head><body><div class="sheet"><div class="head"><h2>${esc(org.name||'Organization')}</h2><b>MEMBER STATEMENT · FY ${esc(d.financialYear)}</b></div><div class="grid"><div><b>Member:</b> ${esc(p.id)} · ${esc(p.name)}</div><div><b>Status:</b> ${esc(p.status)}</div><div><b>Membership:</b> ${esc(p.membershipType)}</div><div><b>Join Date:</b> ${esc(fmtDate(p.joinDate))}</div></div><div class="sum"><div><span>Payable</span><b>${money(s.payable||0)}</b></div><div><span>Paid</span><b>${money(s.paid||0)}</b></div><div><span>Due</span><b>${money(s.due||0)}</b></div><div><span>Donation</span><b>${money(d.donation?.total||0)}</b></div></div><h3>Subscription</h3><table class="tbl"><tr><th>Month</th><th>Payable</th><th>Paid</th><th>Due</th><th>Status</th></tr>${(s.ledger||[]).map(x=>`<tr><td>${esc(x.monthLabel||x.month)}</td><td>${money(x.payable)}</td><td>${money(x.paid)}</td><td>${money(x.due)}</td><td>${esc(x.status)}</td></tr>`).join('')}</table><h3>Receipts</h3><table class="tbl"><tr><th>Receipt</th><th>Date</th><th>Head</th><th>Mode</th><th>Amount</th></tr>${(d.receipts||[]).map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(fmtDate(x.date))}</td><td>${esc(x.type)}</td><td>${esc(x.mode)}</td><td>${money(x.amount)}</td></tr>`).join('')}</table></div><div style="text-align:center;margin-top:14px"><button onclick="window.print()">Print / Save PDF</button></div></body></html>`);w.document.close();
}
function printPortalReceipt(id){
  const d=cache.portal||{},x=(d.receipts||[]).find(r=>r.id===id);if(!x)return;const org=d.organization||{},p=d.profile||{},w=window.open('','_blank','width=700,height=700');if(!w)return alert('Popup blocked.');
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(x.id)}</title><style>body{font-family:Arial;padding:25px;color:#111}.sheet{max-width:650px;margin:auto;border:1px solid #aaa;padding:22px}.head{text-align:center;border-bottom:2px solid #111;padding-bottom:12px}.row{display:flex;justify-content:space-between;border-bottom:1px dashed #ccc;padding:8px 0}.amount{font-size:22px;font-weight:bold}.sign{display:flex;justify-content:space-between;margin-top:50px}.sign span{border-top:1px solid #111;padding-top:5px;min-width:150px;text-align:center}@media print{button{display:none}}</style></head><body><div class="sheet"><div class="head"><h2>${esc(org.name||'Organization')}</h2><b>PAYMENT RECEIPT</b></div><div class="row"><b>Receipt No.</b><span>${esc(x.id)}</span></div><div class="row"><b>Date</b><span>${esc(x.date||'')}</span></div><div class="row"><b>Member</b><span>${esc(p.id)} · ${esc(p.name)}</span></div><div class="row"><b>Payment Head</b><span>${esc(x.type||'')}</span></div><div class="row"><b>Mode</b><span>${esc(x.mode||'')}</span></div><div class="row"><b>Amount</b><span class="amount">${money(x.amount)}</span></div><div class="sign"><span>Member</span><span>Authorized Signatory</span></div></div><div style="text-align:center;margin-top:12px"><button onclick="window.print()">Print / Save PDF</button></div></body></html>`);w.document.close();
}
function renderSecurity(){
  const s=cache.security;if(!s||!canPage('security'))return;const info=s.usersInfo||{},audit=s.auditInfo||{};
  const roles=info.roles||[];$('#securityRoleCards').innerHTML=roles.map(r=>`<div class="card security-role-card"><b>${esc(r)}</b><p>${esc(info.roleDescriptions?.[r]||'')}</p></div>`).join('');
  $('#securityUserRows').innerHTML=(info.users||[]).map(u=>`<tr><td><b>${esc(u.id)}</b></td><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.whatsapp||'—')}</td><td><span class="security-role-pill">${esc(u.role)}</span></td><td>${esc(u.memberId||'—')}</td><td>${u.status==='Active'?'<span class="security-user-active">Active</span>':'<span class="security-user-disabled">Disabled</span>'}</td><td>${u.lastLoginAt?fmtDateTime(u.lastLoginAt):'Never'}</td><td><button class="mini" onclick="openUserForm('${u.id}')">Edit</button></td></tr>`).join('');
  const q=($('#auditSearch')?.value||'').trim().toLowerCase();let rows=audit.rows||[];if(q)rows=rows.filter(x=>`${x.actorName} ${x.actorEmail} ${x.actorRole} ${x.action} ${x.detail} ${x.path}`.toLowerCase().includes(q));
  $('#securityAuditRows').innerHTML=rows.map(a=>`<tr><td>${fmtDateTime(a.at)}</td><td><b>${esc(a.actorName||'System')}</b><br><small>${esc(a.actorEmail||'')}</small></td><td>${esc(a.actorRole||'System')}</td><td><b>${esc(a.action)}</b></td><td>${esc(a.detail||'')}</td><td><code>${esc(a.method||'')} ${esc(a.path||'')}</code></td></tr>`).join('')||'<tr><td colspan="6">No audit entries.</td></tr>';
}
function openUserForm(id=''){
  const existing=id?(cache.users?.users||[]).find(x=>x.id===id):null;
  const members=(cache.members||[]).filter(m=>m.status==='Active');
  const roles=cache.users?.roles||['Super Admin','President','Secretary','Treasurer','Committee Member','General Member'];

  const memberOptions=[
    '<option value="">Select Member</option>',
    ...members.map(m=>`<option value="${esc(m.id)}" ${existing?.memberId===m.id?'selected':''}>${esc(m.id)} — ${esc(m.name)}${m.phone?` · ${esc(m.phone)}`:''}</option>`)
  ].join('');

  const roleOptions=roles.map(r=>`<option ${existing?.role===r?'selected':''}>${esc(r)}</option>`).join('');

  $('#userForm').innerHTML=`
    <div class="full member-user-create-note">
      <b>Select Member → Select User Role → Create User</b>
      <span>Member details will auto-fill from the selected Member profile. The created user will remain linked to that Member ID.</span>
    </div>

    <label class="full">Select Member ${existing?'':'*'}
      <select name="memberId" id="userLinkedMember" ${existing?'':'required'}>${memberOptions}</select>
    </label>

    <label>Name *
      <input name="name" id="userAccountName" value="${esc(existing?.name||'')}" required>
    </label>

    <label>Login Email *
      <input type="email" name="email" id="userAccountEmail" value="${esc(existing?.email||'')}" required>
    </label>

    <label>WhatsApp Login Number
      <input name="whatsapp" id="userAccountWhatsapp" value="${esc(existing?.whatsapp||'')}" placeholder="Example: 919876543210">
    </label>

    <label>User Role *
      <select name="role" id="userAccountRole" required>${roleOptions}</select>
    </label>

    ${existing?`<label class="full">Admin Password Reset
      <input type="password" name="newPassword" minlength="6" placeholder="Leave blank to keep current password">
      <small>If reset by Admin, the user will be asked to change it again.</small>
    </label>`:`<div class="full default-user-password-box"><span>Default Login Password</span><b>cscvle</b><small>User can change this password after login. Admin can also reset it later.</small></div>`}

    <div class="full user-role-preview" id="userRolePreview"></div>

    <div class="actions">
      <button type="button" class="btn" onclick="closeUserForm()">Cancel</button>
      <button class="btn primary">${existing?'Update User':'Create User'}</button>
    </div>`;

  const form=$('#userForm');
  const memberSelect=$('#userLinkedMember');
  const roleSelect=$('#userAccountRole');

  function selectedMember(){
    return members.find(m=>m.id===memberSelect?.value)||null;
  }

  function fillFromMember(force=false){
    const m=selectedMember();
    if(!m)return;
    const name=$('#userAccountName'),email=$('#userAccountEmail'),whatsapp=$('#userAccountWhatsapp');
    if(force||!name.value)name.value=m.name||'';
    if(force||!email.value)email.value=m.email||m.cscEmail||'';
    if(force||!whatsapp.value)whatsapp.value=m.whatsapp||m.phone||m.cscPhone||'';
  }

  function renderRolePreview(){
    const m=selectedMember();
    const role=roleSelect?.value||'General Member';
    const roleNotes={
      'Super Admin':'Full control including users, security, settings, backup and all modules.',
      'President':'Organization-wide view and approval workflow authority.',
      'Secretary':'Member, joining, committee, event, social-work and meeting administration.',
      'Treasurer':'Subscription, donation, income, expense, cash/bank, accounting and payment execution.',
      'Committee Member':'Limited organizational view with permitted approval workflow actions.',
      'General Member':'Own Member Portal only: profile, dues, receipts, donation, welfare/loan, events and notices.'
    };
    const linked=m?`${m.id} — ${m.name}`:'No member selected';
    $('#userRolePreview').innerHTML=`
      <div><span>Linked Member</span><b>${esc(linked)}</b></div>
      <div><span>Assigned Role</span><b>${esc(role)}</b></div>
      <p>${esc(roleNotes[role]||'Role-based access will be applied according to system permissions.')}</p>`;
  }

  memberSelect?.addEventListener('change',()=>{fillFromMember(true);renderRolePreview()});
  roleSelect?.addEventListener('change',renderRolePreview);

  if(existing){
    fillFromMember(false);
  }
  renderRolePreview();

  $('#userFormModal').classList.add('show');

  form.onsubmit=async e=>{
    e.preventDefault();
    const d=Object.fromEntries(new FormData(e.target));
    if(!d.memberId && !existing)return alert('Please select a Member.');
    if(!d.name?.trim())return alert('Name is required.');
    if(!d.email?.trim())return alert('Login Email is required.');

    try{
      if(existing){
        await api('/api/users/'+existing.id,{method:'PUT',body:JSON.stringify(d)});
        toast('User account updated');
      }else{
        await api('/api/users',{method:'POST',body:JSON.stringify(d)});
        toast('Role-based user created');
      }
      closeUserForm();
      await loadAll();
      await showPage('users');
    }catch(x){alert(x.message)}
  };
}
window.openUserForm=openUserForm;

function closeUserForm(){$('#userFormModal').classList.remove('show')}



async function renderWhatsAppOtpSettings(){
  const box=$('#whatsappOtpSettings');
  if(!box||currentUser?.role!=='Super Admin')return;
  try{
    const s=await api('/api/whatsapp-otp-settings');
    const missing=(s.missingUsers||[]);
    box.innerHTML=`
      <div class="settings-slider-head">
        <div>
          <h3>WhatsApp OTP Login</h3>
          <p>When enabled, users sign in with their registered WhatsApp number. A fresh OTP is required for every login.</p>
        </div>
        <div class="otp-status-pill ${s.ready?'ready':'not-ready'}">${s.ready?'READY / ENABLED':(s.enabled?'INVALID CONFIGURATION':'CONFIGURATION REQUIRED')}</div>
      </div>
      <div class="otp-security-note">
        <b>Official WhatsApp Cloud API required.</b>
        <span>Use a Meta-approved Authentication template with OTP Copy Code. Access Token is stored encrypted locally and is excluded from backup exports.</span>
      </div>
      ${missing.length?`<div class="otp-config-warning"><b>${missing.length} active user(s) are missing a WhatsApp Login Number:</b> ${missing.map(x=>`${esc(x.id)} ${esc(x.name)}`).join(', ')}</div>`:''}
      ${(s.duplicateNumbers||[]).length?`<div class="otp-config-warning"><b>Duplicate WhatsApp numbers detected.</b> Fix them before enabling OTP login.</div>`:''}
      ${(s.configurationErrors||[]).length?`<div class="otp-config-warning otp-critical-warning"><b>Configuration problem:</b><br>${(s.configurationErrors||[]).map(x=>`• ${esc(x)}`).join('<br>')}<br><small>Password login stays available until the WhatsApp configuration is valid.</small></div>`:''}
      <form id="whatsappOtpSettingsForm" class="form-grid otp-settings-grid">
        <label class="full otp-enable-row"><input type="checkbox" name="enabled" ${s.enabled?'checked':''}><span><b>Enable WhatsApp OTP Login</b><small>Password login will be blocked while this is enabled. OTP verification will be required every login.</small></span></label>
        <label>Graph API Version<input name="apiVersion" value="${esc(s.apiVersion||'v26.0')}" placeholder="v26.0"></label>
        <label>Phone Number ID<input name="phoneNumberId" inputmode="numeric" pattern="[0-9]{8,30}" value="${esc(s.phoneNumberId||'')}" placeholder="Example: 1906385232743451"><small>Numeric Meta Phone Number ID only — NOT email, mobile number, WABA ID or Business ID.</small></label>
        <label>Authentication Template Name<input name="templateName" pattern="[a-z0-9_]+" value="${esc(s.templateName||'authentication_code_copy_code_button')}"><small>Enter the exact APPROVED AUTHENTICATION template name from WhatsApp Manager.</small></label>
        <label>Template Language<input name="templateLanguage" value="${esc(s.templateLanguage||'en_US')}"></label>
        <label>Default Country Code<input name="defaultCountryCode" value="${esc(s.defaultCountryCode||'91')}"></label>
        <label>OTP Expiry (minutes)<input type="number" name="expiryMinutes" min="3" max="15" value="${Number(s.expiryMinutes||10)}"></label>
        <label>Resend Cooldown (seconds)<input type="number" name="resendSeconds" min="30" max="300" value="${Number(s.resendSeconds||60)}"></label>
        <label>Maximum OTP Attempts<input type="number" name="maxAttempts" min="3" max="10" value="${Number(s.maxAttempts||5)}"></label>
        <label class="full">Meta Access Token<input type="password" name="accessToken" autocomplete="off" placeholder="${s.accessTokenConfigured?'Token already saved — enter a new token only to replace it':'Paste the complete Meta OAuth/System User access token'}"><small>${esc(s.accessTokenHint||'')} · Do not enter email/password. If Meta says “Cannot parse access token”, replace the saved token with a fresh complete token.</small></label>
        <div class="actions full otp-settings-actions">
          <button type="button" class="btn" onclick="validateWhatsAppConfig()">Validate Meta Configuration</button>
          <button class="btn primary">Save WhatsApp OTP Settings</button>
        </div>
      </form>
      <div class="otp-test-row">
        <input id="otpTestNumber" placeholder="Test WhatsApp number" value="${esc(currentUser?.whatsapp||'')}">
        <button type="button" class="btn" onclick="testWhatsAppOtp()">Send Test OTP</button>
      </div>
    `;
    $('#whatsappOtpSettingsForm').onsubmit=async e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(e.target));
      data.enabled=e.target.enabled.checked;
      try{
        const r=await api('/api/whatsapp-otp-settings',{method:'POST',body:JSON.stringify(data)});
        toast(r.enabled?'WhatsApp OTP Login enabled':'WhatsApp OTP settings saved');
        await renderWhatsAppOtpSettings();
      }catch(err){alert(err.message)}
    };
  }catch(err){
    box.innerHTML=`<div class="msg">${esc(err.message||'Unable to load WhatsApp OTP settings')}</div>`;
  }
}
async function validateWhatsAppConfig(){
  const form=$('#whatsappOtpSettingsForm');
  if(!form)return;
  const data=Object.fromEntries(new FormData(form));data.enabled=form.enabled.checked;
  const id=String(data.phoneNumberId||'').trim();
  if(!/^\d{8,30}$/.test(id)){alert('Phone Number ID must be a numeric Meta Phone Number ID. The value in your screenshot is an email address, which is not valid.');return}
  try{
    const r=await api('/api/whatsapp-otp-settings/validate',{method:'POST',body:JSON.stringify(data)});
    alert(`${r.message||'Meta configuration is valid.'}${r.displayPhoneNumber?`\nWhatsApp Number: ${r.displayPhoneNumber}`:''}${r.verifiedName?`\nVerified Name: ${r.verifiedName}`:''}${r.qualityRating?`\nQuality: ${r.qualityRating}`:''}`);
  }catch(err){alert(err.message)}
}
window.validateWhatsAppConfig=validateWhatsAppConfig;

async function testWhatsAppOtp(){
  const n=$('#otpTestNumber')?.value?.trim();
  try{
    const r=await api('/api/whatsapp-otp-settings/test',{method:'POST',body:JSON.stringify({whatsapp:n})});
    alert(r.message||'Test OTP sent');
  }catch(err){alert(err.message)}
}
window.testWhatsAppOtp=testWhatsAppOtp;

async function renderLoginSliderManager(){
  const box=$('#loginSliderManager');
  if(!box || currentUser?.role!=='Super Admin') return;
  try{
    const res=await api('/api/login-slides/manage');
    const slides=res.slides||[];
    box.innerHTML=`
      <div class="settings-slider-head">
        <div>
          <h3>Login Page Image Slider</h3>
          <p>The ERP login page uses a left-side image slider and a right-side login panel. Super Admin can upload multiple images and delete them when needed.</p>
        </div>
        <div class="settings-slider-note">Recommended image size: 1600 × 900 or wider · PNG / JPG / WEBP</div>
      </div>

      <form id="loginSliderUploadForm" class="form-grid login-slider-upload-grid">
        <label>Slide Title<input name="title" placeholder="Example: Organization events, meetings, or activities"></label>
        <label>Short Caption<input name="caption" placeholder="Short message shown on the slider"></label>
        <label class="full">Select Image<input type="file" name="image" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" required></label>
        <div class="actions"><button class="btn primary">Upload Slider Image</button></div>
      </form>

      <div class="login-slide-admin-grid">
        ${slides.length?slides.map(s=>`
          <div class="login-slide-admin-item">
            <div class="login-slide-admin-thumb"><img src="${esc(s.imageUrl)}" alt="${esc(s.title||'Slider image')}"></div>
            <div class="login-slide-admin-meta">
              <h4>${esc(s.title||'Untitled Slide')}</h4>
              <p>${esc(s.caption||'No caption added')}</p>
              <small>${esc(s.originalName||'Image file')} · ${(Number(s.size||0)/1024).toFixed(1)} KB</small>
            </div>
            <div class="login-slide-admin-actions">
              <button type="button" class="mini danger" onclick="deleteLoginSlide('${esc(s.id)}')">Delete</button>
            </div>
          </div>
        `).join(''):`<div class="login-slide-empty">No custom slider image uploaded yet. The login page is currently using built-in fallback slides.</div>`}
      </div>
    `;

    $('#loginSliderUploadForm').onsubmit=async e=>{
      e.preventDefault();
      const file=e.target.image.files?.[0];
      if(!file){alert('Please choose a slider image');return}
      try{
        const dataUrl=await fileToDataURL(file);
        await api('/api/login-slides',{
          method:'POST',
          body:JSON.stringify({
            title:e.target.title.value,
            caption:e.target.caption.value,
            filename:file.name,
            dataUrl
          })
        });
        toast('Login slider image uploaded');
        await renderLoginSliderManager();
      }catch(err){alert(err.message)}
    };
  }catch(err){
    box.innerHTML=`<div class="msg">${esc(err.message||'Unable to load slider settings')}</div>`;
  }
}
async function deleteLoginSlide(id){
  if(!confirm('Delete this login slider image?'))return;
  try{
    await api(`/api/login-slides/${encodeURIComponent(id)}`,{method:'DELETE'});
    toast('Slider image deleted');
    await renderLoginSliderManager();
  }catch(err){alert(err.message)}
}
window.deleteLoginSlide=deleteLoginSlide;


async function renderPublicHomeSliderManager(){
  const box=$('#publicHomeSliderManager');
  if(!box || currentUser?.role!=='Super Admin') return;
  try{
    const res=await api('/api/public-home-slides/manage');
    const slides=res.slides||[];
    box.innerHTML=`
      <div class="settings-slider-head">
        <div>
          <h3>Public Website Image Slider</h3>
          <p>The Public Website uses a large 70% image slider beside the CSC Centre Finder. Upload multiple organization, CSC, event, social-work, or activity photos here.</p>
        </div>
        <div class="settings-slider-note">Recommended: 1600 × 900 · PNG / JPG / WEBP · up to 8 MB</div>
      </div>

      <form id="publicHomeSliderUploadForm" class="form-grid login-slider-upload-grid">
        <label>Slide Title<input name="title" placeholder="Example: CSC VLE Community Network"></label>
        <label>Short Caption<input name="caption" placeholder="Short public message"></label>
        <label class="full">Select Image<input type="file" name="image" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" required></label>
        <div class="actions"><button class="btn primary">Upload Public Slider Image</button></div>
      </form>

      <div class="login-slide-admin-grid">
        ${slides.length?slides.map(s=>`
          <div class="login-slide-admin-item">
            <div class="login-slide-admin-thumb"><img src="${esc(s.imageUrl)}" alt="${esc(s.title||'Public slider image')}"></div>
            <div class="login-slide-admin-meta">
              <h4>${esc(s.title||'Untitled Slide')}</h4>
              <p>${esc(s.caption||'No caption added')}</p>
              <small>${esc(s.originalName||'Image file')} · ${(Number(s.size||0)/1024).toFixed(1)} KB</small>
            </div>
            <div class="login-slide-admin-actions">
              <button type="button" class="mini danger" onclick="deletePublicHomeSlide('${esc(s.id)}')">Delete</button>
            </div>
          </div>
        `).join(''):`<div class="login-slide-empty">No Public Website slider image uploaded yet. The website will use built-in colorful fallback slides.</div>`}
      </div>
    `;
    $('#publicHomeSliderUploadForm').onsubmit=async e=>{
      e.preventDefault();
      const file=e.target.image.files?.[0];
      if(!file){alert('Please choose a Public Website slider image');return}
      try{
        const dataUrl=await fileToDataURL(file);
        await api('/api/public-home-slides',{
          method:'POST',
          body:JSON.stringify({
            title:e.target.title.value,
            caption:e.target.caption.value,
            filename:file.name,
            dataUrl
          })
        });
        toast('Public Website slider image uploaded');
        await renderPublicHomeSliderManager();
      }catch(err){alert(err.message)}
    };
  }catch(err){
    box.innerHTML=`<div class="msg">${esc(err.message||'Unable to load Public Website slider settings')}</div>`;
  }
}
async function deletePublicHomeSlide(id){
  if(!confirm('Delete this Public Website slider image?'))return;
  try{
    await api(`/api/public-home-slides/${encodeURIComponent(id)}`,{method:'DELETE'});
    toast('Public Website slider image deleted');
    await renderPublicHomeSliderManager();
  }catch(err){alert(err.message)}
}
window.deletePublicHomeSlide=deletePublicHomeSlide;

async function loadSettings(){
  if(!canPage('settings')||!$('#settings').classList.contains('active')||$('#settingsForm').dataset.loaded)return;
  try{
    const s=await api('/api/settings');
    $('#settingsForm').innerHTML=`
      <label>Owner / Administrator Name<input name="ownerName" value="${esc(s.ownerName||'')}" required></label>
      <label>Login Email<input type="email" name="email" value="${esc(s.email||'')}" required></label>
      <label>WhatsApp Login Number<input name="whatsapp" value="${esc(s.whatsapp||'')}" placeholder="Example: 919876543210"></label>
      <label class="full">New Password<input type="password" name="newPassword" placeholder="Leave blank to keep current password"></label>
      <div class="actions"><button class="btn primary">Save Administrator Settings</button></div>`;
    $('#settingsForm').dataset.loaded='1';
    $('#settingsForm').onsubmit=async e=>{
      e.preventDefault();
      try{
        await api('/api/settings',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});
        toast('Administrator settings saved');
        if(e.target.newPassword.value){alert('Password changed. Please login again.');location.reload();return}
        $('#settingsForm').dataset.loaded='';await loadAll();
      }catch(x){alert(x.message)}
    };
    await renderWhatsAppOtpSettings();
    await renderLoginSliderManager();
    await renderPublicHomeSliderManager();
  }catch(e){}
}
async function del(type,id){if(!confirm('Delete this record?'))return;try{await api(`/api/${type}/${id}`,{method:'DELETE'});toast('Deleted');await loadAll()}catch(e){alert(e.message)}}
function openForm(kind, editId=''){
  let title='',html='';
  if(kind==='member'){
    const m=editId?cache.members.find(x=>x.id===editId):null;
    if(!m){closeModal();showPage('applications');openApplicationForm();return}
    title=`Edit Member — ${m.id}`;
    const opt=(v,cur)=>v===cur?'selected':'';
    html=`
      ${m?`<div class="full info-strip"><b>Unique Member ID:</b> ${esc(m.id)}</div>`:''}
      <label>Name<input name="name" value="${esc(m?.name||'')}" required></label>
      <label>Father / Spouse Name<input name="fatherSpouse" value="${esc(m?.fatherSpouse||'')}"></label>
      <label>Date of Birth<input type="date" name="dob" value="${esc(m?.dob||'')}"></label>
      <label>Mobile<input name="phone" value="${esc(m?.phone||'')}"></label>
      <label>Email<input type="email" name="email" value="${esc(m?.email||'')}"></label>
      <label>Joining Date<input type="date" name="joinDate" value="${esc(m?.joinDate||dateToday())}"></label>
      <label>Membership Type<select name="membershipType">
        <option ${opt('General',m?.membershipType)}>General</option>
        <option ${opt('Life Member',m?.membershipType)}>Life Member</option>
        <option ${opt('Founder Member',m?.membershipType)}>Founder Member</option>
        <option ${opt('Executive Member',m?.membershipType)}>Executive Member</option>
        <option ${opt('Honorary Member',m?.membershipType)}>Honorary Member</option>
      </select></label>
      <label>Designation<input name="designation" value="${esc(m?.designation||'Member')}" placeholder="Member / President / Secretary etc."></label>
      <label>Member Status<select name="status">
        <option ${opt('Active',m?.status)}>Active</option>
        <option ${opt('Inactive',m?.status)}>Inactive</option>
        <option ${opt('Suspended',m?.status)}>Suspended</option>
        <option ${opt('Resigned',m?.status)}>Resigned</option>
      </select></label>
      <label>Monthly Subscription Rate<input type="number" name="monthlyFee" value="${Number(m?.monthlyFee??cache.master?.monthlyFee??200)}"></label>
      <label class="full">Address<textarea name="address">${esc(m?.address||'')}</textarea></label>

      <h3 class="full section-title">CSC VLE Centre / Public Centre Finder</h3>
      <label>CSC Centre Name<input name="cscCentreName" value="${esc(m?.cscCentreName||'')}" placeholder="Example: ABC CSC Centre"></label>
      <label>CSC ID<input name="cscId" value="${esc(m?.cscId||'')}" placeholder="CSC ID / Operator ID"></label>
      <label>Centre Contact Number<input name="cscPhone" value="${esc(m?.cscPhone||'')}" placeholder="Public centre contact"></label>
      <label>Centre Email<input type="email" name="cscEmail" value="${esc(m?.cscEmail||'')}" placeholder="Public centre email"></label>
      <label>Area / Locality<input name="cscArea" value="${esc(m?.cscArea||'')}"></label>
      <label>Block<input name="cscBlock" value="${esc(m?.cscBlock||'')}"></label>
      <label>District<input name="cscDistrict" value="${esc(m?.cscDistrict||'')}"></label>
      <label>State<input name="cscState" value="${esc(m?.cscState||'West Bengal')}"></label>
      <label>PIN Code<input name="cscPin" value="${esc(m?.cscPin||'')}"></label>
      <label>Landmark<input name="cscLandmark" value="${esc(m?.cscLandmark||'')}"></label>
      <label class="full">CSC Centre Address<textarea name="cscCentreAddress" placeholder="Full public centre address">${esc(m?.cscCentreAddress||'')}</textarea></label>
      <label class="full">Services / Notes<textarea name="cscServices" placeholder="Example: Aadhaar, PAN, Banking, Insurance, Online Services">${esc(m?.cscServices||'')}</textarea></label>
      <label class="full public-csc-toggle">
        <input type="checkbox" name="publicCscVisible" value="true" ${m?.publicCscVisible?'checked':''}>
        <span><b>Show in Public CSC Centre Finder</b><small>Only the CSC centre information entered above will be displayed publicly. Personal home address and private member finance will remain hidden.</small></span>
      </label>

      <h3 class="full section-title">Nominee / Emergency Contact</h3>
      <label>Contact Name<input name="emergencyName" value="${esc(m?.emergencyName||'')}"></label>
      <label>Relation<input name="emergencyRelation" value="${esc(m?.emergencyRelation||'')}"></label>
      <label>Mobile<input name="emergencyPhone" value="${esc(m?.emergencyPhone||'')}"></label>`;
  }
  if(kind==='collection'){
    title=`Add Payment / Collection — FY ${activeFY}`;
    html=`<div class="full info-strip"><b>Automatic Receipt:</b> Receipt Number will be generated automatically after saving.</div>
    <label>Member<select name="memberId"><option value="">Other Donor / Person</option>${cache.members.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
    <label>Other Person Name<input name="personName"></label>
    <label>Payment Head<select name="type" id="collectionType">
      <option>Annual Fee</option>
      <option>Special Contribution</option>
      <option>Joining Fee</option>
      <option>Other Collection</option>
    </select></label>
    <label>Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label>
    <label>Amount<input type="number" name="amount" id="collectionAmount" required></label>
    <label>Date<input type="date" name="date" value="${dateToday()}"></label>
    <label class="full">Notes<textarea name="notes"></textarea></label>`}

  if(kind==='transaction'){title=`Add Income / Expense — FY ${activeFY}`;html=`<label>Type<select name="type"><option>Expense</option><option>Income</option></select></label><label>Category<input name="category" required></label><label>Fund / Donation Purpose<select name="fundingPurpose"><option value="">Not Tagged / General Account</option>${DONATION_PURPOSES.map(p=>`<option>${esc(p)}</option>`).join('')}</select></label><label>Mode<select name="mode"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></label><label class="full">Description<textarea name="description"></textarea></label><label>Amount<input type="number" name="amount" required></label><label>Date<input type="date" name="date" value="${dateToday()}"></label>`}
  $('#modalTitle').textContent=title;
  $('#modalForm').innerHTML=html+`<div class="actions"><button class="btn primary">Save</button></div>`;
  $('#modal').classList.add('show');
  if(kind==='collection'){
    const typeEl=$('#collectionType'), amountEl=$('#collectionAmount');
    const defaultFor=t=>{
      if(t==='Joining Fee') return Number(cache.master?.joiningFee??500);
      if(t==='Annual Fee') return Number(cache.master?.annualFee??0);
      if(t==='Special Contribution') return Number(cache.master?.specialContributionDefault??0);
      return 0;
    };
    const applyDefault=()=>{const v=defaultFor(typeEl.value); amountEl.value=v>0?v:''};
    typeEl.onchange=applyDefault; applyDefault();
  }
  $('#modalForm').onsubmit=async e=>{
    e.preventDefault();
    const d=Object.fromEntries(new FormData(e.target));
    if(kind!=='member') d.financialYear=activeFY;
    const map={member:'members',collection:'collections',transaction:'transactions'};
    try{
      const url=kind==='member'&&editId?`/api/members/${encodeURIComponent(editId)}`:'/api/'+map[kind];
      await api(url,{method:(kind==='member'&&editId)?'PUT':'POST',body:JSON.stringify(d)});
      closeModal();toast(editId?'Member updated':'Saved');await loadAll()
    }catch(x){alert(x.message)}
  };
}

async function viewMember(id){
  try{
    const p=await api(fyUrl(`/api/members/${encodeURIComponent(id)}/profile`));
    const m=p.member,s=p.summary;
    $('#memberProfileBody').innerHTML=`
      <div class="member-profile-head">
        <div class="member-photo-box">
          ${m.photoPath?`<img src="${esc(m.photoPath)}" alt="${esc(m.name)}">`:`<div class="member-photo-placeholder">${esc((m.name||'?').slice(0,1).toUpperCase())}</div>`}
          <input id="memberPhotoFile" type="file" accept=".png,.jpg,.jpeg,.webp">
          <button class="mini" onclick="uploadMemberPhoto('${m.id}')">Upload / Change Photo</button>
        </div>
        <div class="member-main">
          <span class="member-id-chip">${esc(m.id)}</span>
          <h2>${esc(m.name)}</h2>
          <p>${esc(m.designation||'Member')} · ${esc(m.membershipType||'General')} · ${esc(m.status)}</p>
          <button class="mini" onclick="closeMemberProfile();openForm('member','${m.id}')">Edit Profile</button>
        </div>
      </div>

      <div class="profile-summary-grid">
        <div class="profile-stat"><span>FY ${activeFY} Subscription</span><b>${money(s.totalSubscription)}</b><small>${s.dueMonths} due month(s)</small></div>
        <div class="profile-stat"><span>Subscription Arrears</span><b>${money(s.arrears)}</b><small>Expected ${money(s.expectedSubscription)}</small></div>
        <div class="profile-stat"><span>Donation</span><b>${money(s.donation)}</b><small>Selected Financial Year</small></div>
        <div class="profile-stat"><span>Benefits / Assistance</span><b>${money(s.benefitTotal)}</b><small>Selected Financial Year</small></div>
        <div class="profile-stat"><span>Loan / Advance</span><b>${money(s.loanTotal)}</b><small>Total sanctioned/applied</small></div>
        <div class="profile-stat"><span>Loan Outstanding</span><b>${money(s.loanOutstanding)}</b><small>Repaid ${money(s.loanRepaid)}</small></div>
      </div>

      <div class="profile-detail-grid">
        ${detail('Father / Spouse',m.fatherSpouse)}
        ${detail('Date of Birth',m.dob)}
        ${detail('Mobile',m.phone)}
        ${detail('Email',m.email)}
        ${detail('Joining Date',m.joinDate)}
        ${detail('Monthly Subscription',money(m.monthlyFee))}
        ${detail('Address',m.address,'full')}
        ${detail('CSC Centre',m.cscCentreName)}
        ${detail('CSC ID',m.cscId)}
        ${detail('Centre Contact',m.cscPhone)}
        ${detail('Centre Email',m.cscEmail)}
        ${detail('Centre Area / Block',[m.cscArea,m.cscBlock].filter(Boolean).join(' · '))}
        ${detail('Centre District / PIN',[m.cscDistrict,m.cscPin].filter(Boolean).join(' · '))}
        ${detail('CSC Centre Address',m.cscCentreAddress,'full')}
        ${detail('Public CSC Finder',m.publicCscVisible?'Visible':'Hidden')}
        ${detail('Emergency Contact',m.emergencyName)}
        ${detail('Relation',m.emergencyRelation)}
        ${detail('Emergency Mobile',m.emergencyPhone)}
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Nominees</h3><p>Member nominee / beneficiary declaration.</p></div><button class="mini" onclick="addMemberNominee('${m.id}')">+ Add Nominee</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Name</th><th>Relation</th><th>Phone</th><th>Share %</th><th>Primary</th><th></th></tr></thead><tbody>
          ${(p.nominees||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.relation)}</td><td>${esc(x.phone||'—')}</td><td>${Number(x.sharePercent||0).toFixed(2)}%</td><td>${x.isPrimary?'Yes':'No'}</td><td><button class="mini danger" onclick="deleteMemberNominee('${m.id}','${x.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6">No nominees.</td></tr>'}
        </tbody></table></div>
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Benefits / Assistance — FY ${activeFY}</h3><p>Benefits or assistance the member received from the organization.</p></div><button class="mini" onclick="addMemberBenefit('${m.id}')">+ Add Benefit</button></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Amount</th><th></th></tr></thead><tbody>
          ${(p.benefits||[]).map(x=>`<tr><td>${esc(fmtDate(x.date))}</td><td>${esc(x.type)}</td><td>${esc(x.description)}</td><td>${money(x.amount)}</td><td><button class="mini danger" onclick="deleteBenefit('${x.id}','${m.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="5">No benefit/assistance records.</td></tr>'}
        </tbody></table></div>
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Collections — FY ${activeFY}</h3><p>Subscription, Donation and other collections.</p></div></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Date</th><th>Type</th><th>Mode</th><th>Amount</th></tr></thead><tbody>
          ${(p.collections||[]).map(x=>`<tr><td>${esc(fmtDate(x.date))}</td><td>${esc(x.type)}</td><td>${esc(x.mode)}</td><td>${money(x.amount)}</td></tr>`).join('')||'<tr><td colspan="4">No collection records.</td></tr>'}
        </tbody></table></div>
      </div>

      <div class="profile-ledger-block">
        <div class="profile-block-head"><div><h3>Loan / Advance — FY ${activeFY}</h3><p>Member loan/advance summary.</p></div></div>
        <div class="mini-table-wrap"><table class="mini-table"><thead><tr><th>Loan ID</th><th>Date</th><th>Amount</th><th>Repaid</th><th>Outstanding</th><th>Status</th></tr></thead><tbody>
          ${(p.loans||[]).map(x=>{const principal=Number(x.disbursedAmount||0);return `<tr><td>${esc(x.id)}</td><td>${esc(x.applicationDate||x.date||'')}</td><td>${money(principal)}</td><td>${money(x.repaid||0)}</td><td>${money(Math.max(0,principal-Number(x.repaid||0)))}</td><td>${loanStatusBadge(x.status)}</td></tr>`}).join('')||'<tr><td colspan="6">No loan/advance records.</td></tr>'}
        </tbody></table></div>
      </div>`;
    $('#memberProfileModal').classList.add('show');
  }catch(e){alert(e.message)}
}
function detail(label,value,cls=''){return `<div class="profile-detail ${cls}"><span>${label}</span><b>${esc(value||'—')}</b></div>`}
function closeMemberProfile(){$('#memberProfileModal').classList.remove('show')}
async function uploadMemberPhoto(id){
  const f=$('#memberPhotoFile').files[0];if(!f)return alert('Select a member photo.');
  try{
    const dataUrl=await fileToDataURL(f);
    await api(`/api/members/${encodeURIComponent(id)}/photo`,{method:'POST',body:JSON.stringify({filename:f.name,dataUrl})});
    toast('Member photo updated');await loadAll();await viewMember(id);
  }catch(e){alert(e.message)}
}
async function addMemberNominee(memberId){const name=prompt('Nominee Name:','');if(name===null)return;const relation=prompt('Relation:','');if(relation===null)return;const phone=prompt('Phone:','')||'';const sharePercent=prompt('Share %:','100');if(sharePercent===null)return;const isPrimary=confirm('Set as Primary Nominee?');try{await api(`/api/members/${encodeURIComponent(memberId)}/nominees`,{method:'POST',body:JSON.stringify({name,relation,phone,sharePercent:Number(sharePercent||0),isPrimary})});toast('Nominee added');await loadAll();await viewMember(memberId)}catch(e){alert(e.message)}}
async function deleteMemberNominee(memberId,nomineeId){if(!confirm('Delete nominee?'))return;try{await api(`/api/members/${encodeURIComponent(memberId)}/nominees/${encodeURIComponent(nomineeId)}`,{method:'DELETE'});toast('Nominee deleted');await loadAll();await viewMember(memberId)}catch(e){alert(e.message)}}
async function addMemberBenefit(memberId){
  const type=prompt('Benefit / Assistance Type:', 'Financial Assistance'); if(type===null)return;
  const desc=prompt('Description:', ''); if(desc===null)return;
  const amount=prompt('Amount (0 if non-cash benefit):','0'); if(amount===null)return;
  try{
    await api(`/api/members/${encodeURIComponent(memberId)}/benefits`,{method:'POST',body:JSON.stringify({
      type,description:desc,amount:Number(amount||0),date:dateToday(),financialYear:activeFY
    })});
    toast('Benefit / assistance saved');await loadAll();await viewMember(memberId);
  }catch(e){alert(e.message)}
}
async function deleteBenefit(id,memberId){
  if(!confirm('Delete this benefit/assistance record?'))return;
  try{await api(`/api/member-benefits/${encodeURIComponent(id)}`,{method:'DELETE'});toast('Deleted');await loadAll();await viewMember(memberId)}catch(e){alert(e.message)}
}

/* V5.21 Safe Modal Protection:
   Modal/backdrop clicks intentionally DO NOT close popups.
   Close only through explicit X / Cancel / successful Save-Update-Submit actions. */
function closeModal(){$('#modal').classList.remove('show')}







































function printReceipt(id){
  const r=cache.collections.find(x=>x.id===id);
  if(!r)return alert('Receipt not found.');
  const org=cache.master||{};
  const w=window.open('','_blank','width=820,height=760');
  const logo=org.logoPath?`<img src="${esc(org.logoPath)}" style="max-height:70px;max-width:100px;object-fit:contain">`:'';
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(r.id)}</title>
  <style>
  body{font-family:Arial,sans-serif;margin:0;padding:30px;color:#111}.receipt{max-width:720px;margin:auto;border:2px solid #111;padding:24px}
  .head{display:flex;gap:16px;align-items:center;border-bottom:2px solid #111;padding-bottom:14px}.head h1{font-size:22px;margin:0}.head p{margin:4px 0;font-size:12px}
  .title{text-align:center;font-size:18px;font-weight:bold;margin:18px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.row{padding:8px 0;border-bottom:1px dotted #aaa}.row b{display:block;font-size:11px;text-transform:uppercase;color:#555;margin-bottom:4px}
  .amount{font-size:22px;font-weight:bold}.foot{display:flex;justify-content:space-between;margin-top:42px;font-size:12px}.sig{border-top:1px solid #111;padding-top:6px;min-width:170px;text-align:center}
  @media print{button{display:none}}
  </style></head><body><div class="receipt">
  <div class="head">${logo}<div><h1>${esc(org.organizationName||'Organization')}</h1><p>${esc(org.registeredAddress||org.officeAddress||'')}</p></div></div>
  <div class="title">PAYMENT RECEIPT</div>
  <div class="grid">
    <div class="row"><b>Receipt Number</b>${esc(r.id)}</div>
    <div class="row"><b>Financial Year</b>${esc(r.financialYear||activeFY)}</div>
    <div class="row"><b>Date</b>${esc(fmtDate(r.date))}</div>
    <div class="row"><b>Payment Mode</b>${esc(r.mode)}</div>
    <div class="row"><b>Received From</b>${esc(r.personName)}</div>
    <div class="row"><b>Payment Head</b>${esc(r.type)}</div>
    ${r.type==='Donation'?`<div class="row"><b>Donation Type</b>${esc(r.donationType||'External Donation')}</div><div class="row"><b>Donation Purpose</b>${esc(r.donationPurpose||'General Fund')}</div>${r.donorMobile?`<div class="row"><b>Donor Mobile</b>${esc(r.donorMobile)}</div>`:''}`:''}
    <div class="row" style="grid-column:1/-1"><b>Amount</b><span class="amount">${money(r.amount)}</span></div>
    <div class="row" style="grid-column:1/-1"><b>Notes</b>${esc(r.notes||'—')}</div>
  </div>
  <div class="foot"><div>Computer Generated Receipt</div><div class="sig">Authorized Signature</div></div>
  </div><div style="text-align:center;margin-top:15px"><button onclick="window.print()">Print Receipt</button></div></body></html>`);
  w.document.close();
}
function downloadBackup(){window.location=fyUrl('/api/backup')}

let bootRunning=false;
async function boot(){
  if(bootRunning)return;
  bootRunning=true;
  try{
    const st=await init();
    if(st?.configured)await trySession();
  }finally{bootRunning=false}
}
boot();


document.addEventListener('click',e=>{
  const btn=e.target.closest('#addUserButton');
  if(btn){
    e.preventDefault();
    openUserForm();
  }
});
