
async function publicFileToDataUrl(file,maxBytes,label){
  if(!file)throw new Error(`${label} is required.`);
  if(file.size>maxBytes)throw new Error(`${label} is too large. Maximum allowed size is ${(maxBytes/1024/1024).toFixed(0)} MB.`);
  return await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(new Error(`Unable to read ${label}.`));
    reader.readAsDataURL(file);
  });
}

function publicApplicationMessage(text,type='error'){
  const box=$('#publicApplicationMessage');
  if(!box)return;
  box.innerHTML=text?`<div class="public-form-message ${type}">${esc(text)}</div>`:'';
}


const membershipWizard={current:1,total:6,titles:['Personal Information','Permanent Address','CSC Centre Information','Applicant Photo & KYC Documents','Nominee / Emergency Contact','Declaration']};
function openMembershipApplicationModal(){const m=$('#membershipApplicationModal');if(!m)return;m.classList.remove('hidden');m.setAttribute('aria-hidden','false');document.body.classList.add('membership-modal-open');membershipWizard.current=1;updateMembershipWizard();}
function closeMembershipApplicationModal(){const m=$('#membershipApplicationModal');if(!m)return;m.classList.add('hidden');m.setAttribute('aria-hidden','true');document.body.classList.remove('membership-modal-open');publicApplicationMessage('');}
function wizardStepEl(step){return document.querySelector(`.wizard-form-step[data-wizard-step="${step}"]`)}
function validateWizardStep(step){
  const s=wizardStepEl(step);if(!s)return true;
  for(const el of s.querySelectorAll('input,select,textarea')){if(el.required&&!el.checkValidity()){el.reportValidity();el.focus();return false}}
  if(step===4){
    const f=$('#publicMembershipForm'),a=String(f.aadhaarNumber.value||'').replace(/\D/g,''),p=String(f.panNumber.value||'').trim().toUpperCase(),v=String(f.voterNumber.value||'').trim().toUpperCase();
    if(!/^\d{12}$/.test(a)){publicApplicationMessage('Aadhaar Card Number must contain exactly 12 digits.','error');f.aadhaarNumber.focus();return false}
    if(!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(p)){publicApplicationMessage('Enter a valid PAN Card Number, for example ABCDE1234F.','error');f.panNumber.focus();return false}
    if(v.length<6){publicApplicationMessage('Enter a valid Voter Card / EPIC Number.','error');f.voterNumber.focus();return false}
  }
  publicApplicationMessage('');return true;
}
function updateMembershipWizard(){
  document.querySelectorAll('.wizard-form-step').forEach(x=>x.classList.toggle('active',Number(x.dataset.wizardStep)===membershipWizard.current));
  document.querySelectorAll('.wizard-step-indicator').forEach(x=>{const s=Number(x.dataset.wizardNav);x.classList.toggle('active',s===membershipWizard.current);x.classList.toggle('completed',s<membershipWizard.current)});
  const fill=$('#wizardProgressFill');if(fill)fill.style.width=`${((membershipWizard.current-1)/(membershipWizard.total-1))*100}%`;
  setText('#wizardStepCounter',`Step ${membershipWizard.current} of ${membershipWizard.total}`,'');setText('#wizardCurrentStepTitle',membershipWizard.titles[membershipWizard.current-1]||'','');
  $('#wizardBackBtn')?.classList.toggle('hidden',membershipWizard.current===1);$('#wizardNextBtn')?.classList.toggle('hidden',membershipWizard.current===membershipWizard.total);$('#publicApplicationSubmit')?.classList.toggle('hidden',membershipWizard.current!==membershipWizard.total);
}
function nextMembershipWizardStep(){if(validateWizardStep(membershipWizard.current)&&membershipWizard.current<membershipWizard.total){membershipWizard.current++;updateMembershipWizard()}}
function previousMembershipWizardStep(){if(membershipWizard.current>1){membershipWizard.current--;publicApplicationMessage('');updateMembershipWizard()}}
function bindMembershipWizard(){$('#wizardNextBtn')?.addEventListener('click',nextMembershipWizardStep);$('#wizardBackBtn')?.addEventListener('click',previousMembershipWizardStep);updateMembershipWizard();}
window.openMembershipApplicationModal=openMembershipApplicationModal;window.closeMembershipApplicationModal=closeMembershipApplicationModal;

function setCentreAddressFromPermanent(form){
  const fields={
    permanentVillage:'centreVillage',permanentPostOffice:'centrePostOffice',
    permanentPoliceStation:'centrePoliceStation',permanentGpWard:'centreGpWard',
    permanentBlockMunicipality:'centreBlockMunicipality',permanentDistrict:'centreDistrict',
    permanentState:'centreState',permanentPin:'centrePin',permanentAddressLine:'centreAddressLine'
  };
  for(const [a,b] of Object.entries(fields))if(form.elements[a]&&form.elements[b])form.elements[b].value=form.elements[a].value||'';
}
function bindSameAddressApplication(){
  const form=$('#publicMembershipForm'),cb=$('#sameAsPermanentAddress');
  if(!form||!cb)return;
  cb.addEventListener('change',()=>{if(cb.checked)setCentreAddressFromPermanent(form)});
  ['permanentVillage','permanentPostOffice','permanentPoliceStation','permanentGpWard','permanentBlockMunicipality','permanentDistrict','permanentState','permanentPin','permanentAddressLine'].forEach(n=>
    form.elements[n]?.addEventListener('input',()=>{if(cb.checked)setCentreAddressFromPermanent(form)})
  );
}
async function submitPublicMembershipApplication(e){
  e.preventDefault();
  const form=e.currentTarget,button=$('#publicApplicationSubmit');
  publicApplicationMessage('');
  const photo=form.photo.files?.[0],aadhaarFile=form.aadhaarFile.files?.[0],panFile=form.panFile.files?.[0],voterFile=form.voterFile.files?.[0];
  try{
    if(form.sameAsPermanentAddress.checked)setCentreAddressFromPermanent(form);
    if(!form.declaration.checked)throw new Error('Please accept the applicant declaration.');
    const aadhaar=String(form.aadhaarNumber.value||'').replace(/\D/g,'');
    const pan=String(form.panNumber.value||'').trim().toUpperCase();
    const voter=String(form.voterNumber.value||'').trim().toUpperCase();
    if(!/^\d{12}$/.test(aadhaar))throw new Error('Aadhaar Card Number must contain exactly 12 digits.');
    if(!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan))throw new Error('Enter a valid PAN Card Number, for example ABCDE1234F.');
    if(voter.length<6)throw new Error('Enter a valid Voter Card / EPIC Number.');
    if(photo&&!/\.(png|jpg|jpeg|webp)$/i.test(photo.name))throw new Error('Applicant Photo must be PNG, JPG, JPEG or WEBP.');
    for(const [f,label] of [[aadhaarFile,'Aadhaar Card'],[panFile,'PAN Card'],[voterFile,'Voter Card']]){
      if(f&&!/\.(pdf|png|jpg|jpeg|webp)$/i.test(f.name))throw new Error(`${label} upload must be PDF, PNG, JPG, JPEG or WEBP.`);
    }
    if(button){button.disabled=true;button.textContent='Submitting Application...';}
    const [photoDataUrl,aadhaarDataUrl,panDataUrl,voterDataUrl]=await Promise.all([
      publicFileToDataUrl(photo,3*1024*1024,'Applicant Photo'),
      publicFileToDataUrl(aadhaarFile,6*1024*1024,'Aadhaar Card'),
      publicFileToDataUrl(panFile,6*1024*1024,'PAN Card'),
      publicFileToDataUrl(voterFile,6*1024*1024,'Voter Card')
    ]);
    const fd=new FormData(form);
    const payload={
      name:fd.get('name'),fatherSpouse:fd.get('fatherSpouse'),dob:fd.get('dob'),gender:fd.get('gender'),
      phone:fd.get('phone'),whatsapp:fd.get('whatsapp'),email:fd.get('email'),
      permanentVillage:fd.get('permanentVillage'),permanentPostOffice:fd.get('permanentPostOffice'),permanentPoliceStation:fd.get('permanentPoliceStation'),
      permanentGpWard:fd.get('permanentGpWard'),permanentBlockMunicipality:fd.get('permanentBlockMunicipality'),permanentDistrict:fd.get('permanentDistrict'),
      permanentState:fd.get('permanentState'),permanentPin:fd.get('permanentPin'),permanentAddressLine:fd.get('permanentAddressLine'),
      cscId:fd.get('cscId'),cscCentreName:fd.get('cscCentreName'),sameAsPermanentAddress:form.sameAsPermanentAddress.checked,
      centreVillage:fd.get('centreVillage'),centrePostOffice:fd.get('centrePostOffice'),centrePoliceStation:fd.get('centrePoliceStation'),
      centreGpWard:fd.get('centreGpWard'),centreBlockMunicipality:fd.get('centreBlockMunicipality'),centreDistrict:fd.get('centreDistrict'),
      centreState:fd.get('centreState'),centrePin:fd.get('centrePin'),centreAddressLine:fd.get('centreAddressLine'),
      aadhaarNumber:aadhaar,panNumber:pan,voterNumber:voter,
      nomineeName:fd.get('nomineeName'),nomineeRelation:fd.get('nomineeRelation'),nomineePhone:fd.get('nomineePhone'),
      nomineeWhatsapp:fd.get('nomineeWhatsapp'),nomineeAddress:fd.get('nomineeAddress'),declaration:true,
      photoFilename:photo.name,photoDataUrl,
      aadhaarFilename:aadhaarFile.name,aadhaarDataUrl,
      panFilename:panFile.name,panDataUrl,
      voterFilename:voterFile.name,voterDataUrl
    };
    const response=await fetch('/api/public-membership-application',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data.error||'Unable to submit application.');
    form.reset();
    form.permanentState.value='West Bengal';form.centreState.value='West Bengal';
    membershipWizard.current=1;updateMembershipWizard();
    setText('#publicApplicationId',data.applicationId,'');
    closeMembershipApplicationModal();
    const success=$('#publicApplicationSuccess');
    if(success){success.classList.remove('hidden');setTimeout(()=>success.scrollIntoView({behavior:'smooth',block:'center'}),120);}
  }catch(err){publicApplicationMessage(err.message||'Unable to submit application.','error')}
  finally{if(button){button.disabled=false;button.textContent='Submit Membership Application';}}
}

let publicHeroSlidesData=[];
let publicHeroIndex=0;
let publicHeroTimer=null;
let publicCscCentres=[];

const PUBLIC_HERO_FALLBACK=[
  {title:'',caption:'',imageUrl:'/assets/public-slider-1.png'},
  {title:'',caption:'',imageUrl:'/assets/public-slider-2.png'},
  {title:'',caption:'',imageUrl:'/assets/public-slider-3.png'}
];

function publicHeroSlides(){return publicHeroSlidesData.length?publicHeroSlidesData:PUBLIC_HERO_FALLBACK}
function setPublicHeroSlide(i){
  const slides=publicHeroSlides();
  if(!slides.length)return;
  publicHeroIndex=(i+slides.length)%slides.length;
  const track=$('#publicHeroSlides');
  if(track)track.style.transform=`translateX(-${publicHeroIndex*100}%)`;
  document.querySelectorAll('#publicHeroDots button').forEach((b,idx)=>b.classList.toggle('active',idx===publicHeroIndex));
}
function startPublicHeroSlider(){
  if(publicHeroTimer)clearInterval(publicHeroTimer);
  if(publicHeroSlides().length>1)publicHeroTimer=setInterval(()=>setPublicHeroSlide(publicHeroIndex+1),5200);
}
function previousPublicHeroSlide(){setPublicHeroSlide(publicHeroIndex-1);startPublicHeroSlider()}
function nextPublicHeroSlide(){setPublicHeroSlide(publicHeroIndex+1);startPublicHeroSlider()}
window.previousPublicHeroSlide=previousPublicHeroSlide;
window.nextPublicHeroSlide=nextPublicHeroSlide;
window.setPublicHeroSlide=setPublicHeroSlide;

function renderPublicHeroSlides(slides=[]){
  publicHeroSlidesData=Array.isArray(slides)&&slides.length?slides:[];
  const list=publicHeroSlides(),track=$('#publicHeroSlides'),dots=$('#publicHeroDots');
  if(!track||!dots)return;
  track.innerHTML=list.map((s,i)=>{
    const has=!!s.imageUrl;
    return `<div class="public-photo-slide ${has?'has-image':(s.theme||`public-fallback-${i+1}`)}" ${has?`style="background-image:url('${String(s.imageUrl).replace(/'/g,'%27')}')"`:''}>
      ${has?'<div class="public-photo-shade"></div>':'<div class="public-slide-art"><span></span><i></i><b></b></div>'}
    </div>`;
  }).join('');
  dots.innerHTML=list.map((_,i)=>`<button type="button" onclick="setPublicHeroSlide(${i});startPublicHeroSlider()" aria-label="Go to image ${i+1}"></button>`).join('');
  publicHeroIndex=0;
  setPublicHeroSlide(0);
  startPublicHeroSlider();
}
window.startPublicHeroSlider=startPublicHeroSlider;

async function loadPublicHeroSlider(){
  try{
    const r=await fetch('/api/public-home-slider',{cache:'no-store'});
    if(!r.ok)throw new Error('Slider unavailable');
    const d=await r.json();
    renderPublicHeroSlides(d.slides||[]);
  }catch(e){renderPublicHeroSlides([])}
}

function cscSearchText(x){
  return [
    x.vleName,x.memberId,x.cscCentreName,x.cscId,x.centreAddress,x.area,x.block,
    x.district,x.state,x.pin,x.phone,x.email,x.landmark,x.services
  ].join(' ').toLowerCase();
}
function centreMapQuery(x){
  return [x.cscCentreName,x.centreAddress,x.area,x.block,x.district,x.state,x.pin].filter(Boolean).join(', ');
}
function renderCscCentres(rows){
  const box=$('#cscFinderResults');
  if(!box)return;
  setText('#cscFinderCount',String(rows.length),'0');
  if(!rows.length){
    box.innerHTML='<div class="csc-finder-empty">No CSC Centre found for the selected filter.</div>';
    return;
  }
  box.innerHTML=rows.map((x,i)=>`
    <article class="csc-result-card" data-csc-card="${esc(x.memberId)}">
      <button class="csc-result-summary" type="button" onclick="toggleCscCentre('${esc(x.memberId)}')">
        <span class="csc-result-avatar">${esc((x.vleName||'C').slice(0,1).toUpperCase())}</span>
        <span class="csc-result-main">
          <b>${esc(x.cscCentreName||'CSC Centre')}</b>
          <small>${esc(x.vleName||'CSC VLE')}${x.cscId?` · CSC ID ${esc(x.cscId)}`:''}</small>
          <em>${esc([x.area,x.block,x.district,x.pin].filter(Boolean).join(' · ')||'Location details available on click')}</em>
        </span>
        <span class="csc-result-chevron">›</span>
      </button>
      <div class="csc-result-detail">
        <div class="csc-detail-grid">
          <div><span>VLE Name</span><b>${esc(x.vleName||'—')}</b></div>
          <div><span>Member ID</span><b>${esc(x.memberId||'—')}</b></div>
          <div class="full"><span>Centre Address</span><b>${esc(x.centreAddress||[x.area,x.block,x.district,x.state,x.pin].filter(Boolean).join(', ')||'—')}</b></div>
          ${x.landmark?`<div class="full"><span>Landmark</span><b>${esc(x.landmark)}</b></div>`:''}
          <div><span>Contact</span><b>${esc(x.phone||'—')}</b></div>
          <div><span>Email</span><b>${esc(x.email||'—')}</b></div>
          ${x.services?`<div class="full"><span>Services</span><b>${esc(x.services)}</b></div>`:''}
        </div>
        <div class="csc-contact-actions">
          ${x.phone?`<a href="tel:${esc(String(x.phone).replace(/\s+/g,''))}">Call Centre</a>`:''}
          ${x.email?`<a href="mailto:${esc(x.email)}">Email</a>`:''}
          ${centreMapQuery(x)?`<a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(centreMapQuery(x))}">Open Location</a>`:''}
        </div>
      </div>
    </article>
  `).join('');
}
function filterCscCentres(){
  const q=String($('#cscFinderSearch')?.value||'').trim().toLowerCase();
  const block=String($('#cscFinderBlock')?.value||'').trim();
  const district=String($('#cscFinderDistrict')?.value||'').trim();
  const rows=publicCscCentres.filter(x=>{
    if(block && x.block!==block)return false;
    if(district && x.district!==district)return false;
    if(q && !cscSearchText(x).includes(q))return false;
    return true;
  });
  renderCscCentres(rows);
}
function resetCscFinder(){
  if($('#cscFinderSearch'))$('#cscFinderSearch').value='';
  if($('#cscFinderBlock'))$('#cscFinderBlock').value='';
  if($('#cscFinderDistrict'))$('#cscFinderDistrict').value='';
  filterCscCentres();
}
function toggleCscCentre(memberId){
  const card=document.querySelector(`[data-csc-card="${CSS.escape(memberId)}"]`);
  if(!card)return;
  const opening=!card.classList.contains('open');
  document.querySelectorAll('.csc-result-card.open').forEach(x=>x.classList.remove('open'));
  if(opening)card.classList.add('open');
}
window.filterCscCentres=filterCscCentres;
window.resetCscFinder=resetCscFinder;
window.toggleCscCentre=toggleCscCentre;

async function loadCscFinder(){
  try{
    const r=await fetch('/api/public-csc-centres',{cache:'no-store'});
    if(!r.ok)throw new Error('CSC Directory unavailable');
    const d=await r.json();
    publicCscCentres=d.rows||[];
    const block=$('#cscFinderBlock'),district=$('#cscFinderDistrict');
    if(block)block.innerHTML='<option value="">All Blocks</option>'+(d.blocks||[]).map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
    if(district)district.innerHTML='<option value="">All Districts</option>'+(d.districts||[]).map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
    renderCscCentres(publicCscCentres);
  }catch(e){
    publicCscCentres=[];
    renderCscCentres([]);
  }
}


const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const fmtDate=s=>{
  if(!s)return '—';
  const v=String(s).trim(),m=v.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(m)return `${m[3]}-${m[2]}-${m[1]}`;
  const d=new Date(v);
  return Number.isNaN(d.getTime())?v:`${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`;
};
const fmtTime=s=>{const d=new Date(s);return Number.isNaN(d.getTime())?'—':d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true})};
const fmtDateTime=s=>s?`${fmtDate(s)} ${fmtTime(s)}`:'—';
function setText(sel,val,fallback='—'){const el=$(sel);if(el)el.textContent=val||fallback}
function shortText(s,n=170){s=String(s||'').trim();return s.length>n?s.slice(0,n).trim()+'…':s}
function priorityClass(v){return String(v||'Normal').toLowerCase()}

let publicUpdateState={notices:[],events:[]};

function preserveLines(s){
  return esc(String(s||'')).replace(/\r?\n/g,'<br>');
}
function closePublicUpdateModal(){
  const modal=$('#publicUpdateModal');
  if(!modal)return;
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden','true');
  document.body.classList.remove('public-modal-open');
}
function openPublicUpdateModal(title,kicker,html){
  const modal=$('#publicUpdateModal');
  if(!modal)return;
  setText('#publicUpdateModalTitle',title||'Public Update','Public Update');
  setText('#publicUpdateModalKicker',kicker||'PUBLIC UPDATE','PUBLIC UPDATE');
  $('#publicUpdateModalBody').innerHTML=html||'';
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden','false');
  document.body.classList.add('public-modal-open');
  setTimeout(()=>$('#publicUpdateModalClose')?.focus(),30);
}
function noticeModalHtml(n){
  if(!n)return '<div class="public-modal-empty">Notice details are unavailable.</div>';
  return `
    <article class="public-modal-notice">
      <div class="public-modal-meta">
        <span class="priority ${priorityClass(n.priority)}">${esc(n.priority||'Normal')}</span>
        <span>${esc(n.noticeNo||'')}</span>
        <span>${esc(fmtDate(n.date))}</span>
      </div>
      <h3>${esc(n.title||'Notice')}</h3>
      <div class="public-modal-copy">${preserveLines(n.body||'')}</div>
      ${n.attachmentUrl?`<a class="public-modal-attachment" href="${esc(n.attachmentUrl)}" target="_blank" rel="noopener">📎 Open Attachment${n.attachmentOriginalName?` — ${esc(n.attachmentOriginalName)}`:''}</a>`:''}
    </article>`;
}
function eventModalHtml(e){
  if(!e)return '<div class="public-modal-empty">Event details are unavailable.</div>';
  const dateRange=e.endDate&&e.endDate!==e.startDate?`${fmtDate(e.startDate)} – ${fmtDate(e.endDate)}`:fmtDate(e.startDate);
  return `
    <article class="public-modal-event">
      <div class="public-modal-event-badge">UPCOMING EVENT</div>
      <h3>${esc(e.name||'Event')}</h3>
      <div class="public-modal-event-meta">
        <div><span>Date</span><b>${esc(dateRange)}</b></div>
        <div><span>Venue</span><b>${esc(e.venue||'Venue to be announced')}</b></div>
        <div><span>Status</span><b>${esc(e.status||'Planned')}</b></div>
        ${e.registrationDeadline?`<div><span>Registration Deadline</span><b>${esc(fmtDate(e.registrationDeadline))}</b></div>`:''}
      </div>
      ${e.description?`<div class="public-modal-copy">${preserveLines(e.description)}</div>`:''}
    </article>`;
}
function viewFullNotice(id){
  const n=(publicUpdateState.notices||[]).find(x=>String(x.id||x.noticeNo)===String(id)||String(x.noticeNo)===String(id));
  if(!n)return;
  openPublicUpdateModal(n.title||'Notice','FULL PUBLIC NOTICE',noticeModalHtml(n));
}
function viewEventDetails(id){
  const e=(publicUpdateState.events||[]).find(x=>String(x.id)===String(id));
  if(!e)return;
  openPublicUpdateModal(e.name||'Upcoming Event','EVENT DETAILS',eventModalHtml(e));
}
function latestUpdatePopupHtml(notice,event){
  let html='<div class="latest-update-popup">';
  if(notice){
    html+=`<section class="latest-update-section">
      <div class="latest-update-heading"><span>📢</span><div><small>LATEST PUBLIC NOTICE</small><h3>${esc(notice.title||'Notice')}</h3></div></div>
      <div class="latest-update-summary">${preserveLines(shortText(notice.body,420))}</div>
      <div class="latest-update-meta">${esc(notice.noticeNo||'')} · ${esc(fmtDate(notice.date))} · ${esc(notice.priority||'Normal')}</div>
      <button type="button" class="view-full-update-btn" onclick="viewFullNotice('${esc(notice.id||notice.noticeNo)}')">View Full Notice</button>
    </section>`;
  }
  if(event){
    const range=event.endDate&&event.endDate!==event.startDate?`${fmtDate(event.startDate)} – ${fmtDate(event.endDate)}`:fmtDate(event.startDate);
    html+=`<section class="latest-update-section event">
      <div class="latest-update-heading"><span>★</span><div><small>NEXT UPCOMING EVENT</small><h3>${esc(event.name||'Event')}</h3></div></div>
      <div class="latest-event-quick"><b>${esc(range)}</b><span>${esc(event.venue||'Venue to be announced')}</span></div>
      ${event.description?`<div class="latest-update-summary">${preserveLines(shortText(event.description,280))}</div>`:''}
      <button type="button" class="view-full-update-btn event-btn" onclick="viewEventDetails('${esc(event.id)}')">View Event Details</button>
    </section>`;
  }
  html+='</div>';
  return html;
}
function maybeAutoShowLatestUpdate(){
  const notice=publicUpdateState.notices?.[0]||null;
  const event=publicUpdateState.events?.[0]||null;
  if(!notice&&!event)return;
  const key=`oms-v58-latest-${notice?.id||notice?.noticeNo||'none'}-${event?.id||'none'}`;
  try{
    if(sessionStorage.getItem(key))return;
    sessionStorage.setItem(key,'1');
  }catch{}
  setTimeout(()=>{
    openPublicUpdateModal(
      notice&&event?'Latest Notice & Upcoming Event':notice?'Latest Public Notice':'Upcoming Event',
      'LATEST UPDATE',
      latestUpdatePopupHtml(notice,event)
    );
  },700);
}
window.closePublicUpdateModal=closePublicUpdateModal;
window.viewFullNotice=viewFullNotice;
window.viewEventDetails=viewEventDetails;

async function loadPublicSite(){
  try{
    const r=await fetch('/api/public-site',{cache:'no-store'});
    if(!r.ok)throw new Error('Public data unavailable');
    const d=await r.json(),o=d.organization||{},stats=d.stats||{};
    publicUpdateState={notices:d.notices||[],events:d.events||[]};

    document.title=`${o.name||'Organization'} — Official Website`;
    setText('#publicOrgName',o.name,'CSC Digital Yoddha');
    setText('#footerOrgName',o.name,'CSC Digital Yoddha');
    setText('#contactOrg',o.name,'CSC Digital Yoddha');
    setText('#publicVersion',d.appInfo?.version||'V5.21');
    setText('#footerVersion',`${d.appInfo?.appName||'Organization Management ERP'} ${d.appInfo?.version||'V5.21'}`);

    const objective=o.objective||'Membership, accounts, welfare, events, governance and communication—all within one integrated digital system.';
    setText('#heroObjective',objective);
    setText('#aboutEstablished',o.establishmentDate?fmtDate(o.establishmentDate):'—');
    setText('#aboutRegistration',o.registrationNo||'—');
    setText('#aboutArea',o.areaOfOperation||'—');

    setText('#statActiveMembers',stats.activeMembers||0,'0');
    setText('#statUpcomingEvents',stats.upcomingEvents||0,'0');
    setText('#statSocialPrograms',stats.completedSocialPrograms||0,'0');
    setText('#statPublicNotices',stats.publishedNotices||0,'0');

    setText('#contactAddress',o.officeAddress||'Panskura, Purba Medinipur');
    setText('#contactPhone',o.phone||'8001300092, 8900255364, 9734673867, 9733114561');
    setText('#contactEmail',o.email||'—');
    setText('#contactArea',o.areaOfOperation||'Panskura');

    if(o.phone){
      const p=$('#contactPhoneBtn');
      const firstPhone=String(o.phone).split(',')[0].trim().replace(/\s+/g,'');
      p.href='tel:'+firstPhone;
      p.textContent='Call '+firstPhone;
      p.classList.remove('hidden');
    }
    if(o.email){
      const e=$('#contactEmailBtn');
      e.href='mailto:'+o.email;
      e.classList.remove('hidden');
    }

    if(o.logoAvailable){
      const img=$('#publicLogo'),fallback=$('#publicLogoFallback');
      img.onload=()=>{img.classList.remove('hidden');fallback.classList.add('hidden')};
      img.onerror=()=>{img.classList.add('hidden');fallback.classList.remove('hidden')};
      img.src='/api/public-logo?v='+Date.now();
    }

    $('#publicNotices').innerHTML=(d.notices||[]).map(n=>`
      <article class="notice-item">
        <span class="priority ${priorityClass(n.priority)}">${esc(n.priority||'Normal')}</span>
        <div class="notice-top"><h4>${esc(n.title)}</h4><span class="notice-date">${esc(fmtDate(n.date))}</span></div>
        <p>${esc(shortText(n.body,190))}</p>
        <div class="public-update-actions">
          <button type="button" class="view-full-update-btn" onclick="viewFullNotice('${esc(n.id||n.noticeNo)}')">View Full Notice</button>
          ${n.attachmentUrl?`<a class="notice-attachment-mini" href="${esc(n.attachmentUrl)}" target="_blank" rel="noopener">Attachment</a>`:''}
        </div>
      </article>`).join('')||'<div class="empty-public-card compact">No public notice published yet.</div>';

    $('#publicEvents').innerHTML=(d.events||[]).map(e=>`
      <article class="event-item">
        <div class="event-top"><h4>${esc(e.name)}</h4><span class="event-date">${esc(fmtDate(e.startDate))}</span></div>
        <p>${esc(e.venue||'Venue to be announced')}${e.status?` · ${esc(e.status)}`:''}</p>
        ${e.description?`<p>${esc(shortText(e.description,150))}</p>`:''}
        <div class="public-update-actions">
          <button type="button" class="view-full-update-btn event-btn" onclick="viewEventDetails('${esc(e.id)}')">View Event Details</button>
        </div>
      </article>`).join('')||'<div class="empty-public-card compact">No upcoming event published yet.</div>';

    maybeAutoShowLatestUpdate();

    if(!d.configured){
      document.querySelectorAll('a[href="/erp.html"]').forEach(a=>{
        if(a.textContent.trim()==='Login')a.textContent='Setup / Login';
      });
    }
  }catch(err){
    console.warn(err);
  }
}
$('#mobileNavBtn')?.addEventListener('click',()=>$('#siteNav')?.classList.toggle('open'));
document.querySelectorAll('#siteNav a').forEach(a=>a.addEventListener('click',()=>$('#siteNav')?.classList.remove('open')));
$('#publicMembershipForm')?.addEventListener('submit',submitPublicMembershipApplication);
bindSameAddressApplication();
bindMembershipWizard();
loadPublicHeroSlider();
loadCscFinder();
loadPublicSite();
