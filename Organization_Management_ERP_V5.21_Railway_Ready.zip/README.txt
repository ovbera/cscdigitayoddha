ORGANIZATION MANAGEMENT SYSTEM — WINDOWS LOCAL / LAN VERSION
========================================================

QUICK START
1. Extract the ZIP to a normal folder, for example:
   D:\Organization_Management_System

2. Make sure Node.js LTS is installed on the main Windows computer.
   Download from: https://nodejs.org/

3. Double-click:
   START_WINDOWS.bat

4. Chrome/Edge will open:
   http://localhost:3000

5. FIRST TIME ONLY:
   Create your Organization/Business account using:
   - Organization / Business Name
   - Owner / Administrator Name
   - Email
   - Password

6. Keep the START_WINDOWS.bat / server window open while using the system.

SAME WI-FI / LAN ACCESS
-----------------------
The server binds to 0.0.0.0 and can be opened from other computers or mobiles
connected to the same Wi-Fi/LAN.

When the system starts, the black server window prints Network URLs such as:

   http://192.168.1.10:3000

Open that address on the other device.

If another device cannot open it:
- Allow Node.js through Windows Defender Firewall on Private Networks.
- Confirm both devices are connected to the same Wi-Fi/router.
- Confirm the main computer's IP address using:
  ipconfig

DATA STORAGE
------------
All ERP data is saved locally in:
   data\database.json

Keep backup copies of this file.
Dashboard also includes "Export Backup" to download a JSON backup.

MODULES INCLUDED
----------------
- First-time account setup
- Administrator Login
- Dashboard
- Members
- Monthly Subscription / Joining Fee
- Donation / Special Contribution
- Income & Expense
- Member Loan application
- Loan approval
- Loan repayment
- Fund Allocation
- Events & Social Work
- Reports
- Organization Settings
- Password change
- Audit activity
- JSON backup export
- Responsive mobile/desktop interface
- LAN / Wi-Fi access

IMPORTANT SECURITY
------------------
This version is intended for trusted local office/home LAN usage.

For public Internet use:
- Put it behind HTTPS
- Use a proper production database
- Add role-based users and stronger server security
- Add automatic backups
- Do not expose port 3000 directly to the public Internet

STOPPING
--------
Close the server window, or run:
   STOP_WINDOWS.bat


UPDATE: ORGANIZATION MASTER PROFILE + FINANCIAL YEAR
====================================================
Organization Master Profile now includes:
- Organization Name
- Logo Upload
- Establishment Date
- Registration No.
- PAN / TAN
- Registered Address
- Office Address
- Mobile / Email
- Bank Name / Account Name / Account No. / IFSC / Branch
- UPI ID
- Organization Objective
- Area of Operation
- Current Committee Term
- Constitution / By-laws text
- Registration / Official Document Upload
  (PDF, PNG, JPG, WEBP, DOC, DOCX)

Uploaded files are stored in:
  data\uploads\

FINANCIAL YEAR
--------------
The system uses Indian Financial Year: April to March.
Example:
  01-04-2026 to 31-03-2027 = Financial Year 2026-27

A Financial Year selector is shown in the top header.
The following modules are separated / filtered Financial Year-wise:
- Dashboard financial totals
- Collections / Donations
- Income & Expense
- Member Loans
- Fund Allocation
- Events & Social Work
- Reports

Members and Organization Master Profile remain common across all Financial Years.

FULL BACKUP
-----------
For a full manual backup, copy the entire:
  data\
folder, including database.json and uploads.


UPDATE: ADVANCED MEMBER MANAGEMENT
==================================
Each member now has a unique sequential Member ID:
  MEM-000001, MEM-000002, ...

Member Profile includes:
- Unique Member ID
- Name
- Father / Spouse Name
- Date of Birth
- Mobile
- Email
- Address
- Member Photo Upload
- Joining Date
- Membership Type
- Designation
- Status: Active / Inactive / Suspended / Resigned
- Nominee / Emergency Contact
- Monthly Subscription Rate
- Financial Year-wise Total Subscription
- Automatically calculated Subscription Arrears
- Donation Summary
- Organization Benefits / Assistance Ledger
- Loan / Advance Summary and Outstanding
- Profile Edit

ARREARS CALCULATION
-------------------
For the selected Financial Year, subscription arrears are calculated as:
  Due Months × Member Monthly Rate - Subscription Collected

Due months are counted from the later of:
- Member Joining Month
- Financial Year start (April)

up to the earlier of:
- Current month
- Financial Year end (March)


UPDATE: SOFTWARE VERSION BRANDING
=================================
The application now shows a software-style brand header like:
  Organization Management ERP
  V1.0

It also shows the vendor line:
  CSC Digital Yoddha

WHERE IT SHOWS
--------------
- Login / first-time setup screen
- Left sidebar application header
- Sidebar footer version line

HOW TO CHANGE VERSION LATER
---------------------------
Open:
  server.js

Then edit this block:

const APP_INFO = {
  shortName: 'OMS',
  appName: 'Organization Management ERP',
  version: 'V1.0',
  vendor: 'CSC Digital Yoddha',
  subtitle: 'Management ERP'
};

Example future updates:
- V1.1
- V1.2
- V2.0

Once changed, restart the server using START_WINDOWS.bat.
The updated version text will appear automatically across the system.


VERSION V1.1 — MEMBER JOINING WORKFLOW
=====================================
New formal member onboarding flow:

Application
  → Under Verification
  → Committee Approved
  → Payment Pending
  → Joining Fee Received
  → Unique Member ID Generated
  → Active Member

APPLICATION DATA
----------------
- Application ID (APP-000001 format)
- Name
- Father / Spouse Name
- Date of Birth
- Address
- Mobile / Email
- Identity Type and Identity Number
- Applicant Photo
- Occupation
- Membership Type
- Proposed Designation
- Nominee / Emergency Contact
- Monthly Subscription Rate
- Joining Fee
- Declaration accepting organization rules / constitution

APPROVAL STATUS
---------------
Pending
Under Verification
Approved
Payment Pending
Active
Rejected

REJECTION
---------
A rejection reason is mandatory and remains stored in the application history.

MEMBER ID RULE
--------------
Member ID is NOT generated at application time.
It is generated only after:
1. Verification
2. Committee Approval
3. Joining Fee payment

After payment, a joining-fee Collection receipt is also created automatically.

VERSION
-------
Organization Management ERP V1.1


VERSION V1.2 — FEE & AUTO RECEIPT SYSTEM
========================================
Separate membership payment heads:
- Joining Fee
- Monthly Membership Fee
- Annual Fee
- Special Contribution
- Donation
- Other Collection

DEFAULT FEE SETTINGS
--------------------
Organization Master Profile now stores separate defaults for:
- Joining Fee
- Monthly Membership Fee
- Annual Fee
- Special Contribution Default

Special Contribution can be changed whenever the committee decides a different amount.

AUTOMATIC RECEIPT NUMBER
------------------------
Every saved payment automatically receives a Financial Year-wise sequential receipt number.

Example:
  RCPT-2026-27-000001
  RCPT-2026-27-000002
  RCPT-2026-27-000003

A new Financial Year starts its own sequence.

JOINING FEE
-----------
When a Membership Application reaches Payment Pending and the Joining Fee is received:
- Joining Fee receipt is generated automatically
- Member ID is generated
- Member becomes Active

PAYMENT RECEIPT PRINT
---------------------
The Collections screen now has a Receipt button.
It opens a printable receipt showing:
- Organization Name / Logo
- Receipt Number
- Financial Year
- Date
- Member / Payer
- Payment Head
- Payment Mode
- Amount
- Notes

VERSION
-------
Organization Management ERP V1.2


VERSION V1.3 — MONTHLY SUBSCRIPTION MANAGEMENT
==============================================
New dedicated "Monthly Subscription Management" module.

MONTH-WISE DASHBOARD
--------------------
For every Financial Year month (April to March), the system shows:
- Total Members
- Paid
- Unpaid
- Partial Paid
- Total Collection
- Total Due

MEMBER-WISE LEDGER
------------------
Each member has a 12-month Financial Year ledger:
Month | Payable | Paid | Due | Status | Payment Date | Mode

Example:
April | 200 | 200 | 0 | Paid | 05/04 | UPI
May   | 200 | 0   | 200 | Unpaid | - | -
June  | 200 | 100 | 100 | Partial Paid | 10/06 | Cash

MULTI-MONTH PAYMENT
-------------------
Subscription can be received for:
- 1 month
- 3 months
- 6 months
- 12 months

The payment is automatically allocated month-by-month.
Partial payment is supported.

Example:
Monthly rate = 200
April due = 200
May due = 200
June due = 200

If 3 months are selected and payment amount is 500:
April = 200 Paid
May   = 200 Paid
June  = 100 Partial Paid / 100 Due

RECEIPT
-------
Every monthly subscription payment generates the existing Financial Year-wise automatic receipt number:
RCPT-2026-27-000001
RCPT-2026-27-000002
...

VERSION
-------
Organization Management ERP V1.3


VERSION V1.4 — DONATION MANAGEMENT
==================================
A dedicated Donation Management module has been added.

DONATION TYPES
--------------
1. Member Donation
   Extra donation received from registered organization members.

2. External Donation
   Donation received from general public, institutions, well-wishers, etc.

DONATION RECORD
---------------
Each donation stores:
- Automatic Receipt No.
- Donation Type
- Donor Name
- Member ID (for Member Donation)
- Donor Mobile
- Amount
- Donation Purpose
- Payment Mode
- Date
- Notes / Reference
- Financial Year

DONATION PURPOSES
-----------------
- General Fund
- Social Work
- Medical Assistance
- Education
- Disaster Relief
- Event
- Infrastructure
- Emergency Fund

PURPOSE-WISE FUND TRACKING
--------------------------
The Donation screen shows:
Purpose | Received | Spent | Balance

To track spending, Income & Expense entries now have an optional:
  Fund / Donation Purpose

Example:
Donation received for Disaster Relief = 50,000
Expense tagged Disaster Relief = 32,000
Purpose Balance = 18,000

AUTOMATIC RECEIPTS
------------------
Every donation uses the existing Financial Year-wise sequential receipt:
  RCPT-2026-27-000001
  RCPT-2026-27-000002
  ...

Printable donation receipts show:
- Receipt Number
- Donation Type
- Donor Name
- Mobile
- Purpose
- Payment Mode
- Amount
- Date

VERSION
-------
Organization Management ERP V1.4


VERSION V1.5 — INCOME MANAGEMENT
================================
Dedicated Income Management module added.

INCOME CATEGORIES
-----------------
- Joining Fee
- Monthly Subscription
- Annual Subscription
- Donation
- Event Collection
- Sponsorship
- Bank Interest
- Special Contribution
- Other Legal Income

UNIFIED INCOME REGISTER
-----------------------
The Income Management screen automatically combines:
1. Receipt-based income already generated by the ERP:
   - Joining Fee
   - Monthly Subscription
   - Annual Fee
   - Donation
   - Special Contribution
   - Other receipts

2. Manual voucher-based income:
   - Event Collection
   - Sponsorship
   - Bank Interest
   - Other Legal Income

Each income row shows:
- Date
- Amount
- Category
- Source
- Payment Mode
- Receipt / Voucher No.
- Remarks
- Financial Year

AUTO INCOME VOUCHER
-------------------
Manual income entries automatically generate:
  INC-2026-27-000001
  INC-2026-27-000002
  ...

Expense vouchers now use:
  EXP-2026-27-000001

CATEGORY-WISE SUMMARY
---------------------
The Income page shows total amount and number of entries for each income category.

IMPORTANT
---------
Existing receipt-based income is not duplicated.
The Income page reads existing collection receipts and combines them with manual income vouchers.

VERSION
-------
Organization Management ERP V1.5


VERSION V1.6 — EXPENSE MANAGEMENT
=================================
Dedicated Expense Management module added.

EXPENSE CATEGORIES
------------------
- Office Expense
- Printing & Stationery
- Meeting Expense
- Event Expense
- Social Work
- Travel
- Food
- Rent
- Electricity
- Internet
- Bank Charges
- Member Welfare
- Emergency Assistance
- Legal/Professional Expense
- Other Approved Expense

EXPENSE RECORD
--------------
Each expense stores:
- Automatic Voucher No.
- Date
- Category
- Amount
- Paid To
- Payment Mode
- Purpose
- Optional Fund / Donation Purpose
- Bill / Invoice Upload
- Approved By
- Remarks
- Financial Year

EXPENSE VOUCHER
---------------
Automatic voucher sequence:
  EXP-2026-27-000001
  EXP-2026-27-000002
  ...

The Expense register can print a voucher showing:
- Organization details
- Voucher no.
- Date
- Category
- Paid To
- Mode
- Purpose
- Amount
- Approved By
- Bill attachment status
- Signature areas

BILL UPLOAD
-----------
Supported bill files:
- PDF
- PNG
- JPG / JPEG
- WEBP

Maximum file size: 10 MB.
Uploaded files are stored in:
  data\uploads\

Deleting an expense also removes its uploaded bill file.

CATEGORY SUMMARY
----------------
The Expense page shows:
- Total Expense
- Total Vouchers
- Vouchers with Bill
- Vouchers without Bill
- Category-wise amount and voucher count

VERSION
-------
Organization Management ERP V1.6


VERSION V1.7 — CASH & BANK MANAGEMENT
=====================================
Dedicated Cash & Bank Management module added.

ACCOUNT LEDGERS
---------------
Three separate account ledgers are maintained:
1. Cash in Hand
2. Bank Account
3. UPI / Other Account

Each ledger shows:
- Date
- Receipt / Voucher / Transfer Ref No.
- Particulars
- Entry Type
- Money In
- Money Out
- Running Balance

HOW BALANCES ARE CALCULATED
---------------------------
Cash / Bank / UPI balances are calculated from:
- Opening Balance
- Collection Receipts
- Income Vouchers
- Expense Vouchers
- Internal Fund Transfers

Payment mode mapping:
- Cash -> Cash in Hand
- Bank Transfer / Cheque -> Bank Account
- UPI -> UPI / Other Account

OPENING BALANCE
---------------
Opening balances are Financial Year-wise.
Use:
  Cash & Bank -> Opening Balance / Settings

You can also rename the three account labels.

FUND TRANSFER
-------------
Supported internal transfers include:
- Cash -> Bank
- Bank -> Cash
- Cash -> UPI
- UPI -> Cash
- Bank -> UPI
- UPI -> Bank

Fund Transfer is NOT Income and NOT Expense.
Therefore it does not double-count in Income/Expense reports.

Automatic Fund Transfer number:
  TRF-2026-27-000001
  TRF-2026-27-000002
  ...

Before saving a transfer, the system verifies that the source account has enough balance.

TRANSFER REGISTER
-----------------
Stores:
- Transfer No.
- Date
- From Account
- To Account
- Amount
- Reference / UTR / Deposit slip no.
- Remarks

Deleting a transfer recalculates both account balances automatically.

CASH & BANK SUMMARY
-------------------
Shows:
- Cash in Hand Balance
- Bank Balance
- UPI / Other Balance
- Total Available Balance

VERSION
-------
Organization Management ERP V1.7


VERSION V1.8 — FUND ALLOCATION POLICY
=====================================
Dedicated percentage-based Fund Allocation Policy upgraded.

IMPORTANT
---------
These percentages are internal organization policy allocations, not fixed statutory/legal percentages.
The organization should set them according to:
- Registration type
- Constitution / By-laws
- Committee resolution
- Financial policy
- Applicable legal/audit requirements

DEFAULT EXAMPLE STRUCTURE
-------------------------
General / Operating Fund                    25%
Emergency Reserve                           20%
Member Welfare                              15%
Member Financial Assistance / Loan Fund     15%
Social Work                                 10%
Event & Development                         10%
Contingency Reserve                          5%
TOTAL                                      100%

ADMIN / COMMITTEE CONTROL
-------------------------
Admin/Committee can:
- Rename fund heads
- Change percentages
- Add new fund heads
- Remove fund heads
- Add policy/resolution notes
- Reset to the default structure

100% VALIDATION
---------------
The system will NOT save an allocation unless:
  Total Allocation = exactly 100%

Example:
25 + 20 + 15 + 15 + 10 + 10 + 5 = 100%  -> SAVE ALLOWED
25 + 20 + 15 + 15 + 10 + 10 = 95%      -> SAVE BLOCKED
30 + 20 + 15 + 15 + 10 + 10 + 5 = 105% -> SAVE BLOCKED

AVAILABLE FUND
--------------
Allocation amount is calculated against the real Cash & Bank Management total:
  Cash in Hand
+ Bank Account
+ UPI / Other Account
= Available Fund for allocation

This is an earmarking/policy calculation only.
Saving an allocation does NOT create Income, Expense, or Fund Transfer entries.

FINANCIAL YEAR
--------------
Each Financial Year has its own allocation policy.

VERSION
-------
Organization Management ERP V1.8


VERSION V1.9 — MEMBER WELFARE FUND
==================================
Dedicated Member Welfare Fund workflow added.

WELFARE ASSISTANCE TYPES
------------------------
- Medical Emergency
- Accident Assistance
- Death Assistance
- Family Emergency
- Education Assistance
- Natural Disaster Assistance
- Business Emergency Support

WORKFLOW
--------
Application
  -> Document Verification
  -> Committee Review
  -> Approved / Rejected
  -> Payment
  -> Welfare Ledger

APPLICATION RECORD
------------------
Each application stores:
- Welfare Application No.
- Member ID / Member Name
- Assistance Type
- Requested Amount
- Incident / Need Date
- Application Date
- Reason / Purpose
- Additional Details
- Status
- Supporting Documents
- Verification Notes / Verified By
- Committee Notes
- Approved Amount
- Approved By
- Rejection Reason
- Paid Amount
- Complete workflow history

DOCUMENT UPLOAD
---------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB per document.

Documents can be categorized as:
- Supporting Document
- Medical Document
- Estimate / Quotation
- Identity / Relationship Proof
- Death Certificate
- Education Document
- Disaster / Accident Proof
- Committee Reference

APPROVAL RULES
--------------
- Rejection reason is mandatory.
- Approved amount cannot exceed requested amount.
- Approved By is mandatory.
- Committee Review requires a supporting document or verification note.

PAYMENT
-------
Welfare payment creates:
1. Welfare Payment No.
   WFP-2026-27-000001

2. Member Welfare Expense Voucher
   EXP-2026-27-000001

3. Cash / Bank / UPI ledger posting based on payment mode.

Therefore welfare payment is not outside the accounts and is not double-counted.

The system checks the selected Cash/Bank/UPI ledger balance before payment.

WELFARE LEDGER
--------------
Stores:
- Welfare Payment No.
- Date
- Member
- Assistance Type
- Amount
- Payment Mode
- Linked Expense Voucher
- Approved By
- Reference / UTR

FUND POLICY LINK
----------------
The Welfare screen reads the "Member Welfare" percentage from Fund Allocation Policy and shows:
- Welfare Allocation %
- Current Earmarked Amount
- Total Welfare Paid

This is a policy earmarking, not a separate bank account.

VERSION
-------
Organization Management ERP V1.9


VERSION V2.0 — MEMBER LOAN / FINANCIAL ASSISTANCE SYSTEM
========================================================
This is a major workflow upgrade.

IMPORTANT COMPLIANCE GATE
-------------------------
The software does NOT determine whether an organization is legally permitted to lend money or provide member financial assistance.

Before enabling this module, the Admin/Committee must verify:
- Organization registration type
- Constitution / By-laws
- Applicable financial / lending rules
- Committee resolutions
- Professional/legal/accounting advice where appropriate

Until compliance is explicitly confirmed in:
  Member Loans -> Compliance & Eligibility Policy
new applications, sanction and disbursement are blocked.

DEFAULT ELIGIBILITY POLICY
--------------------------
- Minimum 12 completed months membership
- Active Member required
- Subscription due must be zero
- No previous overdue loan
- Committee approval required
- Guarantor optional by default

Admin/Committee can edit these rules.

APPLICATION WORKFLOW
--------------------
Applied
  -> Verification
  -> Committee Approval
  -> Sanctioned
  -> Disbursed
  -> Repayment
  -> Closed

Applications may also be Rejected with a mandatory reason.

LOAN APPLICATION
----------------
Stores:
- Loan Application No. (LNA-FY-000001)
- Member ID / Name
- Requested Amount
- Purpose
- Repayment Period
- Guarantor Member ID / Name / Mobile
- Application Date
- Financial Year
- Eligibility Snapshot
- Supporting Documents
- Verification Notes / Verified By
- Committee Notes
- Sanctioned Amount / Sanction Date
- Approved By / Committee
- Disbursement Date / Mode / Reference
- Maturity Date
- Repayments
- Outstanding Principal
- Rejection Reason
- Complete workflow history

SUPPORTING DOCUMENTS
--------------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB per document.

Document types include:
- Application Form
- Guarantor Document
- Need / Purpose Proof
- Identity Document
- Committee Resolution
- Other Supporting Document

SANCTION RULES
--------------
Before sanction, eligibility is checked again.
Sanctioned amount cannot exceed requested amount.
Committee approval / Approved By is mandatory when the policy requires it.

DISBURSEMENT
------------
Disbursement is allowed only after Sanctioned status.

The system checks:
1. Legal / By-laws compliance confirmation
2. Cash / Bank / UPI source account balance
3. Current Member Financial Assistance / Loan Fund policy availability

Disbursement is NOT an Expense.
It is recorded as principal money-out in the selected Cash/Bank/UPI ledger.

REPAYMENT
---------
Repayment creates:
  LRP-2026-27-000001
  LRP-2026-27-000002
  ...

Repayment is NOT Income.
It is recorded as principal money-in in the selected Cash/Bank/UPI ledger.

Full principal repayment automatically changes the loan status to:
  Closed

A printable Loan Repayment Receipt is available.

LOAN FUND POLICY LINK
---------------------
The module reads the Fund Allocation head:
  Member Financial Assistance / Loan Fund

and shows:
- Policy %
- Current Earmarked Amount
- Current Loan Outstanding
- Policy Available Amount

This is policy earmarking, not a separate physical bank account.

ACCOUNTING RULE
---------------
Loan Disbursement:
  Cash/Bank/UPI OUT
  NOT Expense

Loan Repayment:
  Cash/Bank/UPI IN
  NOT Income

This prevents Income/Expense double counting.

VERSION
-------
Organization Management ERP V2.0


VERSION V2.1 — LOAN REPAYMENT LEDGER & INSTALLMENT SCHEDULE
============================================================
The Loan / Financial Assistance system now has a complete repayment ledger.

REPAYMENT STRUCTURE
-------------------
Each sanctioned/disbursed case can show:

Principal
+ Permitted Charge / Interest (ONLY if separately legally/by-laws permitted)
= Total Repayable

Then:
Total Repayable / Repayment Period = Scheduled Installments

Example:
Principal                 20,000
Permitted Flat Charge 5%   1,000
Total Repayable           21,000
Repayment Period          10 months
Scheduled Installment      2,100 per month

The last installment automatically adjusts small rounding differences.

SEPARATE CHARGE / INTEREST COMPLIANCE GATE
------------------------------------------
Loan Policy Settings now includes:
- Permitted Charge / Interest Enable
- Separate Compliance Confirmation
- Compliance / By-laws / Resolution Note
- Default Flat Charge / Interest Rate %

Default is OFF and 0%.

A positive charge/interest rate cannot be sanctioned unless:
1. Loan facility compliance is already confirmed, AND
2. Permitted charge/interest is separately enabled and compliance-confirmed.

The ERP does not determine whether such charge/interest is lawful.

INSTALLMENT SCHEDULE
--------------------
For every installment the ledger shows:
- Installment No.
- Due Date
- Principal Payable
- Permitted Charge / Interest Payable
- Total Installment
- Paid
- Due
- Installment Status

Installment status:
- Upcoming
- Due
- Overdue
- Paid

OVERALL REPAYMENT STATUS
------------------------
Current:
  No overdue installment and nothing due today.

Due:
  An installment is due today and is not fully paid.

Overdue:
  An installment due date has passed and the installment is not fully paid.

Closed:
  Total Repayable has been fully paid.

PARTIAL PAYMENTS
----------------
Partial installment payments are supported.
Paid and Due amounts are recalculated automatically across the installment schedule.

REPAYMENT RECEIPT
-----------------
Each repayment has its own automatic receipt/reference:
  LRP-2026-27-000001
  LRP-2026-27-000002
  ...

The printable receipt shows:
- Repayment No.
- Loan Application No.
- Member
- Date
- Payment Mode
- Reference
- Principal Component
- Permitted Charge / Interest Component
- Total Amount Received
- Total Repayable
- Outstanding

ACCOUNTING
----------
Loan Disbursement:
  Principal cash/bank/UPI outflow
  NOT Expense

Loan Repayment:
  Full payment cash/bank/UPI inflow ONCE

Principal component:
  NOT Income

Permitted Charge / Interest component:
  Recorded as "Permitted Loan Charge / Interest" Income
  but marked so it is NOT posted to Cash/Bank a second time.

This prevents double counting while maintaining correct Income reporting.

REPAYMENT COMPONENT ALLOCATION
------------------------------
When a permitted flat charge exists, each repayment is split pro-rata between:
- Principal
- Permitted charge / interest

Final repayment automatically adjusts for any rounding difference.

VERSION
-------
Organization Management ERP V2.1


VERSION V2.2 — EVENT / PROJECT MANAGEMENT
=========================================
Every organization event can now be maintained as a separate Event / Project.

EVENT MASTER
------------
Each event stores:
- Automatic Event ID: EVT-2026-27-000001
- Event / Project Name
- Start Date / End Date
- Venue
- Event Budget
- Description / Objective
- Status: Planned / Ongoing / Completed / Cancelled
- Financial Year

EVENT FINANCE
-------------
Each Event can contain linked:
- Collection
- Donation
- Sponsorship
- Member Contribution
- Expenses

These are linked to the existing accounting system.

NO DOUBLE ACCOUNTING
--------------------
The same entry is shown in both:
- Event / Project ledger
and
- Main Collections / Donation / Income / Expense / Cash-Bank modules

but the accounting record is stored only once.

EVENT INCOME
------------
Collection:
  Creates a normal event collection receipt.

Donation:
  Creates a Donation receipt with Purpose = Event.
  Appears in Donation Management.

Sponsorship:
  Creates an Income Voucher under Sponsorship.
  Appears in Income Management.

Member Contribution:
  Creates an event member-contribution receipt.

EVENT EXPENSE
-------------
Event expenses:
- Generate normal Expense Voucher
- Appear in Expense Management
- Update Cash / Bank / UPI ledger based on Payment Mode
- Support Bill / Invoice upload

PARTICIPANTS
------------
Each event can store:
- Member ID, if applicable
- Participant Name
- Mobile
- Role
- Notes

VENDORS
-------
Each event can store:
- Vendor / Service Provider Name
- Mobile
- Service / Item
- Contract / Estimated Amount
- Notes

PHOTOS / DOCUMENTS
------------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB per file.

Suggested document types:
- Event Photo
- Permission / Approval
- Quotation
- Invitation / Poster
- Event Report
- Other Document

FINAL EVENT POSITION
--------------------
Each event shows:
- Event Budget
- Collection
- Donation
- Sponsorship
- Member Contribution
- Total Income
- Total Expense
- Budget Variance
- Final Balance

Formula:
  Total Income - Total Expense = Surplus / Deficit

VERSION
-------
Organization Management ERP V2.2


VERSION V2.3 — SOCIAL WORK MANAGEMENT
=====================================
Dedicated Social Work Management has been added.

SOCIAL WORK TYPES
-----------------
- Blood Donation
- Health Camp
- Food Distribution
- Clothes Distribution
- Educational Support
- Disaster Relief
- Tree Plantation
- Awareness Camp
- Other Social Work

PROJECT RECORD
--------------
Each activity is stored as a separate project with:
- Automatic Project ID: SWP-2026-27-000001
- Project Name
- Social Work Type
- Date
- Location
- Budget
- Expense
- Budget Balance
- Beneficiary Count
- Responsible Members
- Status
- Description / Objective
- Photos
- Documents
- Financial Year

RESPONSIBLE MEMBERS
-------------------
Registered members can be assigned with:
- Member ID
- Name
- Mobile
- Role / Responsibility
- Notes

EXPENSE LINK
------------
Social Work expense automatically:
- Generates an Expense Voucher
- Appears in Expense Management
- Updates Cash / Bank / UPI based on Payment Mode
- Supports Bill / Invoice upload
- Remains linked to the Social Work Project

No duplicate expense is created.

DONATION PURPOSE TRACKING
-------------------------
Disaster Relief project expense:
  Funding Purpose = Disaster Relief

Educational Support project expense:
  Funding Purpose = Education

Other Social Work project expense:
  Funding Purpose = Social Work

This allows Donation Management to show:
Received -> Spent -> Balance

PHOTOS / DOCUMENTS
------------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB per file.

Suggested types:
- Project Photo
- Permission / Approval
- Beneficiary List
- Project Report
- Quotation / Estimate
- Supporting Document
- Other Document

DASHBOARD
---------
Shows:
- Total Projects
- Total Budget
- Total Expense
- Budget Balance
- Total Beneficiaries
- Completed Projects
- Activity-wise Project Count
- Activity-wise Beneficiary Count
- Activity-wise Expense

VERSION
-------
Organization Management ERP V2.3


VERSION V2.4 — ASSET MANAGEMENT
===============================
A dedicated organization-wide Asset Register has been added.

ASSET CATEGORIES
----------------
- Computer
- Printer
- Furniture
- Sound System
- Projector
- Tent
- Vehicle
- Land / Building
- Electrical / Electronic Equipment
- Office Equipment
- Other Asset

ASSET RECORD
------------
Each asset stores:
- Automatic Asset ID
  AST-000001
- Asset Name
- Category
- Purchase Date
- Purchase Value
- Supplier / Vendor
- Asset Details / Model / Serial / Registration / Plot Details
- Purchase Bill / Invoice
- Current Location
- Custodian Member ID, when applicable
- Custodian Name
- Condition
- Status
- Notes

CONDITION
---------
- New
- Excellent
- Good
- Fair
- Poor
- Damaged

STATUS
------
- In Use
- Stored
- Under Repair
- Disposed
- Lost

PURCHASE BILL
-------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
Maximum 10 MB.

The bill can be opened from the Asset Register, replaced during Edit, or removed.

CUSTODIAN
---------
A registered organization member can be selected as Custodian.
If the custodian is not a registered member, a manual Custodian Name can be stored.

LOCATION
--------
Current Location can be updated whenever an asset is moved:
- Office
- Store Room
- Event Site
- Member Custody
- Other Location

ASSET DASHBOARD
---------------
Shows:
- Total Assets
- Original Purchase Value
- In Use
- Stored
- Under Repair
- Disposed
- Lost
- Assets With Bill
- Category-wise Count
- Category-wise Original Purchase Value

ACCOUNTING NOTE
---------------
Purchase Value in Asset Management is an asset-register/historical value.

Saving an Asset does NOT automatically create an Expense.
This avoids double counting when old/existing assets are entered into the ERP.

If a real current purchase needs to be recorded in accounts, create the approved purchase expense separately in Expense Management.

No depreciation/current market value calculation is applied in V2.4.

VERSION
-------
Organization Management ERP V2.4


VERSION V2.5 — COMMITTEE MANAGEMENT
===================================
A dedicated Committee Management module has been added.

COMMITTEE STRUCTURE
-------------------
Supported designations:
- President
- Vice President
- Secretary
- Joint Secretary
- Treasurer
- Executive Member
- General Member
- Other

COMMITTEE MASTER
----------------
Each committee stores:
- Automatic Committee ID
  COM-000001
- Committee Name
- Committee Formation Date
- Term / Session Label
- Term Start Date
- Term End Date
- Notes / Resolution Reference
- Status:
  Current
  Archived

Only one Current Committee can exist at a time.

MEMBER / DESIGNATION REGISTER
-----------------------------
Each committee role stores:
- Committee Member Role ID
- Organization Member ID
- Member Name
- Mobile
- Designation
- Role Start Date
- Role End Date
- Role Status:
  Active
  Ended
- Notes
- End Reason

Committee roles are linked to registered organization Members.

ROLE HISTORY
------------
A current member role is not hard-deleted from history.

If a member leaves a position:
  Use "End Role"

The system stores:
- End Date
- End Reason
- Historical Designation
- Historical Member Snapshot

COMMITTEE ARCHIVE
-----------------
Old committees are NEVER hard-deleted.

When a committee term finishes:
  Archive Committee

Archive stores:
- Archived Date / Time
- Archived By
- Archive Reason
- Full Member / Designation History
- Full Committee Activity History

Archived committees are read-only.

Before a new Current Committee can be created, the previous Current Committee must be archived.

ORGANIZATION MASTER SYNC
------------------------
Current Committee Term Start / End is synchronized with:
  Organization Master -> Current Committee Term

When the current committee is archived, the Organization Master current-term fields are cleared until a new committee is formed.

HISTORY LOG
-----------
Committee history records:
- Committee Formation
- Committee Master Updates
- Member Role Assignments
- Member Role Endings
- Committee Archive

REPORTS
-------
Reports now include:
- Current Committee Name
- Active Committee Roles
- Archived Committee Count

VERSION
-------
Organization Management ERP V2.5


VERSION V2.6 — MEETING & RESOLUTION MANAGEMENT
===============================================
Dedicated Meeting & Resolution Management has been added.

MEETING RECORD
--------------
Each meeting stores:
- Automatic Meeting No.: MTG-2026-27-000001
- Date
- Meeting Title
- Agenda
- Present Members
- Discussion
- Decisions
- Approved By
- Current Committee Snapshot
- Notes
- Minutes PDF / Documents
- Financial Year
- Status: Draft / Finalized

ATTENDANCE
----------
Registered organization members can be recorded as present with:
- Member ID
- Name
- Mobile
- Attendance Role
- Notes

RESOLUTION
----------
Each meeting can contain multiple resolutions.

Automatic Resolution No.:
  RES-2026-27-000001

Each resolution stores:
- Resolution No.
- Category
- Title
- Decision / Resolution Text
- Votes For
- Votes Against
- Abstain
- Voting Result
- Approved By
- Notes

RESOLUTION CATEGORIES
---------------------
- Loan Approval
- Major Expense Approval
- Asset Purchase Approval
- Fund Allocation Change
- General Resolution
- Other

VOTING RESULT
-------------
- Passed
- Unanimous
- Rejected
- Tied
- Not Voted

FINALIZATION
------------
Before Finalize:
- At least one Present Member is required
- Discussion is required
- Decisions are required
- Approved By is required

After Finalize:
- Meeting becomes read-only
- Attendance becomes read-only
- Resolutions become read-only
- Minutes/Documents become read-only

Only Finalized meeting resolutions with voting result Passed or Unanimous are available for governance links.

MINUTES / DOCUMENTS
-------------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB.

Suggested document types:
- Minutes PDF / Document
- Meeting Notice
- Attendance Sheet
- Signed Resolution
- Agenda Document
- Supporting Document

PRINT MINUTES
-------------
The Meeting screen includes a printable Minutes format.
Browser Print may also be used to Save as PDF.

CROSS-MODULE RESOLUTION LINKS
-----------------------------
Loan Sanction:
  Can link a Loan Approval resolution.

Expense Voucher:
  Can link a Major Expense Approval resolution.

Asset Purchase:
  Can link an Asset Purchase Approval resolution.

Fund Allocation:
  Can link a Fund Allocation Change resolution.

Resolution links are governance references only.
They do not create duplicate accounting entries.

REVERSE LINKS
-------------
Resolution details show linked records, for example:
- Loan Application
- Expense Voucher
- Asset ID
- Fund Allocation Financial Year

REPORTS
-------
Reports include:
- Total Meetings
- Finalized Meetings
- Passed Resolutions

VERSION
-------
Organization Management ERP V2.6


VERSION V2.7 — FINANCIAL APPROVAL SYSTEM
========================================
A configurable amount-based Financial Approval System has been added.

SAMPLE POLICY
-------------
₹0 – ₹2,000:
  Treasurer

₹2,000.01 – ₹10,000:
  Treasurer + Secretary

Above ₹10,000:
  Committee Resolution

IMPORTANT:
These amounts are examples only.
They are not mandatory legal limits.
The organization must configure its own limits according to by-laws, committee resolutions and approved financial policy.

DEFAULT
-------
Approval enforcement is OFF by default.
Sample slabs are preloaded only for review.

After the organization approves its own limits:
  Approval System -> Edit Approval Policy -> Enable

CONFIGURABLE POLICY
-------------------
Admin / Committee can configure:
- Policy Name
- Effective Date
- Enabled / Disabled
- Module-wise Enforcement
- Unlimited Approval Slabs
- Required Designation(s)
- Whether Committee Resolution is required

The final slab must be "No Limit" so every amount is covered.

SERVER-SIDE DESIGNATION CHECK
-----------------------------
Required role approval is verified against Committee Management.

Example:
If Treasurer approval is required, the selected Member ID must actually hold the Treasurer designation for the transaction date.

The system checks:
- Committee term
- Member ID
- Designation
- Role Start Date
- Role End Date

FINANCIAL MODULES
-----------------
Policy can be enforced for:
- Expense
- Event Expense
- Social Work Expense
- Welfare Payment
- Asset Purchase
- Loan Sanction

RESOLUTION REQUIREMENT
----------------------
If the slab requires Committee Resolution, it must be:
- Meeting Status = Finalized
- Voting Result = Passed or Unanimous

Required category:
Loan Sanction:
  Loan Approval

Asset Purchase:
  Asset Purchase Approval

Expense / Event Expense / Social Work Expense / Welfare Payment:
  Major Expense Approval

APPROVAL SNAPSHOT
-----------------
Every policy-enforced record stores:
- Policy Name
- Policy Revision
- Approval Context
- Amount
- Approval Range
- Required Designations
- Actual Approver Member IDs / Names
- Committee ID / Name
- Resolution No. / Title
- Validation Timestamp

This means later policy changes do not alter the historical approval basis of old transactions.

RECENT APPROVAL REGISTER
------------------------
Approval System contains a recent approval register for:
- Expenses
- Welfare Payments
- Asset Purchases
- Loan Sanctions

FUND ALLOCATION
---------------
Fund Allocation Change continues to use the V2.6 Committee Resolution link because it is a policy change, not a normal amount-based payment.

VERSION
-------
Organization Management ERP V2.7

VERSION V2.8 — ACCOUNTING LEDGER SYSTEM
=======================================
A unified Accounting Ledger module has been added.

CORE ACCOUNTING FORMULA
-----------------------
Opening Fund Balance + Income - Expense = Closing Fund Balance

For stronger reconciliation, Opening Fund Balance is calculated as:
  Cash Opening
+ Bank Opening
+ UPI / Other Opening
+ Loan Principal Receivable at FY Opening

The system separately shows:
- Liquid Cash / Bank / UPI Closing
- Loan Principal Receivable Closing
- Reconciled Closing Fund Position

This treatment prevents loan principal from being incorrectly counted as Income or Expense.

LOAN PRINCIPAL ACCOUNTING
-------------------------
Loan / Financial Assistance principal disbursement:
  Not treated as Expense in the main Income/Expense formula.
  Cash reduces and Loan Principal Receivable increases.

Loan principal repayment:
  Not treated as Income.
  Cash increases and Loan Principal Receivable reduces.

Permitted charge / interest, only when legally applicable and recorded:
  Recognized as Income when received.

Internal Cash -> Bank -> UPI transfers:
  Not Income and not Expense.
  They only move money between liquid accounts.

AUTOMATIC LEDGERS
-----------------
The Accounting Ledger page includes:
- Income Ledger
- Expense Ledger
- Member Ledger
- Donation Ledger
- Cash Book
- Bank Book
- UPI / Other Book
- Event Ledger
- Welfare Ledger
- Loan / Financial Assistance Ledger
- Fund-wise Ledger

MEMBER LEDGER
-------------
Each Member Ledger can show:
- Membership / contribution receipts
- Donation receipts
- Loan / assistance disbursement
- Loan repayment
- Welfare payment
- Benefit memo records
- Subscription due
- Opening / Closing Loan Outstanding

DONATION LEDGER
---------------
Shows:
- Purpose-wise Opening Balance
- Donation Received
- Purpose-tagged Expense / Spent
- Closing Balance

Supported purposes remain linked to Donation Management.

CASH BOOK / BANK BOOK / UPI BOOK
--------------------------------
Uses the same Cash & Bank engine and shows:
- Opening Balance
- Receipts / Income
- Expenses
- Loan Disbursement
- Loan Repayment
- Internal Fund Transfers
- Running Balance
- Closing Balance

EXPENSE LEDGER
--------------
Shows all Expense Vouchers with:
- Date
- Voucher No.
- Category
- Paid To
- Purpose
- Mode
- Amount
- Running Expense

EVENT LEDGER
------------
Each Event can be selected separately.
It shows a combined running ledger of:
- Collection
- Donation
- Sponsorship
- Member Contribution
- Other Event Income
- Event Expense
- Final Surplus / Deficit

WELFARE LEDGER
--------------
Shows:
- Welfare Payment No.
- Application No.
- Member
- Assistance Type
- Payment Mode
- Amount
- Running Paid Amount
- Approved vs Paid vs Outstanding summary

LOAN / ASSISTANCE LEDGER
------------------------
Shows:
- Opening Principal Outstanding
- Principal Disbursed
- Principal Recovered
- Permitted Charge / Interest Income
- Cash Recovered
- Running Principal Outstanding
- Closing Principal Outstanding

FUND-WISE LEDGER
----------------
The current FY Fund Allocation Policy is used to create fund-wise liquid ledgers.

The ledger maps movements to relevant heads such as:
- General / Operating Fund
- Emergency Reserve
- Member Welfare
- Member Financial Assistance / Loan Fund
- Social Work
- Event & Development
- Contingency Reserve

Each Fund Ledger shows:
- Opening Liquid Allocation
- Inflow
- Outflow
- Closing Liquid Balance
- Current Policy Target
- Variance to Policy Target

The sum of Fund-wise Closing Liquid Balances is reconciled to total Cash + Bank + UPI Closing when allocation totals 100%.

PRINT
-----
The currently selected accounting ledger can be printed or saved as PDF using the browser Print function.

VERSION
-------
Organization Management ERP V2.8


VERSION V2.9 — ADVANCED DASHBOARD & GRAPHICAL REPORTS
=====================================================
The main Dashboard has been redesigned as an organization-wide live control panel.

DASHBOARD KPI CARDS
-------------------
The dashboard shows at a glance:

- Total Members
- Active Members
- Monthly Collection
- Total Due
- Donations
- Current Fund
- Cash Balance
- Bank Balance
- Monthly Expense
- Welfare Assistance
- Loan / Assistance Outstanding
- Upcoming Events

KPI ACCOUNTING SOURCES
----------------------
Total Members:
  All registered Members.

Active Members:
  Members with Status = Active.

Monthly Collection:
  Receipt-based collections in the current calendar month,
  only when that month belongs to the selected Financial Year.

Total Due:
  Outstanding Monthly Subscription of Active Members
  up to the selected FY's current/as-of month.
  Future months are not treated as overdue/due.

Donations:
  Donation receipts in the selected Financial Year.

Current Fund:
  Cash Book Closing + Bank Book Closing + UPI/Other Book Closing.

Cash Balance:
  Cash in Hand closing balance from Cash & Bank Management.

Bank Balance:
  Bank Book closing balance.

Monthly Expense:
  Expense Vouchers in the current calendar month.

Welfare Assistance:
  Welfare Assistance amount actually paid in the selected Financial Year.

Loan / Assistance Outstanding:
  Principal Receivable outstanding as of the selected FY/current date.

Upcoming Events:
  Planned or Ongoing Event Projects whose End Date has not passed.

ACCOUNTING POSITION
-------------------
The Dashboard includes the V2.8 accounting formula:

  Opening Balance
  + Income
  - Expense
  = Closing Fund Position

It also shows:
- Liquid Closing
- Loan Principal Receivable
- Reconciliation Status

GRAPHICAL REPORTS
-----------------
Four live graphical reports have been added.

1. Income vs Expense
   - April to March
   - Month-wise Income and Expense comparison

2. Monthly Collection
   - April to March
   - Receipt-based collection totals

3. Fund Distribution
   - Current liquid fund
   - Approved Fund Allocation Policy %
   - Calculated amount per Fund Head

4. Outstanding Subscription
   - Active Member dues
   - Month-wise outstanding amount
   - Future months are excluded from due

UPCOMING EVENT PANEL
--------------------
Shows the next six Planned / Ongoing events with:
- Event Date
- Event Name
- Venue
- Status

CLICKABLE DASHBOARD
-------------------
Dashboard KPI cards can open the related modules:
- Members
- Subscription
- Donation
- Cash & Bank
- Expense
- Welfare
- Loan
- Events

NO EXTERNAL CHART LIBRARY
-------------------------
Dashboard charts are rendered locally with HTML/CSS.
The Windows Local/LAN application remains dependency-free.

VERSION
-------
Organization Management ERP V2.9


VERSION V3.0 — ADVANCED REPORTS & EXPORT SYSTEM
================================================
A complete Financial Year-wise Report Center has been added.

REPORTS AVAILABLE
-----------------
1. Member List
2. Joining Report
3. Monthly Subscription Report
4. Due Report
5. Donation Report
6. Income Report
7. Expense Report
8. Cash Book
9. Bank Book
10. Event Report
11. Social Work Report
12. Welfare Report
13. Loan / Assistance Report
14. Outstanding Report
15. Asset Register
16. Fund Allocation Report
17. Annual Financial Summary

FINANCIAL YEAR
--------------
All reports use the global Financial Year selector.
Changing the Financial Year refreshes the active report.

MEMBER LIST
-----------
Shows the organization member register up to the selected FY end, including Member ID, membership type, designation, join date, current status, monthly fee and address.

JOINING REPORT
--------------
Shows Membership Applications submitted in the selected Financial Year, workflow status, joining fee and generated Member ID.

MONTHLY SUBSCRIPTION REPORT
---------------------------
Shows per-member:
- Monthly Fee
- Full FY Payable
- Full FY Paid
- Full FY Balance
- Current Due as of the report date
- Paid / Partial / Due month counts

Future months are excluded from Current Due.

DUE REPORT
----------
Shows only Active Members with subscription due as of the report date.

DONATION REPORT
---------------
Shows receipt number, donor type, donor, mobile, purpose, payment mode and amount.

INCOME / EXPENSE
----------------
Generated from the same accounting sources used by Accounting Ledger.
Expense Report includes voucher, paid to, purpose, payment mode, approved by, resolution and bill status.

CASH BOOK / BANK BOOK
---------------------
Includes:
- Opening Balance
- In
- Out
- Running Balance
- Closing Balance

Loan disbursement/repayment and internal transfers follow the Accounting Ledger treatment.

EVENT REPORT
------------
One row per event with Budget, Income, Expense, Surplus/Deficit, Participants, Vendors and Status.

SOCIAL WORK REPORT
------------------
Shows social project Date, Location, Budget, Expense, Balance, Beneficiary Count, Responsible Members and Status.

WELFARE REPORT
--------------
Shows Requested, Approved, Paid and Approved Outstanding amount per welfare application.

LOAN / ASSISTANCE REPORT
------------------------
Shows Requested, Sanctioned, Disbursed, Total Repayable, Paid, Total Outstanding, Principal Outstanding, Repayment Status, Workflow Status and Resolution No.

OUTSTANDING REPORT
------------------
Separates:
- Subscription Due — Receivable
- Loan Principal Outstanding — Receivable
- Approved Welfare Unpaid — Organization Commitment

This avoids mixing money receivable from members with approved assistance the organization still has to pay.

ASSET REGISTER
--------------
Shows assets existing as of the selected FY end with Purchase Date, Purchase Value, Vendor, Location, Custodian, Condition, Status, Bill and Resolution.

FUND ALLOCATION REPORT
----------------------
Shows current liquid fund, Fund Heads, Allocation %, calculated allocated amount, notes and Resolution No.

ANNUAL FINANCIAL SUMMARY
------------------------
Uses the V2.8 accounting basis:
  Opening Fund Position
  + Income
  - Expense
  = Closing Fund Position

Also reports Cash, Bank, UPI, Loan Principal Receivable, Donation, Welfare, Loan Disbursement/Recovery and Subscription Due.

PRINT
-----
Every selected report can be printed in a clean organization-letterhead style format.

PDF
---
Use the Save PDF button.
The browser Print dialog opens; choose "Save as PDF" as destination/printer.
No external PDF library is required.

EXCEL
-----
Every report can be exported as an Excel-compatible .xls file.
The export includes:
- Organization Name
- Report Name
- Financial Year
- Summary
- Full Report Table

The export is generated locally without external libraries or internet access.
Potential spreadsheet-formula text is neutralized before export.

SEARCH
------
The report preview includes a live Search field.
Search affects the preview only; Print/PDF/Excel exports include the complete selected report.

VERSION
-------
Organization Management ERP V3.0


VERSION V3.1 — USER ROLE & SECURITY
===================================
A complete Role-Based Access Control (RBAC) and multi-user login system has been added.

USER ROLES
----------
Super Admin
- Full control
- User account management
- Security / Audit Log
- Settings / Backup
- All modules and all writes

President
- Organization-wide view
- Membership workflow approval
- Welfare approval workflow
- Loan sanction / rejection workflow
- Meeting resolution creation and finalization
- Routine financial data entry is blocked server-side

Secretary
- Joining Application management
- Member management
- Committee management
- Meeting & Resolution administration
- Event management
- Social Work project management
- Financial transaction entry is blocked

Treasurer
- Subscription
- Donation
- Income / Expense
- Cash & Bank
- Accounting records
- Collection / transaction records
- Welfare payment execution
- Loan disbursement / repayment execution
- Event / Social Work financial entries

Committee Member
- Limited organization view
- Membership / Welfare / Loan approval workflow actions
- Routine data entry and accounting edits are blocked

General Member
- Dedicated My Member Portal only
- Own Profile
- Own Monthly Subscription ledger / Due
- Own Receipts
- Own Joining Application status
- Own Welfare Application status
- Own Loan / Financial Assistance status
- Cannot access other members' or organization financial modules

MULTI-USER LOGIN
----------------
Super Admin can create separate login accounts with:
- User ID
- Name
- Email
- Password
- Role
- Optional Linked Member ID
- Active / Disabled Status

General Member login must be linked to a valid Member ID.
Only one active user may be linked to the same Member ID.

The original first-time setup administrator is automatically the first Super Admin user.
Existing V3.0 installations are migrated automatically on startup.

SERVER-SIDE SECURITY
--------------------
Page hiding is not the security boundary.
Every protected API write is checked on the server against the signed-in user's Role.
Unauthorized writes return HTTP 403 Permission Denied.

Uploaded organization files now require an authenticated session before they can be opened.

AUDIT LOG
---------
Important actions now record:
- Who: User ID / Name / Email / Role
- When: Date & Time
- What: Action and details
- Where: HTTP Method + API Path
- Optional Record Type / Record ID

Up to 2,000 latest audit entries are retained in the local database.

User account creation, role changes, status changes and password resets are audited.
Login and Logout are also audited.

USER SAFETY RULES
-----------------
- Email must be unique.
- Password minimum 6 characters.
- At least one Active Super Admin must always remain.
- Disabled users cannot log in.
- Role or password changes invalidate that user's active sessions.
- Backup export removes session data and strips password hashes / salts from User accounts.

GENERAL MEMBER PRIVACY
----------------------
General Member accounts do not use the normal administrative APIs.
They receive only a dedicated /api/my-portal response scoped to their Linked Member ID.

VERSION
-------
Organization Management ERP V3.1


VERSION V3.2 — MEMBER PORTAL & NOTICE TRANSPARENCY
=================================================
The General Member self-service portal has been expanded.

GENERAL MEMBER PORTAL
---------------------
Every General Member login is linked to exactly one Member ID.
The portal remains read-only and server-side isolated from other members and organization financial administration.

A member can see:
- Profile
- Membership Status
- Monthly Subscription
- Due
- Donation
- Receipts
- Welfare Application
- Financial Assistance / Loan Status
- Organization Events
- Notices / Announcements

PROFILE & MEMBERSHIP
--------------------
Shows:
- Member ID
- Name / Photo
- Membership Type
- Membership Status
- Designation
- Joining Date
- Membership Age in Months
- Monthly Fee
- Contact Details
- Address
- Emergency Contact

MONTHLY SUBSCRIPTION & DUE
--------------------------
Financial Year-wise month ledger shows:
- Payable
- Paid
- Due
- Status
- Payment Date
- Payment Mode

DONATION
--------
Only donations linked to the logged-in Member ID are shown.
Includes:
- Receipt No.
- Date
- Donation Purpose
- Mode
- Amount
- Receipt Print

RECEIPTS
--------
All member-linked receipts in the selected Financial Year are available.
Each receipt can be printed / saved as PDF.

WELFARE
-------
Shows the member's own welfare applications:
- Type
- Workflow Status
- Requested Amount
- Approved Amount
- Paid Amount
- Approved Outstanding
- Rejection Reason, when applicable

LOAN / FINANCIAL ASSISTANCE
---------------------------
Shows the member's own assistance cases:
- Application Status
- Repayment Status
- Requested Amount
- Sanctioned Amount
- Total Paid
- Total Outstanding
- Next / Current Installment Due Date and Amount

EVENTS
------
Selected Financial Year organization events are visible without exposing Event financial data.
Shows:
- Event Name
- Date
- Venue
- Status
- Description
- Whether the member is recorded as a Participant
- Participant Role

NOTICE MANAGEMENT
-----------------
A dedicated Notice Management module has been added.

Notice ID example:
  NOT-2026-27-000001

Notice stores:
- Notice No.
- Date
- Title
- Notice Body
- Priority: Normal / Important / Urgent
- Audience
- Publish From
- Publish Until
- Status: Draft / Published / Archived
- Optional Attachment

NOTICE AUDIENCE
---------------
Supported audiences:
- All Members
- Active Members
- Committee Members
- Specific Member

Only Published notices inside the publish window are displayed in Member Portal.
Audience rules are enforced server-side.

NOTICE SECURITY
---------------
Super Admin:
  Full notice management.

Secretary:
  Create / edit / publish / archive notices.

President / Treasurer / Committee Member:
  Read Notice Management.

General Member:
  Cannot access Notice Management API.
  Can only see notices returned through their own Member Portal visibility rules.

NOTICE ATTACHMENT
-----------------
Supported:
- PDF
- PNG
- JPG / JPEG
- WEBP
- DOC / DOCX
Maximum 10 MB.

AUDIT LOG
---------
Notice creation and update/publish/archive actions are recorded with:
- User
- Role
- Date/Time
- API Path
- Notice ID

MEMBER STATEMENT
----------------
Member Portal includes:
  Print My Statement

The printable statement contains:
- Member identity and membership status
- FY Subscription Summary
- Month-wise Subscription Ledger
- Receipt Ledger

VERSION
-------
Organization Management ERP V3.2


VERSION V3.3 — EXTENDED GOVERNANCE & MEMBER SERVICES
====================================================
This release adds the remaining important organization-management modules and links them with the existing V3.2 Member Portal, Notice Board, Receipts, Events, Accounting, Security and Audit Trail.

NEW / EXPANDED MODULES
----------------------
1. Notice Board
   Existing V3.2 Notice Management remains fully available with audience and publish-window controls.

2. Document Management
   Organization-wide document library with Category, Document No., Date, Expiry, Audience, Member Link, Version, Description and secured file upload.

3. Certificate / ID Card Generation
   Issues and prints:
   - Member ID Card
   - Membership Certificate
   - Event Participation Certificate
   - Appreciation Certificate
   - General Certificate
   Issued records are retained FY-wise with Certificate No. and Issued By.

4. SMS / WhatsApp Reminder Center
   - Manual reminder queue
   - Member Due Reminder generation
   - SMS link
   - WhatsApp link
   - Pending / Sent / Cancelled log
   Automatic bulk sending requires a separately configured approved SMS/WhatsApp provider API; V3.3 does not store third-party credentials.

5. Payment Receipt
   Existing automatic Receipt system remains integrated with Member Portal and accounting.

6. Member Due Reminder
   Generates reminders only for Active Members with actual subscription due as-of the selected date. Future subscription months are not treated as due.

7. Event Registration
   Event can define:
   - Registration Open / Closed
   - Registration Deadline
   - Capacity (0 = unlimited)
   General Members can self-register or cancel from Member Portal.
   Staff can register Members and mark Registered -> Attended / Cancelled.
   Attended registrations can automatically appear in Event Participants.

8. Nominee Management
   Member record supports multiple nominees with:
   - Name
   - Relation
   - DOB
   - Phone
   - Address
   - Share %
   - Primary Nominee
   Total share cannot exceed 100%.
   General Member can manage only their own nominees.

9. Complaint / Grievance
   Member Portal can submit grievance with Category, Priority, Subject, Description and Attachment.
   Staff workflow:
   Open -> In Review -> Resolved / Rejected
   Stores Assigned To, Response, Resolution and Audit Trail.

10. Voting / Election
   Election register supports:
   - Election Date
   - Nomination Window
   - Voting Window
   - Positions / Seats
   - Candidate nomination from Member Master
   - Draft / Nomination Open / Voting Open / Closed / Published
   Member Portal enforces one vote per Member per Position.
   Candidate choice is not stored against voter identity; only voter participation is recorded to prevent duplicate voting, while candidate vote totals are stored separately.

11. Vendor Management
   Organization-wide Vendor Master with Contact, Category, GSTIN, PAN, Bank, UPI, Status, Rating and Notes.
   Event Vendor entry can link to Vendor Master.

12. Budget vs Actual
   FY-wise Income Target and Expense Budget heads compare automatically against Accounting Ledger actual values.
   Shows Budget/Target, Actual, Variance and Utilization %.

13. Annual Audit
   Stores Auditor, Firm, Audit Period, Status, Observations, Findings, Recommendations, Audit Report and a financial reconciliation snapshot.
   Completed audit stores the Accounting Overview snapshot.

14. Backup & Audit Trail
   Existing role-aware Audit Trail continues.
   Backup export itself is now audited with User / Role / Time / FY.
   Backup output continues to scrub password hashes, salts and live sessions.

MEMBER PORTAL EXPANSION
-----------------------
General Member can now see/manage only their own:
- Event Registration
- Nominees
- Grievances
- Certificates / ID Cards
- Voting / Election
- Reminders
plus existing Profile, Membership, Subscription, Due, Donation, Receipts, Welfare, Loan, Events and Notices.

SECURITY
--------
All new staff modules use existing V3.1 RBAC and server-side authorization.
General Member self-service endpoints derive Member ID from the authenticated session and do not accept another Member ID.
All important new writes generate Audit Log entries.

VERSION
-------
Organization Management ERP V3.3


VERSION V3.4 — CLEAN, MODERN & RESPONSIVE UI
=============================================
The entire ERP interface has been refreshed without changing the underlying organization/accounting data model.

DESIGN SYSTEM
-------------
- Clean white / soft-slate application canvas
- Modern rounded cards with subtle borders and shadows
- Consistent spacing, typography, buttons, inputs and status pills
- Improved visual hierarchy for dense ERP screens
- Better table readability and horizontal overflow handling
- Updated modal presentation and mobile full-screen forms

SIDEBAR / NAVIGATION
--------------------
- Scrollable sidebar for the large ERP module set
- Sticky software branding and organization identity
- Search Modules field for quick navigation
- Current module highlight
- User name, role and version remain visible at the bottom
- Mobile slide-in navigation with backdrop and Escape-to-close support

RESPONSIVE LAYOUT
-----------------
Optimized breakpoints for:
- Large desktop / office monitor
- Laptop
- Tablet
- Mobile phone

On smaller screens:
- Sidebar becomes a slide-in drawer
- Header controls remain usable
- KPI/stat grids collapse intelligently
- Forms become single-column
- Page action buttons wrap/full-width where appropriate
- Tables remain horizontally scrollable instead of breaking layouts
- Modals use nearly full-screen space for easier data entry
- Member Portal tabs become horizontally scrollable

ACCESSIBILITY / USABILITY
-------------------------
- Larger touch targets
- Stronger focus states
- Clearer hover/active states
- Reduced cramped spacing in forms and tables
- Role badge in the top header reflects the logged-in user's actual role

FUNCTIONAL FIX
--------------
Dashboard "Open Accounting Ledger" now opens the correct Accounting Ledger module.

VERSION
-------
Organization Management ERP V3.4


VERSION V3.5 — GROUPED SIDEBAR NAVIGATION
=========================================
The long sidebar has been converted into compact Main Menus with collapsible Sub Menus.

MAIN MENUS
----------
Dashboard

Organization & Members
- Organization Master
- Joining Applications
- Members
- Committee Management

Finance & Accounts
- Monthly Subscription
- Donation Management
- Income Management
- Expense Management
- Cash & Bank
- Accounting Ledger
- Other Collections
- Income & Expense
- Fund Allocation
- Budget vs Actual

Governance & Approval
- Meeting & Resolution
- Approval System
- Voting & Election

Member Services
- My Member Portal
- Member Welfare Fund
- Member Loans / Assistance
- Certificate & ID
- Reminder Center
- Grievance Management

Programs & Operations
- Event Management
- Social Work Management
- Asset Management
- Vendor Management

Notice & Documents
- Notice Management
- Document Management

Reports & Audit
- Reports
- Annual Audit

Administration
- User Role & Security
- Super Admin Settings

NAVIGATION BEHAVIOUR
--------------------
- Only one Main Menu group remains open at a time.
- Opening another group automatically closes the previous group.
- The group containing the active page opens automatically.
- The last opened Main Menu is remembered in the browser.
- Dashboard remains a direct one-click menu.

SEARCH
------
Sidebar search covers:
- Sub Menu name
- Main Menu group name
- Helpful keywords such as chanda, due, fee, loan, cash, audit, notice, etc.

Search automatically expands matching groups.

ROLE SECURITY
-------------
V3.1+ RBAC remains enforced.
A Main Menu is hidden when the logged-in user has no allowed Sub Menu inside it.

RESPONSIVE
----------
Works on Desktop, Tablet and Mobile.
Mobile Sub Menu rows use larger touch targets.

SMALL FIX
---------
Dashboard "Open Accounting Ledger" button now opens the correct Accounting Ledger module.

VERSION
-------
Organization Management ERP V3.5


VERSION V3.6 — SAFE MODAL / POPUP PROTECTION
=============================================
All website popups / modals are protected from accidental background clicks.

NEW BEHAVIOUR
-------------
When any modal is open:

- Clicking the dark backdrop / outside empty area DOES NOT close the popup.
- Clicking another blank part of the page DOES NOT close the popup.
- Form data remains visible and is not lost because of an accidental outside click.

A modal closes only through an explicit action such as:

- X / Close button
- Cancel button, where provided
- Successful Save
- Successful Update
- Successful Submit
- Other explicit workflow action that intentionally completes and closes the modal

IMPORTANT
---------
The existing modal overlay still blocks clicks from reaching the page underneath.
Therefore an accidental background click cannot activate another menu, page button or form control behind the modal.

ESCAPE KEY
----------
The application does not use Escape to close form modals.
Existing Escape behaviour for the mobile sidebar remains separate and unchanged.

SCOPE
-----
Protection applies across all existing V3.5 modal-based modules, including:

- Member / Joining Application forms
- Committee
- Meeting & Resolution
- Approval Policy
- Subscription Payment / Ledger
- Donation / Income / Expense
- Cash & Bank
- Fund Transfer
- Welfare
- Loan / Assistance
- Event
- Social Work
- Asset
- Notice
- User / Security
- Extended Governance forms and detail modals

VERSION
-------
Organization Management ERP V3.6
\n\nVERSION V3.7 — STARTUP RELIABILITY / LOADING FIX\n=================================================\nFixed the startup screen getting stuck on:\n  Organization Management System\n  Loading...\n\nROOT CAUSE FIXED\n----------------\nThe old START_WINDOWS.bat opened http://localhost:3000 BEFORE starting node server.js.\nOn some Windows/Chrome systems this could open a cached/half-loaded page before the local server was ready.\n\nNEW STARTUP ORDER\n-----------------\n1. START_WINDOWS.bat starts Node.js server first.\n2. It checks http://127.0.0.1:3000/api/status every 500 ms.\n3. Browser opens only after HTTP 200 is confirmed.\n4. If the server is not ready within about 20 seconds, a clear error is shown instead of silently opening a broken page.\n\nFRONTEND SELF-RECOVERY\n----------------------\nThe login/setup screen now:\n- Shows V3.7 immediately instead of the old V1.0 HTML fallback.\n- Shows 'Connecting to local server...' instead of indefinite Loading.\n- Retries /api/status automatically during startup.\n- Uses a request timeout so it cannot wait forever.\n- Shows a clear connection error if the local server cannot be reached.\n- Provides a Retry Connection button.\n- Starts session checking only after server status is successfully available.\n\nCACHE PROTECTION\n----------------\nindex.html now requests:\n- style.css?v=V3.7\n- app.js?v=V3.7\n\nStatic application files are served with no-store/no-cache headers.\nThis prevents an old localhost JavaScript/CSS build from remaining after an ERP upgrade.\n\nNORMAL START\n------------\nZIP Extract\n-> Double-click START_WINDOWS.bat\n-> Wait for 'Server is ready'\n-> Browser opens automatically\n\nDo not open public/index.html directly.\nAlways use START_WINDOWS.bat so API/database functions are available.\n\nVERSION\n-------\nOrganization Management ERP V3.7\n

VERSION V3.8 — SIDEBAR READABILITY & MENU REORGANIZATION
=========================================================
The grouped sidebar has been simplified further and text visibility has been improved.

NEW MAIN MENU ORDER
-------------------
1. Dashboard
2. Members
3. Member Services
4. Accounts
5. Approval
6. Programs
7. Publication
8. Report
9. Administration

RENAMED MAIN MENUS
------------------
Organization & Members -> Members
Finance & Accounts -> Accounts
Governance & Approval -> Approval
Programs & Operations -> Programs
Notice & Documents -> Publication
Reports & Audit -> Report

Member Services has been moved to the 3rd Main Menu position.

READABILITY
-----------
Sidebar text is now:
- Larger
- Brighter / higher contrast
- Slightly bolder
- Easier to read on low-resolution displays
- Easier to tap on tablet/mobile

Sub Menu rows are also taller and clearer.

COMPATIBILITY
-------------
Old saved sidebar group names from V3.5/V3.7 are automatically mapped to the new V3.8 group names.

VERSION
-------
Organization Management ERP V3.8


VERSION V3.9 — HEADER USER PROFILE & SIDEBAR BRANDING
======================================================
User information and Logout have been moved from the sidebar bottom to the top-right header.

TOP-RIGHT USER CARD
-------------------
Shows:
- Member/User Photo
- User Name
- User Role
- Linked Member ID
- Linked Member Designation
- Logout

If the logged-in User Account is linked to a Member ID and that Member has a photo,
the same Member Photo is shown automatically.

If no photo exists, an initial/avatar is shown.

SIDEBAR
-------
The top-left software branding has been removed.
The Organization identity/logo remains at the top.

The old bottom User/Logout area now contains:
- OMS
- Organization Management ERP
- Version
- Local / LAN Management System

RESPONSIVE
----------
Desktop shows full user details.
Tablet shows a compact card.
Small mobile keeps the Member/User photo visible while hiding text to save space.

VERSION
-------
Organization Management ERP V3.9


VERSION V4.0 — PUBLIC ORGANIZATION WEBSITE + ERP LOGIN
=======================================================
A complete public-facing organization website has been added without removing the existing ERP.

PUBLIC WEBSITE
--------------
Opening:
  http://localhost:3000

now shows the public organization website.

The public website includes:
- Organization branding / logo
- About / Objective / Area of Operation
- Public Member Services overview
- Governance & Accountability overview
- Financial Transparency overview
- Public Social Work / Programs
- Public Notices
- Upcoming Events
- Contact / Office information
- Responsive mobile navigation
- Secure Login buttons

ERP LOGIN
---------
Clicking any Login / Open Management Login button opens:

  http://localhost:3000/erp.html

The original Organization Management ERP remains available there.

FIRST-TIME SETUP
----------------
If the system is not configured yet:
- Public Website still opens normally
- Login opens ERP first-time setup
- After setup, Organization Name / Objective / Contact / Logo automatically appear on the public website

DYNAMIC PUBLIC INFORMATION
--------------------------
The public page safely reads selected data from the existing ERP database.

Public Organization fields:
- Organization Name
- Establishment Date
- Registration No.
- Office / Registered Address
- Phone
- Email
- Objective
- Area of Operation
- Organization Logo

Public aggregate statistics:
- Active Member count
- Upcoming Event count
- Completed Social Program count
- Public Notice count

PUBLIC NOTICES
--------------
Only notices with:
- Status = Published
- Audience = All Members
- Current date within Publish From / Publish Until

are shown on the public website.

Private / Active Members / Committee Members / Specific Member notices are NOT exposed publicly.

PUBLIC EVENTS
-------------
Only non-cancelled upcoming events are shown publicly.

PUBLIC SOCIAL PROGRAMS
----------------------
Recent non-cancelled Social Work programs can be shown with:
- Program Name / Type
- Date
- Location
- Beneficiary Count
- Status
- Description

PRIVACY / SECURITY
------------------
The public website does NOT expose:
- PAN / TAN
- Bank Account Number
- IFSC / UPI
- Member personal records
- Member dues
- Loan / Welfare case details
- Internal financial balances
- Audit Log
- User accounts / permissions
- Private documents

All management and member-specific data continue to require ERP login and RBAC permissions.

PUBLIC LOGO
-----------
A dedicated read-only public logo endpoint displays the Organization Master logo.
Other uploaded files remain protected behind authenticated access.

ERP SHORTCUT
------------
Inside the ERP header, a "Public Website" shortcut returns to the public homepage.

DESIGN
------
The public website follows the same visual language as the ERP:
- Navy / blue identity
- Clean white cards
- Soft neutral backgrounds
- Rounded modern components
- Responsive desktop / tablet / mobile design
- Consistent Organization Management branding

START_WINDOWS
-------------
START_WINDOWS.bat now:
1. Starts the local server
2. Waits for server readiness
3. Opens the Public Website at http://localhost:3000

ERP Login remains one click away.

VERSION
-------
Organization Management ERP V4.0

VERSION V4.2 — PUBLIC WEBSITE READABILITY UPDATE
=================================================
Public Website text visibility has been improved.

Changes:
- Larger Header / Navigation text
- Stronger text contrast
- Larger Hero heading and paragraph
- More readable Member Services cards
- Clearer Governance descriptions
- Larger Program, Notice and Event text
- Larger Contact information
- Larger Footer text
- Better mobile readability
- Stronger card border contrast

ERP functionality remains unchanged.

VERSION
-------
Organization Management ERP V4.2


VERSION V4.2 — FULL ENGLISH WEBSITE & ERP UI
=============================================
All built-in/static Bengali interface text has been removed from both the Public Website and the ERP interface.

PUBLIC WEBSITE
--------------
- Navigation, Hero, About, Services, Governance, Programs, Notices, Events, Contact, CTA and Footer are English-only.

ERP INTERFACE
-------------
- Dashboard, Member Portal, Organization Master, Committee, Meeting, Approval, Subscription, Donation, Income, Expense, Cash & Bank, Accounting, Welfare, Loan, Fund Allocation, Notice, Social Work, Assets, Security and Settings static guidance is English-only.

USER-ENTERED DATA
-----------------
Organization names, member names, addresses, objectives, notices, event descriptions and other user-entered records are displayed exactly as entered. The software does not automatically translate user data.

VERSION
-------
Organization Management ERP V4.2


VERSION V4.3 — LOGIN PAGE IMAGE SLIDER + SUPER ADMIN CONTROL
=============================================================
The ERP login screen has been redesigned.

NEW LOGIN PAGE LAYOUT
---------------------
Desktop layout now uses:
- Left Side: Image Slider
- Right Side: Login / First-Time Setup panel

This follows the requested split-screen style while keeping the overall clean and modern design language.

LOGIN SLIDER
------------
The left side of the ERP login page now shows a rotating image slider.

Features:
- Multiple slider images supported
- Auto-slide rotation
- Previous / Next arrow controls
- Slide indicator dots
- Slide title and caption text
- Built-in fallback slides if no custom image is uploaded

SUPER ADMIN CONTROL
-------------------
A new Login Page Image Slider management area has been added to:

  Super Admin Settings

Super Admin can:
- Upload multiple slider images
- Add a Slide Title
- Add a Short Caption
- Delete uploaded slider images

Supported image types:
- PNG
- JPG / JPEG
- WEBP

Public read-only endpoints safely serve the slider images to the ERP login page.

RECOMMENDED IMAGE SIZE
----------------------
For best appearance:
- 1600 × 900
- Or any wide 16:9 image

ERP FUNCTIONALITY
-----------------
All existing ERP modules remain unchanged.

PUBLIC WEBSITE
--------------
Public Website remains available at:
  http://localhost:3000

ERP Login remains available at:
  http://localhost:3000/erp.html

VERSION
-------
Organization Management ERP V4.3


VERSION V4.4 — COLORFUL PREMIUM PUBLIC WEBSITE UI
==================================================
The Public Website now uses a more colorful, premium and modern visual system.

Improvements:
- Gradient navigation hover effects
- Premium gradient Login button
- Enhanced colorful Hero section
- Gradient highlighted Hero heading
- Color-coded Member Service cards
- Colorful Stats section
- Enhanced Governance and Financial Transparency panels
- Improved Program / Social Work cards
- Better Notice and Event presentation
- Gradient Contact section
- Premium CTA and Footer
- Better shadows, hover effects and mobile presentation

All ERP functionality, privacy rules and data behavior remain unchanged.

VERSION
-------
Organization Management ERP V4.4


VERSION V4.5 — PUBLIC CSC CENTRE FINDER + 70/30 IMAGE SLIDER
=============================================================

PUBLIC WEBSITE TOP LAYOUT
-------------------------
The main Public Website section is now:

Left 70%
- Large multiple-photo image slider
- Auto rotation
- Previous / Next controls
- Slide indicator dots
- Slide title and caption
- Member / Management Login button

Right 30%
- Find CSC Centre panel
- Public CSC VLE directory

CSC CENTRE FINDER FILTERS
-------------------------
Visitors can filter by:
- VLE / Member Name
- CSC Centre Name
- CSC ID
- Area / Locality
- Block
- District
- PIN Code
- Centre Address
- Public Contact
- Service keywords

The visible filter controls include:
- Search
- Block
- District

CSC CENTRE DETAILS
------------------
Each result starts as a compact CSC Centre card.

Click the card to display:
- VLE Name
- Member ID
- CSC Centre Name
- CSC ID
- Centre Address
- Area / Block / District / State / PIN
- Landmark
- Public Centre Phone
- Public Centre Email
- Services / Notes

Quick actions:
- Call Centre
- Email
- Open Location in Google Maps

PUBLIC PRIVACY CONTROL
----------------------
Member profiles now have a dedicated:

  Show in Public CSC Centre Finder

checkbox.

A member is shown publicly only when:
- Member Status = Active
- Show in Public CSC Centre Finder = Enabled

Only CSC Centre fields are exposed publicly.

The system does NOT publish:
- Personal home address
- Date of birth
- Father / spouse
- Emergency contact
- Member financial information
- Subscription due
- Donations
- Welfare
- Loans
- Nominees
- Internal documents

CSC VLE PROFILE FIELDS
----------------------
Member profile now supports:
- CSC Centre Name
- CSC ID
- Centre Contact Number
- Centre Email
- Area / Locality
- Block
- District
- State
- PIN Code
- Landmark
- Full CSC Centre Address
- Services / Notes
- Public CSC Finder visibility toggle

PUBLIC WEBSITE SLIDER MANAGEMENT
--------------------------------
Super Admin Settings now also contains:

  Public Website Image Slider

Super Admin can:
- Upload multiple public website photos
- Add slide title
- Add slide caption
- Delete slide images

Supported:
- PNG
- JPG / JPEG
- WEBP
- Up to 8 MB per image

Recommended image size:
- 1600 × 900 or wider

VERSION
-------
Organization Management ERP V4.5


VERSION V4.6 — FULL WIDTH + LARGER READABLE PUBLIC UI
======================================================
The Public Website has been adjusted based on large desktop screen review.

MAIN FIXES
----------
1. Reduced unused left/right whitespace.
2. Increased global site width from the previous narrow centered layout.
3. Enlarged Header, Navigation and Login button text.
4. Enlarged 70% Image Slider area.
5. Enlarged CSC Centre Finder panel.
6. Increased Finder input, filter, result and detail text sizes.
7. Increased Hero title, caption and action button sizes.
8. Enlarged Stats numbers and labels.
9. Enlarged About, Member Services, Governance, Programs, Updates and Contact text.
10. Increased card spacing and visual density so the screen is better filled.

DESKTOP WIDTH
-------------
The Public Website now uses a much wider maximum canvas on large desktop displays.

The 70/30 layout uses more horizontal space and better fills 1440p / 1080p desktop screens.

RESPONSIVE
----------
Tablet and mobile layouts remain responsive.
On smaller screens, the 70/30 layout automatically stacks vertically.

VERSION
-------
Organization Management ERP V4.6


VERSION V4.7 — CSC LOGO ADDED TO PUBLIC FINDER
===============================================
The Public Website CSC Centre Finder card now shows the uploaded CSC logo on the left side of the finder header.

UPDATED AREA
------------
Right-side Public CSC Directory / Find CSC Centre panel:
- Left icon replaced with CSC logo
- Logo stored locally inside website assets
- Desktop and mobile responsive sizing applied

VERSION
-------
Organization Management ERP V4.7


VERSION V4.8 — PHOTO ONLY SLIDER (1, 2, 3 SERIAL ORDER)
========================================================

PUBLIC WEBSITE SLIDER UPDATE
----------------------------
The left-side Public Website slider has been updated with the 3 provided images in serial order:

1. Slider 1
2. Slider 2
3. Slider 3

PHOTO ONLY MODE
---------------
The Public Website slider now shows:
- Only photos
- No text
- No button
- No link

The slider navigation controls remain available for switching photos.

IMAGE SOURCE
------------
The three provided images are stored locally in:
- public/assets/public-slider-1.png
- public/assets/public-slider-2.png
- public/assets/public-slider-3.png

These are used as the default Public Website slider images.

RIGHT SIDE
----------
The right-side Find CSC Centre panel remains unchanged.

VERSION
-------
Organization Management ERP V4.8


VERSION V4.9 — CSC DIGITAL YODDHA ORGANIZATION PROFILE
=======================================================

PUBLIC ORGANIZATION INFORMATION
-------------------------------
Organization:
CSC Digital Yoddha

Office Address:
Panskura, Purba Medinipur

Phone:
8001300092
8900255364
9734673867
9733114561

Email:
Not specified

Area of Operation:
Panskura

PUBLIC WEBSITE BEHAVIOUR
------------------------
These values are used as the default Public Website organization/contact profile.

If the same fields are later entered in:
Organization Master

the ERP Organization Master values take priority over these defaults.

The Public Website Call button uses the first listed number:
8001300092

VERSION
-------
Organization Management ERP V4.9


VERSION V5.0 — ABOUT ORGANIZATION VISUAL BANNER
================================================
The uploaded "Digital Village Through CSC VLE" artwork is now used as the main visual banner in the About the Organization section.

About section layout:
- About heading and organization introduction
- Full-width 4:1 CSC visual banner
- Organization Profile card
- Digital Service Access / Community Support / Transparent Organization principles

Image:
public/assets/about-organization-banner.png

VERSION
-------
Organization Management ERP V5.0


VERSION V5.1 — COMPLETE ABOUT ORGANIZATION CONTENT
===================================================

The About the Organization section now contains the complete CSC Digital Yoddha organization description supplied by the organization.

CONTENT INCLUDED
----------------
- Organization introduction
- CSC VLE unity and professional-development purpose
- Knowledge and CSC project/service sharing
- Operational support for VLEs
- Digital and government service improvement
- Social welfare
- Digital awareness
- Community development
- Transparency and mutual support

OUR VISION
----------
To build a united, transparent and empowered network of CSC VLEs that contributes to digital inclusion and the development of society.

OUR MISSION
-----------
- Strengthen unity and cooperation among CSC VLEs
- Guide and support new and existing VLEs
- Share CSC projects, services and opportunities
- Identify and connect VLEs across block and municipal areas
- Improve digital and government service quality
- Conduct social-welfare and public-awareness programmes
- Encourage transparency, accountability and collective growth

The existing About visual banner remains in place.

VERSION
-------
Organization Management ERP V5.1


VERSION V5.2 — VISION MORE VISIBLE + MISSION 2 COLUMNS
=======================================================

ABOUT SECTION IMPROVEMENT
-------------------------
The Vision and Mission area has been redesigned for better readability.

Updated:
- Our Vision heading increased in size
- Our Vision paragraph increased in size
- Our Mission heading increased in size
- Mission points increased in size
- Mission points now display in 2 columns on desktop/laptop
- Mission points collapse to 1 column on mobile/tablet

VERSION
-------
Organization Management ERP V5.2


VERSION V5.3 — MEMBER BENEFITS SECTION
=======================================
A new Member Benefits section has been added to the Public Website.

BENEFITS INCLUDED
-----------------
1. Unity & Mutual Cooperation
2. Support in Problem Solving
3. Regular Information & Updates
4. Knowledge & Experience Sharing
5. Emergency Financial Assistance
6. Member Welfare Fund
7. Training & Skill Development
8. Events & Networking
9. Participation in Social Work
10. Transparent Accounts & Management
11. Participation in Opinions & Decisions
12. Recognition & Appreciation
13. Long-Term Member Support

CORE MESSAGE
------------
Unity • Cooperation • Transparency • Member Welfare • Social Responsibility

The section also explains that the organization's purpose is not only membership enrollment or monthly contribution collection, but to support members, strengthen cooperation, share information and opportunities, and work collectively for social development.

DESIGN
------
- Two-column desktop layout
- Single-column mobile layout
- Color-coded benefit number badges
- Premium highlighted Core Message panel
- Member Benefits added to the Public Website navigation

VERSION
-------
Organization Management ERP V5.3


VERSION V5.4 — PUBLIC WEBSITE SECTION CLEANUP
=============================================

REMOVED FROM PUBLIC WEBSITE
---------------------------
The following sections have been completely removed:

1. Member Services
2. Governance & Accountability
3. Programs & Social Work

NAVIGATION CLEANUP
------------------
The corresponding top navigation links were also removed:
- Member Services
- Governance
- Programs

The old footer Services link was also removed.

REMAINING PUBLIC WEBSITE
------------------------
The Public Website continues to include:
- Photo Slider
- Find CSC Centre
- Statistics
- About the Organization
- Vision & Mission
- Member Benefits
- Public Notices / Upcoming Events
- Contact
- Login CTA
- Footer

ERP functionality remains unchanged.

VERSION
-------
Organization Management ERP V5.4


VERSION V5.5 — PUBLIC NEW MEMBER APPLICATION
=============================================

The previous Public Website Login CTA area has been replaced with a complete:

NEW MEMBER APPLICATION
Join Our Organization

PUBLIC APPLICATION FORM
-----------------------
Visitors can submit membership applications directly from the Public Website.

Applicant fields include:
- Full Name
- Father’s / Guardian’s Name
- Date of Birth
- Gender
- Mobile Number
- WhatsApp Number
- Email Address
- Full Address
- Occupation / Profession
- Applicant Photo
- Identity Proof Type
- Identity Proof Number
- Identity Proof File
- Membership Type
- Nominee / Emergency Contact
- Nominee Relation
- Nominee / Emergency Mobile
- Reason for Joining
- Declaration acceptance

SUPPORTED UPLOADS
-----------------
Applicant Photo:
- PNG / JPG / JPEG / WEBP
- Maximum 3 MB

Identity Proof:
- PDF / PNG / JPG / JPEG / WEBP
- Maximum 6 MB

ERP INTEGRATION
---------------
A Public Website submission is automatically created inside:

Joining Applications

with:
- APP-000001 style Application ID
- Status = Pending
- Source = Public Website
- Applicant Photo
- Identity Proof
- Complete applicant information
- Workflow history

APPLICATION PROCESS
-------------------
Application Submitted
→ Document Verification
→ Committee Review
→ Approval
→ Joining Fee Payment
→ Member ID Generated
→ Membership Activated

DECLARATION
-----------
The full supplied membership declaration is shown on the Public Website and must be accepted before submission.

IMPORTANT
---------
Submitting the Public Website application does NOT automatically activate membership.

The existing authorized workflow remains mandatory.

ERP STAFF VIEW
--------------
Joining Application detail now also shows:
- Gender
- WhatsApp
- Reason for Joining
- Identity Proof File
- Application Source

PRIVACY
-------
Uploaded Photo and Identity Proof are stored in the protected ERP uploads area.
They are not publicly downloadable.

LOGIN
-----
The top website Login button remains available.
A compact Existing Member / Management Login button is also shown beside the new application section.

VERSION
-------
Organization Management ERP V5.5


VERSION V5.6 — WHATSAPP OTP LOGIN
==================================

A complete WhatsApp OTP login module has been added.

LOGIN FLOW
----------
When WhatsApp OTP Login is enabled:

WhatsApp Number
→ Send OTP
→ OTP arrives on WhatsApp
→ Enter 6-digit OTP
→ Verify
→ Login

A fresh OTP is required for every login.

PASSWORD LOGIN
--------------
Password login remains available only while WhatsApp OTP Login is disabled.

When WhatsApp OTP Login is enabled and fully configured:
- Password login is blocked.
- Every login requires a newly generated WhatsApp OTP.

OFFICIAL API REQUIRED
---------------------
Real WhatsApp OTP delivery requires Meta WhatsApp Business Platform / Cloud API.

Super Admin Settings now includes:
- Enable WhatsApp OTP Login
- Graph API Version
- WhatsApp Phone Number ID
- Meta Access Token
- Approved Authentication Template Name
- Template Language
- Default Country Code
- OTP Expiry
- Resend Cooldown
- Maximum OTP Attempts
- Send Test OTP

Default API version:
v26.0

Default Authentication Template name:
authentication_code_copy_code_button

USER ACCOUNTS
-------------
User Role & Security now includes:
- WhatsApp Login Number

Each active user must have a unique WhatsApp Login Number before OTP Login can be enabled.

For linked General Member accounts, older records may automatically inherit the linked Member's WhatsApp / CSC Phone / Mobile if the user login number was blank.

SECURITY
--------
- OTP is 6 digits.
- OTP expires after the configured period.
- Default expiry: 10 minutes.
- Default resend cooldown: 60 seconds.
- Default maximum verification attempts: 5.
- Rate limiting is applied to OTP requests.
- OTP values are never stored in the database.
- OTP challenges are kept only in server memory and disappear on server restart.
- OTP values are never written to the audit log.
- Meta Access Token is encrypted locally using AES-256-GCM.
- Access Token is never returned to the browser after saving.
- Access Token is removed from backup exports.
- Normal sessions are created only after successful OTP verification.

INTERNET REQUIREMENT
--------------------
The ERP can continue to operate locally / over LAN, but WhatsApp OTP delivery requires internet access from the computer running server.js so it can reach Meta Cloud API.

META REQUIREMENTS
-----------------
Before real OTP can be activated, the organization needs:
- Meta Business Portfolio
- WhatsApp Business Account
- Registered WhatsApp Business phone number
- WhatsApp Phone Number ID
- Permanent/System User Access Token with required WhatsApp permissions
- Approved Authentication template with OTP Copy Code

FIRST-TIME SETUP
----------------
A WhatsApp Login Number field is available when creating the initial Super Admin.

EXISTING INSTALLATIONS
----------------------
Existing V5.5 data remains compatible.

OTP is disabled by default after upgrade.
Configure it in:
Super Admin Settings → WhatsApp OTP Login

VERSION
-------
Organization Management ERP V5.6


VERSION V5.7 — WHATSAPP OTP CONFIGURATION FIX
==============================================

This update fixes configuration problems that can cause:
"Invalid OAuth access token - Cannot parse access token"

CORRECT PHONE NUMBER ID
-----------------------
Phone Number ID must be the numeric Meta WhatsApp Phone Number ID.
Example format:
1906385232743451

Do NOT enter:
- Email address
- WhatsApp/mobile number
- WABA ID
- Meta Business ID

CORRECT META ACCESS TOKEN
-------------------------
Use the complete OAuth/System User access token from Meta.
Do not enter email/password or masked asterisks.

If Meta reports "Cannot parse access token", replace the saved token with a fresh complete token.

NEW VALIDATE META CONFIGURATION BUTTON
--------------------------------------
Super Admin Settings now includes:
Validate Meta Configuration

The ERP checks:
- Phone Number ID format
- Access Token format
- Template name format
- API version format
- Live Meta Graph API connection
- Whether the Phone Number ID is visible to the token

On success it can show:
- Verified Name
- Display WhatsApp Number
- Quality Rating

LOCKOUT PROTECTION
------------------
Invalid WhatsApp configuration is no longer considered ready.

If saved configuration is invalid:
- Password login remains available
- Invalid OTP settings do not force OTP-only login
- The exact configuration errors are displayed

When enabling WhatsApp OTP Login, live Meta configuration validation must succeed.

VERSION
-------
Organization Management ERP V5.7


VERSION V5.8 — FULL NOTICE VIEW + LATEST UPDATE AUTO POPUP
==========================================================

PUBLIC NOTICES
--------------
Every Public Notice now has a "View Full Notice" button.

The full notice popup displays:
- Priority
- Notice Number
- Date
- Full Title
- Complete Notice Content
- Attachment button when a public attachment exists

LATEST NOTICE / UPCOMING EVENT AUTO POPUP
-----------------------------------------
When the Public Website opens, it automatically checks:
- Latest active Public Notice
- Next Upcoming Event

If both exist, both are shown together in one Latest Update popup.
If only one exists, that item is shown.

The same latest Notice/Event combination is shown once per browser session.
A new latest Notice or Event generates a new popup key and will appear again.

UPCOMING EVENT DETAILS
----------------------
Event cards now include "View Event Details" with:
- Date / Date Range
- Venue
- Status
- Registration Deadline
- Full Description

SAFE POPUP BEHAVIOUR
--------------------
The popup does NOT close when clicking outside it.
It closes only through:
- X Close
- Close button

PUBLIC NOTICE ATTACHMENTS
-------------------------
A notice attachment is publicly accessible only when the notice is:
- Published
- Audience = All Members
- Inside its active Publish From / Publish Until date window

DATE FIX
--------
Public Notice visibility and Upcoming Event calculations use the Asia/Kolkata calendar date.

VERSION
-------
Organization Management ERP V5.8


VERSION V5.9 — EXPANDED CSC VLE MEMBER APPLICATION
===================================================
Built directly from the stable V5.8 Notice & Event Auto Popup version.

New Public Application fields:
- Full Name
- Father’s / Guardian’s Name
- Date of Birth
- Gender
- Mobile Number
- WhatsApp Number
- Email
- Permanent Address: Village, Post Office, Police Station, GP/Ward No., Block/Municipality, District, State, PIN, Landmark
- CSC ID
- CSC Centre Name
- Centre Address: Village, Post Office, Police Station, GP/Ward No., Block/Municipality, District, State, PIN, Landmark
- Same as Permanent Address checkbox
- Applicant Photo with 3.5 × 4.5 cm guidance
- Aadhaar Card No. + protected upload
- PAN Card No. + protected upload
- Voter Card No. + protected upload
- Nominee / Emergency Contact
- Declaration

Aadhaar, PAN, Voter Card and applicant photo are protected ERP uploads and are not publicly exposed.
After activation, CSC ID and Centre information are carried to the Member record.

VERSION V5.12 — COMPACT JOIN US + MODAL WIZARD
===============================================
Rebuilt directly from stable V5.9.
The visible Join section is now compact and contains only Join Us and Existing Member Login.
The full six-step membership application exists only inside the modal popup.


VERSION V5.13 — UNIFIED MEMBERSHIP APPLICATION FORM
====================================================

The internal Organization Management ERP Membership Application form now uses the same field structure as the Public CSC VLE Membership Application.

PERSONAL INFORMATION
- Full Name
- Father’s / Guardian’s Name
- Date of Birth
- Gender
- Mobile Number
- WhatsApp Number
- Email

PERMANENT ADDRESS
- Village
- Post Office
- Police Station
- GP / Ward No.
- Block / Municipality
- District
- State
- PIN Code
- Address / Landmark

CSC CENTRE INFORMATION
- CSC ID
- CSC Centre Name
- Same as Permanent Address
- Village
- Post Office
- Police Station
- GP / Ward No.
- Block / Municipality
- District
- State
- PIN Code
- Centre Address / Landmark

PHOTO & KYC
- Applicant Photo (3.5 x 4.5 cm guidance)
- Aadhaar Card No. + Upload
- PAN Card No. + Upload
- Voter Card No. + Upload

NOMINEE / EMERGENCY CONTACT
- Name
- Relation
- Mobile
- WhatsApp
- Address

DECLARATION
- Mandatory

DATA CONSISTENCY
----------------
Public Website applications and Internal ERP applications now create the same application fields and protected KYC document structure.

This removes data mismatch during:
Document Verification -> Committee Review -> Approval -> Payment -> Member Activation.

VERSION
-------
Organization Management ERP V5.13

VERSION V5.14 — FLEXIBLE INTERNAL / STRICT PUBLIC APPLICATION
==============================================================
ERP Internal New Application mandatory fields only:
- Full Name
- Gender
- Mobile Number
- Email ID

All other profile, address, CSC, KYC, nominee and declaration information may be added later by an authorized Admin.

Public Website Self Application remains strict. All fields and uploads marked mandatory on the website must still be completed before submission.


VERSION V5.15 — INTERNAL OPTIONAL FIELDS UI FIX
================================================

ISSUE FIXED
-----------
V5.14 backend accepted only four mandatory Internal ERP fields, but the Internal Membership Application UI still displayed some optional fields with * and retained a few HTML required attributes.

INTERNAL ERP — ONLY MANDATORY
-----------------------------
- Full Name
- Gender
- Mobile Number
- Email ID

INTERNAL ERP — OPTIONAL
-----------------------
- Father’s / Guardian’s Name
- Date of Birth
- WhatsApp Number
- Permanent Address (all fields)
- CSC ID / CSC Centre Name
- CSC Centre Address (all fields)
- Applicant Photo
- Aadhaar Number / Upload
- PAN Number / Upload
- Voter Number / Upload
- Nominee / Emergency Contact (all fields)
- Declaration

All optional fields can be completed later by an authorized Admin.

PUBLIC WEBSITE
--------------
Public Website Self Application remains strict and unchanged.
All fields/uploads marked mandatory in the Public Website form must still be completed.

VERSION
-------
Organization Management ERP V5.15


VERSION V5.16 — MEMBER-BASED ROLE USER CREATION
================================================

USER ROLE & SECURITY
--------------------
Add User now follows this flow:

  Select Member -> Select User Role -> Create User

MEMBER SELECTION
----------------
Only Active Members are available for new user creation.

After selecting a Member:
- Name auto-fills
- Email auto-fills
- WhatsApp Login Number auto-fills
- Member ID is linked to the user account

ROLE SELECTION
--------------
Available roles:
- Super Admin
- President
- Secretary
- Treasurer
- Committee Member
- General Member

The selected role determines server-side access permissions.

LINKING RULES
-------------
- Every newly created role-based user is linked to a Member ID.
- One Member cannot have multiple Active linked user accounts.
- Only one Active Super Admin is allowed.
- Login Email must be unique.
- WhatsApp Login Number must be unique when supplied.
- Password minimum 6 characters.

GENERAL MEMBER
--------------
General Member remains limited to the linked Member's own portal.

VERSION
-------
Organization Management ERP V5.16


VERSION V5.17 — ADD USER BUTTON FIX
====================================
Fixed User Role & Security -> + Add User.

ROOT CAUSE
----------
V5.16 openUserForm() referenced the wrong modal/close identifiers:
- Wrong: #userModal
- Actual: #userFormModal

and:
- Wrong: closeUserModal()
- Actual: closeUserForm()

FIX
---
- openUserForm() now opens #userFormModal
- Cancel/Create/Edit use closeUserForm()
- openUserForm exported to window for inline onclick
- Add User button given a stable id and click fallback
- Existing Select Member -> Select Role -> Create User flow preserved


VERSION V5.18 — DEFAULT PASSWORD & PASSWORD CHANGE
===================================================
NEW ROLE-BASED USERS
- Default password is automatically: cscvle
- Admin no longer needs to type a temporary password when creating a user.
- New users are marked as using the default password.

USER SELF-SERVICE
- Any logged-in user can open Password from the top-right user area.
- Current Password + New Password + Confirm Password required.
- Minimum 6 characters.
- After successful change, default-password flag is cleared.

ADMIN RESET
- Super Admin can edit a user and set a new password.
- Admin password reset invalidates that user's existing sessions.
- After Admin reset, the user is marked to change password again.

SECURITY FIX
- Migrates legacy passwordSalt to salt for V5.16/V5.17-created users.
- New users now save the password salt in the correct field.


VERSION V5.19 — STANDARD DATE & TIME FORMAT
=============================================
Display formatting standardized across the ERP and Public Website.

Date display: DD-MM-YYYY
Example: 09-09-2026

Time display: HH:MM:SS AM/PM
Example: 10:25:30 PM

Important: Database dates/timestamps remain stored in ISO format for reliable sorting, filtering, financial-year logic and audit integrity. Only user-facing display, reports, audit timestamps and print output are formatted. Native HTML date inputs continue using YYYY-MM-DD internally because browsers require that machine format.

VERSION V5.20 — CURRENT MONTH DEFAULT SUBSCRIPTION VIEW
=======================================================
Monthly Subscription Management now opens with the current local month selected by default.

Examples:
- September 2026 -> September 2026
- October 2026 -> October 2026
- January 2027 -> January 2027

The current month is calculated from the Windows/browser local date.
Manual month selection continues to work normally.


VERSION V5.21 — RECEIPT CONTACT REMOVAL
========================================
Payment Receipt header no longer prints the organization Phone / Email line.
Removed from receipt display only; organization contact information elsewhere is unchanged.
