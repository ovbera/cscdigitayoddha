# Organization Management ERP V5.21 — Railway-এ Live করার নির্দেশিকা

এই package-টি Railway deployment-এর জন্য প্রস্তুত। বর্তমান database এবং uploads প্রথম deployment-এ persistent volume-এ স্বয়ংক্রিয়ভাবে copy হবে। পরের deployment-এ volume-এর existing data overwrite হবে না।

## খুব গুরুত্বপূর্ণ

এই project-এর `data/database.json` এবং `data/uploads/`-এ ব্যক্তিগত ও confidential data থাকতে পারে। তাই GitHub repository অবশ্যই **Private** রাখবেন। Public repository-তে এই files upload করবেন না। পুরোনো local encryption key নিরাপত্তার জন্য এই deployment package-এ রাখা হয়নি।

## Railway deployment

1. ZIP extract করুন।
2. Extract করা files একটি **Private GitHub repository**-তে push করুন।
3. [Railway](https://railway.com/) খুলে `New Project` → `Deploy from GitHub repo` নির্বাচন করুন।
4. আপনার private repository select করুন। Railway `package.json` থেকে সাধারণত `npm start` নিজে detect করবে। Detect না হলে service-এর deployment settings-এ Start Command দিন `npm start`।
5. Deployment settings-এ Healthcheck Path দিন `/healthz` এবং timeout দিন `120` seconds।
6. Service-এর `Variables`-এ যোগ করুন:

   ```text
   NODE_ENV=production
   ERP_DATA_DIR=/app/storage
   WA_OTP_TEST_MODE=0
   ```

7. Service-এর `Volumes` থেকে একটি volume add করে mount path দিন:

   ```text
   /app/storage
   ```

8. `Settings` → `Networking` → `Generate Domain` করুন। পাওয়া HTTPS URL-ই ERP-এর live address।
9. Deployment logs-এ `Organization Management System is running` এবং `Persistent ERP data directory: /app/storage` দেখা গেলে deployment সফল।
10. Browser-এ `https://YOUR-DOMAIN/healthz` খুললে `{"ok":true,"version":"V5.21"}` দেখা যাবে।

## First login-এর পরে

- সব administrator/user password বদলে দিন।
- WhatsApp OTP settings-এ access token নতুন করে paste/save করে connection test করুন। পুরোনো token-এর encryption key production package-এ ইচ্ছাকৃতভাবে রাখা হয়নি।
- `WA_OTP_TEST_MODE` কখনো production-এ `1` করবেন না—এতে OTP response-এ দেখা যায়।
- Railway volume-এর নিয়মিত backup রাখুন। ERP-এর `Backup` menu থেকে JSON backup-ও download করুন।

## Custom domain

Railway-এর `Settings` → `Networking` → `Custom Domain`-এ domain যোগ করুন। Railway যে CNAME target দেখাবে, domain provider-এর DNS panel-এ সেই record বসান। HTTPS certificate Railway স্বয়ংক্রিয়ভাবে চালু করবে।

## Troubleshooting

- `Application failed to respond`: Variables-এ `ERP_DATA_DIR=/app/storage` আছে কি না এবং volume-এর mount path একই কি না দেখুন।
- Login cookie কাজ করছে না: `NODE_ENV=production` আছে এবং generated/custom HTTPS domain ব্যবহার করছেন কি না দেখুন।
- পুরোনো data দেখা যাচ্ছে না: প্রথম deployment-এর আগে volume একদম empty ছিল কি না দেখুন। Volume-এ `database.json` আগে থেকে থাকলে bundled database overwrite করা হয় না।
- WhatsApp OTP fail: ERP-এর WhatsApp settings-এ Phone Number ID, access token, approved template name/language এবং Meta permissions যাচাই করুন।

## Local test

Node.js 20 বা 22 দিয়ে:

```bash
npm start
```

তারপর `http://localhost:3000` খুলুন। Local mode-এ existing `data/` folder ব্যবহার হবে।
