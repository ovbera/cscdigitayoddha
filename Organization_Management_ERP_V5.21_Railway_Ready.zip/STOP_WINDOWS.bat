@echo off
title Stop Organization Management System
echo Closing Node.js local server processes...
taskkill /IM node.exe /F >nul 2>nul
echo Done.
pause
